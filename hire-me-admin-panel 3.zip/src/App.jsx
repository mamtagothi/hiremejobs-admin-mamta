// import { Provider } from 'react-redux'
// import { Toaster } from 'react-hot-toast'
// import { store } from './redux/store'
// import { AuthProvider } from './context/AuthContext'
// import AppRoutes from './routes/AppRoutes'

// function App() {
//   return (
//     <Provider store={store}>
//       <AuthProvider>
//         <AppRoutes />
//         <Toaster
//           position="top-right"
//           toastOptions={{
//             duration: 3000,
//             style: { fontSize: '14px', fontFamily: 'Inter, sans-serif' },
//           }}
//         />
//       </AuthProvider>
//     </Provider>
//   )
// }

// export default App

import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { Provider } from 'react-redux'
import { Toaster } from 'react-hot-toast'
import { store } from './redux/store'
import { AuthProvider } from './context/AuthContext'
import AppRoutes from './routes/AppRoutes'

// ─── Create a single QueryClient for the app ───────────────────
// Configured once at module scope so it survives re-renders and
// is shared by every component that calls useQuery/useMutation.
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Data is considered fresh for 30s — inside that window,
      // duplicate requests are served from cache without hitting
      // the network. Tune per-query with `staleTime` if needed.
      staleTime: 30 * 1000,

      // Keep unused cache entries around for 5 minutes before
      // garbage collection. Speeds up back-navigation.
      gcTime: 5 * 60 * 1000,

      // Don't refetch on window focus — quiet admin panels don't
      // need the network chatter. Enable per-query if needed.
      refetchOnWindowFocus: false,

      // Only retry once on failure (instead of the default 3).
      retry: 1,

      // Show cached data while a fresh fetch is in flight —
      // no flashing empty states during refetches.
      refetchOnMount: true,
      refetchOnReconnect: true,
    },
    mutations: {
      // Mutations retry once on transient failures.
      retry: 1,
    },
  },
})

function App() {
  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <AppRoutes />
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 3000,
              style: { fontSize: '14px', fontFamily: 'Inter, sans-serif' },
            }}
          />
        </AuthProvider>

        {/* Devtools — only visible in development builds.
            Auto-excluded from production by the package itself. */}
        <ReactQueryDevtools initialIsOpen={false} position="bottom" />
      </QueryClientProvider>
    </Provider>
  )
}

export default App