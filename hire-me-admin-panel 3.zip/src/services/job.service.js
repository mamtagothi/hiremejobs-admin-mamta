// import api from './api'

// // Build a query string from a plain object, ignoring empty values.
// const buildQuery = (params = {}) => {
//   const entries = Object.entries(params).filter(
//     ([, v]) => v !== undefined && v !== null && v !== "",
//   );
//   if (entries.length === 0) return "";
//   return "?" + new URLSearchParams(entries).toString();
// };

// const jobService = {
//   // ⭐ Bulletproof: the page/limit/search go INTO the URL itself,
//   // so there is no way for axios config handling to drop them.
//   getAll: (params = {}) => api.get(`/jobs${buildQuery(params)}`),
//   getById: (id) => api.get(`/jobs/${id}`),
//   create: (data) => api.post('/jobs', data),
//   update: (id, data) => {
//     return api.put(`/jobs/${id}`, data).catch((err) => {
//       if (err.response?.status === 404 || err.response?.status === 405) {
//         return api.patch(`/jobs/${id}`, data)
//       }
//       throw err
//     })
//   },
//   delete: (id) => api.delete(`/jobs/${id}`),
//   deleteJobBenefits: (jobId) => api.delete(`/jobs/${jobId}/benefits`),
//   deleteWithRelations: async (id) => {
//     try {
//       await api.delete(`/jobs/${id}/benefits`);
//     } catch (e) {
//       // Ignore if no benefits
//     }
//     return api.delete(`/jobs/${id}`);
//   },
// }

// const companyService = {
//   getAll: (params = {}) => api.get(`/companies${buildQuery(params)}`),
//   getById: (id) => api.get(`/companies/${id}`),
//   getActiveWithSubscription: () => api.get('/companies/active-with-subscription'),
// }

// const jobTypeService = {
//   getAll: (params = {}) => api.get(`/job-types${buildQuery(params)}`),
//   getById: (id) => api.get(`/job-types/${id}`),
// }

// const workplaceTypeService = {
//   getAll: (params = {}) => api.get(`/workplace-types${buildQuery(params)}`),
//   getById: (id) => api.get(`/workplace-types/${id}`),
// }

// const functionRoleService = {
//   getAll: (params = {}) => api.get(`/function-roles${buildQuery(params)}`),
//   getById: (id) => api.get(`/function-roles/${id}`),
// }

// export default jobService
// export {
//   companyService,
//   jobTypeService,
//   workplaceTypeService,
//   functionRoleService,
// }

import api from './api'

// Build a query string from a plain object, ignoring empty values.
const buildQuery = (params = {}) => {
  const entries = Object.entries(params).filter(
    ([, v]) => v !== undefined && v !== null && v !== "",
  );
  if (entries.length === 0) return "";
  return "?" + new URLSearchParams(entries).toString();
};

const jobService = {
  // The query string is written directly into the URL — no chance
  // of axios silently dropping `page` from a config object.
  getAll: (params = {}) => api.get(`/jobs${buildQuery(params)}`),
  getById: (id) => api.get(`/jobs/${id}`),
  create: (data) => api.post('/jobs', data),
  update: (id, data) => {
    return api.put(`/jobs/${id}`, data).catch((err) => {
      if (err.response?.status === 404 || err.response?.status === 405) {
        return api.patch(`/jobs/${id}`, data)
      }
      throw err
    })
  },
  delete: (id) => api.delete(`/jobs/${id}`),
  deleteJobBenefits: (jobId) => api.delete(`/jobs/${jobId}/benefits`),
  deleteWithRelations: async (id) => {
    try {
      await api.delete(`/jobs/${id}/benefits`);
    } catch (e) {
      // Ignore if no benefits
    }
    return api.delete(`/jobs/${id}`);
  },
}

const companyService = {
  getAll: (params = {}) => api.get(`/companies${buildQuery(params)}`),
  getById: (id) => api.get(`/companies/${id}`),
  getActiveWithSubscription: () => api.get('/companies/active-with-subscription'),
}

const jobTypeService = {
  getAll: (params = {}) => api.get(`/job-types${buildQuery(params)}`),
  getById: (id) => api.get(`/job-types/${id}`),
}

const workplaceTypeService = {
  getAll: (params = {}) => api.get(`/workplace-types${buildQuery(params)}`),
  getById: (id) => api.get(`/workplace-types/${id}`),
}

const functionRoleService = {
  getAll: (params = {}) => api.get(`/function-roles${buildQuery(params)}`),
  getById: (id) => api.get(`/function-roles/${id}`),
}

export default jobService
export {
  companyService,
  jobTypeService,
  workplaceTypeService,
  functionRoleService,
}