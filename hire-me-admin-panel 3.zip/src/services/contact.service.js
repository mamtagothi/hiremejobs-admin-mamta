


// import api from './api';

// const API_URL = '/contact-us';

// export const contactService = {
//     // Get all contacts with pagination and filters
//     getAll: async (params = {}) => {
//         const response = await api.get(API_URL, { params });
//         return response.data;
//     },

//     // Get single contact by ID
//     getById: async (id) => {
//         const response = await api.get(`${API_URL}/${id}`);
//         return response.data;
//     },


//     getByRole: async (role, params = {}) => {
//         const response = await api.get(`${API_URL}/role/${role}`, { params });
//         return response.data;
//     },

//     // Update contact
//     // update: async (id, data) => {
//     //     const response = await api.put(`${API_URL}/${id}`, data);
//     //     return response.data;
//     // },

//     update: async (id, data) => {
//         console.log('UPDATE ID:', id);
//         console.log('UPDATE URL:', `${API_URL}/contact-us/${id}`);
//         console.log('UPDATE DATA:', data);

//         const response = await api.patch(
//             `${API_URL}/${id}`,
//             data
//         );

//         return response.data;
//     },

//     assign: async (id, userId) => {
//         const response = await api.patch(
//             `${API_URL}/${id}`,
//             {
//                 assigned_to: userId,
//             }
//         );

//         return response.data;
//     },

//     // Delete contact
//     delete: async (id) => {
//         const response = await api.delete(`${API_URL}/${id}`);
//         return response.data;
//     },

//     // Update contact status
//     updateStatus: async (id, status) => {
//         const response = await api.patch(`${API_URL}/${id}/status`, { status });
//         return response.data;
//     },

//     // Assign contact to admin
//     // assign: async (id, adminId) => {
//     //     const response = await api.patch(`${API_URL}/${id}/assign`, { assigned_to: adminId });
//     //     return response.data;
//     // },

//     // Add admin remarks
//     addRemarks: async (id, remarks) => {
//         const response = await api.patch(`${API_URL}/${id}/remarks`, { admin_remarks: remarks });
//         return response.data;
//     },

//     // Resolve contact
//     resolve: async (id) => {
//         const response = await api.patch(`${API_URL}/${id}/resolve`);
//         return response.data;
//     }
// };

const API_BASE = import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

// ─── Helper: Get auth token ─────────────────────────────────────
const getAuthToken = () => {
  return localStorage.getItem("token");
};

// ─── Helper: Handle API responses ──────────────────────────────
const handleResponse = async (response) => {
  const responseData = await response.json().catch(() => ({}));

  if (!response.ok) {
    console.error("API Error Response:", {
      status: response.status,
      statusText: response.statusText,
      data: responseData,
    });

    let errorMessage =
      responseData.message ||
      responseData.error ||
      `HTTP error ${response.status}`;

    if (responseData.errors) {
      if (typeof responseData.errors === "object") {
        const errorDetails = Object.entries(responseData.errors)
          .map(
            ([field, errors]) =>
              `${field}: ${Array.isArray(errors) ? errors.join(", ") : errors}`,
          )
          .join("; ");
        errorMessage = `Validation failed: ${errorDetails}`;
      } else {
        errorMessage = `Validation failed: ${responseData.errors}`;
      }
    }

    if (responseData.data && typeof responseData.data === "object") {
      const fieldErrors = Object.entries(responseData.data)
        .filter(([_, value]) => value && typeof value === "string")
        .map(([field, error]) => `${field}: ${error}`)
        .join("; ");
      if (fieldErrors) {
        errorMessage = `Validation failed: ${fieldErrors}`;
      }
    }

    throw {
      status: response.status,
      message: errorMessage,
      data: responseData,
    };
  }

  return responseData;
};

// ─── Helper: Build headers ──────────────────────────────────────
const getHeaders = (isFormData = false) => {
  const token = getAuthToken();
  const headers = {
    Accept: "application/json",
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  if (!isFormData) {
    headers["Content-Type"] = "application/json";
  }

  return headers;
};

// ─── Contact Service ─────────────────────────────────────────────
const API_URL = "/contact-us";

export const contactService = {
  // ─── Get all contacts (paginated via query string) ─────────────
  // Usage: contactService.getAll({ page: 2, limit: 20, status: "pending" })
  // Produces: /contact-us?page=2&limit=20&status=pending
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    const url = `${API_BASE}${API_URL}${queryString ? `?${queryString}` : ""}`;

    const response = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Get single contact by ID ──────────────────────────────────
  getById: async (id) => {
    const url = `${API_BASE}${API_URL}/${id}`;

    const response = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Get contacts by role (paginated) ──────────────────────────
  getByRole: async (role, params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    const url = `${API_BASE}${API_URL}/role/${role}${
      queryString ? `?${queryString}` : ""
    }`;

    const response = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Update contact ────────────────────────────────────────────
  update: async (id, data) => {
    console.log("UPDATE ID:", id);
    console.log("UPDATE URL:", `${API_BASE}${API_URL}/${id}`);
    console.log("UPDATE DATA:", data);

    const isFormData = data instanceof FormData;
    const url = `${API_BASE}${API_URL}/${id}`;

    const response = await fetch(url, {
      method: "PATCH",
      headers: getHeaders(isFormData),
      body: isFormData ? data : JSON.stringify(data),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Assign contact to a user ──────────────────────────────────
  assign: async (id, userId) => {
    const url = `${API_BASE}${API_URL}/${id}`;

    const response = await fetch(url, {
      method: "PATCH",
      headers: getHeaders(),
      body: JSON.stringify({ assigned_to: userId }),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Delete contact ────────────────────────────────────────────
  delete: async (id) => {
    const url = `${API_BASE}${API_URL}/${id}`;

    const response = await fetch(url, {
      method: "DELETE",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Update contact status ─────────────────────────────────────
  updateStatus: async (id, status) => {
    const url = `${API_BASE}${API_URL}/${id}/status`;

    const response = await fetch(url, {
      method: "PATCH",
      headers: getHeaders(),
      body: JSON.stringify({ status }),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Add admin remarks ─────────────────────────────────────────
  addRemarks: async (id, remarks) => {
    const url = `${API_BASE}${API_URL}/${id}/remarks`;

    const response = await fetch(url, {
      method: "PATCH",
      headers: getHeaders(),
      body: JSON.stringify({ admin_remarks: remarks }),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Resolve contact ───────────────────────────────────────────
  resolve: async (id) => {
    const url = `${API_BASE}${API_URL}/${id}/resolve`;

    const response = await fetch(url, {
      method: "PATCH",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },
};

export default contactService;