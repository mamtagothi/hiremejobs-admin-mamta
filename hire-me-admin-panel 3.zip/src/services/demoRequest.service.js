// import api from './axiosInstance';
// import { storage } from '../utils/storage';

// const BASE_URL = '/demo-requests';

// // Helper function to get current user ID
// const getCurrentUserId = () => {
//     try {
//         const userStr = localStorage.getItem('user');
//         if (userStr) {
//             const user = JSON.parse(userStr);
//             return user?.id || null;
//         }
//         const user = storage.getUser();
//         return user?.id || user?.userId || user?._id || null;
//     } catch (error) {
//         console.error('Error getting user ID:', error);
//         return null;
//     }
// };

// // ─── FIX: date/datetime conversion helpers ─────────────────────────────
// // The API returns full ISO strings like "2026-08-07T10:00:00.000Z".
// // <input type="datetime-local"> only accepts "YYYY-MM-DDTHH:mm" (local time,
// // no seconds/ms/timezone) and <input type="date"> only accepts "YYYY-MM-DD".
// // Feeding the raw ISO string to either input makes the browser silently
// // render it blank — which is why edited/prefilled dates looked "missing"
// // and why re-saving the form nulled them out (blank field -> empty string
// // -> `|| null` -> overwritten).

// // ISO string -> value for <input type="datetime-local">
// export const toDatetimeLocalInput = (isoString) => {
//     if (!isoString) return '';
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return '';
//     const pad = (n) => String(n).padStart(2, '0');
//     return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
// };

// // ISO string -> value for <input type="date">
// export const toDateInput = (isoString) => {
//     if (!isoString) return '';
//     const d = new Date(isoString);
//     if (isNaN(d.getTime())) return '';
//     const pad = (n) => String(n).padStart(2, '0');
//     return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
// };

// // <input type="datetime-local"> value -> full ISO string for the API
// const fromDatetimeLocalInput = (localValue) => {
//     if (!localValue) return null;
//     const d = new Date(localValue);
//     if (isNaN(d.getTime())) return null;
//     return d.toISOString();
// };

// export const demoRequestService = {
//     // Get all demo requests
//     getAll: async (params = {}) => {
//         try {
//             const response = await api.get(BASE_URL, { params });
//             return response.data;
//         } catch (error) {
//             throw error.response?.data || error.message;
//         }
//     },

//     // Get single demo request by ID
//     getById: async (id) => {
//         try {
//             const response = await api.get(`${BASE_URL}/${id}`);
//             return response.data;
//         } catch (error) {
//             if (error.response?.status === 404) return null;
//             throw error.response?.data || error.message;
//         }
//     },

//     // Create new demo request
//     create: async (data) => {
//         try {
//             const submitData = {
//                 name: data.name?.trim() || '',
//                 email: data.email?.trim() || '',
//                 mobile: data.mobile?.trim() || '',
//                 company_name: data.company_name?.trim() || '',
//                 designation: data.designation?.trim() || '',
//                 company_size_id: data.company_size_id ? parseInt(data.company_size_id) : null,
//                 industry_id: data.industry_id ? parseInt(data.industry_id) : null,
//                 city_id: data.city_id ? parseInt(data.city_id) : null,
//                 job_hiring_volume: data.job_hiring_volume ? parseInt(data.job_hiring_volume) : null,
//                 hiring_frequency: data.hiring_frequency || '',
//                 interested_plan: data.interested_plan?.trim() || '',
//                 // date-only input, already "YYYY-MM-DD" — send as-is
//                 preferred_demo_date: data.preferred_demo_date || null,
//                 preferred_demo_time: data.preferred_demo_time || '',
//                 message: data.message?.trim() || '',
//                 source: data.source || '',
//                 status: data.status || 'new',
//                 priority: data.priority || 'medium',
//                 assigned_to: data.assigned_to ? parseInt(data.assigned_to) : null,
//                 admin_remarks: data.admin_remarks?.trim() || '',
//                 // FIX: convert datetime-local -> full ISO before sending
//                 demo_scheduled_at: fromDatetimeLocalInput(data.demo_scheduled_at),
//                 demo_completed_at: fromDatetimeLocalInput(data.demo_completed_at),
//                 follow_up_at: fromDatetimeLocalInput(data.follow_up_at),
//             }; 

//             console.log('📤 Creating demo request:', submitData);
//             const response = await api.post(BASE_URL, submitData);
//             return response.data;
//         } catch (error) {
//             console.error('Create error:', error.response?.data);
//             throw error.response?.data || error.message;
//         }
//     },

//     // Update demo request
//     update: async (id, data) => {
//         try {
//             const userId = getCurrentUserId();

//             const submitData = {
//                 name: data.name?.trim() || '',
//                 email: data.email?.trim() || '',
//                 mobile: data.mobile?.trim() || '',
//                 company_name: data.company_name?.trim() || '',
//                 designation: data.designation?.trim() || '',
//                 company_size_id: data.company_size_id ? parseInt(data.company_size_id) : null,
//                 industry_id: data.industry_id ? parseInt(data.industry_id) : null,
//                 city_id: data.city_id ? parseInt(data.city_id) : null,
//                 job_hiring_volume: data.job_hiring_volume ? parseInt(data.job_hiring_volume) : null,
//                 hiring_frequency: data.hiring_frequency || '',
//                 interested_plan: data.interested_plan?.trim() || '',
//                 preferred_demo_date: data.preferred_demo_date || null,
//                 preferred_demo_time: data.preferred_demo_time || '',
//                 message: data.message?.trim() || '',
//                 source: data.source || '',
//                 status: data.status || 'new',
//                 priority: data.priority || 'medium',
//                 assigned_to: data.assigned_to ? parseInt(data.assigned_to) : null,
//                 admin_remarks: data.admin_remarks?.trim() || '',
//                 // FIX: convert datetime-local -> full ISO before sending
//                 demo_scheduled_at: fromDatetimeLocalInput(data.demo_scheduled_at),
//                 demo_completed_at: fromDatetimeLocalInput(data.demo_completed_at),
//                 follow_up_at: fromDatetimeLocalInput(data.follow_up_at),
//                 updated_by: userId || 1
//             };

//             console.log('📤 Updating demo request:', submitData);

//             let response;
//             try {
//                 response = await api.put(`${BASE_URL}/${id}`, submitData);
//                 console.log('✅ PUT successful');
//                 return response.data;
//             } catch (putError) {
//                 console.log('PUT failed:', putError.response?.status);
//                 if (putError.response?.status === 404 || putError.response?.status === 405) {
//                     console.log('Trying PATCH...');
//                     try {
//                         response = await api.patch(`${BASE_URL}/${id}`, submitData);
//                         console.log('✅ PATCH successful');
//                         return response.data;
//                     } catch (patchError) {
//                         console.log('PATCH failed:', patchError.response?.status);
//                         throw patchError;
//                     }
//                 }
//                 throw putError;
//             }
//         } catch (error) {
//             console.error('Update error:', error);
//             throw error.response?.data || error.message;
//         }
//     },

//     // Delete demo request
//     delete: async (id) => {
//         try {
//             const response = await api.delete(`${BASE_URL}/${id}`);
//             return response.data;
//         } catch (error) {
//             if (error.response?.status === 404) {
//                 return { success: true, message: 'Item already deleted' };
//             }
//             throw error.response?.data || error.message;
//         }
//     },

//     // Bulk delete
//     deleteMany: async (ids) => {
//         try {
//             const response = await api.delete(BASE_URL, { data: { ids } });
//             return response.data;
//         } catch (error) {
//             throw error.response?.data || error.message;
//         }
//     },

//     // Search
//     search: async (query) => {
//         try {
//             const response = await api.get(`${BASE_URL}/search`, { params: { q: query } });
//             return response.data;
//         } catch (error) {
//             throw error.response?.data || error.message;
//         }
//     }
// };

// export default demoRequestService;

import { storage } from "../utils/storage";

const API_BASE = import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

const BASE_URL = "/demo-requests";

// ─── Helper: Get auth token ─────────────────────────────────────
const getAuthToken = () => {
  return (
    localStorage.getItem("careerai_admin_token") ||
    localStorage.getItem("token") ||
    storage.getToken()
  );
};

// ─── Helper: Handle API responses ──────────────────────────────
const handleResponse = async (response) => {
  const responseData = await response.json().catch(() => ({}));

  if (!response.ok) {
    console.error("API Error Response:", {
      status: response.status,
      statusText: response.statusText,
      data: responseData,
    });

    let errorMessage =
      responseData.message ||
      responseData.error ||
      `HTTP error ${response.status}`;

    if (responseData.errors) {
      if (typeof responseData.errors === "object") {
        const errorDetails = Object.entries(responseData.errors)
          .map(
            ([field, errors]) =>
              `${field}: ${Array.isArray(errors) ? errors.join(", ") : errors}`,
          )
          .join("; ");
        errorMessage = `Validation failed: ${errorDetails}`;
      } else {
        errorMessage = `Validation failed: ${responseData.errors}`;
      }
    }

    if (responseData.data && typeof responseData.data === "object") {
      const fieldErrors = Object.entries(responseData.data)
        .filter(([_, value]) => value && typeof value === "string")
        .map(([field, error]) => `${field}: ${error}`)
        .join("; ");
      if (fieldErrors) {
        errorMessage = `Validation failed: ${fieldErrors}`;
      }
    }

    throw {
      status: response.status,
      message: errorMessage,
      data: responseData,
      response: { status: response.status, data: responseData },
    };
  }

  return responseData;
};

// ─── Helper: Build headers ──────────────────────────────────────
const getHeaders = (isFormData = false) => {
  const token = getAuthToken();
  const headers = {
    Accept: "application/json",
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  if (!isFormData) {
    headers["Content-Type"] = "application/json";
  }

  return headers;
};

// ─── Helper: Get current user ID ────────────────────────────────
const getCurrentUserId = () => {
  try {
    const userStr = localStorage.getItem("user");
    if (userStr) {
      const user = JSON.parse(userStr);
      return user?.id || null;
    }
    const user = storage.getUser();
    return user?.id || user?.userId || user?._id || null;
  } catch (error) {
    console.error("Error getting user ID:", error);
    return null;
  }
};

// ─── Date/datetime conversion helpers ───────────────────────────
// ISO string -> value for <input type="datetime-local">
export const toDatetimeLocalInput = (isoString) => {
  if (!isoString) return "";
  const d = new Date(isoString);
  if (isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(
    d.getDate(),
  )}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

// ISO string -> value for <input type="date">
export const toDateInput = (isoString) => {
  if (!isoString) return "";
  const d = new Date(isoString);
  if (isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};

// <input type="datetime-local"> value -> full ISO string for the API
const fromDatetimeLocalInput = (localValue) => {
  if (!localValue) return null;
  const d = new Date(localValue);
  if (isNaN(d.getTime())) return null;
  return d.toISOString();
};

// ─── Demo Request Service ────────────────────────────────────────
export const demoRequestService = {
  // ─── Get all demo requests (paginated via query string) ───────
  // Usage: demoRequestService.getAll({ page: 2, limit: 20, status: "new" })
  // Produces: /demo-requests?page=2&limit=20&status=new
  getAll: async (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    const url = `${API_BASE}${BASE_URL}${queryString ? `?${queryString}` : ""}`;

    const response = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Get single demo request by ID ─────────────────────────────
  getById: async (id) => {
    const url = `${API_BASE}${BASE_URL}/${id}`;

    const response = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    if (response.status === 404) return null;
    return handleResponse(response);
  },

  // ─── Create new demo request ───────────────────────────────────
  create: async (data) => {
    const submitData = {
      name: data.name?.trim() || "",
      email: data.email?.trim() || "",
      mobile: data.mobile?.trim() || "",
      company_name: data.company_name?.trim() || "",
      designation: data.designation?.trim() || "",
      company_size_id: data.company_size_id
        ? parseInt(data.company_size_id)
        : null,
      industry_id: data.industry_id ? parseInt(data.industry_id) : null,
      city_id: data.city_id ? parseInt(data.city_id) : null,
      job_hiring_volume: data.job_hiring_volume
        ? parseInt(data.job_hiring_volume)
        : null,
      hiring_frequency: data.hiring_frequency || "",
      interested_plan: data.interested_plan?.trim() || "",
      // date-only input, already "YYYY-MM-DD" — send as-is
      preferred_demo_date: data.preferred_demo_date || null,
      preferred_demo_time: data.preferred_demo_time || "",
      message: data.message?.trim() || "",
      source: data.source || "",
      status: data.status || "new",
      priority: data.priority || "medium",
      assigned_to: data.assigned_to ? parseInt(data.assigned_to) : null,
      admin_remarks: data.admin_remarks?.trim() || "",
      // convert datetime-local -> full ISO before sending
      demo_scheduled_at: fromDatetimeLocalInput(data.demo_scheduled_at),
      demo_completed_at: fromDatetimeLocalInput(data.demo_completed_at),
      follow_up_at: fromDatetimeLocalInput(data.follow_up_at),
    };

    console.log("📤 Creating demo request:", submitData);

    const url = `${API_BASE}${BASE_URL}`;
    const response = await fetch(url, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(submitData),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Update demo request (PUT with PATCH fallback) ─────────────
  update: async (id, data) => {
    const userId = getCurrentUserId();

    const submitData = {
      name: data.name?.trim() || "",
      email: data.email?.trim() || "",
      mobile: data.mobile?.trim() || "",
      company_name: data.company_name?.trim() || "",
      designation: data.designation?.trim() || "",
      company_size_id: data.company_size_id
        ? parseInt(data.company_size_id)
        : null,
      industry_id: data.industry_id ? parseInt(data.industry_id) : null,
      city_id: data.city_id ? parseInt(data.city_id) : null,
      job_hiring_volume: data.job_hiring_volume
        ? parseInt(data.job_hiring_volume)
        : null,
      hiring_frequency: data.hiring_frequency || "",
      interested_plan: data.interested_plan?.trim() || "",
      preferred_demo_date: data.preferred_demo_date || null,
      preferred_demo_time: data.preferred_demo_time || "",
      message: data.message?.trim() || "",
      source: data.source || "",
      status: data.status || "new",
      priority: data.priority || "medium",
      assigned_to: data.assigned_to ? parseInt(data.assigned_to) : null,
      admin_remarks: data.admin_remarks?.trim() || "",
      demo_scheduled_at: fromDatetimeLocalInput(data.demo_scheduled_at),
      demo_completed_at: fromDatetimeLocalInput(data.demo_completed_at),
      follow_up_at: fromDatetimeLocalInput(data.follow_up_at),
      updated_by: userId || 1,
    };

    console.log("📤 Updating demo request:", submitData);

    const url = `${API_BASE}${BASE_URL}/${id}`;

    // Try PATCH first (the primary backend endpoint for updates)
    try {
      const response = await fetch(url, {
        method: "PATCH",
        headers: getHeaders(),
        body: JSON.stringify(submitData),
        mode: "cors",
        credentials: "include",
      });
      console.log("✅ PATCH successful");
      return handleResponse(response);
    } catch (patchError) {
      console.log("PATCH failed, trying PUT:", patchError?.status || patchError?.response?.status);

      // Fall back to PUT if PATCH isn't supported
      if (
        patchError?.status === 404 ||
        patchError?.status === 405 ||
        patchError?.response?.status === 404 ||
        patchError?.response?.status === 405
      ) {
        console.log("Trying PUT...");
        const response = await fetch(url, {
          method: "PUT",
          headers: getHeaders(),
          body: JSON.stringify(submitData),
          mode: "cors",
          credentials: "include",
        });
        console.log("✅ PUT successful");
        return handleResponse(response);
      }

      throw patchError;
    }
  },

  // ─── Delete demo request ───────────────────────────────────────
  delete: async (id) => {
    const url = `${API_BASE}${BASE_URL}/${id}`;

    const response = await fetch(url, {
      method: "DELETE",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    if (response.status === 404) {
      return { success: true, message: "Item already deleted" };
    }

    return handleResponse(response);
  },

  // ─── Bulk delete ───────────────────────────────────────────────
  deleteMany: async (ids) => {
    const url = `${API_BASE}${BASE_URL}`;

    const response = await fetch(url, {
      method: "DELETE",
      headers: getHeaders(),
      body: JSON.stringify({ ids }),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },

  // ─── Search ────────────────────────────────────────────────────
  search: async (query) => {
    const queryString = new URLSearchParams({ q: query }).toString();
    const url = `${API_BASE}${BASE_URL}/search?${queryString}`;

    const response = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
      mode: "cors",
      credentials: "include",
    });

    return handleResponse(response);
  },
};

export default demoRequestService;