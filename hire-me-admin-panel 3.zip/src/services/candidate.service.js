// import api from './api';

// const candidateService = {
//   getAll: (params) => api.get('/candidate', { params }),
//   getById: (id) => api.get(`/candidate/${id}`),
//   getFullProfile: (id) => api.get(`/candidate-full-profile/${id}`),
//   create: (data) => api.post('/candidate', data),
//   update: (id, data) => api.patch(`/candidate/${id}`, data),
//   delete: (id) => api.delete(`/candidate/${id}`),
// };

// export default candidateService;

import api from './api';

// Build a query string from a plain object, ignoring empty values.
// ⭐ This writes the query string directly into the URL, so axios
// has no way to silently drop `page` / `limit` / `search` / `status`.
const buildQuery = (params = {}) => {
  const entries = Object.entries(params).filter(
    ([, v]) => v !== undefined && v !== null && v !== "",
  );
  if (entries.length === 0) return "";
  return "?" + new URLSearchParams(entries).toString();
};

const candidateService = {
  getAll: (params = {}) => api.get(`/candidate${buildQuery(params)}`),
  getById: (id) => api.get(`/candidate/${id}`),
  getFullProfile: (id) => api.get(`/candidate-full-profile/${id}`),
  create: (data) => api.post('/candidate', data),
  update: (id, data) => api.patch(`/candidate/${id}`, data),
  delete: (id) => api.delete(`/candidate/${id}`),
};

export default candidateService;