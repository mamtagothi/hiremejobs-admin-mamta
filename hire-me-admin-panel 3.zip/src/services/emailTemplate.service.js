import api from "./axiosInstance";

const BASE_URL = "/email-templates";

const getCurrentUserId = () => {
  try {
    const userStr = localStorage.getItem("user");
    if (userStr) {
      const user = JSON.parse(userStr);
      return user?.id || null;
    }
    return null;
  } catch (error) {
    console.error("Error getting user ID:", error);
    return null;
  }
};

export const emailTemplateService = {
  // Get all email templates
  getAll: async (params = {}) => {
    try {
      const response = await api.get(BASE_URL, { params });
      return response.data;
    } catch (error) {
      throw error.response?.data || error.message;
    }
  },

  // Get single email template by ID
  getById: async (id) => {
    try {
      const response = await api.get(`${BASE_URL}/${id}`);
      return response.data;
    } catch (error) {
      if (error.response?.status === 404) {
        return null;
      }
      throw error.response?.data || error.message;
    }
  },

  // Create email template
  create: async (data) => {
    try {
      const userId = getCurrentUserId();

      const submitData = {
        template_key: data.template_key ? data.template_key.trim() : "",
        template_name: data.template_name ? data.template_name.trim() : "",
        subject: data.subject ? data.subject.trim() : "",
        body_html: data.body_html || "",
        body_text: data.body_text || null,
        recipient_type: data.recipient_type || "all",
        variables_json: data.variables_json || null,
        email_send: data.email_send !== undefined ? Boolean(data.email_send) : true,
        status: data.status !== undefined ? Boolean(data.status) : true,
        created_by: userId || null,
        updated_by: userId || null,
      };

      console.log("📤 Creating Email Template:", submitData);
      const response = await api.post(BASE_URL, submitData);
      console.log("✅ Email Template created successfully");
      return response.data;
    } catch (error) {
      console.error("Create error:", error.response?.data || error);
      throw error.response?.data || error.message;
    }
  },

  // Update email template
  update: async (id, data) => {
    try {
      const userId = getCurrentUserId();

      const submitData = {
        template_name: data.template_name ? data.template_name.trim() : "",
        subject: data.subject ? data.subject.trim() : "",
        body_html: data.body_html || "",
        body_text: data.body_text || null,
        recipient_type: data.recipient_type || "all",
        variables_json: data.variables_json || null,
        email_send: data.email_send !== undefined ? Boolean(data.email_send) : true,
        status: data.status !== undefined ? Boolean(data.status) : true,
        updated_by: userId || null,
      };

      console.log(`📤 Updating Email Template ID ${id}:`, submitData);
      const response = await api.put(`${BASE_URL}/${id}`, submitData);
      console.log("✅ Email Template updated successfully");
      return response.data;
    } catch (error) {
      console.error("Update error:", error.response?.data || error);
      throw error.response?.data || error.message;
    }
  },

  // Delete email template
  delete: async (id) => {
    try {
      const response = await api.delete(`${BASE_URL}/${id}`);
      return response.data;
    } catch (error) {
      if (error.response?.status === 404) {
        return { success: true, message: "Item already deleted" };
      }
      throw error.response?.data || error.message;
    }
  },

  // Toggle email send boolean
  toggleEmailSend: async (id) => {
    try {
      console.log(`📤 Toggling email send for Template ID ${id}`);
      const response = await api.patch(`${BASE_URL}/${id}/toggle-send`);
      console.log("✅ Email send toggled successfully");
      return response.data;
    } catch (error) {
      console.error("Toggle error:", error.response?.data || error);
      throw error.response?.data || error.message;
    }
  },
};

export default emailTemplateService;