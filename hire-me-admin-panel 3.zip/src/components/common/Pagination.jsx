﻿// import { useEffect } from "react";
// import { MdChevronLeft, MdChevronRight } from "react-icons/md";

// const PAGE_SIZE_OPTIONS = [10, 20, 25, 50, 100];

// const Pagination = ({
//   page,
//   total,
//   limit,
//   onChange,
//   onLimitChange,
//   itemsCount,
//   links,
//   hasPrev,
//   hasNext,
// }) => {
//   const safePage = Math.max(1, Number(page) || 1);
//   const safeTotal = Math.max(0, Number(total) || 0);
//   const safeItemsCount = Math.max(0, Number(itemsCount) || 0);
//   const effectiveTotal = safeTotal > 0 ? safeTotal : safeItemsCount;
//   const safeLimit = Math.max(1, Number(limit) || 20);
//   const computedTotalPages = Math.max(1, Math.ceil(effectiveTotal / safeLimit));

//   // Determine if Previous button should be disabled
//   let isPrevDisabled = safePage <= 1;
//   if (hasPrev !== undefined) {
//     isPrevDisabled = !hasPrev || safePage <= 1;
//   } else if (links) {
//     const prevVal = links.prev !== undefined ? links.prev : links.previous;
//     isPrevDisabled = prevVal === null || prevVal === false || safePage <= 1;
//   }

//   // Determine if Next button should be disabled
//   let isNextDisabled = safePage >= computedTotalPages;
//   if (hasNext !== undefined) {
//     isNextDisabled = !hasNext;
//   } else if (links) {
//     isNextDisabled = links.next === null || links.next === false;
//   }

//   useEffect(() => {
//     if (
//       safePage > computedTotalPages &&
//       effectiveTotal > 0 &&
//       typeof onChange === "function" &&
//       !links
//     ) {
//       onChange(1);
//     }
//   }, [safePage, computedTotalPages, effectiveTotal, onChange, links]);

//   // If effectiveTotal is 0 and no links provided, don't render
//   if (effectiveTotal <= 0 && !links) {
//     return null;
//   }

//   const clampedPage = safePage;
//   const startItem =
//     effectiveTotal > 0 ? (clampedPage - 1) * safeLimit + 1 : 0;
//   const endItem =
//     effectiveTotal > 0
//       ? Math.min(clampedPage * safeLimit, effectiveTotal)
//       : 0;

//   // Build page number list (show up to 5 page numbers)
//   const totalPages = Math.max(computedTotalPages, safePage);
//   const getPages = () => {
//     if (totalPages <= 5) {
//       return Array.from({ length: totalPages }, (_, i) => i + 1);
//     }
//     if (clampedPage <= 3) return [1, 2, 3, 4, 5];
//     if (clampedPage >= totalPages - 2)
//       return [
//         totalPages - 4,
//         totalPages - 3,
//         totalPages - 2,
//         totalPages - 1,
//         totalPages,
//       ];
//     return [
//       clampedPage - 2,
//       clampedPage - 1,
//       clampedPage,
//       clampedPage + 1,
//       clampedPage + 2,
//     ];
//   };

//   const pages = getPages();

//   return (
//     <div className="flex flex-col gap-3 py-4 px-6 border-t border-slate-100 sm:flex-row sm:items-center sm:justify-between bg-white">
//       {/* Left: Showing X-Y of Z results */}
//       <p className="text-sm text-slate-500 font-medium whitespace-nowrap">
//         {effectiveTotal > 0
//           ? `Showing ${startItem}â€“${endItem} of ${effectiveTotal} results`
//           : `Page ${clampedPage}`}
//       </p>

//       {/* Right: Rows per page + navigation */}
//       <div className="flex items-center gap-3">
//         {/* Rows per page */}
//         {onLimitChange && (
//           <div className="flex items-center gap-2">
//             <span className="text-sm text-slate-500 font-medium whitespace-nowrap">
//               Rows per page:
//             </span>
//             <select
//               value={safeLimit}
//               onChange={(e) => {
//                 const newLimit = Number(e.target.value);
//                 if (typeof onLimitChange === "function") {
//                   onLimitChange(newLimit);
//                 }
//                 if (typeof onChange === "function") {
//                   onChange(1);
//                 }
//               }}
//               className="text-sm border border-gray-300 rounded-md px-2 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-[#4529f7] cursor-pointer"
//             >
//               {PAGE_SIZE_OPTIONS.map((size) => (
//                 <option key={size} value={size}>
//                   {size}
//                 </option>
//               ))}
//             </select>
//           </div>
//         )}

//         {/* Page navigation */}
//         <div className="flex items-center gap-1">
//           {/* Prev */}
//           <button
//             onClick={() =>
//               !isPrevDisabled && onChange?.(Math.max(1, clampedPage - 1))
//             }
//             disabled={isPrevDisabled}
//             className="rounded-full p-1.5 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 text-slate-500 hover:text-slate-800"
//             aria-label="Previous page"
//             title={isPrevDisabled ? "First page" : "Previous page"}
//           >
//             <MdChevronLeft size={20} />
//           </button>

//           {/* Page numbers */}
//           {pages.map((p) => (
//             <button
//               key={p}
//               onClick={() => onChange?.(p)}
//               className={`h-8 w-8 rounded-full text-sm font-medium transition-colors duration-200 ${
//                 p === clampedPage
//                   ? "bg-slate-800 text-white shadow-sm"
//                   : "text-slate-500 hover:bg-slate-100 hover:text-slate-800"
//               }`}
//             >
//               {p}
//             </button>
//           ))}

//           {/* Next */}
//           <button
//             onClick={() => !isNextDisabled && onChange?.(clampedPage + 1)}
//             disabled={isNextDisabled}
//             className="rounded-full p-1.5 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 text-slate-500 hover:text-slate-800"
//             aria-label="Next page"
//             title={isNextDisabled ? "Last page" : "Next page"}
//           >
//             <MdChevronRight size={20} />
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Pagination;

import { useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { MdChevronLeft, MdChevronRight } from "react-icons/md";

const PAGE_SIZE_OPTIONS = [10, 20, 25, 50, 100];

const Pagination = ({
  page,
  total,
  limit,
  onChange,
  onLimitChange,
  itemsCount,
  links,
  hasPrev,
  hasNext,
}) => {
  const [searchParams, setSearchParams] = useSearchParams();

  // â”€â”€â”€ Determine controlled vs URL-driven mode â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // If the parent passes onChange, we're controlled.
  // Otherwise, page/limit come from (and are written to) the URL.
  const isControlled = typeof onChange === "function";

  const urlPage = Number(searchParams.get("page")) || 1;
  const urlLimit = Number(searchParams.get("limit")) || 20;

  const resolvedPage = isControlled ? page : urlPage;
  const resolvedLimit = isControlled ? limit : urlLimit;

  const safePage = Math.max(1, Number(resolvedPage) || 1);
  const safeTotal = Math.max(0, Number(total) || 0);
  const safeItemsCount = Math.max(0, Number(itemsCount) || 0);
  const effectiveTotal = safeTotal > 0 ? safeTotal : safeItemsCount;
  const safeLimit = Math.max(1, Number(resolvedLimit) || 20);
  const computedTotalPages = Math.max(
    1,
    Math.ceil(effectiveTotal / safeLimit)
  );

  // â”€â”€â”€ URL param helper (only used when uncontrolled) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const setUrlParams = useCallback(
    (nextPage, nextLimit) => {
      const params = new URLSearchParams(searchParams);
      if (nextPage && nextPage > 1) {
        params.set("page", String(nextPage));
      } else {
        params.delete("page");
      }
      if (nextLimit && nextLimit !== 20) {
        params.set("limit", String(nextLimit));
      } else {
        params.delete("limit");
      }
      setSearchParams(params, { replace: true });
    },
    [searchParams, setSearchParams]
  );

  // â”€â”€â”€ Change handlers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const handlePageChange = (newPage) => {
    if (isControlled) {
      onChange?.(newPage);
    } else {
      setUrlParams(newPage, safeLimit);
    }
  };

  const handleLimitChange = (newLimit) => {
    if (isControlled) {
      onLimitChange?.(newLimit);
      onChange?.(1);
    } else {
      setUrlParams(1, newLimit);
    }
  };

  // â”€â”€â”€ Prev / Next disabled state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  let isPrevDisabled = safePage <= 1;
  if (hasPrev !== undefined) {
    isPrevDisabled = !hasPrev || safePage <= 1;
  } else if (links) {
    const prevVal = links.prev !== undefined ? links.prev : links.previous;
    isPrevDisabled = prevVal === null || prevVal === false || safePage <= 1;
  }

  let isNextDisabled = safePage >= computedTotalPages;
  if (hasNext !== undefined) {
    isNextDisabled = !hasNext;
  } else if (links) {
    isNextDisabled = links.next === null || links.next === false;
  }

  // â”€â”€â”€ Auto-clamp when page > totalPages â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    if (
      safePage > computedTotalPages &&
      effectiveTotal > 0 &&
      !links
    ) {
      if (isControlled) {
        onChange?.(1);
      } else {
        setUrlParams(1, safeLimit);
      }
    }
  }, [
    safePage,
    computedTotalPages,
    effectiveTotal,
    onChange,
    links,
    isControlled,
    safeLimit,
    setUrlParams,
  ]);

  // Nothing to render if there's no data (and no link hints)
  if (effectiveTotal <= 0 && !links) {
    return null;
  }

  const clampedPage = safePage;
  const startItem =
    effectiveTotal > 0 ? (clampedPage - 1) * safeLimit + 1 : 0;
  const endItem =
    effectiveTotal > 0
      ? Math.min(clampedPage * safeLimit, effectiveTotal)
      : 0;

  // Build page number list (show up to 5 page numbers)
  const totalPages = Math.max(computedTotalPages, safePage);
  const getPages = () => {
    if (totalPages <= 5) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    if (clampedPage <= 3) return [1, 2, 3, 4, 5];
    if (clampedPage >= totalPages - 2)
      return [
        totalPages - 4,
        totalPages - 3,
        totalPages - 2,
        totalPages - 1,
        totalPages,
      ];
    return [
      clampedPage - 2,
      clampedPage - 1,
      clampedPage,
      clampedPage + 1,
      clampedPage + 2,
    ];
  };

  const pages = getPages();

  return (
    <div className="flex flex-col gap-3 py-4 px-6 border-t border-slate-100 sm:flex-row sm:items-center sm:justify-between bg-white">
      {/* Left: Showing Xâ€“Y of Z results */}
      <p className="text-sm text-slate-500 font-medium whitespace-nowrap">
        {effectiveTotal > 0
          ? `Showing ${startItem}â€“${endItem} of ${effectiveTotal} results`
          : `Page ${clampedPage}`}
      </p>

      {/* Right: Rows per page + navigation */}
      <div className="flex items-center gap-3">
        {/* Rows per page â€” shown in uncontrolled (URL) mode OR when
            the parent explicitly passes onLimitChange */}
        {(onLimitChange || !isControlled) && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-500 font-medium whitespace-nowrap">
              Rows per page:
            </span>
            <select
              value={safeLimit}
              onChange={(e) => handleLimitChange(Number(e.target.value))}
              className="text-sm border border-gray-300 rounded-md px-2 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-[#4529f7] cursor-pointer"
            >
              {PAGE_SIZE_OPTIONS.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Page navigation */}
        <div className="flex items-center gap-1">
          {/* Prev */}
          <button
            onClick={() =>
              !isPrevDisabled && handlePageChange(Math.max(1, clampedPage - 1))
            }
            disabled={isPrevDisabled}
            className="rounded-full p-1.5 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 text-slate-500 hover:text-slate-800"
            aria-label="Previous page"
            title={isPrevDisabled ? "First page" : "Previous page"}
          >
            <MdChevronLeft size={20} />
          </button>

          {/* Page numbers */}
          {pages.map((p) => (
            <button
              key={p}
              onClick={() => handlePageChange(p)}
              className={`h-8 w-8 rounded-full text-sm font-medium transition-colors duration-200 ${
                p === clampedPage
                  ? "bg-slate-800 text-white shadow-sm"
                  : "text-slate-500 hover:bg-slate-100 hover:text-slate-800"
              }`}
            >
              {p}
            </button>
          ))}

          {/* Next */}
          <button
            onClick={() =>
              !isNextDisabled && handlePageChange(clampedPage + 1)
            }
            disabled={isNextDisabled}
            className="rounded-full p-1.5 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40 text-slate-500 hover:text-slate-800"
            aria-label="Next page"
            title={isNextDisabled ? "Last page" : "Next page"}
          >
            <MdChevronRight size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Pagination;
