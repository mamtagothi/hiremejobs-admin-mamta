import React from "react";
import { formatNumber } from "../../utils/helpers";
import {
  MdLayers,
  MdCheckCircle,
  MdPauseCircle,
  MdLock,
  MdRestore,
  MdTrendingUp,
  MdPending,
  MdClose,
  MdWork,
  MdBusiness,
  MdPeople,
} from "react-icons/md";

// Icon mapping based on labels to give smart default icons
const getIconForLabel = (label = "") => {
  const l = label.toLowerCase();
  if (l.includes("all")) return MdLayers;
  if (l.includes("active") || l.includes("published") || l.includes("resolved") || l.includes("approved")) return MdCheckCircle;
  if (l.includes("inactive") || l.includes("closed") || l.includes("unresolved") || l.includes("rejected")) return MdPauseCircle;
  if (l.includes("block") || l.includes("banned")) return MdLock;
  if (l.includes("pending") || l.includes("draft") || l.includes("scheduled")) return MdPending;
  if (l.includes("trend")) return MdTrendingUp;
  if (l.includes("job")) return MdWork;
  if (l.includes("compan")) return MdBusiness;
  if (l.includes("candidate") || l.includes("user")) return MdPeople;
  
  return MdLayers;
};

const StatisticFilterCard = ({ label, count, icon, isActive, onClick }) => {
  const Icon = icon || getIconForLabel(label);

  return (
    <div
      onClick={onClick}
      role="button"
      className={`group relative rounded-xl border p-5 shadow-sm transition-all duration-200 cursor-pointer
        ${
          isActive
            ? "bg-[#2C0EEE] border-[#2C0EEE] shadow-lg shadow-[#2C0EEE]/25 text-white"
            : "bg-white border-gray-200 hover:border-[#2C0EEE] hover:shadow-md text-gray-900"
        }
      `}
    >
      <div className="flex items-start gap-3">
        <div className="flex-1 min-w-0">
          <p
            className={`text-xs font-medium tracking-wide uppercase transition-colors duration-200 ${
              isActive ? "text-white/90" : "text-gray-500 group-hover:text-gray-600"
            }`}
          >
            {label}
          </p>
          <p
            className={`text-2xl font-bold mt-1 tabular-nums transition-colors duration-200 ${
              isActive ? "text-white" : "text-gray-900"
            }`}
          >
            {formatNumber(count || 0)}
          </p>
        </div>
        {Icon && (
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-colors duration-200 ${
              isActive
                ? "bg-white/20 text-white"
                : "bg-blue-50 text-[#2C0EEE] group-hover:bg-blue-100"
            }`}
          >
            <Icon size={18} />
          </div>
        )}
      </div>
    </div>
  );
};

export default StatisticFilterCard;
