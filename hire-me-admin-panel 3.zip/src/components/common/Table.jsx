﻿


// import Loader from "./Loader";

// const Table = ({
//   columns = [],
//   data = [],
//   loading = false,
//   emptyMessage = "No records found",
// }) => {
//   // Always ensure data is an array
//   const tableData = Array.isArray(data)
//     ? data
//     : Array.isArray(data?.data)
//     ? data.data
//     : Array.isArray(data?.results)
//     ? data.results
//     : [];

//   return (
//     <div className="overflow-x-auto w-full bg-white rounded-2xl shadow-[0_2px_12px_rgba(0,0,0,0.06)] border border-slate-100">
//       <table className="w-full text-sm text-left">
//         <thead>
//           <tr className="bg-slate-50 border-b border-slate-100">
//             {columns.map((col, i) => (
//               <th
//                 key={i}
//                 className="px-6 py-4 text-xs uppercase tracking-wider font-semibold text-slate-500 whitespace-nowrap"
//               >
//                 {col.header}
//               </th>
//             ))}
//           </tr>
//         </thead>

//         <tbody>
//           {loading ? (
//             <tr>
//               <td colSpan={columns.length} className="py-10">
//                 <Loader />
//               </td>
//             </tr>
//           ) : tableData.length === 0 ? (
//             <tr>
//               <td
//                 colSpan={columns.length}
//                 className="py-10 text-center text-gray-400"
//               >
//                 {emptyMessage}
//               </td>
//             </tr>
//           ) : (
//             tableData.map((row, rowIndex) => (
//               <tr
//                 key={row.id || row._id || rowIndex}
//                 className="border-b border-slate-100 hover:bg-slate-50 transition-colors duration-200"
//               >
//                 {columns.map((col, colIndex) => (
//                   <td
//                     key={colIndex}
//                     className="px-6 py-4 text-slate-700 whitespace-nowrap"
//                   >
//                     {col.render
//                       ? col.render(row[col.key], row)
//                       : row[col.key] ?? "-"}
//                   </td>
//                 ))}
//               </tr>
//             ))
//           )}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default Table;

import Loader from "./Loader";

const Table = ({
  columns = [],
  data = [],
  loading = false,
  emptyMessage = "No records found",
}) => {
  // Always ensure data is an array
  const tableData = Array.isArray(data)
    ? data
    : Array.isArray(data?.data)
    ? data.data
    : Array.isArray(data?.results)
    ? data.results
    : [];

  return (
    <div className="overflow-x-auto w-full bg-white rounded-2xl shadow-[0_2px_12px_rgba(0,0,0,0.06)] border border-slate-100">
      <table className="w-full text-sm text-left">
        <thead>
          <tr className="bg-slate-50 border-b border-slate-100">
            {columns.map((col, index) => (
              <th
                key={index}
                className="px-6 py-4 text-xs uppercase tracking-wider font-semibold text-slate-500 whitespace-nowrap"
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          {loading ? (
            <tr>
              <td colSpan={columns.length} className="py-10">
                <Loader />
              </td>
            </tr>
          ) : tableData.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length}
                className="py-10 text-center text-gray-400"
              >
                {emptyMessage}
              </td>
            </tr>
          ) : (
            tableData.map((row, rowIndex) => (
              <tr
                key={row.id || row._id || rowIndex}
                className="border-b border-slate-100 hover:bg-slate-50 transition-colors duration-200"
              >
                {columns.map((col, colIndex) => (
                  <td
                    key={colIndex}
                    className="px-6 py-4 text-slate-700 whitespace-nowrap"
                  >
                    {col.render
                      ? col.render(
                          row[col.key], // value
                          row,          // entire row
                          rowIndex      // row index
                        )
                      : row[col.key] ?? "-"}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
