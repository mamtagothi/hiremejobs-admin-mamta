import { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { toggleSidebar } from "../../redux/slices/uiSlice";
import { menuItems } from "../../config/menu";
import HireMeLogo from "../../assets/HiremeLogoWhite.png";
// import HireMeLogo from "../../assets/Logo.png"
import {
  MdDashboard,
  MdPeople,
  MdWork,
  MdCategory,
  MdBusiness,
  MdApartment,
  MdSchool,
  MdSubdirectoryArrowRight,
  MdArticle,
  MdImage,
  MdNotifications,
  MdSettings,
  MdSecurity,
  MdLock,
  MdClose,
  MdViewModule,
  MdLocationCity,
  MdLanguage,
  MdLibraryBooks,
  MdAssignment,
  MdMarkEmailUnread,
  MdSupervisorAccount,
  MdTimeline,
  MdCardGiftcard,
  MdLocalOffer,
  MdWorkOutline,
  MdAdUnits,
  MdReceipt,
  MdAttachMoney,
  MdRateReview,
  MdCheckCircle,
  MdBusinessCenter,
  MdSubscript,
  MdPayments,
  MdExtension,
  MdDescription,
  MdKeyboardArrowDown,
  MdWeb,
  MdQuestionAnswer,
  MdFormatQuote,
  MdHelpOutline,
} from "react-icons/md";
import { useAuth } from "../../context/AuthContext";

const iconMap = {
  MdDashboard,
  MdWeb,
  MdQuestionAnswer,
  MdFormatQuote,
  MdHelpOutline,
  MdPeople,
  MdAdUnits,
  MdReceipt,
  MdSubscript,
  MdPayments,
  MdExtension,
  MdDescription,
  MdAttachMoney,
  MdRateReview,
  MdCheckCircle,
  MdBusinessCenter,
  MdWork,
  MdTimeline,
  MdCategory,
  MdBusiness,
  MdApartment,
  MdArticle,
  MdImage,
  MdNotifications,
  MdSettings,
  MdSecurity,
  MdLock,
  MdViewModule,
  MdLanguage,
  MdLocationCity,
  MdSchool,
  MdSubdirectoryArrowRight,
  MdLibraryBooks,
  MdAssignment,
  MdSupervisorAccount,
  MdMarkEmailUnread,
  MdCardGiftcard,
  MdLocalOffer,
  MdWorkOutline,
};

const Sidebar = () => {
  const sidebarOpen = useSelector((s) => s.ui.sidebarOpen);
  const dispatch = useDispatch();
  const { user } = useAuth();
  const location = useLocation();

  // ─── Local user mirror ────────────────────────────────────
  // Keeps the sidebar reactive to profile changes. It initializes
  // from the auth context but also listens for the "user:updated"
  // event (dispatched by the Profile page) and falls back to
  // localStorage so the latest name/email survives a refresh.
  const [localUser, setLocalUser] = useState(() => {
    if (user) return user;
    try {
      const stored = localStorage.getItem("user");
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (user) setLocalUser(user);
  }, [user]);

  useEffect(() => {
    const handleUserUpdated = (e) => {
      if (e?.detail) {
        setLocalUser((prev) => ({ ...prev, ...e.detail }));
      } else {
        try {
          const stored = localStorage.getItem("user");
          if (stored) setLocalUser(JSON.parse(stored));
        } catch {
          /* ignore */
        }
      }
    };
    window.addEventListener("user:updated", handleUserUpdated);
    window.addEventListener("storage", handleUserUpdated);
    return () => {
      window.removeEventListener("user:updated", handleUserUpdated);
      window.removeEventListener("storage", handleUserUpdated);
    };
  }, []);

  // Tracks which dropdown groups are expanded, keyed by label
  const [openGroups, setOpenGroups] = useState({});

  // Auto-expand a group if the current route matches one of its children
  useEffect(() => {
    const matched = {};
    menuItems.forEach((item) => {
      if (item.children) {
        const isChildActive = item.children.some((child) =>
          location.pathname.startsWith(child.path),
        );
        if (isChildActive) matched[item.label] = true;
      }
    });
    if (Object.keys(matched).length) {
      setOpenGroups((prev) => ({ ...prev, ...matched }));
    }
  }, [location.pathname]);

  const toggleGroup = (label) => {
    setOpenGroups((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  // Get user initials for avatar fallback
  const getUserInitials = () => {
    if (!localUser) return "U";
    const name = localUser.name || "";
    if (name.length === 0)
      return localUser.email?.charAt(0).toUpperCase() || "U";
    const parts = name.trim().split(" ");
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    return (
      parts[0].charAt(0) + parts[parts.length - 1].charAt(0)
    ).toUpperCase();
  };

  // Get avatar URL or fallback
  const avatarUrl = localUser?.image
    ? localUser.image.startsWith("http")
      ? localUser.image
      : `https://apidata.hiremejobs.in/uploads/${localUser.image}`
    : null;

  const childLinkClasses = ({ isActive }) =>
    `flex items-center gap-3 px-4 py-2.5 rounded-full border border-transparent transition-all duration-200 ease-in-out group ${
      isActive
        ? "bg-[#F61D25] text-white font-semibold border-[#F61D25] shadow-md shadow-red-900/30"
        : "text-gray-200 hover:bg-[#250508] hover:border-[#6e0f15] hover:text-white"
    }`;

  const topLinkClasses = ({ isActive }) =>
    `flex items-center gap-3.5 px-4 py-2.5 rounded-full border border-transparent transition-all duration-200 ease-in-out group ${
      isActive
        ? "bg-[#F61D25] text-white font-semibold border-[#F61D25] shadow-md shadow-red-900/30"
        : "text-gray-200 hover:bg-[#250508] hover:border-[#6e0f15] hover:text-white"
    }`;

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-black/50 lg:hidden"
          onClick={() => dispatch(toggleSidebar())}
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-30 flex flex-col h-screen bg-black transition-all duration-300 ${
          sidebarOpen ? "w-[272px]" : "w-0 lg:w-16"
        } overflow-hidden`}
      >
        {/* Logo */}
        <div className="flex items-center justify-center bg-black h-16 px-4 flex-shrink-0">
          <div className="w-full h-12 flex items-center justify-center overflow-hidden">
            <img
              src={HireMeLogo}
              alt="Hire Me Logo"
              className="h-10 w-auto object-contain"
            />
          </div>
        </div>

        {/* Nav - Single Scrollbar Container */}
        <nav className="flex-1 min-h-0 overflow-y-auto py-2.5 px-3 space-y-1.5 [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:bg-white/20 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-transparent">
          <ul className="space-y-1.5">
            {menuItems.map((item) => {
              const Icon = iconMap[item.icon];

              // --- Dropdown group (has children) ---
              if (item.children && item.children.length) {
                const isOpen = !!openGroups[item.label];
                const isGroupActive = item.children.some((child) =>
                  location.pathname.startsWith(child.path),
                );
                const hasCategories = item.children.some(
                  (child) => child.category,
                );
                const categoryList = hasCategories
                  ? Array.from(
                      new Set(
                        item.children
                          .map((child) => child.category)
                          .filter(Boolean),
                      ),
                    )
                  : [];

                return (
                  <li key={item.label}>
                    <button
                      type="button"
                      onClick={() => toggleGroup(item.label)}
                      title={!sidebarOpen ? item.label : ""}
                      className={`w-full flex items-center gap-3.5 px-4 py-2.5 rounded-full border border-transparent transition-all duration-200 ease-in-out group ${
                        isGroupActive
                          ? "text-white font-semibold hover:bg-[#250508] hover:border-[#6e0f15]"
                          : "text-gray-200 hover:bg-[#250508] hover:border-[#6e0f15] hover:text-white"
                      }`}
                    >
                      {Icon && <Icon size={21} className="flex-shrink-0 text-white transition-transform duration-150" />}
                      {sidebarOpen && (
                        <>
                          <span className="text-[15px] font-medium whitespace-nowrap flex-1 text-left">
                            {item.label}
                          </span>
                          <MdKeyboardArrowDown
                            size={20}
                            className={`flex-shrink-0 transition-transform duration-200 ${
                              isOpen ? "rotate-180" : ""
                            }`}
                          />
                        </>
                      )}
                    </button>

                    {/* Sub-menu (No nested scrollbar, clean indentation) */}
                    {sidebarOpen && isOpen && (
                      <div className="mt-1 pl-4 space-y-1">
                        {hasCategories ? (
                          categoryList.map((cat) => (
                            <div key={cat} className="pt-2 pb-0.5">
                              <div className="px-4 py-1 text-xs font-semibold tracking-wider text-gray-400 uppercase select-none">
                                {cat}
                              </div>
                              <ul className="mt-1 space-y-1">
                                {item.children
                                  .filter((child) => child.category === cat)
                                  .map((child) => {
                                    const ChildIcon = iconMap[child.icon];
                                    return (
                                      <li key={child.path}>
                                        <NavLink
                                          to={child.path}
                                          className={childLinkClasses}
                                        >
                                          {ChildIcon && (
                                            <ChildIcon
                                              size={19}
                                              className="flex-shrink-0 text-white transition-transform duration-150"
                                            />
                                          )}
                                          <span className="text-[14px] font-medium whitespace-nowrap truncate">
                                            {child.label}
                                          </span>
                                        </NavLink>
                                      </li>
                                    );
                                  })}
                              </ul>
                            </div>
                          ))
                        ) : (
                          <ul className="space-y-1 pt-0.5">
                            {item.children.map((child) => {
                              const ChildIcon = iconMap[child.icon];
                              return (
                                <li key={child.path}>
                                  <NavLink
                                    to={child.path}
                                    className={childLinkClasses}
                                  >
                                    {ChildIcon && (
                                      <ChildIcon
                                        size={19}
                                        className="flex-shrink-0 text-white transition-transform duration-150"
                                      />
                                    )}
                                    <span className="text-[14px] font-medium whitespace-nowrap truncate">
                                      {child.label}
                                    </span>
                                  </NavLink>
                                </li>
                              );
                            })}
                          </ul>
                        )}
                      </div>
                    )}
                  </li>
                );
              }

              // --- Direct link (no children) ---
              return (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    className={topLinkClasses}
                    title={!sidebarOpen ? item.label : ""}
                  >
                    {Icon && <Icon size={21} className="flex-shrink-0 text-white transition-transform duration-150" />}
                    {sidebarOpen && (
                      <span className="text-[15px] font-medium whitespace-nowrap">
                        {item.label}
                      </span>
                    )}
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Footer - User Info */}
        <div className="p-3.5 border-t border-white/10 bg-black flex-shrink-0">
          <div className="flex items-center gap-3 px-2">
            {/* Avatar */}
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={localUser?.name || "User"}
                className="w-10 h-10 rounded-full object-cover flex-shrink-0 border border-white/20"
                onError={(e) => {
                  e.target.style.display = "none";
                }}
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                {getUserInitials()}
              </div>
            )}

            {sidebarOpen && (
              <div className="min-w-0 flex-1">
                <p className="text-[15px] font-medium text-gray-200 truncate">
                  {localUser?.name || "User"}
                </p>
                <p className="text-xs text-gray-400 truncate">
                  {localUser?.email || "No email"}
                </p>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;