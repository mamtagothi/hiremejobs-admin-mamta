// import { useState, useEffect } from "react";
// import { motion, AnimatePresence } from "framer-motion";
// import {
//   MdPerson,
//   MdLock,
//   MdEmail,
//   MdPhone,
//   MdAdminPanelSettings,
//   MdBadge,
//   MdVisibility,
//   MdVisibilityOff,
//   MdErrorOutline,
//   MdInfoOutline,
//   MdSave,
//   MdVpnKey,
//   MdShield,
//   MdCheckCircle,
//   MdEdit,
//   MdCancel,
//   MdCloudUpload,
//   MdClose,
//   MdImage,
//   MdDateRange,
//   MdUpdate,
// } from "react-icons/md";
// import { useAuth } from "../../context/AuthContext";
// import authService from "../../services/auth.service";
// import { showSuccess, showError } from "../../utils/toast";
// import { getInitials } from "../../utils/helpers";

// const API_BASE =
//   import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

// // ─── Helper: build full image URL ───────────────────────────────
// const buildImageUrl = (value) => {
//   if (!value || typeof value !== "string") return null;
//   if (value.startsWith("http") || value.startsWith("data:")) return value;
//   if (value.startsWith("/uploads/")) return `${API_BASE}${value}`;
//   if (value.startsWith("./uploads/")) return `${API_BASE}${value.substring(1)}`;
//   if (value.startsWith("/")) return `${API_BASE}${value}`;
//   return `${API_BASE}/uploads/${value}`;
// };

// // ─── Helper: read user from localStorage safely ────────────────
// const readStoredUser = () => {
//   try {
//     const stored = localStorage.getItem("user");
//     return stored ? JSON.parse(stored) : null;
//   } catch {
//     return null;
//   }
// };

// // ─── Helper: write user to localStorage safely ─────────────────
// const writeStoredUser = (userData) => {
//   try {
//     localStorage.setItem("user", JSON.stringify(userData));
//   } catch {
//     /* ignore */
//   }
// };

// // ─── Helper: format date ────────────────────────────────────────
// const formatDateTime = (value) => {
//   if (!value) return "—";

//   const date = new Date(value);

//   if (Number.isNaN(date.getTime())) {
//     return "—";
//   }

//   return date.toLocaleString("en-IN", {
//     day: "2-digit",
//     month: "short",
//     year: "numeric",
//     hour: "2-digit",
//     minute: "2-digit",
//     hour12: true,
//   });
// };

// // ─── Helper: role mapping ───────────────────────────────────────
// const getRoleName = (roleId) => {
//   const roles = {
//     1: "Super Admin",
//     2: "Admin",
//     3: "Manager",
//     4: "User",
//   };
//   return roles[roleId] || (roleId ? `Role ${roleId}` : "—");
// };

// // ─── Shared components ──────────────────────────────────────────
// const FieldLabel = ({ children, required }) => (
//   <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
//     {children}
//     {required && <span className="text-red-500 ml-0.5">*</span>}
//   </label>
// );

// const TextInput = ({
//   label,
//   required,
//   icon: Icon,
//   error,
//   hint,
//   rightSlot,
//   className = "",
//   ...props
// }) => (
//   <div className={className}>
//     <FieldLabel required={required}>{label}</FieldLabel>
//     <div className="relative">
//       {Icon && (
//         <Icon
//           className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//           size={18}
//         />
//       )}
//       <input
//         {...props}
//         className={`w-full ${Icon ? "pl-10" : "pl-3.5"} ${
//           rightSlot ? "pr-12" : "pr-4"
//         } py-2.5 border rounded-lg text-sm focus:outline-none transition-all ${
//           error
//             ? "border-red-300 focus:ring-2 focus:ring-red-500/20"
//             : "border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
//         } bg-white`}
//       />
//       {rightSlot && (
//         <div className="absolute right-3 top-1/2 -translate-y-1/2">
//           {rightSlot}
//         </div>
//       )}
//     </div>
//     {error ? (
//       <p className="text-xs text-red-500 mt-1">{error}</p>
//     ) : hint ? (
//       <p className="text-xs text-slate-500 mt-1.5">{hint}</p>
//     ) : null}
//   </div>
// );

// const ReadOnlyField = ({ label, value, icon: Icon, className = "" }) => (
//   <div className={className}>
//     <p className="block text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-1.5">
//       {label}
//     </p>
//     <div className="flex items-center gap-2 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg">
//       {Icon && <Icon size={16} className="text-slate-400 flex-shrink-0" />}
//       <span className="text-sm text-slate-800 truncate">
//         {value === undefined || value === null || value === "" ? (
//           <span className="text-slate-400">—</span>
//         ) : (
//           value
//         )}
//       </span>
//     </div>
//   </div>
// );

// // ─── Image preview field for view mode ─────────────────────────
// const ReadOnlyImageField = ({ label, image, className = "" }) => {
//   const url = buildImageUrl(image);

//   return (
//     <div className={className}>
//       <p className="block text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-1.5">
//         {label}
//       </p>

//       <div className="flex items-center justify-center px-3.5 py-4 bg-slate-50 border border-slate-200 rounded-lg">
//         {url ? (
//           <img
//             src={url}
//             alt="Profile"
//             className="w-24 h-24 rounded-xl object-cover border border-slate-200 bg-white shadow-sm"
//             onError={(e) => {
//               e.target.style.display = "none";
//             }}
//           />
//         ) : (
//           <div className="w-24 h-24 rounded-xl bg-slate-100 border border-dashed border-slate-300 flex items-center justify-center">
//             <MdImage size={28} className="text-slate-400" />
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };
// // ─── Disabled/read-only styled input ───────────────────────────
// const DisabledTextInput = ({
//   label,
//   icon: Icon,
//   value,
//   hint,
//   className = "",
// }) => (
//   <div className={className}>
//     <FieldLabel>{label}</FieldLabel>
//     <div className="relative">
//       {Icon && (
//         <Icon
//           className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//           size={18}
//         />
//       )}
//       <input
//         type="text"
//         value={value || ""}
//         readOnly
//         disabled
//         className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-100 text-slate-500 cursor-not-allowed"
//       />
//     </div>
//     {hint && <p className="text-xs text-slate-500 mt-1.5">{hint}</p>}
//   </div>
// );

// // ─── Tabs ────────────────────────────────────────────────────────
// const TABS = [
//   { id: "profile", label: "Profile Info", icon: MdPerson },
//   { id: "password", label: "Change Password", icon: MdLock },
// ];

// // ─── Main Component ─────────────────────────────────────────────
// const Profile = () => {
//   const { user, token, updateUser } = useAuth();
//   const [activeTab, setActiveTab] = useState("profile");
//   const [saving, setSaving] = useState(false);
//   const [pwError, setPwError] = useState(null);

//   // ─── Local user state (initialized from localStorage for freshest data) ──
//   // Priority: localStorage → auth context. This makes sure that after a
//   // refresh the page shows the newest name/email/mobile/image from the API,
//   // not a stale cached copy from the auth provider.
//   const [profileUser, setProfileUser] = useState(() => {
//     const stored = readStoredUser();
//     return stored || user || {};
//   });
//   const [isEditing, setIsEditing] = useState(false);

//   // Sync from auth context whenever it changes (login/logout/etc.)
//   useEffect(() => {
//     if (user && (!profileUser?.id || user.id === profileUser.id)) {
//       // Prefer stored data if it's newer, otherwise use context
//       const stored = readStoredUser();
//       if (stored && stored.id === user.id) {
//         setProfileUser(stored);
//       } else {
//         setProfileUser(user);
//       }
//     }
//   }, [user]);

//   // Listen for updates dispatched by other parts of the app or other tabs
//   useEffect(() => {
//     const handleUpdate = (e) => {
//       if (e?.detail) {
//         setProfileUser((prev) => ({ ...prev, ...e.detail }));
//       } else {
//         const stored = readStoredUser();
//         if (stored) setProfileUser(stored);
//       }
//     };
//     window.addEventListener("user:updated", handleUpdate);
//     window.addEventListener("storage", handleUpdate);
//     return () => {
//       window.removeEventListener("user:updated", handleUpdate);
//       window.removeEventListener("storage", handleUpdate);
//     };
//   }, []);

//   const [form, setForm] = useState({
//     name: profileUser?.name || "",
//     mobile: profileUser?.mobile || "",
//   });

//   // Keep form fields in sync if profileUser changes from outside
//   useEffect(() => {
//     if (!isEditing) {
//       setForm({
//         name: profileUser?.name || "",
//         mobile: profileUser?.mobile || "",
//       });
//     }
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [profileUser?.name, profileUser?.mobile]);

//   const [avatarFile, setAvatarFile] = useState(null);
//   const [avatarPreview, setAvatarPreview] = useState(null);
//   const [avatarRemoved, setAvatarRemoved] = useState(false);

//   // ─── Change Password form state (camelCase to match the API) ──
//   const [pwForm, setPwForm] = useState({
//     oldPassword: "",
//     newPassword: "",
//     confirmPassword: "",
//   });

//   const [showOld, setShowOld] = useState(false);
//   const [showNew, setShowNew] = useState(false);
//   const [showConfirm, setShowConfirm] = useState(false);

//   // ─── Start / Cancel edit ───────────────────────────────────
//   const handleStartEdit = () => {
//     setForm({
//       name: profileUser?.name || "",
//       mobile: profileUser?.mobile || "",
//     });
//     setAvatarFile(null);
//     setAvatarPreview(null);
//     setAvatarRemoved(false);
//     setIsEditing(true);
//   };

//   const handleCancelEdit = () => {
//     setIsEditing(false);
//     setAvatarFile(null);
//     setAvatarPreview(null);
//     setAvatarRemoved(false);
//   };

//   const handleAvatarChange = (file) => {
//     if (!file) return;
//     const validTypes = [
//       "image/jpeg",
//       "image/jpg",
//       "image/png",
//       "image/gif",
//       "image/webp",
//       "image/avif",
//       "image/svg+xml",
//     ];
//     if (!validTypes.includes(file.type)) {
//       showError(
//         "Please upload a valid image file (JPEG, PNG, GIF, WEBP, AVIF, SVG)",
//       );
//       return;
//     }
//     if (file.size > 5 * 1024 * 1024) {
//       showError("Image size must be less than 5MB");
//       return;
//     }
//     const reader = new FileReader();
//     reader.onloadend = () => setAvatarPreview(reader.result);
//     reader.readAsDataURL(file);
//     setAvatarFile(file);
//     setAvatarRemoved(false);
//   };

//   const handleAvatarRemove = () => {
//     setAvatarPreview(null);
//     setAvatarFile(null);
//     setAvatarRemoved(true);
//     const fileInput = document.getElementById("avatar-upload");
//     if (fileInput) fileInput.value = "";
//   };

//   // ─── Profile Save (multipart/form-data like Postman) ───────
//   const handleProfileSave = async (e) => {
//     e.preventDefault();

//     const name = form.name?.trim();
//     const mobile = form.mobile?.trim();
//     // Email is read-only — always use the current value
//     const email = profileUser?.email || "";

//     if (!name) return showError("Name is required");
//     if (name.length < 2) return showError("Name must be at least 2 characters");
//     if (mobile && !/^[0-9+\-\s()]{6,20}$/.test(mobile))
//       return showError("Please enter a valid mobile number");

//     setSaving(true);
//     try {
//       const formData = new FormData();
//       formData.append("name", name);
//       formData.append("email", email);
//       formData.append("mobile", mobile || "");

//       if (avatarFile instanceof File) {
//         formData.append("image", avatarFile);
//       } else if (avatarRemoved) {
//         formData.append("image", "");
//       }

//       // PATCH /user/{id}   with multipart/form-data
//       const response = await fetch(`${API_BASE}/user/${profileUser?.id}`, {
//         method: "PATCH",
//         headers: {
//           Authorization: token ? `Bearer ${token}` : "",
//           // Don't set Content-Type — the browser sets the multipart boundary
//         },
//         body: formData,
//       });

//       const result = await response.json();
//       if (!response.ok || result?.success === false) {
//         throw new Error(result?.message || "Failed to update profile");
//       }

//       // ─── API may return data as an array or an object ──
//       let updated = null;
//       if (result?.data) {
//         if (Array.isArray(result.data)) {
//           updated = result.data[0] || null;
//         } else if (typeof result.data === "object") {
//           updated = result.data.user || result.data;
//         }
//       }

//       // Build the merged user object. Prefer values from the API response,
//       // fall back to what the user just typed.
//       const mergedUser = {
//         ...profileUser,
//         name,
//         email,
//         mobile,
//         ...(updated && typeof updated === "object" ? updated : {}),
//       };

//       // ─── Persist to localStorage FIRST (this is what was missing) ──
//       // Without this step, refreshing the page reverted to the old name
//       // because AuthContext re-hydrated from stale storage.
//       writeStoredUser(mergedUser);

//       // Update local state so the UI reflects changes immediately
//       setProfileUser(mergedUser);

//       // Update the global auth context if available
//       if (typeof updateUser === "function") {
//         updateUser(mergedUser);
//       }

//       // Notify any other listeners in the app (sidebar, header, etc.)
//       try {
//         window.dispatchEvent(
//           new CustomEvent("user:updated", { detail: mergedUser }),
//         );
//       } catch {
//         /* ignore */
//       }

//       setIsEditing(false);
//       setAvatarFile(null);
//       setAvatarPreview(null);
//       setAvatarRemoved(false);
//       showSuccess(result?.message || "Profile updated successfully");
//     } catch (err) {
//       console.error("Profile update error:", err);
//       showError(err?.message || "Failed to update profile");
//     } finally {
//       setSaving(false);
//     }
//   };

//   // ─── Password change (uses /user/reset-password) ───────────
//   const handlePasswordChange = async (e) => {
//     e.preventDefault();
//     setPwError(null);

//     const { oldPassword, newPassword, confirmPassword } = pwForm;

//     // ─── Client-side validation ─────────────────────────────
//     if (!oldPassword || !newPassword || !confirmPassword) {
//       const msg = "All fields are required";
//       setPwError(msg);
//       showError(msg);
//       return;
//     }
//     if (newPassword !== confirmPassword) {
//       const msg = "New password and confirm password do not match";
//       setPwError(msg);
//       showError(msg);
//       return;
//     }
//     if (newPassword.length < 6) {
//       const msg = "New password must be at least 6 characters";
//       setPwError(msg);
//       showError(msg);
//       return;
//     }
//     if (!profileUser?.email) {
//       const msg = "User email not found. Please login again.";
//       setPwError(msg);
//       showError(msg);
//       return;
//     }

//     setSaving(true);
//     try {
//       // PATCH /user/reset-password/
//       // Payload matches the API contract:
//       //   { email, oldPassword, newPassword, confirmPassword }
//       const payload = {
//         email: profileUser.email,
//         oldPassword,
//         newPassword,
//         confirmPassword,
//       };

//       const response = await fetch(`${API_BASE}/user/reset-password/`, {
//         method: "PATCH",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: token ? `Bearer ${token}` : "",
//         },
//         body: JSON.stringify(payload),
//       });

//       const result = await response.json();

//       if (!response.ok || result?.success === false) {
//         throw new Error(result?.message || "Failed to change password");
//       }

//       showSuccess(result?.message || "Password changed successfully");
//       setPwForm({
//         oldPassword: "",
//         newPassword: "",
//         confirmPassword: "",
//       });
//       setPwError(null);
//       setShowOld(false);
//       setShowNew(false);
//       setShowConfirm(false);
//     } catch (err) {
//       console.error("Password change error:", err);
//       const msg =
//         err?.response?.data?.message ||
//         err?.message ||
//         "Failed to change password";
//       setPwError(msg);
//       showError(msg);
//     } finally {
//       setSaving(false);
//     }
//   };

//   // ─── Hero helpers ──────────────────────────────────────────
//   const fullName = profileUser?.name || "User";
//   const initials =
//     getInitials(profileUser?.name || "") || (fullName[0]?.toUpperCase() ?? "U");
//   const roleLabel = getRoleName(profileUser?.role_id);

//   const avatarUrl = isEditing
//     ? avatarPreview ||
//       (avatarRemoved ? null : buildImageUrl(profileUser?.image))
//     : buildImageUrl(profileUser?.image);

//   // ─── Render Tab Content ────────────────────────────────────
//   const renderTabContent = () => {
//     switch (activeTab) {
//       case "profile":
//         return (
//           <div className="space-y-6">
//             {/* Header */}
//             <div className="flex items-start justify-between gap-3 flex-wrap">
//               <div>
//                 <h3 className="text-base font-semibold text-slate-800">
//                   Profile Information
//                 </h3>
//                 <p className="text-xs text-slate-500 mt-0.5">
//                   {isEditing
//                     ? "Update your personal details below."
//                     : "Your personal information on file."}
//                 </p>
//               </div>
//               {!isEditing && (
//                 <button
//                   type="button"
//                   onClick={handleStartEdit}
//                   className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 text-sm font-semibold rounded-lg transition-colors"
//                 >
//                   <MdEdit size={16} />
//                   Edit Profile
//                 </button>
//               )}
//             </div>

//             {isEditing ? (
//               // ─── Edit Mode ─────────────────────────────────
//               <form onSubmit={handleProfileSave} className="space-y-5">
//                 {/* Avatar */}
//                 <div>
//                   <FieldLabel>Profile Photo</FieldLabel>
//                   <div className="flex items-center gap-4">
//                     {avatarUrl ? (
//                       <div className="relative">
//                         <img
//                           src={avatarUrl}
//                           alt="Profile"
//                           className="w-20 h-20 rounded-full object-cover border-2 border-slate-200 shadow-sm"
//                         />
//                         <button
//                           type="button"
//                           onClick={handleAvatarRemove}
//                           className="absolute -top-1 -right-1 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
//                           aria-label="Remove photo"
//                         >
//                           <MdClose size={12} />
//                         </button>
//                       </div>
//                     ) : (
//                       <div className="w-20 h-20 rounded-full bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center">
//                         <MdImage size={28} className="text-slate-400" />
//                       </div>
//                     )}
//                     <div>
//                       <input
//                         type="file"
//                         accept="image/*"
//                         onChange={(e) =>
//                           handleAvatarChange(e.target.files?.[0])
//                         }
//                         className="hidden"
//                         id="avatar-upload"
//                       />
//                       <label
//                         htmlFor="avatar-upload"
//                         className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors text-sm font-medium inline-flex items-center gap-2"
//                       >
//                         <MdCloudUpload size={16} />
//                         Choose Photo
//                       </label>
//                       <p className="mt-1 text-xs text-slate-400">
//                         JPEG, PNG, GIF, WEBP (Max 5MB)
//                       </p>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
//                   <TextInput
//                     label="Full Name"
//                     required
//                     icon={MdPerson}
//                     value={form.name}
//                     onChange={(e) => setForm({ ...form, name: e.target.value })}
//                     placeholder="Enter your full name"
//                     className="sm:col-span-2"
//                   />

//                   {/* Email — read-only, cannot be changed */}
//                   <DisabledTextInput
//                     label="Email"
//                     icon={MdEmail}
//                     value={profileUser?.email || ""}
//                     hint="Email address cannot be changed."
//                     className="sm:col-span-2"
//                   />

//                   <TextInput
//                     label="Mobile"
//                     icon={MdPhone}
//                     value={form.mobile}
//                     onChange={(e) =>
//                       setForm({ ...form, mobile: e.target.value })
//                     }
//                     placeholder="9876543210"
//                     className="sm:col-span-2"
//                   />
//                 </div>

//                 <div className="flex items-center gap-3 pt-1">
//                   <button
//                     type="submit"
//                     disabled={saving}
//                     className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
//                   >
//                     {saving ? (
//                       <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
//                     ) : (
//                       <MdSave size={16} />
//                     )}
//                     {saving ? "Saving..." : "Save Changes"}
//                   </button>
//                   <button
//                     type="button"
//                     onClick={handleCancelEdit}
//                     disabled={saving}
//                     className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
//                   >
//                     <MdCancel size={16} />
//                     Cancel
//                   </button>
//                 </div>
//               </form>
//             ) : (
//               // ─── View Mode (all info shown) ────────────────
//               <div className="space-y-5">
//                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
//                   <ReadOnlyField
//                     label="User ID"
//                     value={profileUser?.id}
//                     icon={MdBadge}
//                   />
//                   <ReadOnlyField
//                     label="Role"
//                     value={roleLabel}
//                     icon={MdAdminPanelSettings}
//                   />
//                   <ReadOnlyField
//                     label="Full Name"
//                     value={profileUser?.name}
//                     icon={MdPerson}
//                   />
//                   <ReadOnlyField
//                     label="Email Address"
//                     value={profileUser?.email}
//                     icon={MdEmail}
//                   />
//                   <ReadOnlyField
//                     label="Mobile Number"
//                     value={profileUser?.mobile}
//                     icon={MdPhone}
//                   />

//                   {/* Profile image preview */}
//                   <ReadOnlyImageField
//                     label="Profile Image"
//                     image={profileUser?.image}
//                   />

//                   <ReadOnlyField
//                     label="Created At"
//                     value={formatDateTime(
//                       profileUser?.createdAt || profileUser?.created_at,
//                     )}
//                     icon={MdDateRange}
//                   />
//                   <ReadOnlyField
//                     label="Last Updated"
//                     value={formatDateTime(
//                       profileUser?.updatedAt || profileUser?.updated_at,
//                     )}
//                     icon={MdUpdate}
//                   />
//                 </div>
//               </div>
//             )}
//           </div>
//         );

//       case "password":
//         return (
//           <form
//             onSubmit={handlePasswordChange}
//             className="space-y-5 max-w-xl"
//             autoComplete="off"
//           >
//             {pwError && (
//               <div className="flex items-start gap-2.5 px-3.5 py-3 bg-red-50 border border-red-200 rounded-lg">
//                 <MdErrorOutline
//                   size={16}
//                   className="text-red-500 mt-0.5 flex-shrink-0"
//                 />
//                 <p className="text-xs text-red-700 leading-relaxed">
//                   {pwError}
//                 </p>
//               </div>
//             )}

//             <TextInput
//               label="Current Password"
//               type={showOld ? "text" : "password"}
//               required
//               icon={MdLock}
//               value={pwForm.oldPassword}
//               onChange={(e) =>
//                 setPwForm({ ...pwForm, oldPassword: e.target.value })
//               }
//               placeholder="Enter your current password"
//               rightSlot={
//                 <button
//                   type="button"
//                   onClick={() => setShowOld((v) => !v)}
//                   className="text-slate-400 hover:text-slate-600 transition-colors"
//                   tabIndex={-1}
//                 >
//                   {showOld ? (
//                     <MdVisibilityOff size={20} />
//                   ) : (
//                     <MdVisibility size={20} />
//                   )}
//                 </button>
//               }
//             />

//             <TextInput
//               label="New Password"
//               type={showNew ? "text" : "password"}
//               required
//               icon={MdVpnKey}
//               value={pwForm.newPassword}
//               onChange={(e) =>
//                 setPwForm({ ...pwForm, newPassword: e.target.value })
//               }
//               placeholder="Enter your new password (min 6 characters)"
//               hint="Minimum 6 characters. Use a mix of letters, numbers and symbols."
//               rightSlot={
//                 <button
//                   type="button"
//                   onClick={() => setShowNew((v) => !v)}
//                   className="text-slate-400 hover:text-slate-600 transition-colors"
//                   tabIndex={-1}
//                 >
//                   {showNew ? (
//                     <MdVisibilityOff size={20} />
//                   ) : (
//                     <MdVisibility size={20} />
//                   )}
//                 </button>
//               }
//             />

//             <TextInput
//               label="Confirm New Password"
//               type={showConfirm ? "text" : "password"}
//               required
//               icon={MdLock}
//               value={pwForm.confirmPassword}
//               onChange={(e) =>
//                 setPwForm({ ...pwForm, confirmPassword: e.target.value })
//               }
//               placeholder="Re-enter your new password"
//               rightSlot={
//                 <button
//                   type="button"
//                   onClick={() => setShowConfirm((v) => !v)}
//                   className="text-slate-400 hover:text-slate-600 transition-colors"
//                   tabIndex={-1}
//                 >
//                   {showConfirm ? (
//                     <MdVisibilityOff size={20} />
//                   ) : (
//                     <MdVisibility size={20} />
//                   )}
//                 </button>
//               }
//             />

//             <div className="flex items-center gap-3 pt-1">
//               <button
//                 type="submit"
//                 disabled={saving}
//                 className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
//               >
//                 {saving ? (
//                   <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
//                 ) : (
//                   <MdShield size={16} />
//                 )}
//                 {saving ? "Updating..." : "Change Password"}
//               </button>
//               <button
//                 type="button"
//                 onClick={() => {
//                   setPwForm({
//                     oldPassword: "",
//                     newPassword: "",
//                     confirmPassword: "",
//                   });
//                   setPwError(null);
//                 }}
//                 disabled={saving}
//                 className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
//               >
//                 Clear
//               </button>
//             </div>
//           </form>
//         );

//       default:
//         return null;
//     }
//   };

//   // ─── Main render ─────────────────────────────────────────────
//   return (
//     <div className="min-h-screen pb-16 bg-[#F4F5FA]">
//       {/* ─── Sticky action bar ─────────────────────────────────── */}
//       <div className="bg-white/85 backdrop-blur-md border-b border-slate-200">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
//           <div className="flex items-center gap-3 min-w-0">
//             <div className="min-w-0">
//               <p className="text-[11px] text-slate-400 leading-tight">
//                 Account
//               </p>
//               <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
//                 My Profile
//               </p>
//             </div>
//           </div>
//           {/* <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-xs font-medium flex-shrink-0">
//             <MdCheckCircle size={13} className="text-emerald-500" />
//             Signed in
//           </span> */}
//         </div>
//       </div>

//       <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
//         {/* ─── Hero ───────────────────────────────────────────────── */}
//         <motion.div
//           initial={{ opacity: 0, y: 12 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.35, ease: "easeOut" }}
//           className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
//         >
//           <div className="relative h-44 sm:h-52 bg-gradient-to-br from-slate-950 via-indigo-950 to-purple-950">
//             <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
//             <div className="absolute inset-0 opacity-10">
//               <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
//               <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
//             </div>
//           </div>

//           <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
//             <div className="flex flex-col sm:flex-row sm:items-end gap-4">
//               {/* Avatar */}
//               <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 backdrop-blur-sm p-1.5 shadow-xl flex-shrink-0 border border-white/10">
//                 {avatarUrl ? (
//                   <img
//                     src={avatarUrl}
//                     alt={fullName}
//                     className="w-full h-full object-cover rounded-xl"
//                     onError={(e) => {
//                       e.target.style.display = "none";
//                     }}
//                   />
//                 ) : (
//                   <div className="w-full h-full rounded-xl bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white font-bold text-lg">
//                     {initials}
//                   </div>
//                 )}
//               </div>

//               {/* Name + chips */}
//               <div className="flex-1 min-w-0">
//                 <div className="flex items-center gap-2 flex-wrap">
//                   <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
//                     {fullName}
//                   </h1>
//                   {profileUser?.role_id && (
//                     <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-400/20 text-indigo-200 ring-1 ring-indigo-400/30">
//                       <MdAdminPanelSettings size={12} />
//                       {roleLabel}
//                     </span>
//                   )}
//                 </div>
//                 <div className="mt-2 flex items-center gap-2 flex-wrap">
//                   {profileUser?.email && (
//                     <span className="text-xs text-white/70">
//                       {profileUser.email}
//                     </span>
//                   )}
//                   {profileUser?.mobile && (
//                     <span className="text-xs text-white/70">
//                       • {profileUser.mobile}
//                     </span>
//                   )}
//                   {profileUser?.id && (
//                     <span className="text-xs text-white/50">
//                       ID #{profileUser.id}
//                     </span>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </motion.div>

//         {/* ─── Quick stat strip ──────────────────────────────────── */}
//         <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
//           <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
//             <MdPerson size={16} className="text-slate-400 flex-shrink-0" />
//             <div className="min-w-0">
//               <p className="text-[10px] text-slate-500 leading-tight">Name</p>
//               <p className="text-sm font-semibold text-slate-700 truncate">
//                 {profileUser?.name || "—"}
//               </p>
//             </div>
//           </div>
//           <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
//             <MdEmail size={16} className="text-slate-400 flex-shrink-0" />
//             <div className="min-w-0">
//               <p className="text-[10px] text-slate-500 leading-tight">Email</p>
//               <p className="text-sm font-semibold text-slate-700 truncate">
//                 {profileUser?.email || "—"}
//               </p>
//             </div>
//           </div>
//           <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
//             <MdPhone size={16} className="text-slate-400 flex-shrink-0" />
//             <div className="min-w-0">
//               <p className="text-[10px] text-slate-500 leading-tight">Mobile</p>
//               <p className="text-sm font-semibold text-slate-700 truncate">
//                 {profileUser?.mobile || "—"}
//               </p>
//             </div>
//           </div>
//           <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
//             <MdBadge size={16} className="text-slate-400 flex-shrink-0" />
//             <div className="min-w-0">
//               <p className="text-[10px] text-slate-500 leading-tight">Role</p>
//               <p className="text-sm font-semibold text-slate-700 truncate">
//                 {roleLabel}
//               </p>
//             </div>
//           </div>
//         </div>

//         {/* ─── Tabs ───────────────────────────────────────────────── */}
//         <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
//           <div className="flex w-full border-b border-slate-200">
//             {TABS.map((tab) => {
//               const Icon = tab.icon;
//               const active = activeTab === tab.id;

//               return (
//                 <button
//                   key={tab.id}
//                   type="button"
//                   onClick={() => setActiveTab(tab.id)}
//                   className={`relative flex-1 w-full flex items-center justify-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
//                     active
//                       ? "text-blue-600"
//                       : "text-slate-500 hover:text-slate-700"
//                   }`}
//                 >
//                   <Icon size={16} />
//                   {tab.label}

//                   {active && (
//                     <motion.span
//                       layoutId="profile-tab-underline"
//                       className="absolute left-0 right-0 -bottom-px h-0.5 bg-blue-600 rounded-full"
//                       transition={{
//                         type: "spring",
//                         stiffness: 500,
//                         damping: 35,
//                       }}
//                     />
//                   )}
//                 </button>
//               );
//             })}
//           </div>

//           <div className="p-5 sm:p-7">
//             <AnimatePresence mode="wait">
//               <motion.div
//                 key={activeTab}
//                 initial={{ opacity: 0, y: 6 }}
//                 animate={{ opacity: 1, y: 0 }}
//                 exit={{ opacity: 0, y: -6 }}
//                 transition={{ duration: 0.18 }}
//               >
//                 {renderTabContent()}
//               </motion.div>
//             </AnimatePresence>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Profile;

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MdPerson,
  MdLock,
  MdEmail,
  MdPhone,
  MdAdminPanelSettings,
  MdBadge,
  MdVisibility,
  MdVisibilityOff,
  MdErrorOutline,
  MdInfoOutline,
  MdSave,
  MdVpnKey,
  MdShield,
  MdCheckCircle,
  MdEdit,
  MdCancel,
  MdCloudUpload,
  MdClose,
  MdImage,
  MdDateRange,
  MdUpdate,
} from "react-icons/md";
import { useAuth } from "../../context/AuthContext";
import authService from "../../services/auth.service";
import { showSuccess, showError } from "../../utils/toast";
import { getInitials } from "../../utils/helpers";

const API_BASE =
  import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

// ─── Helper: build full image URL ───────────────────────────────
const buildImageUrl = (value) => {
  if (!value || typeof value !== "string") return null;
  if (value.startsWith("http") || value.startsWith("data:")) return value;
  if (value.startsWith("/uploads/")) return `${API_BASE}${value}`;
  if (value.startsWith("./uploads/")) return `${API_BASE}${value.substring(1)}`;
  if (value.startsWith("/")) return `${API_BASE}${value}`;
  return `${API_BASE}/uploads/${value}`;
};

// ─── Helper: read user from localStorage safely ────────────────
const readStoredUser = () => {
  try {
    const stored = localStorage.getItem("user");
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
};

// ─── Helper: write user to localStorage safely ─────────────────    
const writeStoredUser = (userData) => {
  try {
    localStorage.setItem("user", JSON.stringify(userData));
  } catch {
    /* ignore */
  }
};

// ─── Helper: format date ────────────────────────────────────────
const formatDateTime = (value) => {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

// ─── Helper: role mapping ───────────────────────────────────────
const getRoleName = (roleId) => {
  const roles = {
    1: "Super Admin",
    2: "Admin",
    3: "Manager",
    4: "User",
  };
  return roles[roleId] || (roleId ? `Role ${roleId}` : "—");
};

// ─── Shared components ──────────────────────────────────────────
const FieldLabel = ({ children, required }) => (
  <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
    {children}
    {required && <span className="text-red-500 ml-0.5">*</span>}
  </label>
);

const TextInput = ({
  label,
  required,
  icon: Icon,
  error,
  hint,
  rightSlot,
  className = "",
  ...props
}) => (
  <div className={className}>
    <FieldLabel required={required}>{label}</FieldLabel>
    <div className="relative">
      {Icon && (
        <Icon
          className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          size={18}
        />
      )}
      <input
        {...props}
        className={`w-full ${Icon ? "pl-10" : "pl-3.5"} ${
          rightSlot ? "pr-12" : "pr-4"
        } py-2.5 border rounded-lg text-sm focus:outline-none transition-all ${
          error
            ? "border-red-300 focus:ring-2 focus:ring-red-500/20"
            : "border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
        } bg-white`}
      />
      {rightSlot && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          {rightSlot}
        </div>
      )}
    </div>
    {error ? (
      <p className="text-xs text-red-500 mt-1">{error}</p>
    ) : hint ? (
      <p className="text-xs text-slate-500 mt-1.5">{hint}</p>
    ) : null}
  </div>
);

const ReadOnlyField = ({ label, value, icon: Icon, className = "" }) => (
  <div className={className}>
    <p className="block text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-1.5">
      {label}
    </p>
    <div className="flex items-center gap-2 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg">
      {Icon && <Icon size={16} className="text-slate-400 flex-shrink-0" />}
      <span className="text-sm text-slate-800 truncate">
        {value === undefined || value === null || value === "" ? (
          <span className="text-slate-400">—</span>
        ) : (
          value
        )}
      </span>
    </div>
  </div>
);

// ─── Image preview field for view mode ─────────────────────────
const ReadOnlyImageField = ({ label, image, className = "" }) => {
  const url = buildImageUrl(image);

  return (
    <div className={className}>
      <p className="block text-[11px] font-medium text-slate-500 uppercase tracking-wide mb-1.5">
        {label}
      </p>

      <div className="flex items-center justify-center px-3.5 py-4 bg-slate-50 border border-slate-200 rounded-lg">
        {url ? (
          <img
            src={url}
            alt="Profile"
            className="w-24 h-24 rounded-xl object-cover border border-slate-200 bg-white shadow-sm"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
        ) : (
          <div className="w-24 h-24 rounded-xl bg-slate-100 border border-dashed border-slate-300 flex items-center justify-center">
            <MdImage size={28} className="text-slate-400" />
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Disabled/read-only styled input ───────────────────────────
const DisabledTextInput = ({
  label,
  icon: Icon,
  value,
  hint,
  className = "",
}) => (
  <div className={className}>
    <FieldLabel>{label}</FieldLabel>
    <div className="relative">
      {Icon && (
        <Icon
          className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          size={18}
        />
      )}
      <input
        type="text"
        value={value || ""}
        readOnly
        disabled
        className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-100 text-slate-500 cursor-not-allowed"
      />
    </div>
    {hint && <p className="text-xs text-slate-500 mt-1.5">{hint}</p>}
  </div>
);

// ─── Tabs ────────────────────────────────────────────────────────
const TABS = [
  { id: "profile", label: "Profile Info", icon: MdPerson },
  { id: "password", label: "Change Password", icon: MdLock },
];

// ─── Normalize API response into a user object ────────────────
// The API may return { data: {...} }, { data: [{...}] }, or a bare object.
const extractUserFromResponse = (result) => {
  if (!result || typeof result !== "object") return null;

  // Try the usual wrappers
  if (result.data) {
    if (Array.isArray(result.data) && result.data.length > 0) {
      return result.data[0];
    }
    if (typeof result.data === "object") {
      // Nested user object
      if (result.data.user && typeof result.data.user === "object") {
        return result.data.user;
      }
      return result.data;
    }
  }

  // Bare object with an id
  if (result.id || result._id) return result;

  return null;
};

// ─── Main Component ─────────────────────────────────────────────
const Profile = () => {
  const { user, token, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState("profile");
  const [saving, setSaving] = useState(false);
  const [pwError, setPwError] = useState(null);
  const [profileLoading, setProfileLoading] = useState(true);

  // ─── Local user state ──────────────────────────────────────
  // Initialized from localStorage (fast paint) or the auth context.
  // Then replaced with the fresh API response.
  const [profileUser, setProfileUser] = useState(() => {
    const stored = readStoredUser();
    return stored || user || {};
  });
  const [isEditing, setIsEditing] = useState(false);

  // ─── Fetch fresh profile from /user/:id on mount ──────────
  // Uses the user id from auth context if available, otherwise falls
  // back to the localStorage user. This ensures the page always shows
  // the most current data from the server, not a stale cached copy.
  useEffect(() => {
    let cancelled = false;

    const fetchProfile = async () => {
      try {
        // Resolve the id from auth context first, then localStorage
        const storedUser = readStoredUser();
        const userIdValue = user?.id || storedUser?.id;

        if (!userIdValue) {
          // No id available — keep whatever we already have
          if (!cancelled) setProfileLoading(false);
          return;
        }

        const response = await fetch(`${API_BASE}/user/${userIdValue}`, {
          method: "GET",
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to load profile (HTTP ${response.status})`);
        }

        const result = await response.json();
        const fetchedUser = extractUserFromResponse(result);

        if (!fetchedUser || cancelled) return;

        // Merge on top of what we have so we don't lose any fields
        const mergedUser = {
          ...(readStoredUser() || {}),
          ...(user || {}),
          ...fetchedUser,
        };

        setProfileUser(mergedUser);
        writeStoredUser(mergedUser);

        // Sync to global auth context if it supports updates
        if (typeof updateUser === "function") {
          updateUser(mergedUser);
        }
      } catch (error) {
        console.error("Profile fetch error:", error);
        // Silent fallback: keep the locally cached data
      } finally {
        if (!cancelled) setProfileLoading(false);
      }
    };

    fetchProfile();

    return () => {
      cancelled = true;
    };
  }, [user?.id, token]);

  // ─── Keep listening for auth context changes ──────────────
  useEffect(() => {
    if (user && (!profileUser?.id || user.id === profileUser.id)) {
      const stored = readStoredUser();
      if (stored && stored.id === user.id) {
        setProfileUser(stored);
      } else {
        setProfileUser(user);
      }
    }
  }, [user]);

  // ─── Listen for updates dispatched by other parts of the app ──
  useEffect(() => {
    const handleUpdate = (e) => {
      if (e?.detail) {
        setProfileUser((prev) => ({ ...prev, ...e.detail }));
      } else {
        const stored = readStoredUser();
        if (stored) setProfileUser(stored);
      }
    };
    window.addEventListener("user:updated", handleUpdate);
    window.addEventListener("storage", handleUpdate);
    return () => {
      window.removeEventListener("user:updated", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, []);

  const [form, setForm] = useState({
    name: profileUser?.name || "",
    mobile: profileUser?.mobile || "",
  });

  // Keep form fields in sync if profileUser changes from outside
  useEffect(() => {
    if (!isEditing) {
      setForm({
        name: profileUser?.name || "",
        mobile: profileUser?.mobile || "",
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileUser?.name, profileUser?.mobile]);

  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [avatarRemoved, setAvatarRemoved] = useState(false);

  // ─── Change Password form state (camelCase to match the API) ──
  const [pwForm, setPwForm] = useState({
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // ─── Start / Cancel edit ───────────────────────────────────
  const handleStartEdit = () => {
    setForm({
      name: profileUser?.name || "",
      mobile: profileUser?.mobile || "",
    });
    setAvatarFile(null);
    setAvatarPreview(null);
    setAvatarRemoved(false);
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setAvatarFile(null);
    setAvatarPreview(null);
    setAvatarRemoved(false);
  };

  const handleAvatarChange = (file) => {
    if (!file) return;
    const validTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/gif",
      "image/webp",
      "image/avif",
      "image/svg+xml",
    ];
    if (!validTypes.includes(file.type)) {
      showError(
        "Please upload a valid image file (JPEG, PNG, GIF, WEBP, AVIF, SVG)",
      );
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      showError("Image size must be less than 5MB");
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => setAvatarPreview(reader.result);
    reader.readAsDataURL(file);
    setAvatarFile(file);
    setAvatarRemoved(false);
  };

  const handleAvatarRemove = () => {
    setAvatarPreview(null);
    setAvatarFile(null);
    setAvatarRemoved(true);
    const fileInput = document.getElementById("avatar-upload");
    if (fileInput) fileInput.value = "";
  };

  // ─── Profile Save (multipart/form-data like Postman) ───────
  const handleProfileSave = async (e) => {
    e.preventDefault();

    const name = form.name?.trim();
    const mobile = form.mobile?.trim();
    // Email is read-only — always use the current value
    const email = profileUser?.email || "";

    if (!name) return showError("Name is required");
    if (name.length < 2) return showError("Name must be at least 2 characters");
    if (mobile && !/^[0-9+\-\s()]{6,20}$/.test(mobile))
      return showError("Please enter a valid mobile number");

    setSaving(true);
    try {
      const formData = new FormData();
      formData.append("name", name);
      formData.append("email", email);
      formData.append("mobile", mobile || "");

      if (avatarFile instanceof File) {
        formData.append("image", avatarFile);
      } else if (avatarRemoved) {
        formData.append("image", "");
      }

      // PATCH /user/{id}   with multipart/form-data
      const response = await fetch(`${API_BASE}/user/${profileUser?.id}`, {
        method: "PATCH",
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          // Don't set Content-Type — the browser sets the multipart boundary
        },
        body: formData,
      });

      const result = await response.json();
      if (!response.ok || result?.success === false) {
        throw new Error(result?.message || "Failed to update profile");
      }

      // ─── API may return data as an array or an object ──
      const updated = extractUserFromResponse(result);

      // Build the merged user object. Prefer values from the API response,
      // fall back to what the user just typed.
      const mergedUser = {
        ...profileUser,
        name,
        email,
        mobile,
        ...(updated && typeof updated === "object" ? updated : {}),
      };

      // Persist to localStorage FIRST so a refresh keeps the fresh data
      writeStoredUser(mergedUser);

      // Update local state so the UI reflects changes immediately
      setProfileUser(mergedUser);

      // Update the global auth context if available
      if (typeof updateUser === "function") {
        updateUser(mergedUser);
      }

      // Notify any other listeners in the app (sidebar, header, etc.)
      try {
        window.dispatchEvent(
          new CustomEvent("user:updated", { detail: mergedUser }),
        );
      } catch {
        /* ignore */
      }

      setIsEditing(false);
      setAvatarFile(null);
      setAvatarPreview(null);
      setAvatarRemoved(false);
      showSuccess(result?.message || "Profile updated successfully");
    } catch (err) {
      console.error("Profile update error:", err);
      showError(err?.message || "Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  // ─── Password change (uses /user/reset-password) ───────────
  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setPwError(null);

    const { oldPassword, newPassword, confirmPassword } = pwForm;

    // ─── Client-side validation ─────────────────────────────
    if (!oldPassword || !newPassword || !confirmPassword) {
      const msg = "All fields are required";
      setPwError(msg);
      showError(msg);
      return;
    }
    if (newPassword !== confirmPassword) {
      const msg = "New password and confirm password do not match";
      setPwError(msg);
      showError(msg);
      return;
    }
    if (newPassword.length < 6) {
      const msg = "New password must be at least 6 characters";
      setPwError(msg);
      showError(msg);
      return;
    }
    if (!profileUser?.email) {
      const msg = "User email not found. Please login again.";
      setPwError(msg);
      showError(msg);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        email: profileUser.email,
        oldPassword,
        newPassword,
        confirmPassword,
      };

      const response = await fetch(`${API_BASE}/user/reset-password/`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: token ? `Bearer ${token}` : "",
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok || result?.success === false) {
        throw new Error(result?.message || "Failed to change password");
      }

      showSuccess(result?.message || "Password changed successfully");
      setPwForm({
        oldPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setPwError(null);
      setShowOld(false);
      setShowNew(false);
      setShowConfirm(false);
    } catch (err) {
      console.error("Password change error:", err);
      const msg =
        err?.response?.data?.message ||
        err?.message ||
        "Failed to change password";
      setPwError(msg);
      showError(msg);
    } finally {
      setSaving(false);
    }
  };

  // ─── Hero helpers ──────────────────────────────────────────
  const fullName = profileUser?.name || "User";
  const initials =
    getInitials(profileUser?.name || "") || (fullName[0]?.toUpperCase() ?? "U");
  const roleLabel = getRoleName(profileUser?.role_id);

  const avatarUrl = isEditing
    ? avatarPreview ||
      (avatarRemoved ? null : buildImageUrl(profileUser?.image))
    : buildImageUrl(profileUser?.image);

  // ─── Render Tab Content ────────────────────────────────────
  const renderTabContent = () => {
    switch (activeTab) {
      case "profile":
        return (
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div>
                <h3 className="text-base font-semibold text-slate-800">
                  Profile Information
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isEditing
                    ? "Update your personal details below."
                    : "Your personal information on file."}
                </p>
              </div>
              {!isEditing && (
                <button
                  type="button"
                  onClick={handleStartEdit}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-blue-600 text-sm font-semibold rounded-lg transition-colors"
                >
                  <MdEdit size={16} />
                  Edit Profile
                </button>
              )}
            </div>

            {isEditing ? (
              // ─── Edit Mode ─────────────────────────────────
              <form onSubmit={handleProfileSave} className="space-y-5">
                {/* Avatar */}
                <div>
                  <FieldLabel>Profile Photo</FieldLabel>
                  <div className="flex items-center gap-4">
                    {avatarUrl ? (
                      <div className="relative">
                        <img
                          src={avatarUrl}
                          alt="Profile"
                          className="w-20 h-20 rounded-full object-cover border-2 border-slate-200 shadow-sm"
                        />
                        <button
                          type="button"
                          onClick={handleAvatarRemove}
                          className="absolute -top-1 -right-1 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                          aria-label="Remove photo"
                        >
                          <MdClose size={12} />
                        </button>
                      </div>
                    ) : (
                      <div className="w-20 h-20 rounded-full bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center">
                        <MdImage size={28} className="text-slate-400" />
                      </div>
                    )}
                    <div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) =>
                          handleAvatarChange(e.target.files?.[0])
                        }
                        className="hidden"
                        id="avatar-upload"
                      />
                      <label
                        htmlFor="avatar-upload"
                        className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg cursor-pointer hover:bg-blue-100 transition-colors text-sm font-medium inline-flex items-center gap-2"
                      >
                        <MdCloudUpload size={16} />
                        Choose Photo
                      </label>
                      <p className="mt-1 text-xs text-slate-400">
                        JPEG, PNG, GIF, WEBP (Max 5MB)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <TextInput
                    label="Full Name"
                    required
                    icon={MdPerson}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Enter your full name"
                    className="sm:col-span-2"
                  />

                  {/* Email — read-only, cannot be changed */}
                  <DisabledTextInput
                    label="Email"
                    icon={MdEmail}
                    value={profileUser?.email || ""}
                    hint="Email address cannot be changed."
                    className="sm:col-span-2"
                  />

                  <TextInput
                    label="Mobile"
                    icon={MdPhone}
                    value={form.mobile}
                    onChange={(e) =>
                      setForm({ ...form, mobile: e.target.value })
                    }
                    placeholder="9876543210"
                    className="sm:col-span-2"
                  />
                </div>

                <div className="flex items-center gap-3 pt-1">
                  <button
                    type="submit"
                    disabled={saving}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
                  >
                    {saving ? (
                      <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <MdSave size={16} />
                    )}
                    {saving ? "Saving..." : "Save Changes"}
                  </button>
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    disabled={saving}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
                  >
                    <MdCancel size={16} />
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              // ─── View Mode (all info shown) ────────────────
              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <ReadOnlyField
                    label="User ID"
                    value={profileUser?.id}
                    icon={MdBadge}
                  />
                  <ReadOnlyField
                    label="Role"
                    value={roleLabel}
                    icon={MdAdminPanelSettings}
                  />
                  <ReadOnlyField
                    label="Full Name"
                    value={profileUser?.name}
                    icon={MdPerson}
                  />
                  <ReadOnlyField
                    label="Email Address"
                    value={profileUser?.email}
                    icon={MdEmail}
                  />
                  <ReadOnlyField
                    label="Mobile Number"
                    value={profileUser?.mobile}
                    icon={MdPhone}
                  />

                  {/* Profile image preview */}
                  <ReadOnlyImageField
                    label="Profile Image"
                    image={profileUser?.image}
                  />

                  <ReadOnlyField
                    label="Created At"
                    value={formatDateTime(
                      profileUser?.createdAt || profileUser?.created_at,
                    )}
                    icon={MdDateRange}
                  />
                  <ReadOnlyField
                    label="Last Updated"
                    value={formatDateTime(
                      profileUser?.updatedAt || profileUser?.updated_at,
                    )}
                    icon={MdUpdate}
                  />
                </div>
              </div>
            )}
          </div>
        );

      case "password":
        return (
          <form
            onSubmit={handlePasswordChange}
            className="space-y-5 max-w-xl"
            autoComplete="off"
          >
            {pwError && (
              <div className="flex items-start gap-2.5 px-3.5 py-3 bg-red-50 border border-red-200 rounded-lg">
                <MdErrorOutline
                  size={16}
                  className="text-red-500 mt-0.5 flex-shrink-0"
                />
                <p className="text-xs text-red-700 leading-relaxed">
                  {pwError}
                </p>
              </div>
            )}

            <TextInput
              label="Current Password"
              type={showOld ? "text" : "password"}
              required
              icon={MdLock}
              value={pwForm.oldPassword}
              onChange={(e) =>
                setPwForm({ ...pwForm, oldPassword: e.target.value })
              }
              placeholder="Enter your current password"
              rightSlot={
                <button
                  type="button"
                  onClick={() => setShowOld((v) => !v)}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                  tabIndex={-1}
                >
                  {showOld ? (
                    <MdVisibilityOff size={20} />
                  ) : (
                    <MdVisibility size={20} />
                  )}
                </button>
              }
            />

            <TextInput
              label="New Password"
              type={showNew ? "text" : "password"}
              required
              icon={MdVpnKey}
              value={pwForm.newPassword}
              onChange={(e) =>
                setPwForm({ ...pwForm, newPassword: e.target.value })
              }
              placeholder="Enter your new password (min 6 characters)"
              hint="Minimum 6 characters. Use a mix of letters, numbers and symbols."
              rightSlot={
                <button
                  type="button"
                  onClick={() => setShowNew((v) => !v)}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                  tabIndex={-1}
                >
                  {showNew ? (
                    <MdVisibilityOff size={20} />
                  ) : (
                    <MdVisibility size={20} />
                  )}
                </button>
              }
            />

            <TextInput
              label="Confirm New Password"
              type={showConfirm ? "text" : "password"}
              required
              icon={MdLock}
              value={pwForm.confirmPassword}
              onChange={(e) =>
                setPwForm({ ...pwForm, confirmPassword: e.target.value })
              }
              placeholder="Re-enter your new password"
              rightSlot={
                <button
                  type="button"
                  onClick={() => setShowConfirm((v) => !v)}
                  className="text-slate-400 hover:text-slate-600 transition-colors"
                  tabIndex={-1}
                >
                  {showConfirm ? (
                    <MdVisibilityOff size={20} />
                  ) : (
                    <MdVisibility size={20} />
                  )}
                </button>
              }
            />

            <div className="flex items-center gap-3 pt-1">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
              >
                {saving ? (
                  <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <MdShield size={16} />
                )}
                {saving ? "Updating..." : "Change Password"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setPwForm({
                    oldPassword: "",
                    newPassword: "",
                    confirmPassword: "",
                  });
                  setPwError(null);
                }}
                disabled={saving}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
              >
                Clear
              </button>
            </div>
          </form>
        );

      default:
        return null;
    }
  };

  // ─── Main render ─────────────────────────────────────────────
  return (
    <div className="min-h-screen pb-16 bg-[#F4F5FA]">
      {/* ─── Sticky action bar ─────────────────────────────────── */}
      <div className="bg-white/85 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400 leading-tight">
                Account
              </p>
              <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
                My Profile
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {/* ─── Hero ───────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
        >
          <div className="relative h-44 sm:h-52 bg-gradient-to-br from-slate-950 via-indigo-950 to-purple-950">
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
            </div>
          </div>

          <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              {/* Avatar */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 backdrop-blur-sm p-1.5 shadow-xl flex-shrink-0 border border-white/10">
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt={fullName}
                    className="w-full h-full object-cover rounded-xl"
                    onError={(e) => {
                      e.target.style.display = "none";
                    }}
                  />
                ) : (
                  <div className="w-full h-full rounded-xl bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white font-bold text-lg">
                    {initials}
                  </div>
                )}
              </div>

              {/* Name + chips */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
                    {fullName}
                  </h1>
                  {profileUser?.role_id && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-400/20 text-indigo-200 ring-1 ring-indigo-400/30">
                      <MdAdminPanelSettings size={12} />
                      {roleLabel}
                    </span>
                  )}
                </div>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  {profileUser?.email && (
                    <span className="text-xs text-white/70">
                      {profileUser.email}
                    </span>
                  )}
                  {profileUser?.mobile && (
                    <span className="text-xs text-white/70">
                      • {profileUser.mobile}
                    </span>
                  )}
                  {profileUser?.id && (
                    <span className="text-xs text-white/50">
                      ID #{profileUser.id}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ─── Quick stat strip ──────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdPerson size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Name</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {profileUser?.name || "—"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdEmail size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Email</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {profileUser?.email || "—"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdPhone size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Mobile</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {profileUser?.mobile || "—"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdBadge size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Role</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {roleLabel}
              </p>
            </div>
          </div>
        </div>

        {/* ─── Tabs ───────────────────────────────────────────────── */}
        <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex w-full border-b border-slate-200">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex-1 w-full flex items-center justify-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
                    active
                      ? "text-blue-600"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}

                  {active && (
                    <motion.span
                      layoutId="profile-tab-underline"
                      className="absolute left-0 right-0 -bottom-px h-0.5 bg-blue-600 rounded-full"
                      transition={{
                        type: "spring",
                        stiffness: 500,
                        damping: 35,
                      }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                {renderTabContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;