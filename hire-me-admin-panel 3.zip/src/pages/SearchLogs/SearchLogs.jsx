﻿// // pages/searchLogs/SearchLogs.jsx
// import React, { useState, useEffect, useMemo } from "react";
// import { useNavigate } from "react-router-dom";
// import Table from "../../components/common/Table";
// import Pagination from "../../components/common/Pagination";
// import { MdSearch, MdRefresh, MdVisibility } from "react-icons/md";
// import searchLogService from "../../services/searchLog.service";
// import { showError } from "../../utils/toast";

// // â”€â”€â”€ Parse API date "DD/MM/YYYY, HH:MM:SS am/pm" â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// const parseApiDate = (dateString) => {
//   if (!dateString) return null;
//   const match = dateString.match(
//     /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
//   );
//   if (match) {
//     let [_, day, month, year, hours, minutes, seconds, ampm] = match;
//     hours = parseInt(hours);
//     if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
//     if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
//     return new Date(
//       parseInt(year),
//       parseInt(month) - 1, 
//       parseInt(day),
//       hours,
//       parseInt(minutes),
//       parseInt(seconds),
//     );
//   }
//   const d = new Date(dateString);
//   return !isNaN(d) ? d : null;
// };

// const formatDate = (dateString) => {
//   const d = parseApiDate(dateString);
//   if (!d) return "â€”";
//   return d.toLocaleDateString("en-IN", {
//     day: "2-digit",
//     month: "short",
//     year: "numeric",
//   });
// };

// const formatTime = (dateString) => {
//   const d = parseApiDate(dateString);
//   if (!d) return "";
//   return d.toLocaleTimeString("en-IN", {
//     hour: "2-digit",
//     minute: "2-digit",
//     hour12: true,
//   });
// };

// // â”€â”€â”€ Extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// const extractList = (body) => {
//   if (Array.isArray(body)) return body;
//   if (!body || typeof body !== "object") return [];
//   if (Array.isArray(body.data)) return body.data;
//   if (Array.isArray(body.data?.data)) return body.data.data;
//   if (Array.isArray(body.results)) return body.results;
//   return [];
// };

// const extractPagination = (body) => {
//   if (!body || typeof body !== "object") return null;
//   if (body.pagination) return body.pagination;
//   if (body.data?.pagination) return body.data.pagination;
//   if (body.meta?.pagination) return body.meta.pagination;
//   if (body.meta) return body.meta;
//   return null;
// };

// const SearchLogs = () => {
//   const navigate = useNavigate();
//   const [logs, setLogs] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [search, setSearch] = useState("");
//   const [page, setPage] = useState(1);
//   const [limit, setLimit] = useState(10);
//   const [error, setError] = useState(null); 

//   const normalizeLog = (item) => ({
//     id: item.id,
//     keyword: item.keyword || "",
//     searched_at: item.searched_at || null,
//     created_at: item.created_at || null,
//     updated_at: item.updated_at || null,
//     candidate_id: item.candidate_id,
//     candidate_name: item.Candidate
//       ? `${item.Candidate.first_name || ""} ${item.Candidate.last_name || ""}`.trim() ||
//         "â€”"
//       : "â€”",
//     city_name: item.City?.name || item.City?.city_name || "â€”",
//     industry_name: item.Industry?.name || item.Industry?.industry_name || "â€”",
//     experience_level_name:
//       item.ExperienceLevel?.name || item.ExperienceLevel?.level || "â€”",
//   });

//   // â”€â”€â”€ Load ALL pages (same pattern as SearchCandidates) â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const load = async () => {
//     setLoading(true);
//     setError(null);
//     try {
//       const PER_PAGE = 20;

//       const firstResponse = await searchLogService.getAll({
//         page: 1,
//         limit: PER_PAGE,
//       });
//       // Your api wrapper already returns parsed data â€” adjust if needed:
//       const firstBody = firstResponse?.data ?? firstResponse;

//       let allRaw = extractList(firstBody);
//       const pagination = extractPagination(firstBody);

//       const totalPages = Number(
//         pagination?.totalPages || pagination?.total_pages || 0,
//       );

//       let currentPage = 2;
//       const maxPages = totalPages > 0 ? totalPages : 999;

//       while (currentPage <= maxPages) {
//         const response = await searchLogService.getAll({
//           page: currentPage,
//           limit: PER_PAGE,
//         });
//         const body = response?.data ?? response;
//         const pageRaw = extractList(body);
//         if (pageRaw.length === 0) break;
//         allRaw.push(...pageRaw);

//         const pagePagination = extractPagination(body);
//         const pageTotalPages = Number(
//           pagePagination?.totalPages || pagePagination?.total_pages || 0,
//         );
//         if (pageTotalPages && currentPage >= pageTotalPages) break;

//         currentPage++;
//         if (currentPage > 500) break;
//       }

//       const uniqueRaw = Array.from(
//         new Map(allRaw.map((item) => [String(item?.id), item])).values(),
//       );

//       setLogs(uniqueRaw.map(normalizeLog));
//     } catch (err) {
//       console.error("Load search logs error:", err);
//       const msg =
//         err.response?.data?.message ||
//         err.message ||
//         "Failed to load search logs";
//       setError(msg);
//       showError(msg);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     load();
//   }, []);

//   useEffect(() => {
//     setPage(1);
//   }, [search]);

//   const filteredData = useMemo(() => {
//     const query = search.toLowerCase().trim();
//     if (!query) return logs;

//     return logs.filter((item) =>
//       [
//         item.keyword,
//         item.candidate_name,
//         item.city_name,
//         item.industry_name,
//       ].some((value) =>
//         String(value ?? "")
//           .toLowerCase()
//           .includes(query),
//       ),
//     );
//   }, [logs, search]);

//   const paginatedData = filteredData.slice((page - 1) * limit, page * limit);

//   const openView = (row) => {
//     navigate(`/search-logs/view/${row.id}`, { state: { item: row } });
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * limit + i + 1,
//     },
//     {
//       header: "Keyword",
//       key: "keyword",
//       render: (v) => (
//         <div className="flex items-center gap-2">
//           <span className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center text-[#2C0EEE] flex-shrink-0">
//             <MdSearch size={14} />
//           </span>
//           <span className="font-medium text-slate-800">
//             {v || <span className="text-slate-400 italic">No keyword</span>}
//           </span>
//         </div>
//       ),
//     },
//     {
//       header: "Candidate",
//       key: "candidate_name",
//       render: (v) => (
//         <span className="text-slate-700 font-medium capitalize">{v}</span>
//       ),
//     },
//     // {
//     //   header: "City",
//     //   key: "city_name",
//     //   render: (v) => <span className="text-slate-600 text-sm">{v}</span>,
//     // },
//     // {
//     //   header: "Industry",
//     //   key: "industry_name",
//     //   render: (v) => <span className="text-slate-600 text-sm">{v}</span>,
//     // },
//     // {
//     //   header: "Experience Level",
//     //   key: "experience_level_name",
//     //   render: (v) => <span className="text-slate-600 text-sm">{v}</span>,
//     // },
//     {
//       header: "Searched At",
//       key: "created_at",
//       render: (v, row) => (
//         <div className="flex flex-col">
//           <span className="text-slate-600 text-sm">
//             {formatDate(row.created_at || v)}
//           </span>
//           <span className="text-xs text-slate-400">
//             {formatTime(row.created_at || v)}
//           </span>
//         </div>
//       ),
//     },
//     { 
//       header: "Actions",
//       key: "id",
//       render: (_, row) => (
//         <div className="flex gap-1 justify-end">
//           <button
//             onClick={() => openView(row)}
//             className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-[#2C0EEE] rounded-lg transition-colors"
//             title="View Details"
//           >
//             <MdVisibility size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   if (error && logs.length === 0) {
//     return (
//       <div className="space-y-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Search Logs</h1>
//           <p className="text-sm text-slate-500 mt-1">
//             View candidate search history
//           </p>
//         </div>
//         <div className="bg-white rounded-xl border border-red-200 shadow-sm p-8 text-center">
//           <p className="text-red-600 font-medium">{error}</p>
//           <button
//             onClick={load}
//             className="mt-4 px-4 py-2 bg-[#2C0EEE] text-white rounded-lg hover:bg-[#250bc4] transition-colors"
//           >
//             Retry
//           </button>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-4">
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Search Logs</h1>
//           <p className="text-sm text-slate-500 mt-1">
//             View candidate search history
//           </p>
//         </div>
//         <button
//           onClick={load}
//           disabled={loading}
//           className="inline-flex items-center gap-2 px-4 py-2 bg-transparent text-[#2C0EEE] border border-[#2C0EEE] rounded-lg hover:bg-[#2C0EEE] hover:text-white transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
//         >
//           <MdRefresh size={16} className={loading ? "animate-spin" : ""} />
//           Refresh
//         </button>
//       </div>

//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
//           <div className="relative w-full sm:w-80">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search by keyword, candidate, city or industry..."
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2C0EEE] transition-colors"
//             />
//           </div>
//           <span className="text-xs text-slate-400">
//             {filteredData.length} of {logs.length} records
//           </span>
//         </div>

//         <Table
//           columns={columns}
//           data={paginatedData}
//           loading={loading}
//           emptyMessage="No search logs found"
//         />

//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
//           <p className="text-xs text-slate-400">
//             Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
//             {"â€“"}
//             {Math.min(page * limit, filteredData.length)} of{" "}
//             {filteredData.length} logs
//           </p>
//           <Pagination
//             page={page}
//             total={filteredData.length}
//             limit={limit}
//             itemsCount={paginatedData.length}
//             onChange={setPage}
//             onLimitChange={(newLimit) => {
//               setLimit(newLimit);
//               setPage(1);
//             }}
//           />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SearchLogs;


// pages/searchLogs/SearchLogs.jsx
import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/common/Table";
import Pagination from "../../components/common/Pagination";
import { MdSearch, MdRefresh, MdVisibility } from "react-icons/md";
import searchLogService from "../../services/searchLog.service";
import { showError } from "../../utils/toast";

// â”€â”€â”€ Parse API date "DD/MM/YYYY, HH:MM:SS am/pm" â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const parseApiDate = (dateString) => {
  if (!dateString) return null;
  const match = dateString.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
  );
  if (match) {
    let [_, day, month, year, hours, minutes, seconds, ampm] = match;
    hours = parseInt(hours);
    if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
    if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
    return new Date(
      parseInt(year),
      parseInt(month) - 1,
      parseInt(day),
      hours,
      parseInt(minutes),
      parseInt(seconds),
    );
  }
  const d = new Date(dateString);
  return !isNaN(d) ? d : null;
};

const formatDate = (dateString) => {
  const d = parseApiDate(dateString);
  if (!d) return "â€”";
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const formatTime = (dateString) => {
  const d = parseApiDate(dateString);
  if (!d) return "";
  return d.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

// â”€â”€â”€ Extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const extractList = (body) => {
  if (Array.isArray(body)) return body;
  if (!body || typeof body !== "object") return [];
  if (Array.isArray(body.data)) return body.data;
  if (Array.isArray(body.data?.data)) return body.data.data;
  if (Array.isArray(body.results)) return body.results;
  return [];
};

const extractPagination = (body) => {
  if (!body || typeof body !== "object") return null;
  if (body.pagination) return body.pagination;
  if (body.data?.pagination) return body.data.pagination;
  if (body.meta?.pagination) return body.meta.pagination;
  if (body.meta) return body.meta;
  return null;
};

const SearchLogs = () => {
  const navigate = useNavigate();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [error, setError] = useState(null);

  const normalizeLog = (item) => ({
    id: item.id,
    keyword: item.keyword || "",
    searched_at: item.searched_at || null,
    created_at: item.created_at || null,
    updated_at: item.updated_at || null,

    candidate_id: item.candidate_id,
    candidate_name: item.Candidate
      ? `${item.Candidate.first_name || ""} ${item.Candidate.last_name || ""}`.trim() ||
        "â€”"
      : "â€”",
    city_name: item.City?.name || item.City?.city_name || "â€”",
    industry_name: item.Industry?.name || item.Industry?.industry_name || "â€”",
    experience_level_name:
      item.ExperienceLevel?.name || item.ExperienceLevel?.level || "â€”",
  });

  // â”€â”€â”€ Load ONLY the current page from the API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const loadPage = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await searchLogService.getAll({
        page,
        limit,
      });

      const body = response?.data ?? response;
      const rawList = extractList(body);
      const pagination = extractPagination(body);

      setLogs(rawList.map(normalizeLog));

      if (pagination) {
        setTotal(Number(pagination.total) || 0);
        setTotalPages(Number(pagination.totalPages) || 1);
      } else {
        // Fallback if API didn't return pagination metadata
        setTotal(rawList.length);
        setTotalPages(1);
      }
    } catch (err) {
      console.error("Load search logs error:", err);
      const msg =
        err.response?.data?.message ||
        err.message ||
        "Failed to load search logs";
      setError(msg);
      showError(msg);
    } finally {
      setLoading(false);
    }
  };

  // Reload when page or limit changes
  useEffect(() => {
    loadPage();
  }, [page, limit]);

  // Reset to page 1 when search term changes (client-side filter)
  useEffect(() => {
    setPage(1);
  }, [search]);

  // â”€â”€â”€ Client-side search on the CURRENT page only â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // For full-dataset search, the API would need to support a
  // `search` query param. See the note below.
  const filteredData = useMemo(() => {
    const query = search.toLowerCase().trim();
    if (!query) return logs;

    return logs.filter((item) =>
      [
        item.keyword,
        item.candidate_name,
        item.city_name,
        item.industry_name,
      ].some((value) =>
        String(value ?? "")
          .toLowerCase()
          .includes(query),
      ),
    );
  }, [logs, search]);

  const openView = (row) => {
    navigate(`/search-logs/view/${row.id}`, { state: { item: row } });
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Keyword",
      key: "keyword",
      render: (v) => (
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center text-[#2C0EEE] flex-shrink-0">
            <MdSearch size={14} />
          </span>
          <span className="font-medium text-slate-800">
            {v || <span className="text-slate-400 italic">No keyword</span>}
          </span>
        </div>
      ),
    },
    {
      header: "Candidate",
      key: "candidate_name",
      render: (v) => (
        <span className="text-slate-700 font-medium capitalize">{v}</span>
      ),
    },
    {
      header: "Searched At",
      key: "created_at",
      render: (v, row) => (
        <div className="flex flex-col">
          <span className="text-slate-600 text-sm">
            {formatDate(row.created_at || v)}
          </span>
          <span className="text-xs text-slate-400">
            {formatTime(row.created_at || v)}
          </span>
        </div>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (_, row) => (
        <div className="flex gap-1 justify-end">
          <button
            onClick={() => openView(row)}
            className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-[#2C0EEE] rounded-lg transition-colors"
            title="View Details"
          >
            <MdVisibility size={16} />
          </button>
        </div>
      ),
    },
  ];

  if (error && logs.length === 0) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Search Logs</h1>
          <p className="text-sm text-slate-500 mt-1">
            View candidate search history
          </p>
        </div>
        <div className="bg-white rounded-xl border border-red-200 shadow-sm p-8 text-center">
          <p className="text-red-600 font-medium">{error}</p>
          <button
            onClick={loadPage}
            className="mt-4 px-4 py-2 bg-[#2C0EEE] text-white rounded-lg hover:bg-[#250bc4] transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Search Logs</h1>
          <p className="text-sm text-slate-500 mt-1">View search history</p>
        </div>
        <button
          onClick={loadPage}
          disabled={loading}
          className="inline-flex items-center gap-2 px-4 py-2 bg-transparent text-[#2C0EEE] border border-[#2C0EEE] rounded-lg hover:bg-[#2C0EEE] hover:text-white transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
        >
          <MdRefresh size={16} className={loading ? "animate-spin" : ""} />
          Refresh
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-80">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by keyword, candidate, city or industry..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2C0EEE] transition-colors"
            />
          </div>
          <span className="text-xs text-slate-400">
            {filteredData.length} of {logs.length} on this page &middot;{" "}
            {total.toLocaleString()} total
          </span>
        </div>

        <Table
          columns={columns}
          data={filteredData}
          loading={loading}
          emptyMessage="No search logs found"
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
          <p className="text-xs text-slate-400">
            Showing{" "}
            {total === 0
              ? 0
              : (page - 1) * limit + (filteredData.length > 0 ? 1 : 0)}
            {"â€“"}
            {(page - 1) * limit + filteredData.length} of{" "}
            {total.toLocaleString()} logs
          </p>
          <Pagination
            page={page}
            total={total}
            limit={limit}
            itemsCount={logs.length}
            onChange={setPage}
            onLimitChange={(newLimit) => {
              setLimit(newLimit);
              setPage(1);
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default SearchLogs;

