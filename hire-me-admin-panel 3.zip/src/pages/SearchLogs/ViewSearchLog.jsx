// pages/searchLogs/ViewSearchLog.jsx
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  MdArrowBack,
  MdSearch,
  MdPerson,
  MdLocationOn,
  MdBusiness,
  MdWork,
  MdCalendarToday,
  MdBadge,
  MdErrorOutline,
  MdHistory, 
  MdCategory,
} from "react-icons/md";
import searchLogService from "../../services/searchLog.service";

// ─── Parse API date "DD/MM/YYYY, HH:MM:SS am/pm" ──────────────────
const parseApiDate = (dateString) => {
  if (!dateString) return null;
  const match = dateString.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
  );
  if (match) {
    let [_, day, month, year, hours, minutes, seconds, ampm] = match;
    hours = parseInt(hours);
    if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
    if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
    return new Date(
      parseInt(year),
      parseInt(month) - 1,
      parseInt(day),
      hours,
      parseInt(minutes),
      parseInt(seconds),
    );
  }
  const d = new Date(dateString);
  return !isNaN(d) ? d : null;
};

const displayDateTime = (raw) => {
  if (!raw) return "—";
  const d = parseApiDate(raw);
  if (!d) return raw;
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

// ─── Small shared pieces ─────────────────────────────────────────
const FieldLabel = ({ children }) => (
  <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
    {children}
  </label>
);

const ReadOnlyValue = ({ children, icon: Icon }) => (
  <div className="flex items-center gap-2 text-sm text-slate-700 py-2 px-3 bg-slate-50 rounded-lg border border-slate-200">
    {Icon && <Icon size={14} className="text-slate-400 flex-shrink-0" />}
    <span className="truncate">{children ?? "—"}</span>
  </div>
);

// ─── Tabs ──────────────────────────────────────────────────────
const TABS = [
  { id: "search", label: "Search Details", icon: MdSearch },
];

const ViewSearchLog = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [log, setLog] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("search");

useEffect(() => {
  const loadData = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const response = await searchLogService.getById(id);
      const body = response?.data ?? response;
      const record = body?.data ?? body;
      setLog(record || null);
    } catch (err) {
      console.error("Failed to load search log:", err);
      setLog(null);
    } finally {
      setLoading(false);
    }
  };
  loadData();
}, [id]);

  const handleBack = () => navigate("/search-logs");

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-9 h-9 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-slate-400">Loading search details...</p>
        </div>
      </div>
    );
  }

  if (!log) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="text-center bg-white rounded-2xl border border-slate-200 shadow-sm px-10 py-12">
          <MdErrorOutline size={40} className="text-slate-300 mx-auto mb-3" />
          <p className="text-slate-600 font-medium">Search log not found</p>
          <button
            onClick={handleBack}
            className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <MdArrowBack size={16} />
            Back to search logs
          </button>
        </div>
      </div>
    );
  }

  const {
    id: logId,
    keyword,
    searched_at,
    created_at,
    updated_at,
    Candidate,
    City,
    Industry,
    ExperienceLevel,
  } = log;

  const candidateName = Candidate
    ? `${Candidate.first_name || ""} ${Candidate.last_name || ""}`.trim() || "—"
    : "—";

  const cityName = City?.name || City?.city_name || "—";
  const industryName = Industry?.name || Industry?.industry_name || "—";
  const experienceLevelName =
    ExperienceLevel?.name || ExperienceLevel?.level || "—";

  const renderTabContent = () => {
    return (
      <div className="space-y-8">
        {/* Search Information */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <MdSearch size={18} className="text-blue-600" />
            Search Information
          </h3>

          <div>
            <FieldLabel>Search Keyword</FieldLabel>
            <ReadOnlyValue icon={MdSearch}>
              {keyword || "—"}
            </ReadOnlyValue>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <FieldLabel>Searched At</FieldLabel>
              <ReadOnlyValue icon={MdCalendarToday}>
                {displayDateTime(searched_at || created_at)}
              </ReadOnlyValue>
            </div>
            <div>
              <FieldLabel>Created At</FieldLabel>
              <ReadOnlyValue icon={MdCalendarToday}>
                {displayDateTime(created_at)}
              </ReadOnlyValue>
            </div>
            <div>
              <FieldLabel>Updated At</FieldLabel>
              <ReadOnlyValue icon={MdCalendarToday}>
                {displayDateTime(updated_at)}
              </ReadOnlyValue>
            </div>
          </div>
        </div>

        {/* Candidate Information */}
        <div className="pt-6 border-t border-slate-200 space-y-4">
          <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <MdPerson size={18} className="text-blue-600" />
            Candidate Information
          </h3>
          {Candidate ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 rounded-lg border border-slate-200 p-4">
              <div>
                <span className="text-xs font-medium text-slate-500">
                  First Name
                </span>
                <p className="text-sm font-medium text-slate-700 mt-0.5">
                  {Candidate.first_name || "—"}
                </p>
              </div>
              <div>
                <span className="text-xs font-medium text-slate-500">
                  Last Name
                </span>
                <p className="text-sm font-medium text-slate-700 mt-0.5">
                  {Candidate.last_name || "—"}
                </p>
              </div>
              {/* <div>
                <span className="text-xs font-medium text-slate-500">
                  Candidate ID
                </span>
                <p className="text-sm font-medium text-slate-700 mt-0.5">
                  #{Candidate.id}
                </p>
              </div> */}
            </div>
          ) : (
            <p className="text-slate-400 text-sm">
              No candidate information available.
            </p>
          )}
        </div>

        {/* Search Filters */}
        <div className="pt-6 border-t border-slate-200 space-y-4">
          <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-2">
            <MdLocationOn size={18} className="text-blue-600" />
            Search Filters
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 rounded-lg border border-slate-200 p-4">
            <div>
              <span className="text-xs font-medium text-slate-500">
                City
              </span>
              <p className="text-sm font-medium text-slate-700 mt-0.5">
                {cityName}
              </p>
            </div>
            <div>
              <span className="text-xs font-medium text-slate-500">
                Industry
              </span>
              <p className="text-sm font-medium text-slate-700 mt-0.5">
                {industryName}
              </p>
            </div>
            <div>
              <span className="text-xs font-medium text-slate-500">
                Experience Level
              </span>
              <p className="text-sm font-medium text-slate-700 mt-0.5">
                {experienceLevelName}
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen pb-16">
      {/* ─── Sticky action bar ─────────────────────────────────── */}
      <div className="bg-white/85 backdrop-blur-md border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={handleBack}
              className="p-2 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
              aria-label="Back"
            >
              <MdArrowBack size={19} className="text-slate-600" />
            </button>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400 leading-tight">
                Search Logs
              </p>
              <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
                "{keyword || "Untitled search"}"
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={handleBack}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors"
            >
              Back
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {/* ─── Hero ───────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
        >
          <div className="relative h-40 sm:h-44 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-800">
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/95 via-slate-900/50 to-slate-900/10" />
          </div>

          <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-1.5 shadow-xl flex-shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white">
                  <MdSearch size={26} />
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
                  "{keyword || "Untitled search"}"
                </h1>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-white/70 flex items-center gap-1">
                    <MdPerson size={12} /> {candidateName}
                  </span>
                  <span className="text-xs text-white/70 flex items-center gap-1">
                    <MdCalendarToday size={12} />{" "}
                    {displayDateTime(searched_at || created_at)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ─── Quick stat strip ──────────────────────────────────── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdPerson size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">
                Candidate
              </p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {candidateName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdLocationOn size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">City</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {cityName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdBusiness size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">
                Industry
              </p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {industryName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdWork size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">
                Experience
              </p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {experienceLevelName}
              </p>
            </div>
          </div>
        </div>

        {/* ─── Tabs ───────────────────────────────────────────────── */}
        <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex overflow-x-auto border-b border-slate-200 px-2">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
                    active
                      ? "text-blue-600"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}
                  {active && (
                    <motion.span
                      layoutId="search-log-view-tab-underline"
                      className="absolute left-2 right-2 -bottom-px h-0.5 bg-blue-600 rounded-full"
                      transition={{
                        type: "spring",
                        stiffness: 500,
                        damping: 35,
                      }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                {renderTabContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};
 
export default ViewSearchLog; 