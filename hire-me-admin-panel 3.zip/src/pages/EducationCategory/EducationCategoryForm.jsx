// pages/education/EducationCategoryForm.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, useParams } from 'react-router-dom';
import FormPage from '../../components/common/FormPage';
import { ViewBadge, ViewTrendingBadge } from '../../components/common/FormPageUtils';
import { educationCategoryService } from '../../services/educationCategory.service';
import { educationSubCategoryService } from '../../services/educationSubCategory.service';
import { showSuccess, showError } from '../../utils/toast';
import { formatDate } from '../../utils/helpers';
import { fetchUsers } from '../../utils/getUserName';
import { useAuth } from '../../context/AuthContext';

const EducationCategoryForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { user } = useAuth();
  const userId = user?.id;

  const [mode, setMode] = useState('add'); // 'add' | 'edit' | 'view'
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [userNameCache, setUserNameCache] = useState({});
  const [pageLoading, setPageLoading] = useState(false);
  const [subCategories, setSubCategories] = useState([]);

  // Determine mode from URL
  useEffect(() => {
    const path = location.pathname;
    if (path.includes('/view/')) {
      setMode('view');
    } else if (path.includes('/edit/')) {
      setMode('edit');
    } else {
      setMode('add');
    }
  }, [location.pathname]);

  // Fetch users for display names
  useEffect(() => {
    const loadUsers = async () => {
      try {
        const users = await fetchUsers();
        const userMap = {};
        Object.keys(users).forEach(id => {
          userMap[id] = users[id].name;
        });
        setUserNameCache(userMap);
      } catch (error) {
        console.error('Failed to load users:', error);
      }
    };
    loadUsers();
  }, []);

  // Fetch sub-categories to check if category has children
  useEffect(() => {
    const loadSubCategories = async () => {
      try {
        const r = await educationSubCategoryService.getAll({ limit: 1000 });
        const rawData = r.data?.data || r.data?.results || r.data || [];
        const subs = Array.isArray(rawData) ? rawData : [];
        setSubCategories(subs);
      } catch (error) {
        console.error('Failed to load sub-categories:', error);
      }
    };
    loadSubCategories();
  }, []);

  // Fetch data for edit/view modes
  useEffect(() => {
    const fetchData = async () => {
      if ((mode === 'edit' || mode === 'view') && id) {
        setPageLoading(true);
        try {
          let item = location.state?.item;

          if (!item) {
            const response = await educationCategoryService.getById(id);
            item = response.data;
          }

          // Normalize the data
          const normalizedData = {
            id: item.id || item._id,
            name: item.name || "",
            status: item.status || "active",
            is_status: item.status === "active",
            is_trending: item.is_trending || false,
            created_at: item.created_at || item.createdAt || null,
            updated_at: item.updated_at || item.updatedAt || null,
            created_by: item.created_by || null,
            updated_by: item.updated_by || null,
          };

          setData(normalizedData);
        } catch (error) {
          console.error('Fetch error:', error);
          showError("Failed to load education category data");
          navigate('/education-categories');
        } finally {
          setPageLoading(false);
        }
      }
    };
    fetchData();
  }, [id, mode, location.state, navigate]);

  // Get user name with caching
  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  // Get status value
  const getStatusValue = (row) => {
    if (row?.is_status !== undefined) {
      return row.is_status;
    }
    if (row?.status !== undefined) {
      return row.status === "active";
    }
    return true;
  };

  // Check if category has sub-categories
  const getSubCategoryCount = (categoryId) => {
    return subCategories.filter((sub) => {
      const parentId = sub.education_id || sub.EducationCategory?.id;
      return String(parentId) === String(categoryId);
    }).length;
  };

  // Define fields for the form
  const getFields = () => {
    // Base fields (common for all modes)
    const baseFields = [
      {
        name: "name",
        label: "Category Name",
        type: "text",
        required: true,
        placeholder: "e.g. Computer Science",
        help: "Enter a unique name for the category",
        viewRender: (value) => <span className="font-medium text-lg">{value}</span>
      },

      {
        name: "status",
        label: "Status",
        type: "radio",
        options: [
          { value: "active", label: "Active" },
          { value: "inactive", label: "Inactive" },
        ],
        color: "text-[#2c0eee] focus:ring-[#4529f7]",
        viewRender: () => {
          const isActive =
            data?.is_status === true ||
            data?.is_status === 1 ||
            data?.is_status === "1" ||
            data?.is_status === "true";

          return <ViewBadge active={isActive} />;
        }
      },
      {
        name: "is_trending",
        label: "Mark as Trending",
        type: "checkbox",
        color: "text-yellow-500 focus:ring-yellow-500",
        help: "Trending categories will be highlighted in the listing",
        viewRender: (value) => <ViewTrendingBadge isTrending={value} />
      }
    ];

    // ═══════════════════════════════════════════════════════════
    // 🔹 ONLY ADD AUDIT FIELDS IN VIEW MODE
    // ═══════════════════════════════════════════════════════════
    if (mode === 'view') {
      const auditFields = [
        {
          name: "created_by",
          label: "Created By",
          type: "text",
          disabled: true,
          viewRender: (value) => {
            const name = getUserNameCached(value);
            return name !== "-" ? name : "System";
          }
        },
        {
          name: "updated_by",
          label: "Updated By",
          type: "text",
          disabled: true,
          viewRender: (value) => {
            if (!value) return '—';
            const name = getUserNameCached(value);
            return name !== "-" ? name : "System";
          }
        },
        {
          name: "created_at",
          label: "Created At",
          type: "text",
          disabled: true,
          viewRender: (value) => value ? formatDate(value) : '—'
        },
        {
          name: "updated_at",
          label: "Updated At",
          type: "text",
          disabled: true,
          viewRender: (value) => value ? formatDate(value) : '—'
        }
      ];

      return [...baseFields, ...auditFields];
    }

    // For add and edit modes - return only base fields (no audit fields)
    return baseFields;
  };

  // Validation rules
  const getValidationRules = (existingData) => ({
    name: {
      required: true,
      requiredMessage: 'Category name is required',
      minLength: 2,
      minLengthMessage: 'Category name must be at least 2 characters',
      maxLength: 50,
      maxLengthMessage: 'Category name must be at most 50 characters',
      custom: (value) => {
        // Will check in submit handler
        return null;
      }
    }
  });

  // Submit handler for add/edit
  const handleSubmit = async (formData) => {
    setLoading(true);

    try {
      const submitData = {
        name: formData.name,
        status: formData.status,
        is_trending: formData.is_trending || false,
      };

      // ═══════════════════════════════════════════════════════════
      // 🔹 SET created_by AND updated_by
      // ═══════════════════════════════════════════════════════════
      if (mode === 'edit') {
        // For edit: only set updated_by
        submitData.updated_by = userId;
      } else {
        // For create: set both created_by and updated_by
        submitData.created_by = userId;
        submitData.updated_by = userId;
      }

      // Check for duplicate name
      const allData = await educationCategoryService.getAll({ limit: 1000 });
      const existingItems = allData.data?.data || allData.data?.results || allData.data || [];
      const duplicate = existingItems.some(item =>
        item.name.toLowerCase() === formData.name.toLowerCase() &&
        (mode === 'add' || item.id !== id)
      );

      // if (duplicate) {
      //     showError('This category name already exists');
      //     setLoading(false);
      //     return;
      // }

      if (mode === 'edit') {
        await educationCategoryService.update(id, submitData);
        showSuccess("Category updated successfully");
      } else {
        await educationCategoryService.create(submitData);
        showSuccess("Category created successfully");
      }

      navigate('/education-categories');
    } catch (error) {
      console.error('Submit error:', error);
      const errorMessage = error?.message ||
        error?.response?.data?.message ||
        "Failed to save";
      showError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Delete handler
  const handleDelete = async () => {
    // Check if category has sub-categories
    const childCount = getSubCategoryCount(id);
    if (childCount > 0) {
      showError(`Cannot delete this category because it has ${childCount} sub-categor${childCount === 1 ? "y" : "ies"} linked to it.`);
      throw new Error("Category has sub-categories");
    }

    try {
      await educationCategoryService.delete(id);
      showSuccess("Category deleted successfully");
      navigate('/education-categories');
    } catch (error) {
      console.error('Delete error:', error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/sub[-_ ]?categor|child|foreign\s*key|constraint/i.test(message)) {
        showError("Cannot delete this category because it has sub-categories linked to it.");
      } else {
        showError(message || "Failed to delete category");
      }
      throw error;
    }
  };

  // Prepare initial data
  const getInitialData = () => {
    if (mode === 'add') {
      return {
        name: "",
        status: "active",
        is_trending: false
      };
    }

    if (data) {
      // Base initial data (common for all modes)
      const initialData = {
        name: data.name || "",
        status: data.is_status ? "active" : "inactive",
        is_trending: data.is_trending || false,
      };

      // ═══════════════════════════════════════════════════════════
      // 🔹 ONLY ADD AUDIT FIELDS IN VIEW MODE
      // ═══════════════════════════════════════════════════════════
      if (mode === 'view') {
        initialData.created_by = data.created_by;
        initialData.updated_by = data.updated_by;
        initialData.created_at = data.created_at;
        initialData.updated_at = data.updated_at;
      }

      return initialData;
    }

    return {
      name: "",
      status: "active",
      is_trending: false
    };
  };

  // Get title based on mode
  const getTitle = () => {
    if (mode === 'view') return 'Education Category Details';
    if (mode === 'edit') return 'Edit Education Category';
    return 'Add New Education Category';
  };

  // Get submit label
  const getSubmitLabel = () => {
    if (mode === 'edit') return 'Update Category';
    return 'Create Category';
  };

  // Handle loading state
  if (pageLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#2c0eee] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-3 text-gray-500">Loading category data...</p>
        </div>
      </div>
    );
  }

  // If view/edit mode and data not loaded, show error
  if ((mode === 'view' || mode === 'edit') && !data && !pageLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500">Education category not found</p>
          <button
            onClick={() => navigate('/education-categories')}
            className="mt-3 text-[#2c0eee] hover:underline"
          >
            Go back
          </button>
        </div>
      </div>
    );
  }

  return (
    <FormPage
      title={getTitle()}
      mode={mode}
      fields={getFields()}
      initialData={getInitialData()}
      validationRules={getValidationRules(data)}
      onSubmit={handleSubmit}
      onDelete={handleDelete}
      navigateTo="/education-categories"
      submitLabel={getSubmitLabel()}
      editLabel="Edit Category"
      deleteLabel="Delete Category"
      loading={loading}
      showDelete={mode !== 'add'}
      showEdit={mode === 'view'}
      enableEditMode={mode === 'view'}
      breadcrumb={mode === 'view' ? 'Viewing category details' : mode === 'edit' ? 'Updating category' : 'Creating new category'}
      onEdit={() => navigate(`/education-categories/edit/${id}`, { state: { item: data } })}
    />
  );
};

export default EducationCategoryForm;
