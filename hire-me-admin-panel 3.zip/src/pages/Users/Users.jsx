import { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import userService from "../../services/user.service";
import { showSuccess, showError } from "../../utils/toast";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdRefresh,
  MdPerson,
  MdEmail,
} from "react-icons/md";
import { formatDate } from "../../utils/helpers";

const API_BASE =
  import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

const getImageUrl = (path) => {
  if (!path) return null;
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  return `${API_BASE}${path.startsWith("/") ? path : `/${path}`}`;
};

const wasActuallyUpdated = (createdAt, updatedAt) => {
  if (!createdAt || !updatedAt) return false;
  const created = new Date(createdAt).getTime();
  const updated = new Date(updatedAt).getTime();
  if (Number.isNaN(created) || Number.isNaN(updated)) return false;
  return updated - created > 2000;
};

const normalizeUser = (item) => ({
  id: item.id,
  name: item.name || "",
  email: item.email || "",
  mobile: item.mobile || null,
  role_id: item.role_id || null,
  image: item.image || null,
  status: item.status || "inactive",
  reset_token: item.reset_token || null,
  reset_token_expiry: item.reset_token_expiry || null,
  otp: item.otp || null,
  otp_expiry: item.otp_expiry || null,
  createdAt: item.createdAt || item.created_at || null,
  updatedAt: item.updatedAt || item.updated_at || null,
});

const extractList = (res) => {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.data?.data)) return res.data.data;
  if (Array.isArray(res.data)) return res.data;
  if (Array.isArray(res.results)) return res.results;
  return [];
};

const Users = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Search & Filter
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  /* Active/Inactive status filter commented out as requested
  const [statusFilter, setStatusFilter] = useState("all");
  */

  // Pagination
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  // Reset page to 1 on search change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);

  // Load roles
  useEffect(() => {
    const loadRoles = async () => {
      try {
        const response = await userService.getRoles();
        const body = response?.data ?? response;
        const roleData = body?.data?.data || body?.data || body || [];
        setRoles(Array.isArray(roleData) ? roleData : []);
      } catch (err) {
        console.error("Load roles error:", err);
      }
    };
    loadRoles();
  }, []);

  // Fetch users
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await userService.getAll();
      const rawData = extractList(response);
      const items = rawData.map(normalizeUser);
      setData(items);
    } catch (err) {
      console.error("Load users error:", err);
      showError(err.response?.data?.message || "Failed to load users");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // Client-side search filtering
  const filteredData = useMemo(() => {
    let result = data;
    /* Active/Inactive status filtering commented out as requested
    if (statusFilter !== "all") {
      result = result.filter((item) => item.status === statusFilter);
    }
    */
    if (debouncedSearch) {
      const query = debouncedSearch.toLowerCase();
      result = result.filter((item) =>
        [item.name, item.email, item.mobile].some((val) =>
          String(val ?? "").toLowerCase().includes(query)
        )
      );
    }
    return result;
  }, [data, debouncedSearch]);

  // Paginate filtered results
  const paginatedData = useMemo(() => {
    const start = (page - 1) * limit;
    return filteredData.slice(start, start + limit);
  }, [filteredData, page, limit]);

  /* Active/Inactive count calculations commented out as requested
  const activeCount = useMemo(
    () => data.filter((u) => u.status === "active").length,
    [data]
  );
  const inactiveCount = useMemo(
    () => data.filter((u) => u.status === "inactive").length,
    [data]
  );
  */

  const openAdd = () => navigate("/users/add");
  const openEdit = (item) => navigate(`/users/edit/${item.id}`);
  const openView = (item) => navigate(`/users/view/${item.id}`);

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await userService.delete(deleteId);
      showSuccess("User deleted successfully");
      load();
    } catch (err) {
      console.error("Delete error:", err);
      showError(err.response?.data?.message || "Failed to delete user");
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Photo",
      key: "image",
      render: (image) =>
        image ? (
          <img
            src={getImageUrl(image)}
            alt="profile"
            className="w-8 h-8 object-cover rounded-full border border-slate-200"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
        ) : (
          <div className="w-8 h-8 rounded-full border border-slate-200 bg-slate-50 flex items-center justify-center text-gray-300 text-xs font-medium">
            <MdPerson size={16} />
          </div>
        ),
    },
    {
      header: "Name",
      key: "name",
      render: (_, row) => (
        <span className="font-medium text-slate-800">
          {row.name || "Unnamed"}
        </span>
      ),
    },
    {
      header: "Email",
      key: "email",
      render: (v) => (
        <div className="flex items-center gap-1">
          <MdEmail className="text-slate-400" size={14} />
          <span className="text-sm text-slate-500">{v}</span>
        </div>
      ),
    },
    {
      header: "Mobile",
      key: "mobile",
      render: (v) => <span className="text-sm text-slate-500">{v || "â€”"}</span>,
    },
    {
      header: "Updated At",
      key: "updatedAt",
      render: (v, row) => {
        const updated = wasActuallyUpdated(row.createdAt, row.updatedAt);
        return (
          <span className="text-slate-500 text-sm">
            {updated ? formatDate(row.updatedAt) : "â€”"}
          </span>
        );
      },
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() => openView(row)}
            className="p-1.5 hover:bg-slate-800 text-white shadow-sm text-blue-600 rounded-lg transition-colors"
            title="View Profile"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() => openEdit(row)}
            className="p-1.5 hover:bg-gray-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All Users", count: data.length },
    /* Active and Inactive tabs commented out as requested
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
    */
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Users</h1>
          <p className="text-sm text-slate-500 mt-1">Manage system users</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={load}
            loading={loading}
          >
            Refresh
          </Button>
          <Button icon={MdAdd} onClick={openAdd}>
            Add User
          </Button>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search users..."
              className="w-full pl-10 pr-3 py-2.5 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <div
                key={tab.key}
                className="flex items-center gap-1.5 font-medium text-slate-800"
              >
                {tab.label}
                <span className="text-xs px-2 py-0.5 rounded-md font-semibold bg-slate-800 text-white shadow-sm">
                  {tab.count}
                </span>
              </div>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No users found"
        />

        {/* Footer â€” Pagination */}
        <div className="px-5 py-3 border-t border-slate-100">
          <Pagination
            page={page}
            total={filteredData.length}
            limit={limit}
            itemsCount={paginatedData.length}
            onChange={setPage}
            onLimitChange={(newLimit) => {
              setLimit(newLimit);
              setPage(1);
            }}
          />
        </div>
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete User"
        message="Delete this user? This action cannot be undone."
      />
    </div>
  );
};

export default Users;
