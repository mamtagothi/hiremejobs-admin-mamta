﻿import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdInsertPhoto,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { subIndustryService } from "../../services/subIndustry.service";
import { industryService } from "../../services/industry.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";
import { useAuth } from "../../context/AuthContext";

const API_BASE_URL = "https://apidata.hiremejobs.in";

/* ------------------------------------------------------------------ */
/*  How many records to request per API call (backend caps this at 100) */
/* ------------------------------------------------------------------ */
const PAGE_SIZE = 100;
const MAX_PAGES = 500; // safety guard against infinite loops

/* ------------------------------------------------------------------ */
/*  Extract the array of rows out of any API response shape            */
/* ------------------------------------------------------------------ */
const extractArrayData = (res) => {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.data)) return res.data;
  if (Array.isArray(res.data?.data)) return res.data.data;
  if (Array.isArray(res.data?.rows)) return res.data.rows;
  if (Array.isArray(res.data?.results)) return res.data.results;
  if (Array.isArray(res.data?.sub_industries)) return res.data.sub_industries;
  if (Array.isArray(res.data?.subIndustries)) return res.data.subIndustries;
  if (Array.isArray(res.sub_industries)) return res.sub_industries;
  if (Array.isArray(res.subIndustries)) return res.subIndustries;
  if (Array.isArray(res.rows)) return res.rows;
  if (Array.isArray(res.results)) return res.results;
  return [];
};

/* ------------------------------------------------------------------ */
/*  Extract the "pagination" block out of any API response shape       */
/* ------------------------------------------------------------------ */
const extractPagination = (res) => {
  if (!res) return null;
  return (
    res.pagination ||
    res?.data?.pagination ||
    res?.data?.meta ||
    res?.meta ||
    null
  );
};

/* ------------------------------------------------------------------ */
/*  Fetch EVERY page from a paginated endpoint                         */
/* ------------------------------------------------------------------ */
const fetchAllRecords = async (service, params = {}) => {
  const all = [];
  const seen = new Set();
  let page = 1;
  let totalPages = Infinity;
  let totalRecords = null;

  while (page <= totalPages && page <= MAX_PAGES) {
    const res = await service.getAll({ ...params, page, limit: PAGE_SIZE });

    const rows = extractArrayData(res);
    if (!rows.length) break;

    rows.forEach((row) => {
      const key =
        row?.id ??
        row?._id ??
        row?.sub_industry_id ??
        row?.subindustry_id ??
        row?.slug;

      if (key != null) {
        if (seen.has(key)) return;
        seen.add(key);
      }
      all.push(row);
    });

    const meta = extractPagination(res);

    if (meta) {
      if (meta.total != null) totalRecords = Number(meta.total);
      if (meta.totalPages != null) {
        totalPages = Number(meta.totalPages) || 1;
      }
    }

    // Stop conditions
    if (totalRecords != null && all.length >= totalRecords) break;
    if (!meta?.totalPages && rows.length < PAGE_SIZE) break;

    page += 1;
  }

  return all;
};

/* ------------------------------------------------------------------ */
/*  Safe date parser (API sends "DD/MM/YYYY, hh:mm:ss am/pm")          */
/* ------------------------------------------------------------------ */
const parseDateSafe = (value) => {
  if (!value) return 0;
  if (typeof value === "number") return value;

  const str = String(value).trim();

  const native = new Date(str).getTime();
  if (!Number.isNaN(native)) return native;

  const m = str.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4}),?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?$/i
  );

  if (m) {
    const [, d, mo, y, h, mi, s, ap] = m;
    let hours = Number(h);
    if (ap) {
      const isPm = ap.toLowerCase() === "pm";
      if (isPm && hours < 12) hours += 12;
      if (!isPm && hours === 12) hours = 0;
    }
    return new Date(
      Number(y),
      Number(mo) - 1,
      Number(d),
      hours,
      Number(mi),
      Number(s) || 0
    ).getTime();
  }

  return 0;
};

const normalizeStatusValue = (val) => {
  if (
    val === true ||
    val === 1 ||
    val === "1" ||
    val === "true" ||
    val === "active"
  ) {
    return true;
  }
  if (
    val === false ||
    val === 0 ||
    val === "0" ||
    val === "false" ||
    val === "inactive" ||
    val === null ||
    val === undefined
  ) {
    return false;
  }
  return Boolean(val);
};

const SubIndustry = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [statusFilter, setStatusFilter] = useState("all");
  const [imageErrors, setImageErrors] = useState({});
  const [userNameCache, setUserNameCache] = useState({});
  const { user } = useAuth();
  const userId = user?.id;

  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  const normalizeSubIndustry = (item, parentMap = {}) => {
    const indId =
      item.industry_id ??
      item.Industry?.id ??
      item.Industry?.industry_id ??
      "";

    const parentName =
      item.Industry?.name ||
      item.industry_name ||
      item.parent_industry_name ||
      (indId ? parentMap[indId] : "") ||
      "";

    const rawStatus =
      item.is_status !== undefined && item.is_status !== null
        ? item.is_status
        : item.status;
    const isStatus = normalizeStatusValue(rawStatus);
    const isTrending = normalizeStatusValue(item.is_trending);

    return {
      id: item.id || item._id || item.sub_industry_id || item.subindustry_id,
      name: item.name || item.sub_industry_name || "",
      slug: item.slug || "",
      icon: item.icon || null,
      industry_id: indId,
      Industry: item.Industry || null,
      parent_industry_name: parentName,
      is_status: isStatus,
      is_trending: isTrending,
      status: isStatus ? "active" : "inactive",
      sort_order: Number(item.sort_order) || 0,
      created_by: item.created_by || null,
      updated_by: item.updated_by || null,
      createdAt: item.created_at || item.createdAt || null,
      updatedAt: item.updated_at || item.updatedAt || null,
      raw: item,
    };
  };

  const load = async () => {
    setLoading(true);
    try {
      const [users, parentList, rawData] = await Promise.all([
        fetchUsers().catch(() => ({})),

        // fetch ALL parent industries (loops every page)
        fetchAllRecords(industryService).catch((err) => {
          console.error("Industry load error:", err);
          return [];
        }),

        // fetch ALL sub-industries (loops every page -> 1089 records)
        fetchAllRecords(subIndustryService),
      ]);

      const userMap = {};
      if (users && typeof users === "object") {
        Object.keys(users).forEach((id) => {
          userMap[id] = users[id]?.name || `User ${id}`;
        });
      }
      setUserNameCache(userMap);

      const parentMap = {};
      parentList.forEach((ind) => {
        const indId = ind.id || ind._id || ind.industry_id;
        if (indId) parentMap[indId] = ind.name || "";
      });

      const subIndustries = rawData.map((item) =>
        normalizeSubIndustry(item, parentMap)
      );

      const sortedSubIndustries = subIndustries.sort((a, b) => {
        const dateA = parseDateSafe(a.createdAt);
        const dateB = parseDateSafe(b.createdAt);
        if (dateA === dateB) return (Number(b.id) || 0) - (Number(a.id) || 0);
        return dateB - dateA;
      });

      setData(sortedSubIndustries);
    } catch (error) {
      console.error("Load error:", error);
      showError(error.message || "Failed to load sub-industries");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    setPage(1);
  }, [search, statusFilter]);

  const filteredData = React.useMemo(() => {
    let result = data;

    if (statusFilter !== "all") {
      const wantActive = statusFilter === "active";
      result = result.filter((item) => item.is_status === wantActive);
    }

    const query = search.toLowerCase().trim();
    if (query) {
      result = result.filter(
        (item) =>
          String(item.name ?? "").toLowerCase().includes(query) ||
          String(item.parent_industry_name ?? "").toLowerCase().includes(query)
      );
    }

    return result;
  }, [data, search, statusFilter]);

  const paginatedData = filteredData.slice((page - 1) * limit, page * limit);

  const activeCount = React.useMemo(
    () => data.filter((r) => r.is_status === true).length,
    [data]
  );
  const inactiveCount = React.useMemo(
    () => data.length - activeCount,
    [data, activeCount]
  );

  const getFullImageUrl = (value) => {
    if (!value) return null;
    if (value.startsWith("http") || value.startsWith("data:image")) {
      return value;
    }
    if (value.startsWith("/uploads/")) {
      return `${API_BASE_URL}${value}`;
    }
    return value;
  };

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await subIndustryService.delete(deleteId);
      showSuccess("Sub-industry deleted successfully");
      load();
    } catch (error) {
      console.error("Delete error:", error);
      showError(error.message || "Failed to delete");
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  const handleStatusToggle = async (row) => {
    const currentStatus = getStatusValue(row);
    const newStatus = !currentStatus;

    const industryId = Number(row.industry_id);

    console.log("STATUS TOGGLE ROW:", row);
    console.log("INDUSTRY ID:", industryId);

    if (!industryId || Number.isNaN(industryId)) {
      showError("Parent industry is missing");
      return;
    }

    try {
      const updateData = {
        name: row.name,
        industry_id: industryId,
        is_status: newStatus,
        is_trending: row.is_trending === true,
        sort_order: Number(row.sort_order) || 0,
      };

      console.log("STATUS UPDATE PAYLOAD:", updateData);

      await subIndustryService.update(row.id, updateData);

      showSuccess(
        `Status ${newStatus ? "activated" : "deactivated"} successfully`
      );

      await load();
    } catch (error) {
      console.error("Status toggle error:", error);
      console.error("API ERROR:", error?.response?.data);

      showError(
        error?.response?.data?.message ||
          error?.message ||
          "Failed to update status"
      );
    }
  };

  const handleTrendingToggle = async (row) => {
    const newTrending = !row.is_trending;

    const industryId = Number(row.industry_id);

    console.log("TRENDING TOGGLE ROW:", row);
    console.log("INDUSTRY ID:", industryId);

    if (!industryId || Number.isNaN(industryId)) {
      showError("Parent industry is missing");
      return;
    }

    try {
      const updateData = {
        name: row.name,
        industry_id: industryId,
        is_status: getStatusValue(row),
        is_trending: newTrending,
        sort_order: Number(row.sort_order) || 0,
      };

      console.log("TRENDING UPDATE PAYLOAD:", updateData);

      await subIndustryService.update(row.id, updateData);

      showSuccess(
        `Trending ${newTrending ? "enabled" : "disabled"} successfully`
      );

      await load();
    } catch (error) {
      console.error("Trending toggle error:", error);
      console.error("API ERROR:", error?.response?.data);

      showError(
        error?.response?.data?.message ||
          error?.message ||
          "Failed to update trending"
      );
    }
  };

  const getBooleanValue = (value) => {
    return (
      value === true ||
      value === 1 ||
      value === "1" ||
      value === "true" ||
      value === "active"
    );
  };

  const getStatusValue = (row) => {
    if (row?.is_status !== undefined && row?.is_status !== null) {
      return getBooleanValue(row.is_status);
    }

    return getBooleanValue(row?.status);
  };

  const handleImageError = (id) => {
    setImageErrors((prev) => ({ ...prev, [id]: true }));
  };

  const renderIconPreview = (value, rowId) => {
    if (!value) return <span className="text-slate-400 text-xs">-</span>;

    const hasError = imageErrors[rowId];
    const fullUrl = getFullImageUrl(value);

    if (!hasError && fullUrl) {
      return (
        <div className="flex items-center gap-2">
          <div className="relative group cursor-pointer">
            <img
              src={fullUrl}
              alt="Sub-industry icon"
              className="w-12 h-12 rounded-lg object-cover border border-slate-200 shadow-sm"
              onError={() => handleImageError(rowId)}
            />
            <button
              onClick={() => window.open(fullUrl, "_blank")}
              className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center text-white"
              title="Click to view image"
            >
              <MdVisibility size={16} />
            </button>
          </div>
        </div>
      );
    } else {
      return (
        <div className="w-12 h-12 rounded-lg bg-blue-50 border border-[#4529f7] flex items-center justify-center text-[#2c0eee]">
          <MdInsertPhoto size={20} />
        </div>
      );
    }
  };

  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by) {
      return getUserNameCached(row.updated_by);
    }
    return "-";
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Icon",
      key: "icon",
      render: (value, row) => renderIconPreview(value, row.id),
    },
    {
      header: "Sub-Industry Name",
      key: "name",
      render: (v) => (
        <span className="font-medium capitalize text-slate-800">{v}</span>
      ),
    },
    {
      header: "Parent Industry",
      key: "parent_industry_name",
      render: (v) => <span className="text-slate-600">{v || "-"}</span>,
    },
    {
      header: "Sort Order",
      key: "sort_order",
      render: (v) => <span className="text-slate-500 text-sm">{v || 0}</span>,
    },
    {
      header: "Trending",
      key: "is_trending",
      render: (value, row) => {
        const isTrending = getBooleanValue(row?.is_trending);

        return (
          <button
            onClick={() => handleTrendingToggle(row)}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              isTrending ? "bg-yellow-500" : "bg-gray-300"
            }`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                isTrending ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },
    {
      header: "Status",
      key: "is_status",
      render: (_, row) => {
        const isActive = getStatusValue(row);

        return (
          <button
            onClick={() => handleStatusToggle(row)}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              isActive ? "bg-[#2c0eee]" : "bg-gray-300"
            }`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                isActive ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => (
        <span className="text-slate-500 text-sm font-medium">
          {getUpdatedByName(row)}
        </span>
      ),
    },
    {
      header: "Updated At",
      key: "updatedAt",
      render: (value) => (
        <span className="text-slate-500 text-sm">
          {value ? formatDate(value) : "-"}
        </span>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() =>
              navigate(`/subindustries/view/${id}`, { state: { item: row } })
            }
            className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() =>
              navigate(`/subindustries/edit/${id}`, { state: { item: row } })
            }
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: data.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Sub-Industries</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage sub-industry categories
          </p>
        </div>
        <Button icon={MdAdd} onClick={() => navigate("/subindustries/add")}>
          Add Sub-Industry
        </Button>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search sub-industries..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? "text-[#2c0eee]"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No sub-industries found"
        />

        {/* Footer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
          <p className="text-xs text-slate-400">
            Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
            {"â€“"}
            {Math.min(page * limit, filteredData.length)} of{" "}
            {filteredData.length} sub-industries
          </p>
          <Pagination
            page={page}
            total={filteredData.length}
            limit={limit}
            onChange={setPage}
            onLimitChange={(newLimit) => {
              setLimit(newLimit);
              setPage(1);
            }}
          />
        </div>
      </div>

      {/* Confirm Dialog */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Sub-Industry"
        message="Delete this sub-industry? This action cannot be undone."
      />
    </div>
  );
};

export default SubIndustry;

