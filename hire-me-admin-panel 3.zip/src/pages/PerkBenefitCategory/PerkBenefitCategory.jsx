﻿// // import React, { useState, useEffect, useCallback } from "react";
// // import {
// //   MdAdd,
// //   MdEdit,
// //   MdDelete,
// //   MdSearch,
// //   MdVisibility,
// // } from "react-icons/md";
// // import Table from "../../components/common/Table";
// // import Button from "../../components/common/Button";
// // import Pagination from "../../components/common/Pagination";
// // import FormModal from "../../components/common/FormModal";
// // import ConfirmDialog from "../../components/common/ConfirmDialog";
// // import ViewModal, { ViewRow, ViewBadge, ViewTrendingBadge } from "../../components/common/ViewModal";
// // import { perkBenefitCategoryService } from "../../services/perkBenefitCategory.service";
// // import { perkBenefitService } from "../../services/perkBenefit.service";
// // import { showSuccess, showError, showInfo } from "../../utils/toast";
// // import { formatDate } from "../../utils/helpers";

// // const PerkBenefitCategory = () => {
// //   const [data, setData] = useState([]);
// //   const [loading, setLoading] = useState(false);
// //   const [modalOpen, setModalOpen] = useState(false);
// //   const [viewModalOpen, setViewModalOpen] = useState(false);
// //   const [viewData, setViewData] = useState(null);
// //   const [editItem, setEditItem] = useState(null);
// //   const [deleteId, setDeleteId] = useState(null);
// //   const [formLoading, setFormLoading] = useState(false);
// //   const [deleteLoading, setDeleteLoading] = useState(false);
// //   const [search, setSearch] = useState("");
// //   const [page, setPage] = useState(1);
// //   const [limit, setLimit] = useState(20);
// //   const [statusFilter, setStatusFilter] = useState("all");
// //   const [checkingSubCategories, setCheckingSubCategories] = useState({});

// //   const normalizeCategory = (item) => ({
// //     id: item.id || item._id,
// //     name: item.name || "",
// //     is_status: item.is_status !== undefined ? item.is_status : true,
// //     is_trending: item.is_trending || false,
// //     status: item.status !== undefined ? item.status : true,
// //     createdAt: item.created_at || item.createdAt || null,
// //     updatedAt: item.updated_at || item.updatedAt || null,
// //     created_by: item.created_by || "",
// //     raw: item,
// //   });

// //   const load = async () => {
// //     setLoading(true);
// //     try {
// //       const r = await perkBenefitCategoryService.getAll({ limit: 1000 });
// //       const rawData = r.data?.data || r.data?.results || r.data || [];
// //       const categories = Array.isArray(rawData) ? rawData.map(normalizeCategory) : [];
// //       setData(categories);
// //     } catch (error) {
// //       console.error('Load error:', error);
// //       showError(error.message || "Failed to load perk benefit categories");
// //     } finally {
// //       setLoading(false);
// //     }
// //   };

// //   useEffect(() => {
// //     load();
// //   }, []);

// //   useEffect(() => {
// //     setPage(1);
// //   }, [search, statusFilter]);

// //   const filteredData = React.useMemo(() => {
// //     let result = data;
// //     if (statusFilter !== "all") {
// //       const isActive = statusFilter === "active";
// //       result = result.filter((item) => {
// //         const itemStatus = item.is_status === true || item.status === true || item.status === "active";
// //         return itemStatus === isActive;
// //       });
// //     }
// //     const query = search.toLowerCase().trim();
// //     if (query) {
// //       result = result.filter((item) =>
// //         String(item.name ?? "").toLowerCase().includes(query)
// //       );
// //     }
// //     return result;
// //   }, [data, search, statusFilter]);

// //   const paginatedData = filteredData.slice((page - 1) * limit, page * limit);

// //   const activeCount = data.filter((r) => r.is_status === true || r.status === true || r.status === "active").length;
// //   const inactiveCount = data.length - activeCount;

// //   // Form fields configuration
// //   const getFormFields = () => {
// //     return [
// //       {
// //         name: "name",
// //         label: "Category Name",
// //         type: "text",
// //         required: true,
// //         placeholder: "e.g. Health Benefits",
// //         help: "Enter a unique name for the perk benefit category"
// //       },
// //       {
// //         name: "status",
// //         label: "Status",
// //         type: "radio",
// //         options: [
// //           { value: "active", label: "Active" },
// //           { value: "inactive", label: "Inactive" },
// //         ],
// //         color: "text-[#2c0eee] focus:ring-[#4529f7]",
// //       },
// //       {
// //         name: "is_trending",
// //         label: "Mark as Trending",
// //         type: "checkbox",
// //         color: "text-yellow-500 focus:ring-yellow-500",
// //         help: "Trending categories will be highlighted in the listing",
// //       },
// //     ];
// //   };

// //   // Validation rules
// //   const validationRules = {
// //     name: {
// //       required: true,
// //       requiredMessage: 'Category name is required',
// //       minLength: 2,
// //       minLengthMessage: 'Category name must be at least 2 characters',
// //       maxLength: 50,
// //       maxLengthMessage: 'Category name must be at most 50 characters',
// //       custom: (value) => {
// //         const exists = data.some(item =>
// //           item.name.toLowerCase() === value.toLowerCase() &&
// //           (!editItem || item.id !== editItem.id)
// //         );
// //         if (exists) {
// //           return 'This category name already exists';
// //         }
// //         return null;
// //       }
// //     }
// //   };

// //   const openAdd = () => {
// //     setEditItem(null);
// //     setModalOpen(true);
// //   };

// //   const openEdit = (item) => {
// //     setEditItem(item);
// //     setModalOpen(true);
// //   };

// //   const openView = (item) => {
// //     setViewData(item);
// //     setViewModalOpen(true);
// //   };

// //   const handleSubmit = async (formData) => {
// //     setFormLoading(true);
// //     try {
// //       const submitData = {
// //         name: formData.name,
// //         is_status: formData.status === "active",
// //         is_trending: formData.is_trending || false,
// //       };

// //       if (editItem) {
// //         await perkBenefitCategoryService.update(editItem.id, submitData);
// //         showSuccess("Category updated successfully");
// //       } else {
// //         await perkBenefitCategoryService.create(submitData);
// //         showSuccess("Category created successfully");
// //       }
// //       setModalOpen(false);
// //       load();
// //     } catch (error) {
// //       console.error('Submit error:', error);
// //       showError(error.message || error?.response?.data?.message || "Failed to save");
// //     } finally {
// //       setFormLoading(false);
// //     }
// //   };

// //   // const handleDelete = async () => {
// //   //   if (!deleteId) return;

// //   //   setDeleteLoading(true);
// //   //   try {
// //   //     // Check if category has sub-categories
// //   //     try {
// //   //       const response = await perkBenefitService.getByCategoryId(deleteId);
// //   //       const subCategories = response.data || response.results || [];

// //   //       if (subCategories.length > 0) {
// //   //         showInfo(
// //   //           `Cannot delete this category because it has ${subCategories.length} sub-categor${subCategories.length > 1 ? 'ies' : 'y'}. Please delete the sub-categories first.`
// //   //         );
// //   //         setDeleteLoading(false);
// //   //         setDeleteId(null);
// //   //         return;
// //   //       }
// //   //     } catch (error) {
// //   //       console.warn('Could not check sub-categories:', error);
// //   //     }

// //   //     await perkBenefitCategoryService.delete(deleteId);
// //   //     showSuccess("Category deleted successfully");
// //   //     load();
// //   //   } catch (error) {
// //   //     console.error('Delete error:', error);
// //   //     showError(error.message || "Failed to delete");
// //   //   } finally {
// //   //     setDeleteId(null);
// //   //     setDeleteLoading(false);
// //   //   }
// //   // };

// //   const handleDelete = async () => {
// //     showError("You cannot delete it because it have child categories");
// //     return; // âŒ stop function here
// //   };

// //   const handleDeleteClick = async (row) => {
// //     const categoryId = row.id || row._id;
// //     const categoryName = row.name || "";

// //     setCheckingSubCategories(prev => ({ ...prev, [categoryId]: true }));

// //     try {
// //       // Check if category has sub-categories
// //       const response = await perkBenefitService.getByCategoryId(categoryId);
// //       const subCategories = response.data || response.results || [];

// //       if (subCategories.length > 0) {
// //         showInfo(
// //           `Cannot delete "${categoryName}" because it has ${subCategories.length} sub-categor${subCategories.length > 1 ? 'ies' : 'y'}. Please delete the sub-categories first.`
// //         );
// //         setCheckingSubCategories(prev => ({ ...prev, [categoryId]: false }));
// //         return;
// //       }

// //       setDeleteId(categoryId);
// //     } catch (error) {
// //       console.error('Delete click error:', error);
// //       // If we can't check sub-categories, allow deletion
// //       setDeleteId(categoryId);
// //     } finally {
// //       setCheckingSubCategories(prev => ({ ...prev, [categoryId]: false }));
// //     }
// //   };

// //   const handleStatusToggle = async (row) => {
// //     const currentStatus = row.is_status !== undefined ? row.is_status : row.status;
// //     const newStatus = !currentStatus;

// //     try {
// //       const updateData = {
// //         name: row.name,
// //         is_trending: row.is_trending || false,
// //         is_status: newStatus,
// //       };

// //       await perkBenefitCategoryService.update(row.id, updateData);
// //       showSuccess(`Status ${newStatus ? "activated" : "deactivated"} successfully`);
// //       load();
// //     } catch (error) {
// //       console.error('Status toggle error:', error);
// //       showError(error.response?.data?.message || error.message || "Failed to update status");
// //     }
// //   };

// //   const handleTrendingToggle = async (row) => {
// //     const newValue = !row.is_trending;

// //     try {
// //       const updateData = {
// //         name: row.name,
// //         is_trending: newValue,
// //         is_status: row.is_status !== undefined ? row.is_status : row.status,
// //       };

// //       await perkBenefitCategoryService.update(row.id, updateData);
// //       showSuccess(`Trending ${newValue ? "enabled" : "disabled"} successfully`);
// //       load();
// //     } catch (error) {
// //       console.error('Trending toggle error:', error);
// //       showError(error.response?.data?.message || error.message || "Failed to update trending");
// //     }
// //   };

// //   const getStatusValue = (row) => {
// //     if (row.is_status !== undefined) {
// //       return row.is_status;
// //     }
// //     if (row.status !== undefined) {
// //       return row.status;
// //     }
// //     return true;
// //   };

// //   const columns = [
// //     {
// //       header: "#",
// //       key: "id",
// //       render: (_, __, i) => (page - 1) * limit + i + 1
// //     },
// //     {
// //       header: "Category Name",
// //       key: "name",
// //       render: (v) => (
// //         <span className="font-medium capitalize text-slate-800">{v}</span>
// //       ),
// //     },
// //     {
// //       header: "Trending",
// //       key: "is_trending",
// //       render: (value, row) => (
// //         <button
// //           onClick={() => handleTrendingToggle(row)}
// //           className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${value ? "bg-yellow-500" : "bg-gray-300"
// //             }`}
// //         >
// //           <span
// //             className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${value ? "translate-x-6" : "translate-x-1"
// //               }`}
// //           />
// //         </button>
// //       ),
// //     },
// //     {
// //       header: "Status",
// //       key: "status",
// //       render: (status, row) => {
// //         const isActive = getStatusValue(row);
// //         return (
// //           <button
// //             onClick={() => handleStatusToggle(row)}
// //             className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${isActive ? "bg-[#2c0eee]" : "bg-gray-300"
// //               }`}
// //           >
// //             <span
// //               className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${isActive ? "translate-x-6" : "translate-x-1"
// //                 }`}
// //             />
// //           </button>
// //         );
// //       },
// //     },
// //     {
// //       header: "Created At",
// //       key: "createdAt",
// //       render: (v) => <span className="text-slate-500 text-sm">{formatDate(v)}</span>,
// //     },
// //     {
// //       header: "Actions",
// //       key: "id",
// //       render: (id, row) => {
// //         const isChecking = checkingSubCategories[id];
// //         return (
// //           <div className="flex gap-1">
// //             <button
// //               onClick={() => openView(row)}
// //               className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
// //               title="View"
// //               disabled={isChecking}
// //             >
// //               <MdVisibility size={16} />
// //             </button>
// //             <button
// //               onClick={() => openEdit(row)}
// //               className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
// //               title="Edit"
// //               disabled={isChecking}
// //             >
// //               <MdEdit size={16} />
// //             </button>
// //             <button
// //               onClick={() => handleDeleteClick(row)}
// //               className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
// //               title="Delete"
// //               disabled={isChecking}
// //             >
// //               {isChecking ? (
// //                 <span className="inline-block w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></span>
// //               ) : (
// //                 <MdDelete size={16} />
// //               )}
// //             </button>
// //           </div>
// //         );
// //       },
// //     },
// //   ];

// //   const tabs = [
// //     { key: "all", label: "All", count: data.length },
// //     { key: "active", label: "Active", count: activeCount },
// //     { key: "inactive", label: "Inactive", count: inactiveCount },
// //   ];

// //   return (
// //     <div className="space-y-4">
// //       {/* Header */}
// //       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
// //         <div>
// //           <h1 className="text-2xl font-bold text-slate-900">Perk & Benefit Categories</h1>
// //           <p className="text-sm text-slate-500 mt-1">Manage perk and benefit categories for job listings</p>
// //         </div>
// //         <Button icon={MdAdd} onClick={openAdd}>
// //           Add Category
// //         </Button>
// //       </div>

// //       {/* Table Card */}
// //       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
// //         {/* Top bar: search + tabs */}
// //         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
// //           <div className="relative w-full sm:w-72">
// //             <MdSearch
// //               size={18}
// //               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
// //             />
// //             <input
// //               type="text"
// //               value={search}
// //               onChange={(e) => setSearch(e.target.value)}
// //               placeholder="Search categories..."
// //               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
// //             />
// //           </div>

// //           <div className="flex items-center gap-5 text-sm">
// //             {tabs.map((tab) => (
// //               <button
// //                 key={tab.key}
// //                 onClick={() => setStatusFilter(tab.key)}
// //                 className={`flex items-center gap-1.5 font-medium transition-colors ${statusFilter === tab.key ? "text-[#2c0eee]" : "text-slate-500 hover:text-slate-700"
// //                   }`}
// //               >
// //                 {tab.label}
// //                 <span
// //                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${statusFilter === tab.key
// //                     ? "bg-slate-800 text-white shadow-sm"
// //                     : "bg-slate-100 text-slate-500"
// //                     }`}
// //                 >
// //                   {tab.count}
// //                 </span>
// //               </button>
// //             ))}
// //           </div>
// //         </div>

// //         <Table
// //           columns={columns}
// //           data={paginatedData}
// //           loading={loading}
// //           emptyMessage="No categories found"
// //         />

// //         {/* Footer */}
// //         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
// //           <p className="text-xs text-slate-400">
// //             Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
// //             {"â€“"}
// //             {Math.min(page * limit, filteredData.length)} of {filteredData.length} categories
// //           </p>
// //           <Pagination
// //             page={page}
// //             total={filteredData.length}
// //             limit={limit}
// //             onChange={setPage}
// //             onLimitChange={(newLimit) => {
// //               setLimit(newLimit);
// //               setPage(1);
// //             }}
// //           />
// //         </div>
// //       </div>

// //       {/* Form Modal */}
// //       <FormModal
// //         isOpen={modalOpen}
// //         onClose={() => setModalOpen(false)}
// //         onSubmit={handleSubmit}
// //         title={editItem ? "Edit Category" : "Add Category"}
// //         fields={getFormFields()}
// //         initialData={editItem ? {
// //           name: editItem.name || "",
// //           status: editItem.is_status !== undefined ? (editItem.is_status ? "active" : "inactive") : "active",
// //           is_trending: editItem.is_trending || false
// //         } : {
// //           name: "",
// //           status: "active",
// //           is_trending: false
// //         }}
// //         validationRules={validationRules}
// //         loading={formLoading}
// //         submitLabel={editItem ? "Update" : "Create"}
// //         size="sm"
// //       />

// //       {/* View Modal */}
// //       <ViewModal
// //         isOpen={viewModalOpen}
// //         onClose={() => {
// //           setViewModalOpen(false);
// //           setViewData(null);
// //         }}
// //         title="Category Details"
// //       >
// //         {viewData && (
// //           <div className="space-y-1">
// //             <ViewRow label="Category Name" value={viewData.name} />
// //             <ViewRow
// //               label="Status"
// //               value={
// //                 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${getStatusValue(viewData)
// //                   ? "bg-green-50 text-green-700"
// //                   : "bg-slate-100 text-slate-500"
// //                   }`}>
// //                   <span className={`w-1.5 h-1.5 rounded-full ${getStatusValue(viewData) ? "bg-green-500" : "bg-gray-400"}`} />
// //                   {getStatusValue(viewData) ? "Active" : "Inactive"}
// //                 </span>
// //               }
// //             />
// //             <ViewRow
// //               label="Trending"
// //               value={
// //                 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${viewData.is_trending
// //                   ? "bg-yellow-50 text-yellow-700"
// //                   : "bg-slate-100 text-slate-500"
// //                   }`}>
// //                   <span className={`w-1.5 h-1.5 rounded-full ${viewData.is_trending ? "bg-yellow-500" : "bg-gray-400"}`} />
// //                   {viewData.is_trending ? "Trending" : "Not Trending"}
// //                 </span>
// //               }
// //             />
// //             <ViewRow label="Created At" value={formatDate(viewData.createdAt)} />
// //             {viewData.updatedAt && (
// //               <ViewRow label="Updated At" value={formatDate(viewData.updatedAt)} />
// //             )}
// //             {viewData.created_by && (
// //               <ViewRow label="Created By" value={viewData.created_by} />
// //             )}
// //           </div>
// //         )}
// //       </ViewModal>

// //       <ConfirmDialog
// //         isOpen={!!deleteId}
// //         onClose={() => setDeleteId(null)}
// //         onConfirm={handleDelete}
// //         loading={deleteLoading}
// //         title="Delete Category"
// //         message="Delete this category? Associated perk benefits may be affected."
// //       />
// //     </div>
// //   );
// // };

// // export default PerkBenefitCategory;

// import React, { useState, useEffect, useCallback } from "react";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdVisibility,
// } from "react-icons/md";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import Pagination from "../../components/common/Pagination";
// import FormModal from "../../components/common/FormModal";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import ViewModal, { ViewRow, ViewBadge, ViewTrendingBadge } from "../../components/common/ViewModal";
// import { perkBenefitCategoryService } from "../../services/perkBenefitCategory.service";
// import { perkBenefitService } from "../../services/perkBenefit.service";
// import { showSuccess, showError, showInfo } from "../../utils/toast";
// import { formatDate } from "../../utils/helpers";
// import { fetchUsers } from "../../utils/getUserName";

// const PerkBenefitCategory = () => {
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [modalOpen, setModalOpen] = useState(false);
//   const [viewModalOpen, setViewModalOpen] = useState(false);
//   const [viewData, setViewData] = useState(null);
//   const [editItem, setEditItem] = useState(null);
//   const [deleteId, setDeleteId] = useState(null);
//   const [formLoading, setFormLoading] = useState(false);
//   const [deleteLoading, setDeleteLoading] = useState(false);
//   const [search, setSearch] = useState("");
//   const [page, setPage] = useState(1);
//   const [limit, setLimit] = useState(20);
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [perkBenefits, setPerkBenefits] = useState([]);
//   const [userNameCache, setUserNameCache] = useState({});

//   const getUserNameCached = (userId) => {
//     if (!userId) return "-";
//     return userNameCache[userId] || `User ${userId}`;
//   };

//   const normalizeCategory = (item) => ({
//     id: item.id || item._id,
//     name: item.name || "",
//     is_status: item.is_status !== undefined ? item.is_status : true,
//     is_trending: item.is_trending || false,
//     status: item.status !== undefined ? item.status : true,
//     createdAt: item.created_at || item.createdAt || null,
//     updatedAt: item.updated_at || item.updatedAt || null,
//     created_by: item.created_by || null,
//     updated_by: item.updated_by || null,
//     raw: item,
//   });

//   const load = async () => {
//     setLoading(true);
//     try {

//       const users = await fetchUsers();
//       const userMap = {};
//       Object.keys(users).forEach(id => {
//         userMap[id] = users[id].name;
//       });
//       setUserNameCache(userMap);

//       const r = await perkBenefitCategoryService.getAll({ limit: 1000 });
//       const rawData = r.data?.data || r.data?.results || r.data || [];
//       const categories = Array.isArray(rawData) ? rawData.map(normalizeCategory) : [];
//       // Sort by created_at descending (newest first)
//       const sortedCategories = categories.sort((a, b) => {
//         return new Date(b.createdAt) - new Date(a.createdAt);
//       });
//       setData(sortedCategories);
//     } catch (error) {
//       console.error('Load error:', error);
//       showError(error.message || "Failed to load perk benefit categories");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch all perk benefits so we know which categories have children.
//   const loadPerkBenefits = async () => {
//     try {
//       const r = await perkBenefitService.getAll({ limit: 1000 });
//       const rawData = r.data?.data || r.data?.results || r.data || [];
//       const benefits = Array.isArray(rawData) ? rawData : [];
//       setPerkBenefits(benefits);
//       return benefits;
//     } catch (error) {
//       console.error('Load perk benefits error:', error);
//       return perkBenefits;
//     }
//   };

//   useEffect(() => {
//     load();
//     loadPerkBenefits();
//   }, []);

//   useEffect(() => {
//     setPage(1);
//   }, [search, statusFilter]);

//   const filteredData = React.useMemo(() => {
//     let result = data;
//     if (statusFilter !== "all") {
//       const isActive = statusFilter === "active";
//       result = result.filter((item) => {
//         const itemStatus = item.is_status === true || item.status === true || item.status === "active";
//         return itemStatus === isActive;
//       });
//     }
//     const query = search.toLowerCase().trim();
//     if (query) {
//       result = result.filter((item) =>
//         String(item.name ?? "").toLowerCase().includes(query)
//       );
//     }
//     return result;
//   }, [data, search, statusFilter]);

//   const paginatedData = filteredData.slice((page - 1) * limit, page * limit);

//   const activeCount = data.filter((r) => r.is_status === true || r.status === true || r.status === "active").length;
//   const inactiveCount = data.length - activeCount;

//   // How many perk benefits point back to this category?
//   const getPerkBenefitsCount = (categoryId) => {
//     return perkBenefits.filter((benefit) => {
//       const parentId = benefit.category_id || benefit.perks_benefits_category?.id;
//       return String(parentId) === String(categoryId);
//     }).length;
//   };

//   // Form fields configuration
//   const getFormFields = (editData = null) => {
//     return [
//       {
//         name: "name",
//         label: "Category Name",
//         type: "text",
//         required: true,
//         placeholder: "e.g. Health Benefits",
//         help: "Enter a unique name for the perk benefit category"
//       },
//       {
//         name: "status",
//         label: "Status",
//         type: "radio",
//         options: [
//           { value: "active", label: "Active" },
//           { value: "inactive", label: "Inactive" },
//         ],
//         color: "text-[#2c0eee] focus:ring-[#4529f7]",
//       },
//       {
//         name: "is_trending",
//         label: "Mark as Trending",
//         type: "checkbox",
//         color: "text-yellow-500 focus:ring-yellow-500",
//         help: "Trending categories will be highlighted in the listing",
//       },
//     ];
//   };

//   // Validation rules
//   const validationRules = {
//     name: {
//       required: true,
//       requiredMessage: 'Category name is required',
//       minLength: 2,
//       minLengthMessage: 'Category name must be at least 2 characters',
//       maxLength: 50,
//       maxLengthMessage: 'Category name must be at most 50 characters',
//       custom: (value) => {
//         const exists = data.some(item =>
//           item.name.toLowerCase() === value.toLowerCase() &&
//           (!editItem || item.id !== editItem.id)
//         );
//         if (exists) {
//           return 'This category name already exists';
//         }
//         return null;
//       }
//     }
//   };

//   const openAdd = () => {
//     setEditItem(null);
//     setModalOpen(true);
//   };

//   const openEdit = (item) => {
//     setEditItem(item);
//     setModalOpen(true);
//   };

//   const openView = (item) => {
//     setViewData(item);
//     setViewModalOpen(true);
//   };

//   const handleSubmit = async (formData) => {
//     setFormLoading(true);
//     try {
//       const submitData = {
//         name: formData.name,
//         is_status: formData.status === "active",
//         is_trending: formData.is_trending || false,
//       };

//       if (editItem) {
//         await perkBenefitCategoryService.update(editItem.id, submitData);
//         showSuccess("Category updated successfully");
//       } else {
//         await perkBenefitCategoryService.create(submitData);
//         showSuccess("Category created successfully");
//       }
//       setModalOpen(false);
//       load();
//     } catch (error) {
//       console.error('Submit error:', error);
//       showError(error.message || error?.response?.data?.message || "Failed to save");
//     } finally {
//       setFormLoading(false);
//     }
//   };

//   // Fired from the trash icon - blocks the action up front if perk benefits
//   // are still linked, instead of opening a confirm dialog that can't succeed.
//   const handleDeleteClick = (row) => {
//     const childCount = getPerkBenefitsCount(row.id);
//     if (childCount > 0) {
//       showError(
//         `Cannot delete "${row.name}" - it has ${childCount} perk benefit${childCount === 1 ? "" : "s"} linked to it. Please delete or reassign ${childCount === 1 ? "it" : "them"} first.`
//       );
//       return;
//     }
//     setDeleteId(row.id);
//   };

//   // Fired when the user confirms deletion in the dialog. By this point we've
//   // already verified there are no linked perk benefits, but the catch block
//   // below still recognizes a backend "has children" error as a fallback.
//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       await perkBenefitCategoryService.delete(deleteId);
//       showSuccess("Category deleted successfully");
//       load();
//       loadPerkBenefits();
//     } catch (error) {
//       console.error('Delete error:', error);
//       const message = error?.response?.data?.message || error?.message || "";
//       if (/perk[-_ ]?benefit|child|foreign\s*key|constraint/i.test(message)) {
//         showError("Cannot delete this category because it has perk benefits linked to it.");
//       } else {
//         showError(message || "Failed to delete category");
//       }
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   const handleStatusToggle = async (row) => {
//     const currentStatus = row.is_status !== undefined ? row.is_status : row.status;
//     const newStatus = !currentStatus;

//     try {
//       const updateData = {
//         name: row.name,
//         is_trending: row.is_trending || false,
//         is_status: newStatus,
//         status: newStatus,
//       };

//       await perkBenefitCategoryService.update(row.id, updateData);
//       showSuccess(`Status ${newStatus ? "activated" : "deactivated"} successfully`);
//       load();
//     } catch (error) {
//       console.error('Status toggle error:', error);
//       showError(error.response?.data?.message || error.message || "Failed to update status");
//     }
//   };

//   const handleTrendingToggle = async (row) => {
//     const newValue = !row.is_trending;

//     try {
//       const updateData = {
//         name: row.name,
//         is_trending: newValue,
//         is_status: row.is_status !== undefined ? row.is_status : row.status,
//         status: row.is_status !== undefined ? row.is_status : row.status,
//       };

//       await perkBenefitCategoryService.update(row.id, updateData);
//       showSuccess(`Trending ${newValue ? "enabled" : "disabled"} successfully`);
//       load();
//     } catch (error) {
//       console.error('Trending toggle error:', error);
//       showError(error.response?.data?.message || error.message || "Failed to update trending");
//     }
//   };

//   const getStatusValue = (row) => {
//     if (row.is_status !== undefined) {
//       return row.is_status;
//     }
//     if (row.status !== undefined) {
//       return row.status;
//     }
//     return true;
//   };

//   // Get display name for created by
//   const getCreatedByName = (row) => {
//     if (!row) return "-";
//     if (row.created_by) {
//       return getUserNameCached(row.created_by);
//     }
//     return "-";
//   };

//   // Get display name for updated by
//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     if (row.updated_by) {
//       return getUserNameCached(row.updated_by);
//     }
//     return "-";
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * limit + i + 1
//     },
//     {
//       header: "Category Name",
//       key: "name",
//       render: (v) => (
//         <span className="font-medium capitalize text-slate-800">{v}</span>
//       ),
//     },
//     {
//       header: "Trending",
//       key: "is_trending",
//       render: (value, row) => (
//         <button
//           onClick={() => handleTrendingToggle(row)}
//           className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${value ? "bg-yellow-500" : "bg-gray-300"
//             }`}
//         >
//           <span
//             className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${value ? "translate-x-6" : "translate-x-1"
//               }`}
//           />
//         </button>
//       ),
//     },
//     {
//       header: "Status",
//       key: "status",
//       render: (status, row) => {
//         const isActive = getStatusValue(row);
//         return (
//           <button
//             onClick={() => handleStatusToggle(row)}
//             className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${isActive ? "bg-[#2c0eee]" : "bg-gray-300"
//               }`}
//           >
//             <span
//               className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${isActive ? "translate-x-6" : "translate-x-1"
//                 }`}
//             />
//           </button>
//         );
//       },
//     },
//     {
//       header: "Created By",
//       key: "created_by",
//       render: (_, row) => (
//         <span className="text-slate-500 text-sm font-medium">
//           {getCreatedByName(row)}
//         </span>
//       ),
//     },
//     {
//       header: "Updated By",
//       key: "updated_by",
//       render: (_, row) => (
//         <span className="text-slate-500 text-sm font-medium">
//           {getUpdatedByName(row)}
//         </span>
//       ),
//     },
//     {
//       header: "Created At",
//       key: "createdAt",
//       render: (v) => <span className="text-slate-500 text-sm">{formatDate(v)}</span>,
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => {
//         const childCount = getPerkBenefitsCount(row.id);
//         const canDelete = childCount === 0;
//         return (
//           <div className="flex gap-1">
//             <button
//               onClick={() => openView(row)}
//               className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
//               title="View"
//             >
//               <MdVisibility size={16} />
//             </button>
//             <button
//               onClick={() => openEdit(row)}
//               className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
//               title="Edit"
//             >
//               <MdEdit size={16} />
//             </button>
//             <button
//               onClick={() => handleDeleteClick(row)}
//               className={`p-1.5 rounded-lg transition-colors ${canDelete
//                 ? "hover:bg-red-50 text-slate-500 hover:text-red-600"
//                 : "text-gray-300 hover:bg-slate-50 hover:text-slate-400"
//                 }`}
//               title={canDelete ? "Delete" : `Cannot delete - ${childCount} perk benefit${childCount === 1 ? "" : "s"} linked`}
//             >
//               <MdDelete size={16} />
//             </button>
//           </div>
//         );
//       },
//     },
//   ];

//   const tabs = [
//     { key: "all", label: "All", count: data.length },
//     { key: "active", label: "Active", count: activeCount },
//     { key: "inactive", label: "Inactive", count: inactiveCount },
//   ];

//   return (
//     <div className="space-y-4">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Perk & Benefit Categories</h1>
//           <p className="text-sm text-slate-500 mt-1">Manage perk and benefit categories for job listings</p>
//         </div>
//         <Button icon={MdAdd} onClick={openAdd}>
//           Add Category
//         </Button>
//       </div>

//       {/* Table Card */}
//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         {/* Top bar: search + tabs */}
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
//           <div className="relative w-full sm:w-72">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search categories..."
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
//             />
//           </div>

//           <div className="flex items-center gap-5 text-sm">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${statusFilter === tab.key ? "text-[#2c0eee]" : "text-slate-500 hover:text-slate-700"
//                   }`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${statusFilter === tab.key
//                     ? "bg-slate-800 text-white shadow-sm"
//                     : "bg-slate-100 text-slate-500"
//                     }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={paginatedData}
//           loading={loading}
//           emptyMessage="No categories found"
//         />

//         {/* Footer */}
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
//           <p className="text-xs text-slate-400">
//             Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
//             {"â€“"}
//             {Math.min(page * limit, filteredData.length)} of {filteredData.length} categories
//           </p>
//           <Pagination
//             page={page}
//             total={filteredData.length}
//             limit={limit}
//             onChange={setPage}
//             onLimitChange={(newLimit) => {
//               setLimit(newLimit);
//               setPage(1);
//             }}
//           />
//         </div>
//       </div>

//       {/* Form Modal */}
//       <FormModal
//         isOpen={modalOpen}
//         onClose={() => setModalOpen(false)}
//         onSubmit={handleSubmit}
//         title={editItem ? "Edit Category" : "Add Category"}
//         fields={getFormFields(editItem)}
//         initialData={editItem ? {
//           name: editItem.name || "",
//           status: editItem.is_status !== undefined ? (editItem.is_status ? "active" : "inactive") : "active",
//           is_trending: editItem.is_trending || false
//         } : {
//           name: "",
//           status: "active",
//           is_trending: false
//         }}
//         validationRules={validationRules}
//         loading={formLoading}
//         submitLabel={editItem ? "Update" : "Create"}
//         size="sm"
//       />

//       {/* View Modal */}
//       <ViewModal
//         isOpen={viewModalOpen}
//         onClose={() => {
//           setViewModalOpen(false);
//           setViewData(null);
//         }}
//         title="Category Details"
//       >
//         {viewData && (
//           <div className="space-y-1">
//             <ViewRow label="Category Name" value={viewData.name} />
//             <ViewRow
//               label="Status"
//               value={
//                 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${getStatusValue(viewData)
//                   ? "bg-green-50 text-green-700"
//                   : "bg-slate-100 text-slate-500"
//                   }`}>
//                   <span className={`w-1.5 h-1.5 rounded-full ${getStatusValue(viewData) ? "bg-green-500" : "bg-gray-400"}`} />
//                   {getStatusValue(viewData) ? "Active" : "Inactive"}
//                 </span>
//               }
//             />
//             <ViewRow
//               label="Trending"
//               value={
//                 <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${viewData.is_trending
//                   ? "bg-yellow-50 text-yellow-700"
//                   : "bg-slate-100 text-slate-500"
//                   }`}>
//                   <span className={`w-1.5 h-1.5 rounded-full ${viewData.is_trending ? "bg-yellow-500" : "bg-gray-400"}`} />
//                   {viewData.is_trending ? "Trending" : "Not Trending"}
//                 </span>
//               }
//             />
//             <ViewRow label="Created At" value={formatDate(viewData.createdAt)} />
//             {viewData.updatedAt && (
//               <ViewRow label="Updated At" value={formatDate(viewData.updatedAt)} />
//             )}
//             {viewData.created_by && (
//               <ViewRow label="Created By" value={viewData.created_by} />
//             )}
//           </div>
//         )}
//       </ViewModal>

//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Category"
//         message="Delete this category? Associated perk benefits may be affected."
//       />
//     </div>
//   );
// };

// export default PerkBenefitCategory;

// pages/PerkBenefitCategory.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { perkBenefitCategoryService } from "../../services/perkBenefitCategory.service";
import { perkBenefitService } from "../../services/perkBenefit.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

const PerkBenefitCategory = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [statusFilter, setStatusFilter] = useState("all");
  const [perkBenefits, setPerkBenefits] = useState([]);
  const [userNameCache, setUserNameCache] = useState({});

  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  const normalizeCategory = (item) => ({
    id: item.id || item._id,
    name: item.name || "",
    is_status: item.is_status !== undefined ? item.is_status : true,
    is_trending: item.is_trending || false,
    status: item.status !== undefined ? item.status : true,
    createdAt: item.created_at || item.createdAt || null,
    updatedAt: item.updated_at || item.updatedAt || null,
    created_by: item.created_by || null,
    updated_by: item.updated_by || null,
    raw: item,
  });

  const load = async () => {
    setLoading(true);
    try {
      const users = await fetchUsers();
      const userMap = {};
      Object.keys(users).forEach((id) => {
        userMap[id] = users[id].name;
      });
      setUserNameCache(userMap);

      const r = await perkBenefitCategoryService.getAll({ limit: 1000 });
      const rawData = r.data?.data || r.data?.results || r.data || [];
      const categories = Array.isArray(rawData)
        ? rawData.map(normalizeCategory)
        : [];
      const sortedCategories = categories.sort((a, b) => {
        return new Date(b.createdAt) - new Date(a.createdAt);
      });
      setData(sortedCategories);
    } catch (error) {
      console.error("Load error:", error);
      showError(error.message || "Failed to load perk benefit categories");
    } finally {
      setLoading(false);
    }
  };

  const loadPerkBenefits = async () => {
    try {
      const r = await perkBenefitService.getAll({ limit: 1000 });
      const rawData = r.data?.data || r.data?.results || r.data || [];
      const benefits = Array.isArray(rawData) ? rawData : [];
      setPerkBenefits(benefits);
      return benefits;
    } catch (error) {
      console.error("Load perk benefits error:", error);
      return perkBenefits;
    }
  };

  useEffect(() => {
    load();
    loadPerkBenefits();
  }, []);

  useEffect(() => {
    setPage(1);
  }, [search, statusFilter]);

  const filteredData = React.useMemo(() => {
    let result = data;
    if (statusFilter !== "all") {
      const isActive = statusFilter === "active";
      result = result.filter((item) => {
        const itemStatus =
          item.is_status === true ||
          item.status === true ||
          item.status === "active";
        return itemStatus === isActive;
      });
    }
    const query = search.toLowerCase().trim();
    if (query) {
      result = result.filter((item) =>
        String(item.name ?? "")
          .toLowerCase()
          .includes(query),
      );
    }
    return result;
  }, [data, search, statusFilter]);

  const paginatedData = filteredData.slice((page - 1) * limit, page * limit);

  const activeCount = data.filter(
    (r) => r.is_status === true || r.status === true || r.status === "active",
  ).length;
  const inactiveCount = data.length - activeCount;

  const getPerkBenefitsCount = (categoryId) => {
    return perkBenefits.filter((benefit) => {
      const parentId =
        benefit.category_id || benefit.perks_benefits_category?.id;
      return String(parentId) === String(categoryId);
    }).length;
  };

  const getCreatedByName = (row) => {
    if (!row) return "-";
    if (row.created_by) {
      return getUserNameCached(row.created_by);
    }
    return "-";
  };

  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by) {
      return getUserNameCached(row.updated_by);
    }
    return "-";
  };

  const handleDeleteClick = (row) => {
    const childCount = getPerkBenefitsCount(row.id);
    if (childCount > 0) {
      showError(`Cannot delete it has perk benefit linked to it.`);
      return;
    }
    setDeleteId(row.id);
  };

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await perkBenefitCategoryService.delete(deleteId);
      showSuccess("Category deleted successfully");
      load();
      loadPerkBenefits();
    } catch (error) {
      console.error("Delete error:", error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/perk[-_ ]?benefit|child|foreign\s*key|constraint/i.test(message)) {
        showError(
          "Cannot delete this category because it has perk benefits linked to it.",
        );
      } else {
        showSuccess("Category deleted successfully");
        load();
      }
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  const handleStatusToggle = async (row) => {
    const currentStatus =
      row.is_status !== undefined ? row.is_status : row.status;
    const newStatus = !currentStatus;

    try {
      const updateData = {
        name: row.name,
        is_trending: row.is_trending || false,
        is_status: newStatus,
        status: newStatus,
      };

      await perkBenefitCategoryService.update(row.id, updateData);
      showSuccess(
        `Status ${newStatus ? "activated" : "deactivated"} successfully`,
      );
      load();
    } catch (error) {
      console.error("Status toggle error:", error);
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update status",
      );
    }
  };

  const handleTrendingToggle = async (row) => {
    const newValue = !row.is_trending;

    try {
      const updateData = {
        name: row.name,
        is_trending: newValue,
        is_status: row.is_status !== undefined ? row.is_status : row.status,
        status: row.is_status !== undefined ? row.is_status : row.status,
      };

      await perkBenefitCategoryService.update(row.id, updateData);
      showSuccess(`Trending ${newValue ? "enabled" : "disabled"} successfully`);
      load();
    } catch (error) {
      console.error("Trending toggle error:", error);
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update trending",
      );
    }
  };

  const getStatusValue = (row) => {
    if (row.is_status !== undefined) {
      return row.is_status;
    }
    if (row.status !== undefined) {
      return row.status;
    }
    return true;
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Category Name",
      key: "name",
      render: (v) => (
        <span className="font-medium capitalize text-slate-800">{v}</span>
      ),
    },
    {
      header: "Trending",
      key: "is_trending",
      render: (value, row) => (
        <button
          onClick={() => handleTrendingToggle(row)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            value ? "bg-yellow-500" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              value ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Status",
      key: "status",
      render: (status, row) => {
        const isActive = getStatusValue(row);
        return (
          <button
            onClick={() => handleStatusToggle(row)}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              isActive ? "bg-[#2c0eee]" : "bg-gray-300"
            }`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                isActive ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => (
        <span className="text-slate-500 text-sm font-medium">
          {getUpdatedByName(row)}
        </span>
      ),
    },
    {
      header: "Updated At",
      key: "updatedAt",
      render: (value) => (
        <span className="text-slate-500 text-sm">
          {value ? formatDate(value) : "-"}
        </span>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => {
        const childCount = getPerkBenefitsCount(row.id);
        const canDelete = childCount === 0;
        return (
          <div className="flex gap-1">
            <button
              onClick={() =>
                navigate(`/perk-benefit-categories/view/${row.id}`, {
                  state: { item: row },
                })
              }
              className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
              title="View"
            >
              <MdVisibility size={16} />
            </button>
            <button
              onClick={() =>
                navigate(`/perk-benefit-categories/edit/${row.id}`, {
                  state: { item: row },
                })
              }
              className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
              title="Edit"
            >
              <MdEdit size={16} />
            </button>
            <button
              onClick={() => handleDeleteClick(row)}
              className={`p-1.5 rounded-lg transition-colors ${
                canDelete
                  ? "hover:bg-red-50 text-red-600"
                  : "text-gray-300 hover:bg-slate-50 hover:text-slate-400 cursor-not-allowed"
              }`}
              title={canDelete ? "Delete" : `Cannot delete perk benefit linked`}
            >
              <MdDelete size={16} />
            </button>
          </div>
        );
      },
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: data.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Perk & Benefit Categories
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage perk and benefit categories for job listings
          </p>
        </div>
        <Button
          icon={MdAdd}
          onClick={() => navigate("/perk-benefit-categories/add")}
        >
          Add Category
        </Button>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search categories..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? "text-[#2c0eee]"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No categories found"
        />

        {/* Footer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
          <p className="text-xs text-slate-400">
            Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
            {"â€“"}
            {Math.min(page * limit, filteredData.length)} of{" "}
            {filteredData.length} categories
          </p>
          <Pagination
            page={page}
            total={filteredData.length}
            limit={limit}
            onChange={setPage}
            onLimitChange={(newLimit) => {
              setLimit(newLimit);
              setPage(1);
            }}
          />
        </div>
      </div>

      {/* Confirm Dialog */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Category"
        message="Delete this category? Associated perk benefits may be affected."
      />
    </div>
  );
};

export default PerkBenefitCategory;

