﻿import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdRefresh,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { cmsPageService } from "../../services/cmsPage.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";
import { useAuth } from "../../context/AuthContext";

const toBool = (val, fallback = false) => {
  if (val === undefined || val === null || val === "") return fallback;
  if (val === true || val === 1 || val === "1" || val === "true") return true;
  if (val === false || val === 0 || val === "0" || val === "false")
    return false;
  return Boolean(val);
};

const normalizeBannerImage = (value) => {
  if (!value) return null;
  if (typeof value === "string") return value.trim() || null;
  if (typeof value === "object") {
    return normalizeBannerImage(
      value.url ||
        value.uri ||
        value.path ||
        value.image ||
        value.banner_image ||
        value.file
    );
  }
  return null;
};

// Read the logged-in user from localStorage
const getLoggedInUserFromStorage = () => {
  try {
    const raw = localStorage.getItem("user");
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return null;
    return parsed;
  } catch (error) {
    console.error("Failed to read logged-in user from localStorage:", error);
    return null;
  }
};

const CmsPages = () => {
  const navigate = useNavigate();
  const { user: authUser } = useAuth();

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [statusFilter, setStatusFilter] = useState("all");
  const [userNameCache, setUserNameCache] = useState({});
  const [togglingId, setTogglingId] = useState(null);

  const [currentUser, setCurrentUser] = useState(
    () => getLoggedInUserFromStorage() || authUser || null
  );

  useEffect(() => {
    const fromStorage = getLoggedInUserFromStorage();
    if (fromStorage) {
      setCurrentUser(fromStorage);
    } else if (authUser) {
      setCurrentUser(authUser);
    }
  }, [authUser]);

  useEffect(() => {
    const handleStorage = (e) => {
      if (e.key === "user") {
        setCurrentUser(getLoggedInUserFromStorage() || authUser || null);
      }
    };
    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, [authUser]);

  // Debounce search box
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, 300);
    return () => clearTimeout(t);
  }, [search]);

  // Reset page when search or status filter changes
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, statusFilter]);

  // Resolve Updated By display
  const getUpdatedByDisplay = (userId) => {
    if (!userId) return { label: "â€”", title: undefined };

    if (currentUser?.id && Number(currentUser.id) === Number(userId)) {
      return {
        label: currentUser.name || currentUser.email || `User ${userId}`,
        title: currentUser.email || undefined,
      };
    }

    return {
      label: userNameCache[userId] || `User ${userId}`,
      title: undefined,
    };
  };

  // Normalize item
  const normalizeCmsPage = (item) => ({
    id: item.id || item._id,
    page_name: item.page_name || "",
    page_slug: item.page_slug || "",
    page_type: item.page_type || "",
    short_description: item.short_description || "",
    page_title: item.page_title || "",
    meta_title: item.meta_title || "",
    meta_description: item.meta_description || "",
    meta_keywords: item.meta_keywords || "",
    banner_image: normalizeBannerImage(item.banner_image),
    banner_title: item.banner_title || "",
    banner_subtitle: item.banner_subtitle || "",
    banner_CTA_button: item.banner_CTA_button || "",
    content: item.content || "",
    status: toBool(item.status, true),
    is_menu_visible: toBool(item.is_menu_visible, false),
    is_footer_visible: toBool(item.is_footer_visible, false),
    display_order: item.display_order || 0,
    created_by: item.created_by || null,
    updated_by: item.updated_by || null,
    created_at: item.created_at || null,
    updated_at: item.updated_at || null,
  });

  // Load all CMS pages
  const load = useCallback(async () => {
    setLoading(true);
    try {
      if (Object.keys(userNameCache).length === 0) {
        const users = await fetchUsers();
        const userMap = {};
        Object.keys(users || {}).forEach((id) => {
          userMap[id] = users[id].name;
        });
        setUserNameCache(userMap);
      }

      const response = await cmsPageService.getAll({ page: 1, limit: 100 });
      const rawData =
        response?.data?.data || response?.data?.results || response?.data || [];
      const list1 = Array.isArray(rawData) ? rawData : [];

      const pagination = response?.data?.pagination || response?.pagination;
      const totalPages = pagination?.totalPages || 1;

      let allRawData = [...list1];

      if (totalPages > 1) {
        const fetchPromises = [];
        for (let p = 2; p <= totalPages; p++) {
          fetchPromises.push(cmsPageService.getAll({ page: p, limit: 100 }));
        }
        const results = await Promise.all(fetchPromises);
        results.forEach((res) => {
          const rawList =
            res?.data?.data || res?.data?.results || res?.data || [];
          if (Array.isArray(rawList)) {
            allRawData.push(...rawList);
          }
        });
      }

      const pages = allRawData.map(normalizeCmsPage);
      const sortedPages = pages.sort((a, b) => {
        if (a.display_order !== b.display_order) {
          return a.display_order - b.display_order;
        }
        return (b.id || 0) - (a.id || 0);
      });

      setData(sortedPages);
    } catch (error) {
      console.error("Load error:", error);
      showError(error.message || "Failed to load CMS pages");
    } finally {
      setLoading(false);
    }
  }, [userNameCache]);

  useEffect(() => {
    load();
  }, [load]);

  // Tab counts
  const activeCount = useMemo(
    () => data.filter((r) => r.status === true).length,
    [data]
  );
  const inactiveCount = useMemo(
    () => data.length - activeCount,
    [data, activeCount]
  );

  // Client-side filtering across data
  const filteredData = useMemo(() => {
    let rows = data;

    if (debouncedSearch) {
      const q = debouncedSearch.toLowerCase();
      rows = rows.filter((r) =>
        [r.page_name, r.page_slug, r.page_type, r.short_description, r.page_title]
          .filter(Boolean)
          .some((field) => field.toLowerCase().includes(q))
      );
    }

    if (statusFilter === "active") {
      rows = rows.filter((r) => r.status === true);
    } else if (statusFilter === "inactive") {
      rows = rows.filter((r) => r.status === false);
    }

    return rows;
  }, [data, debouncedSearch, statusFilter]);

  const paginatedData = useMemo(() => {
    return filteredData.slice((page - 1) * limit, page * limit);
  }, [filteredData, page, limit]);

  // Navigation
  const openAdd = () => navigate("/cms-pages/add");
  const openEdit = (item) =>
    navigate(`/cms-pages/edit/${item.id}`, { state: { item } });
  const openView = (item) =>
    navigate(`/cms-pages/view/${item.id}`, { state: { item } });

  // Delete
  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await cmsPageService.delete(deleteId);
      showSuccess("CMS page deleted successfully");
      load();
    } catch (error) {
      console.error("Delete error:", error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
        showError(
          "Cannot delete this page because it is being used in other records."
        );
      } else {
        showError(message || "Failed to delete CMS page");
      }
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  // Toggle active/inactive status
  const handleStatusToggle = async (row) => {
    if (togglingId === row.id) return;
    const currentStatus = row.status === true;
    const newStatus = !currentStatus;
    const prevUpdatedBy = row.updated_by;
    const prevUpdatedAt = row.updated_at;
    const nowIso = new Date().toISOString();

    setTogglingId(row.id);
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id
          ? {
              ...item,
              status: newStatus,
              updated_by: currentUser?.id ?? item.updated_by,
              updated_at: nowIso,
            }
          : item
      )
    );

    try {
      await cmsPageService.update(row.id, {
        status: newStatus ? 1 : 0,
        updated_by: currentUser?.id,
      });
      showSuccess(
        `Status ${newStatus ? "activated" : "deactivated"} successfully`
      );
    } catch (error) {
      console.error("Status toggle error:", error);
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id
            ? {
                ...item,
                status: currentStatus,
                updated_by: prevUpdatedBy,
                updated_at: prevUpdatedAt,
              }
            : item
        )
      );
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update status"
      );
    } finally {
      setTogglingId(null);
    }
  };

  // Toggle Menu visibility
  const handleMenuToggle = async (row) => {
    if (togglingId === `menu-${row.id}`) return;
    const currentVal = row.is_menu_visible === true;
    const newVal = !currentVal;
    const prevUpdatedBy = row.updated_by;
    const prevUpdatedAt = row.updated_at;
    const nowIso = new Date().toISOString();

    setTogglingId(`menu-${row.id}`);
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id
          ? {
              ...item,
              is_menu_visible: newVal,
              updated_by: currentUser?.id ?? item.updated_by,
              updated_at: nowIso,
            }
          : item
      )
    );

    try {
      await cmsPageService.update(row.id, {
        is_menu_visible: newVal ? 1 : 0,
        updated_by: currentUser?.id,
      });
      showSuccess(
        `Menu visibility ${newVal ? "enabled" : "disabled"} successfully`
      );
    } catch (error) {
      console.error("Menu toggle error:", error);
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id
            ? {
                ...item,
                is_menu_visible: currentVal,
                updated_by: prevUpdatedBy,
                updated_at: prevUpdatedAt,
              }
            : item
        )
      );
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update menu visibility"
      );
    } finally {
      setTogglingId(null);
    }
  };

  // Toggle Footer visibility
  const handleFooterToggle = async (row) => {
    if (togglingId === `footer-${row.id}`) return;
    const currentVal = row.is_footer_visible === true;
    const newVal = !currentVal;
    const prevUpdatedBy = row.updated_by;
    const prevUpdatedAt = row.updated_at;
    const nowIso = new Date().toISOString();

    setTogglingId(`footer-${row.id}`);
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id
          ? {
              ...item,
              is_footer_visible: newVal,
              updated_by: currentUser?.id ?? item.updated_by,
              updated_at: nowIso,
            }
          : item
      )
    );

    try {
      await cmsPageService.update(row.id, {
        is_footer_visible: newVal ? 1 : 0,
        updated_by: currentUser?.id,
      });
      showSuccess(
        `Footer visibility ${newVal ? "enabled" : "disabled"} successfully`
      );
    } catch (error) {
      console.error("Footer toggle error:", error);
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id
            ? {
                ...item,
                is_footer_visible: currentVal,
                updated_by: prevUpdatedBy,
                updated_at: prevUpdatedAt,
              }
            : item
        )
      );
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update footer visibility"
      );
    } finally {
      setTogglingId(null);
    }
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Page Name",
      key: "page_name",
      render: (v) => <span className="font-medium text-slate-800">{v}</span>,
    },
    {
      header: "Slug",
      key: "page_slug",
      render: (v) => <span className="text-slate-500 text-sm">{v}</span>,
    },
    {
      header: "Page Type",
      key: "page_type",
      render: (v) => <span className="text-slate-500 text-sm">{v || "â€”"}</span>,
    },
    {
      header: "Status",
      key: "status",
      render: (value, row) => (
        <button
          onClick={() => handleStatusToggle(row)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            row.status === true ? "bg-[#2c0eee]" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              row.status === true ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Menu",
      key: "is_menu_visible",
      render: (value, row) => (
        <button
          onClick={() => handleMenuToggle(row)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            row.is_menu_visible === true ? "bg-blue-500" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              row.is_menu_visible === true ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Footer",
      key: "is_footer_visible",
      render: (value, row) => (
        <button
          onClick={() => handleFooterToggle(row)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            row.is_footer_visible === true ? "bg-green-500" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              row.is_footer_visible === true ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => {
        const { label, title } = getUpdatedByDisplay(row.updated_by);
        return (
          <span className="text-slate-500 text-sm font-medium" title={title}>
            {label}
          </span>
        );
      },
    },
    {
      header: "Updated At",
      key: "updated_at",
      render: (v) => (
        <span className="text-slate-500 text-sm">{formatDate(v)}</span>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() => openView(row)}
            className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() => openEdit(row)}
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: data.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">CMS Pages</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage static pages and content
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={load}
            loading={loading}
          >
            Refresh
          </Button>
          <Button icon={MdAdd} onClick={openAdd}>
            Add CMS Page
          </Button>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search pages..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? "text-blue-600"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No CMS pages found"
        />

        <Pagination
          page={page}
          total={filteredData.length}
          limit={limit}
          onChange={setPage}
          onLimitChange={(newLimit) => {
            setLimit(newLimit);
            setPage(1);
          }}
        />
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete CMS Page"
        message="Delete this page? This action cannot be undone."
      />
    </div>
  );
};

export default CmsPages;

