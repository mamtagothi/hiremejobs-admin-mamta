﻿// import React, { useState, useEffect, useMemo, useCallback } from "react";
// import { useNavigate } from "react-router-dom";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import Pagination from "../../components/common/Pagination";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import candidateService from "../../services/candidate.service";
// import { showSuccess, showError } from "../../utils/toast";
// import { formatDate } from "../../utils/helpers";
// import { fetchUsers } from "../../utils/getUserName";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdVisibility,
//   MdOpenInNew,
// } from "react-icons/md";

// const API_BASE_URL = "https://apidata.hiremejobs.in";

// // â”€â”€â”€ Helpers to safely extract arrays & pagination from any response shape â”€â”€
// const extractList = (body) => {
//   if (Array.isArray(body)) return body;
//   if (!body || typeof body !== "object") return [];
//   if (Array.isArray(body.data?.data)) return body.data.data;
//   if (Array.isArray(body.data)) return body.data;
//   if (Array.isArray(body.results)) return body.results;
//   return [];
// };

// const extractPagination = (body) => {
//   if (!body || typeof body !== "object") return null;
//   if (body.data?.pagination) return body.data.pagination;
//   if (body.pagination) return body.pagination;
//   return null;
// };

// const Candidates = () => {
//   const navigate = useNavigate();
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [deleteId, setDeleteId] = useState(null);
//   const [deleteLoading, setDeleteLoading] = useState(false);
//   const [search, setSearch] = useState("");
//   const [debouncedSearch, setDebouncedSearch] = useState("");
//   const [page, setPage] = useState(1);
//   const [limit, setLimit] = useState(10);
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [userNameCache, setUserNameCache] = useState({});

//   // Get user name with caching
//   const getUserNameCached = (userId) => {
//     if (!userId) return "-";
//     return userNameCache[userId] || `User ${userId}`;
//   };

//   // Get full image URL
//   const getFullImageUrl = (value) => {
//     if (!value) return null;
//     if (value.startsWith("http") || value.startsWith("data:image")) {
//       return value;
//     }
//     if (value.startsWith("/uploads/")) {
//       return `${API_BASE_URL}${value}`;
//     }
//     if (value.startsWith("./uploads/")) {
//       return `${API_BASE_URL}${value.substring(1)}`;
//     }
//     if (value.startsWith("/")) {
//       return `${API_BASE_URL}${value}`;
//     }
//     return value;
//   };

//   // Normalize candidate data
//   const normalizeCandidate = (item) => ({
//     id: item.id || item._id,
//     first_name: item.first_name || "",
//     last_name: item.last_name || "",
//     email: item.email || "",
//     mobile: item.mobile || "",
//     profile_photo: item.profile_photo || null,
//     status: String(item.status || "inactive")
//       .trim()
//       .toLowerCase(),
//     last_login_at: item.last_login_at || null,
//     created_by: item.created_by || null,
//     updated_by: item.updated_by || null,
//     created_at: item.createdAt || item.created_at || null,
//     updated_at: item.updatedAt || item.updated_at || null,
//   });

//   const [paginationLinks, setPaginationLinks] = useState(null);
//   const [totalItems, setTotalItems] = useState(0);

//   // Debounce search input to avoid hitting API on every keystroke
//   useEffect(() => {
//     const handler = setTimeout(() => {
//       setDebouncedSearch(search);
//     }, 350);
//     return () => clearTimeout(handler);
//   }, [search]);

//   // Reset page to 1 when search or status filter changes
//   useEffect(() => {
//     setPage(1);
//   }, [debouncedSearch, statusFilter]);

//   // â”€â”€â”€ Dynamic Candidate Load Function â”€â”€â”€
//   const load = useCallback(
//     async (
//       searchTerm = "",
//       currentPage = 1,
//       currentLimit = 10,
//       currentStatus = "all",
//     ) => {
//       setLoading(true);

//       try {
//         // 1. Fetch user cache if not loaded
//         if (Object.keys(userNameCache).length === 0) {
//           try {
//             const users = await fetchUsers();
//             const userMap = {};
//             Object.keys(users || {}).forEach((id) => {
//               userMap[id] = users[id].name;
//             });
//             setUserNameCache(userMap);
//           } catch (e) {
//             console.warn("Could not fetch user names cache:", e);
//           }
//         }

//         // 2. Build API params with page, limit, search, status
//         const params = {
//           page: currentPage,
//           limit: currentLimit,
//         };
//         if (searchTerm && searchTerm.trim()) {
//           params.search = searchTerm.trim();
//         }
//         if (currentStatus && currentStatus !== "all") {
//           params.status = currentStatus;
//         }

//         // 3. Fetch page data
//         const response = await candidateService.getAll(params);
//         const body = response?.data;

//         const rawList = extractList(body);
//         const pagination = extractPagination(body);
//         const extractedLinks =
//           pagination?.links || body?.links || body?.data?.links || null;

//         // 4. Remove duplicate items by ID & normalize
//         const uniqueCandidates = Array.from(
//           new Map(rawList.map((c) => [String(c?.id ?? c?._id), c])).values(),
//         );
//         const items = uniqueCandidates.map(normalizeCandidate);

//         setData(items);
//         setPaginationLinks(extractedLinks);

//         const serverTotal = Number(
//           pagination?.total || pagination?.total_items || 0,
//         );
//         setTotalItems(serverTotal > 0 ? serverTotal : items.length);
//       } catch (error) {
//         console.error("Candidate load error:", error);
//         showError(
//           error?.response?.data?.message || "Failed to load candidates",
//         );
//         setData([]);
//         setPaginationLinks(null);
//         setTotalItems(0);
//       } finally {
//         setLoading(false);
//       }
//     },
//     [userNameCache],
//   );

//   useEffect(() => {
//     load(debouncedSearch, page, limit, statusFilter);
//   }, [debouncedSearch, page, limit, statusFilter, load]);

//   const filteredData = useMemo(() => {
//     let result = data;
//     if (statusFilter !== "all") {
//       result = result.filter((item) => {
//         if (statusFilter === "active") return item.status === "active";
//         if (statusFilter === "inactive") return item.status === "inactive";
//         if (statusFilter === "blocked") return item.status === "blocked";
//         return true;
//       });
//     }
//     const query = search.toLowerCase().trim();
//     if (query) {
//       result = result.filter((item) =>
//         [item.first_name, item.last_name, item.email, item.mobile].some(
//           (value) =>
//             String(value ?? "")
//               .toLowerCase()
//               .includes(query),
//         ),
//       );
//     }
//     return result;
//   }, [data, search, statusFilter]);

//   const paginatedData = useMemo(() => {
//     // If backend provided pagination links or server returned paginated items (data.length <= limit)
//     if (paginationLinks || (totalItems > data.length && data.length <= limit)) {
//       return filteredData;
//     }
//     return filteredData.slice((page - 1) * limit, page * limit);
//   }, [filteredData, page, limit, paginationLinks, totalItems, data.length]);

//   // Counts for tabs
//   const activeCount = data.filter((c) => c.status === "active").length;
//   const inactiveCount = data.filter((c) => c.status === "inactive").length;
//   const blockedCount = data.filter((c) => c.status === "blocked").length;

//   const getCreatedByName = (row) => {
//     if (!row) return "-";
//     if (row.created_by) {
//       return getUserNameCached(row.created_by);
//     }
//     return "-";
//   };

//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     if (row.updated_by) {
//       return getUserNameCached(row.updated_by);
//     }
//     return "-";
//   };

//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       await candidateService.delete(deleteId);
//       showSuccess("Candidate deleted successfully");
//       load();
//     } catch (err) {
//       console.error("Delete error:", err);
//       showError(err.response?.data?.message || "Failed to delete");
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   const getCurrentUserId = () => {
//     try {
//       const user = JSON.parse(localStorage.getItem("user") || "{}");
//       if (user.id) return parseInt(user.id, 10);

//       const userId = localStorage.getItem("userId");
//       if (userId) return parseInt(userId, 10);
//     } catch (err) {
//       console.warn("Could not get user ID from localStorage");
//     }

//     return 1;
//   };

//   // â”€â”€â”€ NEW: Change status to any value (active / inactive / blocked) â”€â”€
//   const handleStatusChange = async (id, newStatus) => {
//     const previousStatus = data.find((item) => item.id === id)?.status;

//     // Optimistic update
//     setData((prev) =>
//       prev.map((item) =>
//         item.id === id ? { ...item, status: newStatus } : item,
//       ),
//     );

//     try {
//       await candidateService.update(id, {
//         status: newStatus,
//         updated_by: getCurrentUserId(),
//       });
//       showSuccess(`Status updated to ${newStatus}`);
//     } catch (err) {
//       // Revert on failure
//       setData((prev) =>
//         prev.map((item) =>
//           item.id === id ? { ...item, status: previousStatus } : item,
//         ),
//       );
//       console.error("Status update error:", err);
//       showError(err.response?.data?.message || "Failed to update status");
//     }
//   };

//   // Navigate to view page instead of opening popup
//   const openView = (item) => {
//     navigate(`/candidates/view/${item.id}`, { state: { item } });
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * limit + i + 1,
//     },
//     // Photo column commented out (can be re-enabled if needed)
//     // {
//     //   header: "Photo",
//     //   key: "profile_photo",
//     //   render: (photo) =>
//     //     photo ? (
//     //       <img
//     //         src={getFullImageUrl(photo)}
//     //         alt="profile"
//     //         className="w-8 h-8 object-cover rounded-full border border-slate-200"
//     //         onError={(e) => {
//     //           e.target.style.display = "none";
//     //         }}
//     //       />
//     //     ) : (
//     //       <div className="w-8 h-8 rounded-full border border-slate-200 bg-slate-50 flex items-center justify-center text-gray-300 text-xs font-medium">
//     //         ?
//     //       </div>
//     //     ),
//     // },
//     {
//       header: "Full Name",
//       key: "first_name",
//       render: (_, row) => (
//         <span className="font-medium capitalize text-slate-800">
//           {row.first_name} {row.last_name}
//         </span>
//       ),
//     },
//     {
//       header: "Email",
//       key: "email",
//       render: (v) => <span className="text-sm text-slate-500">{v}</span>,
//     },
//     {
//       header: "Mobile",
//       key: "mobile",
//       render: (v) => <span className="text-sm text-slate-500">{v}</span>,
//     },
//     {
//       header: "Status",
//       key: "status",
//       render: (status, row) => (
//         <select
//           value={status}
//           onChange={(e) => handleStatusChange(row.id, e.target.value)}
//           className={`text-xs font-medium px-2.5 py-1.5 rounded-lg border focus:outline-none focus:ring-2 cursor-pointer transition-colors ${
//             status === "active"
//               ? "bg-green-50 text-green-700 border-green-200 focus:ring-green-100"
//               : status === "blocked"
//                 ? "bg-red-50 text-red-700 border-red-200 focus:ring-red-100"
//                 : "bg-slate-100 text-slate-600 border-gray-200 focus:ring-gray-100"
//           }`}
//         >
//           <option value="active">Active</option>
//           <option value="inactive">Inactive</option>
//           <option value="blocked">Blocked</option>
//         </select>
//       ),
//     },
//     {
//       header: "Last Login",
//       key: "last_login_at",
//       render: (v) => (
//         <span className="text-slate-500 text-sm">{v ? formatDate(v) : "â€”"}</span>
//       ),
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => (
//         <div className="flex gap-1 justify-end">
//           <button
//             onClick={() => openView(row)}
//             className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-[#2c0eee] rounded-lg transition-colors"
//             title="View Profile"
//           >
//             <MdVisibility size={16} />
//           </button>
//           {/* Edit button - Commented out */}
//           {/* <button
//             onClick={() => navigate(`/candidates/edit/${row.id}`, { state: { item: row } })}
//             className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
//             title="Edit"
//           >
//             <MdEdit size={16} />
//           </button> */}
//           <button
//             onClick={() => setDeleteId(id)}
//             className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
//             title="Delete"
//           >
//             <MdDelete size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   // Tabs: All, Active, Inactive, Blocked (like company module)
//   const tabs = [
//     { key: "all", label: "All", count: data.length },
//     { key: "active", label: "Active", count: activeCount },
//     { key: "inactive", label: "Inactive", count: inactiveCount },
//     { key: "blocked", label: "Blocked", count: blockedCount },
//   ];

//   return (
//     <div className="space-y-4">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Candidates</h1>
//           <p className="text-sm text-slate-500 mt-1">
//             Manage registered candidates
//           </p>
//         </div>
//         {/* Add button - Commented out */}
//         {/* <Button icon={MdAdd} onClick={() => navigate('/candidates/add')}>
//           Add Candidate
//         </Button> */}
//       </div>

//       {/* Table Card */}
//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         {/* Top bar: search + tabs */}
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
//           <div className="relative w-full sm:w-72">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search candidates..."
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
//             />
//           </div>

//           <div className="flex items-center gap-5 text-sm flex-wrap">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${
//                   statusFilter === tab.key
//                     ? tab.key === "blocked"
//                       ? "text-red-600"
//                       : "text-[#2c0eee]"
//                     : "text-slate-500 hover:text-slate-700"
//                 }`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                     statusFilter === tab.key
//                       ? tab.key === "blocked"
//                         ? "bg-red-50 text-red-600"
//                         : "bg-slate-800 text-white shadow-sm"
//                       : "bg-slate-100 text-slate-500"
//                   }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={paginatedData}
//           loading={loading}
//           emptyMessage="No candidates found"
//         />

//         {/* Footer */}
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
//           <p className="text-xs text-slate-400">
//             Showing {totalItems === 0 ? 0 : (page - 1) * limit + 1}
//             {"â€“"}
//             {Math.min(page * limit, totalItems)} of {totalItems} candidates
//           </p>
//           <Pagination
//             page={page}
//             total={totalItems}
//             limit={limit}
//             links={paginationLinks}
//             onChange={setPage}
//             onLimitChange={(newLimit) => {
//               setLimit(newLimit);
//               setPage(1);
//             }}
//           />
//         </div>
//       </div>

//       {/* Delete Confirmation */}
//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Candidate"
//         message="Delete this candidate? This action cannot be undone."
//       />
//     </div>
//   );
// };

// export default Candidates;

import React, { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import candidateService from "../../services/candidate.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdOpenInNew,
} from "react-icons/md";

const API_BASE_URL = "https://apidata.hiremejobs.in";

// â”€â”€â”€ Response shape helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// The API returns:
//   { data: { pagination: {...}, data: [...] } }
// and axios may or may not unwrap it. These helpers find the list
// and pagination block at whatever nesting level they live.
const extractList = (body) => {
  if (!body) return [];
  if (Array.isArray(body)) return body;
  if (Array.isArray(body.data?.data)) return body.data.data;
  if (Array.isArray(body.data)) return body.data;
  if (Array.isArray(body.results)) return body.results;
  return [];
};

const extractPagination = (body) => {
  if (!body || typeof body !== "object") return null;
  if (body.pagination) return body.pagination;
  if (body.data?.pagination) return body.data.pagination;
  if (body.meta) return body.meta;
  return null;
};

const PAGE_SIZE = 100;
const MAX_PAGES = 500;

const fetchAllRecords = async (service, params = {}) => {
  const all = [];
  const seen = new Set();
  let page = 1;
  let totalPages = Infinity;
  let totalRecords = null;

  while (page <= totalPages && page <= MAX_PAGES) {
    let res;
    try {
      res = await service.getAll({ ...params, page, limit: PAGE_SIZE });
    } catch {
      res = await service.getAll({ ...params, page, limit: 20 });
    }
    const body = res?.data ?? res;

    const rows = extractList(body);
    if (!rows.length) break;

    rows.forEach((row) => {
      const key = row?.id ?? row?._id ?? row?.email;
      if (key != null) {
        if (seen.has(key)) return;
        seen.add(key);
      }
      all.push(row);
    });

    const meta = extractPagination(body);
    if (meta) {
      if (meta.total != null) totalRecords = Number(meta.total);
      if (meta.totalPages != null) {
        totalPages = Number(meta.totalPages) || 1;
      }
    }

    if (totalRecords != null && all.length >= totalRecords) break;
    if (!meta?.totalPages && rows.length < 20) break;

    page += 1;
  }

  return all;
};

const normalizeCandidateStatus = (val) => {
  if (
    val === true ||
    val === 1 ||
    val === "1" ||
    val === "true" ||
    val === "active"
  ) {
    return "active";
  }
  if (val === "blocked") {
    return "blocked";
  }
  return "inactive";
};

const Candidates = () => {
  const navigate = useNavigate();

  // â”€â”€â”€ Data & UI state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Pagination
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);

  // User cache
  const [userNameCache, setUserNameCache] = useState({});

  // â”€â”€â”€ User name helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  // â”€â”€â”€ Image URL helper â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const getFullImageUrl = (value) => {
    if (!value) return null;
    if (value.startsWith("http") || value.startsWith("data:image")) {
      return value;
    }
    if (value.startsWith("/uploads/")) return `${API_BASE_URL}${value}`;
    if (value.startsWith("./uploads/"))
      return `${API_BASE_URL}${value.substring(1)}`;
    if (value.startsWith("/")) return `${API_BASE_URL}${value}`;
    return value;
  };

  // â”€â”€â”€ Normalize candidate â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const normalizeCandidate = (item) => ({
    id: item.id || item._id,
    first_name: item.first_name || "",
    last_name: item.last_name || "",
    email: item.email || "",
    mobile: item.mobile || "",
    profile_photo: item.profile_photo || null,
    status: normalizeCandidateStatus(item.status),
    last_login_at: item.last_login_at || null,
    created_by: item.created_by || null,
    updated_by: item.updated_by || null,
    created_at: item.createdAt || item.created_at || null,
    updated_at: item.updatedAt || item.updated_at || null,
  });

  // Reset page when search or status filter changes
  useEffect(() => {
    setPage(1);
  }, [search, statusFilter]);

  // â”€â”€â”€ Load users once â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const users = await fetchUsers();
        const userMap = {};
        Object.keys(users || {}).forEach((id) => {
          userMap[id] = users[id].name;
        });
        if (!cancelled) setUserNameCache(userMap);
      } catch (e) {
        console.warn("Could not fetch user names cache:", e);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // â”€â”€â”€ Load candidates from the API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const rawList = await fetchAllRecords(candidateService);
      const items = rawList.map(normalizeCandidate);
      setData(items);
    } catch (error) {
      console.error("Candidate load error:", error);
      showError(error?.response?.data?.message || "Failed to load candidates");
      setData([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // â”€â”€â”€ Status tab counts & filters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const activeCount = React.useMemo(
    () => data.filter((c) => c.status === "active").length,
    [data]
  );
  const inactiveCount = React.useMemo(
    () => data.filter((c) => c.status === "inactive").length,
    [data]
  );
  const blockedCount = React.useMemo(
    () => data.filter((c) => c.status === "blocked").length,
    [data]
  );

  const tabs = [
    { key: "all", label: "All", count: data.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
    { key: "blocked", label: "Blocked", count: blockedCount },
  ];

  const filteredData = React.useMemo(() => {
    let result = data;

    if (statusFilter !== "all") {
      result = result.filter((item) => item.status === statusFilter);
    }

    const query = search.toLowerCase().trim();
    if (query) {
      result = result.filter((item) => {
        const fullName = `${item.first_name} ${item.last_name}`.toLowerCase();
        return (
          fullName.includes(query) ||
          item.first_name.toLowerCase().includes(query) ||
          item.last_name.toLowerCase().includes(query) ||
          item.email.toLowerCase().includes(query) ||
          item.mobile.toLowerCase().includes(query)
        );
      });
    }

    return result;
  }, [data, search, statusFilter]);

  const paginatedData = React.useMemo(() => {
    const start = (page - 1) * limit;
    return filteredData.slice(start, start + limit);
  }, [filteredData, page, limit]);

  // â”€â”€â”€ Handlers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await candidateService.delete(deleteId);
      showSuccess("Candidate deleted successfully");
      load();
    } catch (err) {
      console.error("Delete error:", err);
      showError(err.response?.data?.message || "Failed to delete");
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  const getCurrentUserId = () => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      if (user.id) return parseInt(user.id, 10);
      const userId = localStorage.getItem("userId");
      if (userId) return parseInt(userId, 10);
    } catch (err) {
      console.warn("Could not get user ID from localStorage");
    }
    return 1;
  };

  const handleStatusChange = async (id, newStatus) => {
    const previousStatus = data.find((item) => item.id === id)?.status;

    // Optimistic update
    setData((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: newStatus } : item,
      ),
    );

    try {
      await candidateService.update(id, {
        status: newStatus,
        updated_by: getCurrentUserId(),
      });
      showSuccess(`Status updated to ${newStatus}`);
    } catch (err) {
      // Revert on failure
      setData((prev) =>
        prev.map((item) =>
          item.id === id ? { ...item, status: previousStatus } : item,
        ),
      );
      console.error("Status update error:", err);
      showError(err.response?.data?.message || "Failed to update status");
    }
  };

  const openView = (item) => {
    navigate(`/candidates/view/${item.id}`, { state: { item } });
  };

  // â”€â”€â”€ Table Columns â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Full Name",
      key: "first_name",
      render: (_, row) => (
        <span className="font-medium capitalize text-slate-800">
          {row.first_name} {row.last_name}
        </span>
      ),
    },
    {
      header: "Email",
      key: "email",
      render: (v) => <span className="text-sm text-slate-500">{v}</span>,
    },
    {
      header: "Mobile",
      key: "mobile",
      render: (v) => <span className="text-sm text-slate-500">{v}</span>,
    },
    {
      header: "Status",
      key: "status",
      render: (status, row) => (
        <select
          value={status}
          onChange={(e) => handleStatusChange(row.id, e.target.value)}
          className={`text-xs font-medium px-2.5 py-1.5 rounded-lg border focus:outline-none focus:ring-2 cursor-pointer transition-colors ${
            status === "active"
              ? "bg-green-50 text-green-700 border-green-200 focus:ring-green-100"
              : status === "blocked"
                ? "bg-red-50 text-red-700 border-red-200 focus:ring-red-100"
                : "bg-slate-100 text-slate-600 border-gray-200 focus:ring-gray-100"
          }`}
        >
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="blocked">Blocked</option>
        </select>
      ),
    },
    {
      header: "Last Login",
      key: "last_login_at",
      render: (v) => (
        <span className="text-slate-500 text-sm">{v ? formatDate(v) : "â€”"}</span>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1 justify-end">
          <button
            onClick={() => openView(row)}
            className="p-1.5 hover:bg-blue-50 text-slate-500 hover:text-[#2c0eee] rounded-lg transition-colors"
            title="View Profile"
          >
            <MdVisibility size={16} />
          </button>
          {/* <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button> */}
        </div>
      ),
    },
  ];

  // â”€â”€â”€ Main render â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Candidates</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage registered candidates
          </p>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search candidates..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm flex-wrap">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? tab.key === "blocked"
                      ? "text-red-600"
                      : "text-[#2c0eee]"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? tab.key === "blocked"
                        ? "bg-red-50 text-red-600"
                        : "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No candidates found"
        />

        {/* Footer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
          <p className="text-xs text-slate-400">
            Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
            {"â€“"}
            {Math.min(page * limit, filteredData.length)} of{" "}
            {filteredData.length} candidates
          </p>
          <Pagination
            page={page}
            total={filteredData.length}
            limit={limit}
            onChange={setPage}
            onLimitChange={(newLimit) => {
              setLimit(newLimit);
              setPage(1);
            }}
          />
        </div>
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Candidate"
        message="Delete this candidate? This action cannot be undone."
      />
    </div>
  );
};

export default Candidates;
