﻿// import React, {
//   useState,
//   useEffect,
//   useMemo,
//   useCallback,
//   useRef,
// } from "react";
// import { useNavigate } from "react-router-dom";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import Pagination from "../../components/common/Pagination";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import jobService from "../../services/job.service";
// import companyUserService from "../../services/company.service";
// import { showSuccess, showError } from "../../utils/toast";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdVisibility,
//   MdRefresh,
//   MdDateRange,
// } from "react-icons/md";
// import { formatDate } from "../../utils/helpers";
// import { useAuth } from "../../context/AuthContext";

// const Jobs = () => {
//   const navigate = useNavigate();
//   const { user } = useAuth();
//   const userId = user?.id;

//   // â”€â”€â”€ Pagination & Filters â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const [page, setPage] = useState(1);
//   const [limit, setLimit] = useState(20);

//   const [search, setSearch] = useState("");
//   const [debouncedSearch, setDebouncedSearch] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");

//   // â”€â”€â”€ Date Range Filter â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const [dateFilterType, setDateFilterType] = useState("all");
//   const [startDate, setStartDate] = useState("");
//   const [endDate, setEndDate] = useState("");
//   const [showDatePicker, setShowDatePicker] = useState(false);

//   // â”€â”€â”€ Data & UI state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const [jobs, setJobs] = useState([]);
//   const [total, setTotal] = useState(0);
//   const [loading, setLoading] = useState(false);
//   const [userNameCache, setUserNameCache] = useState({});
//   const [deleteId, setDeleteId] = useState(null);
//   const [deleteLoading, setDeleteLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [paginationLinks, setPaginationLinks] = useState(null);
//   const requestIdRef = useRef(0);

//   // â”€â”€â”€ Debounce search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     const timer = setTimeout(() => {
//       setDebouncedSearch(search.trim());
//     }, 400);
//     return () => clearTimeout(timer);
//   }, [search]);

//   // â”€â”€â”€ User name cache â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const getUserNameCached = (userId) => {
//     if (!userId) return "-";
//     return userNameCache[userId] || "-";
//   };

//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     if (row.updated_by_name !== undefined) {
//       return row.updated_by_name?.trim() || "-";
//     }
//     return row.updated_by ? getUserNameCached(row.updated_by) : "-";
//   };

//   // â”€â”€â”€ Helper: Parse API date format "DD/MM/YYYY, HH:MM:SS am/pm" â”€â”€
//   const parseApiDate = (dateString) => {
//     if (!dateString) return null;

//     const match = dateString.match(
//       /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
//     );
//     if (match) {
//       let [_, day, month, year, hours, minutes, seconds, ampm] = match;
//       hours = parseInt(hours);
//       if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
//       if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
//       return new Date(
//         parseInt(year),
//         parseInt(month) - 1,
//         parseInt(day),
//         hours,
//         parseInt(minutes),
//         parseInt(seconds),
//       );
//     }

//     const d = new Date(dateString);
//     return !isNaN(d) ? d : null;
//   };

//   // â”€â”€â”€ Get date range for filter â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const getDateRange = (filterType) => {
//     const now = new Date();
//     const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

//     switch (filterType) {
//       case "today": {
//         const start = new Date(today);
//         const end = new Date(today);
//         end.setHours(23, 59, 59, 999);
//         return { start, end };
//       }
//       case "week": {
//         const weekStart = new Date(today);
//         weekStart.setDate(today.getDate() - today.getDay());
//         weekStart.setHours(0, 0, 0, 0);
//         const end = new Date(today);
//         end.setHours(23, 59, 59, 999);
//         return { start: weekStart, end };
//       }
//       case "month": {
//         const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
//         monthStart.setHours(0, 0, 0, 0);
//         const end = new Date(today);
//         end.setHours(23, 59, 59, 999);
//         return { start: monthStart, end };
//       }
//       case "custom": {
//         if (startDate && endDate) {
//           const start = new Date(startDate);
//           start.setHours(0, 0, 0, 0);
//           const end = new Date(endDate);
//           end.setHours(23, 59, 59, 999);
//           return { start, end };
//         }
//         return { start: null, end: null };
//       }
//       default:
//         return { start: null, end: null };
//     }
//   };

//   // â”€â”€â”€ Normalize job object â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const normalizeJob = (item) => ({
//     id: item.id,
//     title: item.title || "",
//     job_description: item.job_description || "",
//     company_id: item.company_id || item.Company?.company_id || null,
//     company_name: item.Company?.company_name || "",
//     jobtype_id: item.jobtype_id || item.JobType?.jobtype_id || null,
//     jobtype_name: item.JobType?.name || "",
//     workplacetype_id:
//       item.workplacetype_id || item.WorkplaceType?.workplacetype_id || null,
//     workplacetype_name: item.WorkplaceType?.name || "",
//     functionrole_id:
//       item.functionrole_id || item.FunctionRole?.functionrole_id || null,
//     functionrole_name: item.FunctionRole?.name || "",
//     experience_min: item.experience_min ?? "",
//     experience_max: item.experience_max ?? "",
//     salary_min: item.salary_min ?? "",
//     salary_max: item.salary_max ?? "",
//     job_status: item.job_status || "draft",
//     expiry_date: item.expiry_date || "",
//     is_trending:
//       item.is_trending === true ||
//       item.is_trending === "true" ||
//       item.is_trending === 1,
//     is_status:
//       item.is_status === true ||
//       item.is_status === "true" ||
//       item.is_status === 1,
//     created_at: item.created_at || null,
//     updated_at: item.updated_at || null,
//     created_by: item.created_by || null,
//     updated_by: item.updated_by || null,
//     updated_by_name: item.Company?.CompanyUser
//       ? item.Company.CompanyUser.full_name
//       : item.CompanyUser
//         ? item.CompanyUser.full_name
//         : item.updated_by_name,
//   });

//   // â”€â”€â”€ Load jobs with pagination â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const load = useCallback(
//     async ({ silent = false } = {}) => {
//       const requestId = ++requestIdRef.current;
//       if (!silent) setLoading(true);
//       setError(null);

//       try {
//         if (Object.keys(userNameCache).length === 0) {
//           try {
//             const usersResponse = await companyUserService.getCompanyUsers();
//             const users =
//               usersResponse?.data?.data ||
//               usersResponse?.data ||
//               usersResponse ||
//               [];
//             const userMap = {};
//             const userList = Array.isArray(users) ? users : users ? [users] : [];
//             userList.forEach((companyUser) => {
//               const id =
//                 companyUser.user_id ||
//                 companyUser.id ||
//                 companyUser.company_user_id;
//               if (id) {
//                 userMap[id] = companyUser.full_name?.trim() || null;
//               }
//             });
//             setUserNameCache(userMap);
//           } catch (e) {
//             console.warn("Could not fetch company users:", e);
//           }
//         }

//         const params = { page, limit };
//         if (debouncedSearch) {
//           params.search = debouncedSearch;
//         }

//         // â­ Debug: log exactly what we're asking for so you can
//         // confirm in DevTools that page=2 is being sent.
//         console.log("[Jobs] requesting page:", page, "limit:", limit, "params:", params);

//         const response = await jobService.getAll(params);
//         if (requestIdRef.current !== requestId) return;

//         let rawList = [];
//         let totalItems = 0;
//         let links = null;

//         // â”€â”€â”€ Parse the response â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//         const body = response?.data ?? response;

//         if (body?.data && Array.isArray(body.data)) {
//           rawList = body.data;
//           totalItems = body.pagination?.total ?? body.total ?? rawList.length;
//           links = body.pagination?.links ?? body.links ?? null;
//         } else if (Array.isArray(body)) {
//           rawList = body;
//           totalItems = body.length;
//         } else if (body?.results && Array.isArray(body.results)) {
//           rawList = body.results;
//           totalItems = body.pagination?.total ?? body.total ?? rawList.length;
//           links = body.pagination?.links ?? body.links ?? null;
//         } else if (body?.data?.data && Array.isArray(body.data.data)) {
//           rawList = body.data.data;
//           totalItems =
//             body.data.pagination?.total ??
//             body.data.total ??
//             rawList.length;
//           links = body.data.pagination?.links ?? body.data.links ?? null;
//         }

//         const idsPreview = rawList.slice(0, 3).map((j) => j.id).join(",");
//         console.log(
//           `[Jobs] page=${page} â†’ ${rawList.length} rows, first ids=[${idsPreview}], total=${totalItems}`,
//         );

//         const items = rawList.map(normalizeJob);
//         setJobs(items);
//         setTotal(totalItems);
//         setPaginationLinks(links);
//       } catch (err) {
//         if (requestIdRef.current !== requestId) return;
//         console.error("Load jobs error:", err);
//         let errorMessage = "Failed to load jobs";
//         if (
//           err.message?.includes("NetworkError") ||
//           err.message?.includes("Failed to fetch")
//         ) {
//           errorMessage = "Network error: Unable to connect to the server.";
//         } else if (err.status === 401 || err.status === 403) {
//           errorMessage = "Access denied. Please log in again.";
//         } else if (err.message) {
//           errorMessage = err.message;
//         }
//         setError(errorMessage);
//         showError(errorMessage);
//       } finally {
//         if (requestIdRef.current === requestId && !silent) setLoading(false);
//       }
//     },
//     [page, limit, debouncedSearch, userNameCache],
//   );

//   useEffect(() => {
//     load();
//   }, [load]);

//   // Reset page when search or filter changes
//   useEffect(() => {
//     setPage(1);
//   }, [debouncedSearch, statusFilter, dateFilterType, startDate, endDate]);

//   // â”€â”€â”€ Client-side filtering (applied to the current page) â”€â”€â”€â”€â”€â”€â”€
//   const filteredData = useMemo(() => {
//     let result = [...jobs];

//     const query = debouncedSearch.toLowerCase();
//     if (query) {
//       result = result.filter(
//         (j) =>
//           j.title.toLowerCase().includes(query) ||
//           (j.company_name && j.company_name.toLowerCase().includes(query)) ||
//           (j.jobtype_name && j.jobtype_name.toLowerCase().includes(query)) ||
//           (j.job_status && j.job_status.toLowerCase().includes(query)),
//       );
//     }

//     if (statusFilter === "active") {
//       result = result.filter((j) => j.is_status === true);
//     } else if (statusFilter === "inactive") {
//       result = result.filter((j) => j.is_status === false);
//     } else if (statusFilter === "trending") {
//       result = result.filter((j) => j.is_trending === true);
//     }

//     const dateRange = getDateRange(dateFilterType);
//     if (dateRange.start && dateRange.end) {
//       const { start, end } = dateRange;
//       result = result.filter((j) => {
//         const jobDate = parseApiDate(j.updated_at);
//         if (!jobDate) return false;
//         return jobDate >= start && jobDate <= end;
//       });
//     }

//     return result;
//   }, [jobs, debouncedSearch, statusFilter, dateFilterType, startDate, endDate]);

//   const paginatedData = filteredData;

//   // â”€â”€â”€ Compute counts â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const activeCount = jobs.filter((j) => j.is_status === true).length;
//   const inactiveCount = jobs.filter((j) => j.is_status === false).length;
//   const trendingCount = jobs.filter((j) => j.is_trending === true).length;

//   const tabs = [
//     { key: "all", label: "All", count: total },
//     { key: "active", label: "Active", count: activeCount },
//     { key: "inactive", label: "Inactive", count: inactiveCount },
//     { key: "trending", label: "Trending", count: trendingCount },
//   ];

//   const dateFilterOptions = [
//     { key: "all", label: "All Time" },
//     { key: "today", label: "Today" },
//     { key: "week", label: "This Week" },
//     { key: "month", label: "This Month" },
//     { key: "custom", label: "Custom Range" },
//   ];

//   // â”€â”€â”€ Handlers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       try {
//         await jobService.deleteJobBenefits(deleteId);
//       } catch (benefitErr) {
//         console.log("No benefits to delete or already deleted");
//       }
//       await jobService.delete(deleteId);
//       showSuccess("Job deleted successfully");
//       load();
//     } catch (err) {
//       console.error("Delete error:", err);
//       showError(err.response?.data?.message || "Failed to delete");
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   const handleTrendingToggle = async (id, current) => {
//     const newVal = !current;
//     try {
//       await jobService.update(id, {
//         is_trending: newVal,
//         updated_by: userId,
//       });
//       showSuccess(`Trending updated to ${newVal ? "Yes" : "No"}`);
//       load({ silent: true });
//     } catch (err) {
//       showError(err.response?.data?.message || "Failed to update trending");
//     }
//   };

//   const handleStatusToggle = async (id, current) => {
//     const newVal = !current;
//     try {
//       await jobService.update(id, {
//         is_status: newVal,
//         updated_by: userId,
//       });
//       showSuccess(`Status updated to ${newVal ? "Active" : "Inactive"}`);
//       load({ silent: true });
//     } catch (err) {
//       showError(err.response?.data?.message || "Failed to update status");
//     }
//   };

//   const handleDateFilterChange = (key) => {
//     setDateFilterType(key);
//     if (key !== "custom") {
//       setStartDate("");
//       setEndDate("");
//       setShowDatePicker(false);
//     } else {
//       setShowDatePicker(true);
//     }
//   };

//   const clearDateFilter = () => {
//     setDateFilterType("all");
//     setStartDate("");
//     setEndDate("");
//     setShowDatePicker(false);
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * limit + i + 1,
//     },
//     {
//       header: "Title",
//       key: "title",
//       render: (v) => <span className="font-medium text-slate-800">{v}</span>,
//     },
//     {
//       header: "Company",
//       key: "company_name",
//       render: (v) => <span className="text-slate-600">{v || "â€”"}</span>,
//     },
//     {
//       header: "Job Type",
//       key: "jobtype_name",
//       render: (v) => <span className="text-slate-600">{v || "â€”"}</span>,
//     },
//     {
//       header: "Workplace",
//       key: "workplacetype_name",
//       render: (v) => <span className="text-slate-600">{v || "â€”"}</span>,
//     },
//     {
//       header: "Status",
//       key: "job_status",
//       render: (v) => (
//         <span
//           className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
//             v === "published"
//               ? "bg-green-100 text-green-800"
//               : v === "draft"
//                 ? "bg-slate-100 text-slate-800"
//                 : "bg-yellow-100 text-yellow-800"
//           }`}
//         >
//           {v}
//         </span>
//       ),
//     },
//     {
//       header: "Trending",
//       key: "is_trending",
//       render: (val, row) => (
//         <button
//           onClick={() => handleTrendingToggle(row.id, val)}
//           className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//             val ? "bg-amber-500" : "bg-gray-300"
//           }`}
//         >
//           <span
//             className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//               val ? "translate-x-6" : "translate-x-1"
//             }`}
//           />
//         </button>
//       ),
//     },
//     {
//       header: "Active",
//       key: "is_status",
//       render: (val, row) => (
//         <button
//           onClick={() => handleStatusToggle(row.id, val)}
//           className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//             val ? "bg-[#2c0eee]" : "bg-gray-300"
//           }`}
//         >
//           <span
//             className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//               val ? "translate-x-6" : "translate-x-1"
//             }`}
//           />
//         </button>
//       ),
//     },
//     {
//       header: "Updated By",
//       key: "updated_by",
//       render: (_, row) => (
//         <span className="text-slate-600 text-sm font-medium">
//           {getUpdatedByName(row)}
//         </span>
//       ),
//     },
//     {
//       header: "Updated At",
//       key: "updated_at",
//       render: (v) => (
//         <span className="text-slate-500 text-sm">{formatDate(v)}</span>
//       ),
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => (
//         <div className="flex gap-1 justify-end">
//           <button
//             onClick={() =>
//               navigate(`/jobs/view/${row.id}`, { state: { item: row } })
//             }
//             className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
//             title="View"
//           >
//             <MdVisibility size={16} />
//           </button>
//           <button
//             onClick={() =>
//               navigate(`/jobs/edit/${row.id}`, { state: { item: row } })
//             }
//             className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
//             title="Edit"
//           >
//             <MdEdit size={16} />
//           </button>
//           <button
//             onClick={() => setDeleteId(id)}
//             className="p-1.5 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
//             title="Delete"
//           >
//             <MdDelete size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   if (error) {
//     return (
//       <div className="space-y-4">
//         <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//           <div>
//             <h1 className="text-2xl font-bold text-slate-900">Jobs</h1>
//             <p className="text-sm text-slate-500 mt-1">Manage job listings</p>
//           </div>
//         </div>
//         <div className="bg-white rounded-xl border border-red-200 shadow-sm overflow-hidden p-8 text-center">
//           <div className="text-red-500 mb-4">
//             <svg
//               className="w-12 h-12 mx-auto"
//               fill="none"
//               stroke="currentColor"
//               viewBox="0 0 24 24"
//             >
//               <path
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//                 strokeWidth="2"
//                 d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
//               />
//             </svg>
//           </div>
//           <h3 className="text-lg font-medium text-slate-900 mb-2">
//             Failed to Load Jobs
//           </h3>
//           <p className="text-slate-600 max-w-md mx-auto whitespace-pre-line">
//             {error}
//           </p>
//           <button
//             onClick={() => load()}
//             className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
//           >
//             Retry
//           </button>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-4">
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Jobs</h1>
//           <p className="text-sm text-slate-500 mt-1">Manage job listings</p>
//         </div>
//         <div className="flex items-center gap-2">
//           <Button
//             variant="secondary"
//             icon={MdRefresh}
//             onClick={() => load()}
//             loading={loading}
//           >
//             Refresh
//           </Button>
//           <Button icon={MdAdd} onClick={() => navigate("/jobs/add")}>
//             Add Job
//           </Button>
//         </div>
//       </div>

//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         <div className="flex flex-col gap-3 px-5 py-4 border-b border-slate-100">
//           <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
//             <div className="relative w-full sm:w-72">
//               <MdSearch
//                 size={18}
//                 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//               />
//               <input
//                 type="text"
//                 value={search}
//                 onChange={(e) => setSearch(e.target.value)}
//                 placeholder="Search by title, company, type, status..."
//                 className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
//               />
//             </div>

//             <div className="flex items-center gap-2 flex-wrap">
//               <div className="flex items-center gap-1 bg-slate-50 rounded-full p-1 border border-slate-200">
//                 <MdDateRange size={16} className="text-slate-500 ml-2" />
//                 {dateFilterOptions.map((opt) => (
//                   <button
//                     key={opt.key}
//                     onClick={() => handleDateFilterChange(opt.key)}
//                     className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
//                       dateFilterType === opt.key
//                         ? "bg-[#2c0eee] text-white"
//                         : "text-slate-600 hover:bg-gray-200"
//                     }`}
//                   >
//                     {opt.label}
//                   </button>
//                 ))}
//               </div>

//               {showDatePicker && (
//                 <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-200">
//                   <input
//                     type="date"
//                     value={startDate}
//                     onChange={(e) => setStartDate(e.target.value)}
//                     className="px-2 py-1 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee]"
//                   />
//                   <span className="text-slate-400">to</span>
//                   <input
//                     type="date"
//                     value={endDate}
//                     onChange={(e) => setEndDate(e.target.value)}
//                     className="px-2 py-1 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee]"
//                   />
//                   <button
//                     onClick={clearDateFilter}
//                     className="text-slate-400 hover:text-slate-600 text-sm"
//                   >
//                     âœ•
//                   </button>
//                 </div>
//               )}

//               {dateFilterType !== "all" && (
//                 <span className="text-xs text-[#2c0eee] font-medium bg-blue-50 px-2 py-1 rounded-full">
//                   {dateFilterType === "custom"
//                     ? `${startDate || "..."} â†’ ${endDate || "..."}`
//                     : dateFilterOptions.find(
//                         (opt) => opt.key === dateFilterType,
//                       )?.label}
//                 </span>
//               )}
//             </div>
//           </div>

//           <div className="flex items-center gap-5 text-sm flex-wrap">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${
//                   statusFilter === tab.key
//                     ? tab.key === "trending"
//                       ? "text-amber-600"
//                       : "text-[#2c0eee]"
//                     : "text-slate-500 hover:text-slate-700"
//                 }`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                     statusFilter === tab.key
//                       ? tab.key === "trending"
//                         ? "bg-amber-50 text-amber-600"
//                         : "bg-slate-800 text-white shadow-sm"
//                       : "bg-slate-100 text-slate-500"
//                   }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={paginatedData}
//           loading={loading}
//           emptyMessage="No jobs found"
//         />

//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
//           <p className="text-xs text-slate-400">
//             Showing {total === 0 ? 0 : (page - 1) * limit + 1}
//             {"â€“"}
//             {Math.min(page * limit, total)} of {total} jobs
//           </p>
//           <Pagination
//             page={page}
//             total={total}
//             limit={limit}
//             links={paginationLinks}
//             onChange={setPage}
//             onLimitChange={(newLimit) => {
//               setLimit(newLimit);
//               setPage(1);
//             }}
//           />
//         </div>
//       </div>

//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Job"
//         message="Delete this job? This action cannot be undone."
//       />
//     </div>
//   );
// };

// export default Jobs;

import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import jobService from "../../services/job.service";
import companyUserService from "../../services/company.service";
import { showSuccess, showError } from "../../utils/toast";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdRefresh,
  MdDateRange,
} from "react-icons/md";
import { formatDate } from "../../utils/helpers";
import { useAuth } from "../../context/AuthContext";

const Jobs = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const userId = user?.id;

  // ============================================================
  // Pagination
  // ============================================================
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);

  // ============================================================
  // Search
  // ============================================================
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  // ============================================================
  // Filters
  // ============================================================
  const [statusFilter, setStatusFilter] = useState("all");

  const [dateFilterType, setDateFilterType] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showDatePicker, setShowDatePicker] = useState(false);

  // ============================================================
  // Data
  // ============================================================
  const [jobs, setJobs] = useState([]);
  const [total, setTotal] = useState(0);
  const [paginationLinks, setPaginationLinks] = useState(null);
  const [counts, setCounts] = useState({
    all: 0,
    active: 0,
    inactive: 0,
    trending: 0,
  });

  // ============================================================
  // UI
  // ============================================================
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [userNameCache, setUserNameCache] = useState({});

  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [togglingIds, setTogglingIds] = useState(new Set());

  // ============================================================
  // Refs
  // ============================================================

  // Prevent duplicate automatic requests
  const lastRequestKeyRef = useRef(null);

  // Prevent company users API from being called more than once
  const usersLoadedRef = useRef(false);

  // Prevent stale response from replacing latest response
  const requestIdRef = useRef(0);

  // Prevent redundant tab counts requests for same search term
  const lastCountsSearchRef = useRef(null);

  // ============================================================
  // Debounce Search
  // ============================================================
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(1);
    }, 250);

    return () => clearTimeout(timer);
  }, [search]);

  // ============================================================
  // Load Company Users
  //
  // IMPORTANT:
  // This is separate from loadJobs().
  // Therefore userNameCache changes will NOT recreate loadJobs().
  // ============================================================
  useEffect(() => {
    if (usersLoadedRef.current) return;

    usersLoadedRef.current = true;

    const loadCompanyUsers = async () => {
      try {
        const usersResponse = await companyUserService.getCompanyUsers();

        const users =
          usersResponse?.data?.data ||
          usersResponse?.data ||
          usersResponse ||
          [];

        const userMap = {};

        const userList = Array.isArray(users)
          ? users
          : users
            ? [users]
            : [];

        userList.forEach((companyUser) => {
          const id =
            companyUser.user_id ||
            companyUser.id ||
            companyUser.company_user_id;

          if (id) {
            userMap[id] = companyUser.full_name?.trim() || null;
          }
        });

        setUserNameCache(userMap);
      } catch (err) {
        console.warn("Could not fetch company users:", err);
      }
    };

    loadCompanyUsers();
  }, []);

  // ============================================================
  // User Name Helpers
  // ============================================================
  const getUserNameCached = useCallback(
    (id) => {
      if (!id) return "-";

      return userNameCache[id] || "-";
    },
    [userNameCache],
  );

  const getUpdatedByName = useCallback(
    (row) => {
      if (!row) return "-";

      if (row.updated_by_name !== undefined) {
        return row.updated_by_name?.trim() || "-";
      }

      return row.updated_by
        ? getUserNameCached(row.updated_by)
        : "-";
    },
    [getUserNameCached],
  );

  // ============================================================
  // Parse API Date
  // ============================================================
  const parseApiDate = useCallback((dateString) => {
    if (!dateString) return null;

    const match = dateString.match(
      /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
    );

    if (match) {
      let [
        _,
        day,
        month,
        year,
        hours,
        minutes,
        seconds,
        ampm,
      ] = match;

      hours = parseInt(hours);

      if (ampm.toLowerCase() === "pm" && hours < 12) {
        hours += 12;
      }

      if (ampm.toLowerCase() === "am" && hours === 12) {
        hours = 0;
      }

      return new Date(
        parseInt(year),
        parseInt(month) - 1,
        parseInt(day),
        hours,
        parseInt(minutes),
        parseInt(seconds),
      );
    }

    const d = new Date(dateString);

    return !isNaN(d) ? d : null;
  }, []);

  // ============================================================
  // Get Date Range
  // ============================================================
  const getDateRange = useCallback(
    (filterType) => {
      const now = new Date();

      const today = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
      );

      switch (filterType) {
        case "today": {
          const start = new Date(today);

          const end = new Date(today);
          end.setHours(23, 59, 59, 999);

          return { start, end };
        }

        case "week": {
          const weekStart = new Date(today);

          weekStart.setDate(
            today.getDate() - today.getDay(),
          );

          weekStart.setHours(0, 0, 0, 0);

          const end = new Date(today);

          end.setHours(23, 59, 59, 999);

          return {
            start: weekStart,
            end,
          };
        }

        case "month": {
          const monthStart = new Date(
            today.getFullYear(),
            today.getMonth(),
            1,
          );

          monthStart.setHours(0, 0, 0, 0);

          const end = new Date(today);

          end.setHours(23, 59, 59, 999);

          return {
            start: monthStart,
            end,
          };
        }

        case "custom": {
          if (startDate && endDate) {
            const start = new Date(startDate);

            start.setHours(0, 0, 0, 0);

            const end = new Date(endDate);

            end.setHours(23, 59, 59, 999);

            return {
              start,
              end,
            };
          }

          return {
            start: null,
            end: null,
          };
        }

        default:
          return {
            start: null,
            end: null,
          };
      }
    },
    [startDate, endDate],
  );

  // ============================================================
  // Normalize Job
  // ============================================================
  const normalizeJob = useCallback((item) => {
    return {
      id: item.id,

      title: item.title || "",

      job_description: item.job_description || "",

      company_id:
        item.company_id ||
        item.Company?.company_id ||
        null,

      company_name:
        item.Company?.company_name || "",

      jobtype_id:
        item.jobtype_id ||
        item.JobType?.jobtype_id ||
        null,

      jobtype_name:
        item.JobType?.name || "",

      workplacetype_id:
        item.workplacetype_id ||
        item.WorkplaceType?.workplacetype_id ||
        null,

      workplacetype_name:
        item.WorkplaceType?.name || "",

      functionrole_id:
        item.functionrole_id ||
        item.FunctionRole?.functionrole_id ||
        null,

      functionrole_name:
        item.FunctionRole?.name || "",

      experience_min:
        item.experience_min ?? "",

      experience_max:
        item.experience_max ?? "",

      salary_min:
        item.salary_min ?? "",

      salary_max:
        item.salary_max ?? "",

      job_status:
        item.job_status || "draft",

      expiry_date:
        item.expiry_date || "",

      is_trending:
        item.is_trending === true ||
        item.is_trending === "true" ||
        item.is_trending === 1,

      is_status:
        item.is_status === true ||
        item.is_status === "true" ||
        item.is_status === 1,

      created_at:
        item.created_at || null,

      updated_at:
        item.updated_at || null,

      created_by:
        item.created_by || null,

      updated_by:
        item.updated_by || null,

      updated_by_name:
        item.Company?.CompanyUser
          ? item.Company.CompanyUser.full_name
          : item.CompanyUser
            ? item.CompanyUser.full_name
            : item.updated_by_name,
    };
  }, []);

  // ============================================================
  // Fetch Tab Counts (Non-blocking Background Sync)
  // ============================================================
  const fetchTabCounts = useCallback(
    async (searchQuery = "", currentTab = null, currentTotal = null) => {
      const searchKey = `${searchQuery}`;
      lastCountsSearchRef.current = searchKey;

      try {
        const searchParam = searchQuery ? { search: searchQuery } : {};

        // Reuse known total for current tab to avoid duplicate request
        const reqAll =
          currentTab === "all" && currentTotal !== null
            ? Promise.resolve(currentTotal)
            : jobService.getAll({ limit: 1, ...searchParam });

        const reqActive =
          currentTab === "active" && currentTotal !== null
            ? Promise.resolve(currentTotal)
            : jobService.getAll({ limit: 1, is_status: true, ...searchParam });

        const reqInactive =
          currentTab === "inactive" && currentTotal !== null
            ? Promise.resolve(currentTotal)
            : jobService.getAll({ limit: 1, is_status: false, ...searchParam });

        const reqTrending =
          currentTab === "trending" && currentTotal !== null
            ? Promise.resolve(currentTotal)
            : jobService.getAll({ limit: 1, is_trending: true, ...searchParam });

        const [allRes, activeRes, inactiveRes, trendingRes] = await Promise.all([
          reqAll,
          reqActive,
          reqInactive,
          reqTrending,
        ]);

        const getResTotal = (res) => {
          if (typeof res === "number") return res;
          const body = res?.data ?? res;
          if (body?.pagination?.total !== undefined) return body.pagination.total;
          if (body?.total !== undefined) return body.total;
          if (Array.isArray(body?.data)) return body.data.length;
          if (Array.isArray(body)) return body.length;
          return 0;
        };

        if (lastCountsSearchRef.current === searchKey) {
          setCounts({
            all: getResTotal(allRes),
            active: getResTotal(activeRes),
            inactive: getResTotal(inactiveRes),
            trending: getResTotal(trendingRes),
          });
        }
      } catch (err) {
        console.warn("Could not fetch tab counts:", err);
      }
    },
    [],
  );

  // ============================================================
  // LOAD JOBS
  // ============================================================
  const load = useCallback(
    async ({ silent = false, force = false } = {}) => {
      const requestKey = `${page}-${limit}-${debouncedSearch}-${statusFilter}`;

      // Prevent duplicate automatic requests
      if (!force && lastRequestKeyRef.current === requestKey) {
        return;
      }

      lastRequestKeyRef.current = requestKey;

      const requestId = ++requestIdRef.current;

      if (!silent) {
        setLoading(true);
      }

      setError(null);

      try {
        const params = {
          page,
          limit,
        };

        if (debouncedSearch) {
          params.search = debouncedSearch;
        }

        if (statusFilter === "active") {
          params.is_status = true;
        } else if (statusFilter === "inactive") {
          params.is_status = false;
        } else if (statusFilter === "trending") {
          params.is_trending = true;
        }

        console.log(
          "[Jobs] API REQUEST:",
          params,
        );

        const response = await jobService.getAll(params);

        // Ignore old/stale request
        if (requestIdRef.current !== requestId) {
          return;
        }

        let rawList = [];
        let totalItems = 0;
        let links = null;

        const body = response?.data ?? response;

        if (
          body?.data &&
          Array.isArray(body.data)
        ) {
          rawList = body.data;

          totalItems =
            body.pagination?.total ??
            body.total ??
            rawList.length;

          links =
            body.pagination?.links ??
            body.links ??
            null;
        } else if (Array.isArray(body)) {
          rawList = body;

          totalItems = body.length;
        } else if (
          body?.results &&
          Array.isArray(body.results)
        ) {
          rawList = body.results;

          totalItems =
            body.pagination?.total ??
            body.total ??
            rawList.length;

          links =
            body.pagination?.links ??
            body.links ??
            null;
        } else if (
          body?.data?.data &&
          Array.isArray(body.data.data)
        ) {
          rawList = body.data.data;

          totalItems =
            body.data.pagination?.total ??
            body.data.total ??
            rawList.length;

          links =
            body.data.pagination?.links ??
            body.data.links ??
            null;
        }

        const items = rawList.map(normalizeJob);

        console.log(
          `[Jobs] page=${page} status=${statusFilter} â†’ ${items.length} rows, total=${totalItems}`,
        );

        setJobs(items);
        setTotal(totalItems);
        setPaginationLinks(links);

        setCounts((prev) => ({
          ...prev,
          [statusFilter]: totalItems,
        }));

        // Background fetch remaining tab counts after main query resolves
        if (lastCountsSearchRef.current !== debouncedSearch) {
          fetchTabCounts(debouncedSearch, statusFilter, totalItems);
        }
      } catch (err) {
        if (requestIdRef.current !== requestId) {
          return;
        }

        console.error("Load jobs error:", err);

        let errorMessage = "Failed to load jobs";

        if (
          err.message?.includes("NetworkError") ||
          err.message?.includes("Failed to fetch")
        ) {
          errorMessage =
            "Network error: Unable to connect to the server.";
        } else if (
          err.status === 401 ||
          err.status === 403
        ) {
          errorMessage =
            "Access denied. Please log in again.";
        } else if (err.message) {
          errorMessage = err.message;
        }

        setError(errorMessage);

        showError(errorMessage);
      } finally {
        if (
          requestIdRef.current === requestId &&
          !silent
        ) {
          setLoading(false);
        }
      }
    },
    [
      page,
      limit,
      debouncedSearch,
      statusFilter,
      normalizeJob,
      fetchTabCounts,
    ],
  );

  useEffect(() => {
    load();
  }, [load]);

  // ============================================================
  // Client-side Date Filtering
  // ============================================================
  const filteredData = useMemo(() => {
    let result = [...jobs];

    const dateRange = getDateRange(
      dateFilterType,
    );

    if (
      dateRange.start &&
      dateRange.end
    ) {
      const { start, end } = dateRange;

      result = result.filter((j) => {
        const jobDate = parseApiDate(
          j.updated_at,
        );

        if (!jobDate) {
          return false;
        }

        return (
          jobDate >= start &&
          jobDate <= end
        );
      });
    }

    return result;
  }, [
    jobs,
    dateFilterType,
    getDateRange,
    parseApiDate,
  ]);

  const paginatedData = filteredData;

  // ============================================================
  // Tabs
  // ============================================================
  const tabs = [
    {
      key: "all",
      label: "All",
      count: counts.all,
    },
    {
      key: "active",
      label: "Active",
      count: counts.active,
    },
    {
      key: "inactive",
      label: "Inactive",
      count: counts.inactive,
    },
    {
      key: "trending",
      label: "Trending",
      count: counts.trending,
    },
  ];

  // ============================================================
  // Date Options
  // ============================================================
  const dateFilterOptions = [
    {
      key: "all",
      label: "All Time",
    },
    {
      key: "today",
      label: "Today",
    },
    {
      key: "week",
      label: "This Week",
    },
    {
      key: "month",
      label: "This Month",
    },
    // {
    //   key: "custom",
    //   label: "Custom Range",
    // },
  ];

  // ============================================================
  // Delete
  // ============================================================
  const handleDelete = async () => {
    setDeleteLoading(true);

    try {
      try {
        await jobService.deleteJobBenefits(
          deleteId,
        );
      } catch (benefitErr) {
        console.log(
          "No benefits to delete or already deleted",
        );
      }

      await jobService.delete(deleteId);

      showSuccess(
        "Job deleted successfully",
      );

      // Force reload after delete
      await load({
        force: true,
      });
      fetchTabCounts(debouncedSearch);
    } catch (err) {
      console.error(
        "Delete error:",
        err,
      );

      showError(
        err.response?.data?.message ||
          "Failed to delete",
      );
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  // ============================================================
  // Trending Toggle
  // ============================================================
  const handleTrendingToggle = async (id, current) => {
    if (togglingIds.has(`trending-${id}`)) return;

    const newVal = !current;

    // 1. Mark item as toggling
    setTogglingIds((prev) => new Set(prev).add(`trending-${id}`));

    // 2. Optimistic local state update
    setJobs((prevJobs) =>
      prevJobs.map((j) => (j.id === id ? { ...j, is_trending: newVal } : j)),
    );

    // 3. Optimistic tab count update
    setCounts((prev) => ({
      ...prev,
      trending: newVal
        ? prev.trending + 1
        : Math.max(0, prev.trending - 1),
    }));

    try {
      await jobService.update(id, {
        is_trending: newVal,
        updated_by: userId,
      });

      showSuccess(`Trending updated to ${newVal ? "Yes" : "No"}`);
    } catch (err) {
      // 4. Revert state on failure
      setJobs((prevJobs) =>
        prevJobs.map((j) => (j.id === id ? { ...j, is_trending: current } : j)),
      );

      setCounts((prev) => ({
        ...prev,
        trending: current
          ? prev.trending + 1
          : Math.max(0, prev.trending - 1),
      }));

      showError(
        err.response?.data?.message || "Failed to update trending",
      );
    } finally {
      setTogglingIds((prev) => {
        const next = new Set(prev);
        next.delete(`trending-${id}`);
        return next;
      });
    }
  };

  // ============================================================
  // Status Toggle (Active / Inactive)
  // ============================================================
  const handleStatusToggle = async (id, current) => {
    if (togglingIds.has(`status-${id}`)) return;

    const newVal = !current;

    // 1. Mark item as toggling
    setTogglingIds((prev) => new Set(prev).add(`status-${id}`));

    // 2. Optimistic local state update
    setJobs((prevJobs) =>
      prevJobs.map((j) => (j.id === id ? { ...j, is_status: newVal } : j)),
    );

    // 3. Optimistic tab count update
    setCounts((prev) => ({
      ...prev,
      active: newVal
        ? prev.active + 1
        : Math.max(0, prev.active - 1),
      inactive: !newVal
        ? prev.inactive + 1
        : Math.max(0, prev.inactive - 1),
    }));

    try {
      await jobService.update(id, {
        is_status: newVal,
        updated_by: userId,
      });

      showSuccess(`Status updated to ${newVal ? "Active" : "Inactive"}`);
    } catch (err) {
      // 4. Revert state on failure
      setJobs((prevJobs) =>
        prevJobs.map((j) => (j.id === id ? { ...j, is_status: current } : j)),
      );

      setCounts((prev) => ({
        ...prev,
        active: current
          ? prev.active + 1
          : Math.max(0, prev.active - 1),
        inactive: !current
          ? prev.inactive + 1
          : Math.max(0, prev.inactive - 1),
      }));

      showError(
        err.response?.data?.message || "Failed to update status",
      );
    } finally {
      setTogglingIds((prev) => {
        const next = new Set(prev);
        next.delete(`status-${id}`);
        return next;
      });
    }
  };

  // ============================================================
  // Date Filter
  // ============================================================
  const handleDateFilterChange = (
    key,
  ) => {
    setDateFilterType(key);

    // Date filtering is client-side,
    // so NO API request here.
    setPage(1);

    if (key !== "custom") {
      setStartDate("");
      setEndDate("");
      setShowDatePicker(false);
    } else {
      setShowDatePicker(true);
    }
  };

  const clearDateFilter = () => {
    setDateFilterType("all");
    setStartDate("");
    setEndDate("");
    setShowDatePicker(false);
    setPage(1);
  };

  // ============================================================
  // Columns
  // ============================================================
  const columns = [
    {
      header: "#",
      key: "id",

      render: (_, __, i) =>
        (page - 1) * limit + i + 1,
    },

    {
      header: "Title",
      key: "title",

      render: (v) => (
        <span className="font-medium text-slate-800">
          {v}
        </span>
      ),
    },

    {
      header: "Company",
      key: "company_name",

      render: (v) => (
        <span className="text-slate-600">
          {v || "â€”"}
        </span>
      ),
    },

    {
      header: "Job Type",
      key: "jobtype_name",

      render: (v) => (
        <span className="text-slate-600">
          {v || "â€”"}
        </span>
      ),
    },

    {
      header: "Workplace",
      key: "workplacetype_name",

      render: (v) => (
        <span className="text-slate-600">
          {v || "â€”"}
        </span>
      ),
    },

    {
      header: "Status",
      key: "job_status",

      render: (v) => (
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            v === "published"
              ? "bg-green-100 text-green-800"
              : v === "draft"
                ? "bg-slate-100 text-slate-800"
                : "bg-yellow-100 text-yellow-800"
          }`}
        >
          {v}
        </span>
      ),
    },

    {
      header: "Trending",
      key: "is_trending",

      render: (val, row) => {
        const isToggling = togglingIds.has(`trending-${row.id}`);
        return (
          <button
            onClick={() => handleTrendingToggle(row.id, val)}
            disabled={isToggling}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              val ? "bg-amber-500" : "bg-gray-300"
            } ${isToggling ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                val ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },

    {
      header: "Active",
      key: "is_status",

      render: (val, row) => {
        const isToggling = togglingIds.has(`status-${row.id}`);
        return (
          <button
            onClick={() => handleStatusToggle(row.id, val)}
            disabled={isToggling}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              val ? "bg-[#2c0eee]" : "bg-gray-300"
            } ${isToggling ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                val ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },

    {
      header: "Updated By",
      key: "updated_by",

      render: (_, row) => (
        <span className="text-slate-600 text-sm font-medium">
          {getUpdatedByName(row)}
        </span>
      ),
    },

    {
      header: "Updated At",
      key: "updated_at",

      render: (v) => (
        <span className="text-slate-500 text-sm">
          {formatDate(v)}
        </span>
      ),
    },

    {
      header: "Actions",
      key: "id",

      render: (id, row) => (
        <div className="flex gap-1 justify-end">
          <button
            onClick={() =>
              navigate(
                `/jobs/view/${row.id}`,
                {
                  state: {
                    item: row,
                  },
                },
              )
            }
            className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>

          <button
            onClick={() =>
              navigate(
                `/jobs/edit/${row.id}`,
                {
                  state: {
                    item: row,
                  },
                },
              )
            }
            className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>

          <button
            onClick={() =>
              setDeleteId(id)
            }
            className="p-1.5 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  // ============================================================
  // Error Screen
  // ============================================================
  if (error) {
    return (
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Jobs
            </h1>

            <p className="text-sm text-slate-500 mt-1">
              Manage job listings
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-red-200 shadow-sm overflow-hidden p-8 text-center">
          <div className="text-red-500 mb-4">
            <svg
              className="w-12 h-12 mx-auto"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 1.732 3.732 3z"
              />
            </svg>
          </div>

          <h3 className="text-lg font-medium text-slate-900 mb-2">
            Failed to Load Jobs
          </h3>

          <p className="text-slate-600 max-w-md mx-auto whitespace-pre-line">
            {error}
          </p>

          <button
            onClick={() =>
              load({
                force: true,
              })
            }
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // ============================================================
  // UI
  // ============================================================
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Jobs
          </h1>

          <p className="text-sm text-slate-500 mt-1">
            Manage job listings
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={() => {
              fetchTabCounts(debouncedSearch);
              load({
                force: true,
              });
            }}
            loading={loading}
          >
            Refresh
          </Button>

          <Button
            icon={MdAdd}
            onClick={() =>
              navigate("/jobs/add")
            }
          >
            Add Job
          </Button>
        </div>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Filters */}
        <div className="flex flex-col gap-3 px-5 py-4 border-b border-slate-100">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
            {/* Search */}
            <div className="relative w-full sm:w-72">
              <MdSearch
                size={18}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />

              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  lastRequestKeyRef.current = null;
                }}
                placeholder="Search by title, company, type, status..."
                className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
              />
            </div>

            {/* Date Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1 bg-slate-50 rounded-full p-1 border border-slate-200">
                <MdDateRange
                  size={16}
                  className="text-slate-500 ml-2"
                />

                {dateFilterOptions.map(
                  (opt) => (
                    <button
                      key={opt.key}
                      onClick={() =>
                        handleDateFilterChange(
                          opt.key,
                        )
                      }
                      className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                        dateFilterType ===
                        opt.key
                          ? "bg-[#2c0eee] text-white"
                          : "text-slate-600 hover:bg-gray-200"
                      }`}
                    >
                      {opt.label}
                    </button>
                  ),
                )}
              </div>

              {showDatePicker && (
                <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-200">
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => {
                      setStartDate(
                        e.target.value,
                      );
                      setPage(1);
                    }}
                    className="px-2 py-1 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee]"
                  />

                  <span className="text-slate-400">
                    to
                  </span>

                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => {
                      setEndDate(
                        e.target.value,
                      );
                      setPage(1);
                    }}
                    className="px-2 py-1 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee]"
                  />

                  <button
                    onClick={
                      clearDateFilter
                    }
                    className="text-slate-400 hover:text-slate-600 text-sm"
                  >
                    âœ•
                  </button>
                </div>
              )}

              {dateFilterType !==
                "all" && (
                <span className="text-xs text-[#2c0eee] font-medium bg-blue-50 px-2 py-1 rounded-full">
                  {dateFilterType ===
                  "custom"
                    ? `${startDate || "..."} â†’ ${
                        endDate || "..."
                      }`
                    : dateFilterOptions.find(
                        (opt) =>
                          opt.key ===
                          dateFilterType,
                      )?.label}
                </span>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-5 text-sm flex-wrap">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => {
                  setStatusFilter(
                    tab.key,
                  );
                  setPage(1);
                }}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter ===
                  tab.key
                    ? tab.key ===
                      "trending"
                      ? "text-amber-600"
                      : "text-[#2c0eee]"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}

                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter ===
                    tab.key
                      ? tab.key ===
                        "trending"
                        ? "bg-amber-50 text-amber-600"
                        : "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No jobs found"
        />

        {/* Pagination */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
          <p className="text-xs text-slate-400">
            Showing{" "}
            {total === 0
              ? 0
              : (page - 1) *
                  limit +
                1}
            {"â€“"}
            {Math.min(
              page * limit,
              total,
            )}{" "}
            of {total} jobs
          </p>

          <Pagination
            page={page}
            total={total}
            limit={limit}
            links={paginationLinks}
            onChange={(newPage) => {
              setPage(newPage);

              // New page = new API request
              lastRequestKeyRef.current =
                null;
            }}
            onLimitChange={(
              newLimit,
            ) => {
              setLimit(newLimit);
              setPage(1);

              // New limit = new API request
              lastRequestKeyRef.current =
                null;
            }}
          />
        </div>
      </div>

      {/* Delete Dialog */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() =>
          setDeleteId(null)
        }
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Job"
        message="Delete this job? This action cannot be undone."
      />
    </div>
  );
};

export default Jobs;
