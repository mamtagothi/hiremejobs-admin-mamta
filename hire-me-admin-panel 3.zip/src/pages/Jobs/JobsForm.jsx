// import React, { useEffect, useMemo, useRef, useState } from "react";
// import { useLocation, useNavigate, useParams } from "react-router-dom";
// import { motion, AnimatePresence } from "framer-motion";
// import {
//   MdArrowBack,
//   MdSave,
//   MdCancel,
//   MdDelete,
//   MdWarning,
//   MdClose,
//   MdLanguage,
//   MdCalendarToday,
//   MdCategory,
//   MdGroups,
//   MdReceiptLong,
//   MdDescription,
//   MdImage,
//   MdHistory,
//   MdApartment,
//   MdPerson,
//   MdCreditCard,
//   MdPermIdentity,
//   MdOpenInNew,
//   MdCloudUpload,
//   MdWhatshot,
//   MdCheckCircle,
//   MdErrorOutline,
//   MdPauseCircle,
//   MdBlock,
//   MdWork,
//   MdBusiness,
//   MdAttachMoney,
//   MdDateRange,
//   MdTrendingUp,
//   MdCheck,
//   MdSearch,
//   MdKeyboardArrowDown,
// } from "react-icons/md";
// import jobService, {
//   companyService,
//   jobTypeService,
//   workplaceTypeService,
//   functionRoleService,
// } from "../../services/job.service";
// import { showSuccess, showError } from "../../utils/toast";
// import { formatDate } from "../../utils/helpers";
// import { fetchUsers } from "../../utils/getUserName";
// import { useAuth } from "../../context/AuthContext";

// // ─── Helpers ──────────────────────────────────────────────────

// const toNumberOrEmpty = (value) => {
//   if (value === null || value === undefined || value === "") return "";
//   const number = Number(value);
//   return Number.isNaN(number) ? "" : number;
// };

// const toBoolean = (value) =>
//   value === true || value === 1 || value === "1" || value === "true";

// const getCompanyName = (company) =>
//   company?.company_name ||
//   company?.Company?.company_name ||
//   company?.CompanyUser?.company_name ||
//   company?.CompanyUser?.company_user_email ||
//   company?.CompanyUser?.email ||
//   "";

// const parseApiDate = (dateString) => {
//   if (!dateString) return null;
//   if (dateString instanceof Date) return dateString;
//   if (typeof dateString !== "string") return null;
//   if (dateString.includes("T")) {
//     const d = new Date(dateString);
//     if (!Number.isNaN(d.getTime())) return d;
//   }
//   const match = dateString.match(
//     /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
//   );
//   if (match) {
//     let [, day, month, year, hours, minutes, seconds, ampm] = match;
//     hours = Number(hours);
//     if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
//     if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
//     const d = new Date(
//       Number(year),
//       Number(month) - 1,
//       Number(day),
//       hours,
//       Number(minutes),
//       Number(seconds),
//     );
//     return Number.isNaN(d.getTime()) ? null : d;
//   }
//   const d = new Date(dateString);
//   return Number.isNaN(d.getTime()) ? null : d;
// };

// const formatDateTime = (date) => {
//   if (!date) return "—";
//   const parsed = typeof date === "string" ? parseApiDate(date) : date;
//   if (!parsed || Number.isNaN(parsed.getTime())) return "—";
//   return parsed.toLocaleString("en-IN", {
//     day: "2-digit",
//     month: "short",
//     year: "numeric",
//   });
// };

// const generateSlug = (title) => {
//   if (!title) return "";
//   return title
//     .toLowerCase()
//     .trim()
//     .replace(/[^a-z0-9\s-]/g, "")
//     .replace(/\s+/g, "-")
//     .replace(/-+/g, "-")
//     .substring(0, 100);
// };

// // ─── Company fetch helpers (fetch ALL companies, page by page) ─

// const COMPANIES_PAGE_SIZE = 500;
// const COMPANIES_MAX_PAGES = 40;

// const extractListFromResponse = (response) => {
//   const root = response?.data ?? response;
//   const candidates = [
//     root,
//     root?.data,
//     root?.results,
//     root?.rows,
//     root?.items,
//     root?.companies,
//     root?.list,
//     root?.data?.data,
//     root?.data?.results,
//     root?.data?.rows,
//     root?.data?.items,
//     root?.data?.companies,
//     root?.data?.list,
//   ];
//   for (const candidate of candidates) {
//     if (Array.isArray(candidate)) return candidate;
//   }
//   return [];
// };

// const extractTotalFromResponse = (response) => {
//   const root = response?.data;
//   const candidates = [
//     root?.total,
//     root?.count,
//     root?.totalCount,
//     root?.total_count,
//     root?.data?.total,
//     root?.data?.count,
//     root?.data?.totalCount,
//     root?.data?.total_count,
//     root?.meta?.total,
//     root?.data?.meta?.total,
//   ];
//   for (const candidate of candidates) {
//     if (candidate !== undefined && candidate !== null && !Number.isNaN(Number(candidate))) {
//       return Number(candidate);
//     }
//   }
//   return null;
// };

// const getCompanyId = (company) =>
//   toNumberOrEmpty(
//     company?.id ??
//       company?.company_id ??
//       company?.Company?.id ??
//       company?.Company?.company_id,
//   );

// // Fetches every company across all pages instead of only the first page.
// const fetchAllCompanies = async () => {
//   const collected = [];
//   const seen = new Set();
//   let page = 1;
//   let hasMore = true;

//   while (hasMore && page <= COMPANIES_MAX_PAGES) {
//     const response = await companyService.getAll({
//       page,
//       limit: COMPANIES_PAGE_SIZE,
//       page_size: COMPANIES_PAGE_SIZE,
//       per_page: COMPANIES_PAGE_SIZE,
//     });

//     const list = extractListFromResponse(response);
//     if (!list.length) break;

//     list.forEach((company) => {
//       const id = getCompanyId(company);
//       const key = id !== "" ? `id:${id}` : `name:${getCompanyName(company)}`;
//       if (seen.has(key)) return;
//       seen.add(key);
//       collected.push(company);
//     });

//     const total = extractTotalFromResponse(response);
//     if (total !== null) {
//       hasMore = page * COMPANIES_PAGE_SIZE < total;
//     } else {
//       hasMore = list.length >= COMPANIES_PAGE_SIZE;
//     }
//     page += 1;
//   }

//   return collected;
// };

// // ─── Rich text (TinyMCE-style) content styles ─────────────────

// const RICH_CONTENT_CSS = `
// .rich-content {
//   font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
//   font-size: 15px;
//   line-height: 1.7;
//   color: #334155;
//   word-wrap: break-word;
//   overflow-wrap: anywhere;
// }
// .rich-content > *:first-child { margin-top: 0; }
// .rich-content > *:last-child { margin-bottom: 0; }
// .rich-content p { margin: 0 0 1em; }
// .rich-content h1, .rich-content h2, .rich-content h3,
// .rich-content h4, .rich-content h5, .rich-content h6 {
//   color: #0f172a;
//   font-weight: 700;
//   line-height: 1.3;
//   margin: 1.4em 0 0.6em;
// }
// .rich-content h1 { font-size: 2em; }
// .rich-content h2 { font-size: 1.6em; }
// .rich-content h3 { font-size: 1.3em; }
// .rich-content h4 { font-size: 1.1em; }
// .rich-content h5 { font-size: 1em; }
// .rich-content h6 { font-size: 0.9em; text-transform: uppercase; letter-spacing: 0.04em; }
// .rich-content strong, .rich-content b { font-weight: 700; color: #0f172a; }
// .rich-content em, .rich-content i { font-style: italic; }
// .rich-content u { text-decoration: underline; }
// .rich-content s, .rich-content strike { text-decoration: line-through; }
// .rich-content a { color: #2563eb; text-decoration: underline; }
// .rich-content a:hover { color: #1d4ed8; }
// .rich-content ul { list-style: disc; padding-left: 1.6em; margin: 0 0 1em; }
// .rich-content ol { list-style: decimal; padding-left: 1.6em; margin: 0 0 1em; }
// .rich-content ul ul { list-style: circle; }
// .rich-content ul ul ul { list-style: square; }
// .rich-content li { margin: 0.3em 0; }
// .rich-content li > ul, .rich-content li > ol { margin: 0.3em 0 0; }
// .rich-content blockquote {
//   border-left: 4px solid #cbd5e1;
//   background: #f8fafc;
//   margin: 1em 0;
//   padding: 0.6em 1em;
//   color: #475569;
//   border-radius: 0 8px 8px 0;
// }
// .rich-content hr { border: 0; border-top: 1px solid #e2e8f0; margin: 1.5em 0; }
// .rich-content img { max-width: 100%; height: auto; border-radius: 8px; }
// .rich-content pre {
//   background: #0f172a;
//   color: #e2e8f0;
//   padding: 1em;
//   border-radius: 10px;
//   overflow-x: auto;
//   font-size: 13px;
//   margin: 1em 0;
// }
// .rich-content code {
//   background: #f1f5f9;
//   color: #be185d;
//   padding: 0.15em 0.4em;
//   border-radius: 4px;
//   font-size: 0.9em;
//   font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
// }
// .rich-content pre code { background: transparent; color: inherit; padding: 0; }
// .rich-content table {
//   border-collapse: collapse;
//   width: 100%;
//   margin: 1em 0;
//   display: block;
//   overflow-x: auto;
// }
// .rich-content th, .rich-content td {
//   border: 1px solid #cbd5e1;
//   padding: 8px 12px;
//   text-align: left;
//   vertical-align: top;
// }
// .rich-content th { background: #f1f5f9; font-weight: 600; color: #0f172a; }
// .rich-content sub { vertical-align: sub; font-size: 0.8em; }
// .rich-content sup { vertical-align: super; font-size: 0.8em; }
// `;

// // Decodes double-escaped HTML (e.g. "&lt;p&gt;Text&lt;/p&gt;") and strips
// // dangerous tags / attributes before rendering. No extra dependency needed.
// const sanitizeHtml = (html) => {
//   if (!html) return "";
//   let raw = String(html);

//   const hasRealTags = /<\/?[a-z][\s\S]*?>/i.test(raw);
//   const hasEscapedTags = /&lt;\/?[a-z][\s\S]*?&gt;/i.test(raw);
//   if (!hasRealTags && hasEscapedTags) {
//     const textarea = document.createElement("textarea");
//     textarea.innerHTML = raw;
//     raw = textarea.value;
//   }

//   const doc = new DOMParser().parseFromString(raw, "text/html");
//   doc
//     .querySelectorAll("script, style, iframe, object, embed, link, meta, form, base")
//     .forEach((node) => node.remove());

//   doc.body.querySelectorAll("*").forEach((el) => {
//     Array.from(el.attributes).forEach((attr) => {
//       const name = attr.name.toLowerCase();
//       const value = attr.value.trim().toLowerCase();
//       if (
//         name.startsWith("on") ||
//         ((name === "href" || name === "src" || name === "xlink:href") &&
//           (value.startsWith("javascript:") || value.startsWith("data:text/html")))
//       ) {
//         el.removeAttribute(attr.name);
//       }
//     });
//     if (el.tagName === "A") {
//       el.setAttribute("target", "_blank");
//       el.setAttribute("rel", "noopener noreferrer");
//     }
//   });

//   return doc.body.innerHTML;
// };

// const RichTextView = ({ html }) => {
//   const safe = sanitizeHtml(html);
//   const hasContent =
//     safe.replace(/<[^>]*>/g, "").replace(/&nbsp;/g, " ").trim().length > 0 ||
//     /<img|<table|<hr/i.test(safe);

//   if (!hasContent) {
//     return <p className="text-sm text-slate-400">No description provided.</p>;
//   }
//   return <div className="rich-content" dangerouslySetInnerHTML={{ __html: safe }} />;
// };

// // ─── Status styles ─────────────────────────────────────────────

// const STATUS_STYLES = {
//   draft: {
//     pill: "bg-gray-100 text-gray-700 ring-1 ring-gray-200",
//     dot: "bg-gray-400",
//     icon: MdPauseCircle,
//   },
//   published: {
//     pill: "bg-green-50 text-green-700 ring-1 ring-green-200",
//     dot: "bg-green-500",
//     icon: MdCheckCircle,
//   },
//   closed: {
//     pill: "bg-yellow-50 text-yellow-700 ring-1 ring-yellow-200",
//     dot: "bg-yellow-500",
//     icon: MdErrorOutline,
//   },
// };

// const StatusPill = ({ status }) => {
//   const style = STATUS_STYLES[status] || STATUS_STYLES.draft;
//   const Icon = style.icon;
//   return (
//     <span
//       className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${style.pill}`}
//     >
//       <Icon size={13} />
//       {status ? status.charAt(0).toUpperCase() + status.slice(1) : "Unknown"}
//     </span>
//   );
// };

// const ViewBadge = ({ active }) => (
//   <span
//     className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
//       active
//         ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200"
//         : "bg-slate-100 text-slate-500 ring-1 ring-slate-200"
//     }`}
//   >
//     <span
//       className={`w-1.5 h-1.5 rounded-full ${
//         active ? "bg-emerald-500" : "bg-slate-400"
//       }`}
//     />
//     {active ? "Active" : "Inactive"}
//   </span>
// );

// // ─── Helper components ────────────────────────────────────────

// const FieldLabel = ({ children, required }) => (
//   <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
//     {children}
//     {required && <span className="text-red-500 ml-0.5">*</span>}
//   </label>
// );

// const ReadOnlyValue = ({ children }) => (
//   <div className="text-sm text-slate-700 py-2 px-3 bg-slate-50 rounded-lg border border-slate-200">
//     {children || "—"}
//   </div>
// );

// const HeroStat = ({ icon: Icon, label, value }) => (
//   <div className="flex items-center gap-2.5 rounded-xl bg-white/10 backdrop-blur-sm px-3.5 py-2.5 min-w-0">
//     <Icon size={16} className="text-white/70 flex-shrink-0" />
//     <div className="min-w-0">
//       <p className="text-[10px] text-black leading-tight">{label}</p>
//       <p className="text-sm font-semibold text-black truncate leading-tight">
//         {value || "—"}
//       </p>
//     </div>
//   </div>
// );

// // ─── Searchable select (used for Company) ─────────────────────

// const SearchableSelect = ({
//   name,
//   value,
//   options = [],
//   onChange,
//   onBlur,
//   placeholder = "Select option",
//   searchPlaceholder = "Search...",
//   disabled = false,
//   hasError = false,
//   loading = false,
//   emptyMessage = "No options found",
// }) => {
//   const [isOpen, setIsOpen] = useState(false);
//   const [query, setQuery] = useState("");
//   const containerRef = useRef(null);
//   const searchRef = useRef(null);

//   const selectedOption = useMemo(
//     () => options.find((opt) => String(opt.value) === String(value ?? "")),
//     [options, value],
//   );

//   const filteredOptions = useMemo(() => {
//     const q = query.trim().toLowerCase();
//     if (!q) return options;
//     return options.filter((opt) =>
//       String(opt.label ?? "").toLowerCase().includes(q),
//     );
//   }, [options, query]);

//   useEffect(() => {
//     if (!isOpen) return undefined;
//     const handleClickOutside = (event) => {
//       if (containerRef.current && !containerRef.current.contains(event.target)) {
//         setIsOpen(false);
//         setQuery("");
//         onBlur?.();
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, [isOpen, onBlur]);

//   useEffect(() => {
//     if (!isOpen) return undefined;
//     const timer = setTimeout(() => searchRef.current?.focus(), 0);
//     return () => clearTimeout(timer);
//   }, [isOpen]);

//   const handleToggle = () => {
//     if (disabled) return;
//     setIsOpen((prev) => !prev);
//     setQuery("");
//   };

//   const handleSelect = (optionValue) => {
//     onChange?.(optionValue);
//     setIsOpen(false);
//     setQuery("");
//     onBlur?.();
//   };

//   const handleClear = (event) => {
//     event.stopPropagation();
//     onChange?.("");
//     setQuery("");
//     onBlur?.();
//   };

//   const handleKeyDown = (event) => {
//     if (event.key === "Escape") {
//       setIsOpen(false);
//       setQuery("");
//       onBlur?.();
//     } else if (event.key === "Enter" && isOpen) {
//       event.preventDefault();
//       if (filteredOptions.length > 0) handleSelect(filteredOptions[0].value);
//     }
//   };

//   return (
//     <div ref={containerRef} className="relative" onKeyDown={handleKeyDown}>
//       <button
//         type="button"
//         name={name}
//         disabled={disabled}
//         onClick={handleToggle}
//         className={`w-full flex items-center justify-between gap-2 px-3.5 py-2.5 border ${
//           hasError ? "border-red-500" : "border-slate-300"
//         } rounded-lg text-sm text-left bg-white transition-colors focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400 ${
//           disabled
//             ? "opacity-60 cursor-not-allowed"
//             : "cursor-pointer hover:border-slate-400"
//         }`}
//       >
//         <span
//           className={`truncate ${selectedOption ? "text-slate-800" : "text-slate-400"}`}
//         >
//           {selectedOption
//             ? selectedOption.label
//             : loading
//               ? "Loading..."
//               : placeholder}
//         </span>
//         <span className="flex items-center gap-1 flex-shrink-0">
//           {selectedOption && !disabled && (
//             <span
//               role="button"
//               tabIndex={-1}
//               onClick={handleClear}
//               className="p-0.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
//             >
//               <MdClose size={14} />
//             </span>
//           )}
//           <MdKeyboardArrowDown
//             size={18}
//             className={`text-slate-400 transition-transform duration-200 ${
//               isOpen ? "rotate-180" : ""
//             }`}
//           />
//         </span>
//       </button>

//       <AnimatePresence>
//         {isOpen && (
//           <motion.div
//             initial={{ opacity: 0, y: -4 }}
//             animate={{ opacity: 1, y: 0 }}
//             exit={{ opacity: 0, y: -4 }}
//             transition={{ duration: 0.14 }}
//             className="absolute z-50 mt-1 w-full rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden"
//           >
//             <div className="p-2 border-b border-slate-100">
//               <div className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-slate-50 border border-slate-200">
//                 <MdSearch size={16} className="text-slate-400 flex-shrink-0" />
//                 <input
//                   ref={searchRef}
//                   value={query}
//                   onChange={(e) => setQuery(e.target.value)}
//                   placeholder={searchPlaceholder}
//                   className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
//                 />
//                 {query && (
//                   <button
//                     type="button"
//                     onClick={() => setQuery("")}
//                     className="text-slate-400 hover:text-slate-600 flex-shrink-0"
//                   >
//                     <MdClose size={14} />
//                   </button>
//                 )}
//               </div>
//             </div>
//             <ul className="max-h-60 overflow-y-auto py-1">
//               {filteredOptions.length === 0 ? (
//                 <li className="px-3.5 py-3 text-sm text-slate-400 text-center">
//                   {emptyMessage}
//                 </li>
//               ) : (
//                 filteredOptions.map((opt) => {
//                   const isSelected = String(opt.value) === String(value ?? "");
//                   return (
//                     <li key={opt.value}>
//                       <button
//                         type="button"
//                         onClick={() => handleSelect(opt.value)}
//                         className={`w-full flex items-center justify-between gap-2 px-3.5 py-2 text-sm text-left transition-colors ${
//                           isSelected
//                             ? "bg-blue-50 text-blue-700 font-medium"
//                             : "text-slate-700 hover:bg-slate-50"
//                         }`}
//                       >
//                         <span className="truncate">{opt.label}</span>
//                         {isSelected && (
//                           <MdCheck size={15} className="text-blue-600 flex-shrink-0" />
//                         )}
//                       </button>
//                     </li>
//                   );
//                 })
//               )}
//             </ul>
//           </motion.div>
//         )}
//       </AnimatePresence>
//     </div>
//   );
// };

// const Tabs = [
//   { id: "overview", label: "Overview", icon: MdApartment },
//   { id: "classification", label: "Classification", icon: MdCategory },
//   { id: "compensation", label: "Compensation", icon: MdAttachMoney },
//   { id: "description", label: "Description", icon: MdDescription },
//   { id: "status", label: "Status & Features", icon: MdCheck },
//   { id: "activity", label: "Activity", icon: MdHistory },
// ];

// // ─── Main Component ────────────────────────────────────────────

// const JobsForm = () => {
//   const navigate = useNavigate();
//   const location = useLocation();
//   const { id } = useParams();
//   const { user } = useAuth();
//   const userId = user?.id;

//   // ─── Mode resolution ──────────────────────────────────────

//   const resolveModeFromPath = (pathname) => {
//     if (pathname.includes("/view/")) return "view";
//     if (pathname.includes("/edit/")) return "edit";
//     return "add";
//   };

//   const [mode, setMode] = useState(() => resolveModeFromPath(location.pathname));
//   const [pageLoading, setPageLoading] = useState(() => {
//     const initialMode = resolveModeFromPath(location.pathname);
//     return initialMode === "edit" || initialMode === "view";
//   });
//   const [data, setData] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [activeTab, setActiveTab] = useState("overview");

//   // ─── Dropdown states ───────────────────────────────────────

//   const [companies, setCompanies] = useState([]);
//   const [jobTypes, setJobTypes] = useState([]);
//   const [workplaceTypes, setWorkplaceTypes] = useState([]);
//   const [functionRoles, setFunctionRoles] = useState([]);
//   const [loadingDropdowns, setLoadingDropdowns] = useState(false);
//   const [userNameCache, setUserNameCache] = useState({});

//   // ─── Fetch dropdowns ──────────────────────────────────────

//   useEffect(() => {
//     let isCancelled = false;

//     const fetchDropdowns = async () => {
//       setLoadingDropdowns(true);
//       try {
//         const [
//           allCompanies,
//           jobTypeResponse,
//           workplaceResponse,
//           functionRoleResponse,
//         ] = await Promise.all([
//           fetchAllCompanies(),
//           jobTypeService.getAll(),
//           workplaceTypeService.getAll(),
//           functionRoleService.getAll(),
//         ]);

//         if (isCancelled) return;

//         // Companies (ALL companies, de-duplicated + sorted A→Z)
//         const normalizedCompanies = Array.isArray(allCompanies)
//           ? allCompanies
//               .map((c) => ({
//                 ...c,
//                 id: getCompanyId(c),
//               }))
//               .filter((c) => c.id !== "")
//               .sort((a, b) =>
//                 (getCompanyName(a) || "").localeCompare(
//                   getCompanyName(b) || "",
//                   undefined,
//                   { sensitivity: "base" },
//                 ),
//               )
//           : [];
//         setCompanies(normalizedCompanies);

//         // Job Types
//         const jobTypeData = jobTypeResponse?.data?.data || jobTypeResponse?.data || [];
//         const normalizedJobTypes = Array.isArray(jobTypeData)
//           ? jobTypeData
//               .filter(
//                 (item) =>
//                   item.is_status === true ||
//                   item.is_status === 1 ||
//                   item.status === true ||
//                   item.status === 1,
//               )
//               .map((item) => ({
//                 ...item,
//                 id: toNumberOrEmpty(item.job_type_id ?? item.id),
//               }))
//               .filter((item) => item.id !== "")
//           : [];
//         setJobTypes(normalizedJobTypes);

//         // Workplace Types
//         const workplaceData =
//           workplaceResponse?.data?.data || workplaceResponse?.data || [];
//         const normalizedWorkplaceTypes = Array.isArray(workplaceData)
//           ? workplaceData
//               .filter(
//                 (item) =>
//                   item.is_status === true ||
//                   item.is_status === 1 ||
//                   item.status === true ||
//                   item.status === 1,
//               )
//               .map((item) => ({
//                 ...item,
//                 id: toNumberOrEmpty(item.workplacetype_id ?? item.id),
//               }))
//               .filter((item) => item.id !== "")
//           : [];
//         setWorkplaceTypes(normalizedWorkplaceTypes);

//         // Function Roles
//         const functionRoleData =
//           functionRoleResponse?.data?.data || functionRoleResponse?.data || [];
//         const normalizedFunctionRoles = Array.isArray(functionRoleData)
//           ? functionRoleData
//               .filter(
//                 (item) =>
//                   item.is_status === true ||
//                   item.is_status === 1 ||
//                   item.status === true ||
//                   item.status === 1,
//               )
//               .map((item) => ({
//                 ...item,
//                 id: toNumberOrEmpty(item.functionrole_id ?? item.id),
//               }))
//               .filter((item) => item.id !== "")
//           : [];
//         setFunctionRoles(normalizedFunctionRoles);
//       } catch (error) {
//         if (isCancelled) return;
//         console.error("Error loading dropdowns:", error);
//         showError("Failed to load form data. Please refresh.");
//       } finally {
//         if (!isCancelled) setLoadingDropdowns(false);
//       }
//     };

//     fetchDropdowns();

//     return () => {
//       isCancelled = true;
//     };
//   }, []);

//   // ─── Load users ────────────────────────────────────────────

//   useEffect(() => {
//     const loadUsers = async () => {
//       try {
//         const users = await fetchUsers();
//         const userMap = {};
//         Object.keys(users || {}).forEach((uid) => {
//           userMap[uid] = users[uid]?.name;
//         });
//         setUserNameCache(userMap);
//       } catch (error) {
//         console.error("Failed to load users:", error);
//       }
//     };
//     loadUsers();
//   }, []);

//   const getCreatedByName = (row) => {
//     if (!row?.created_by) return "—";
//     return userNameCache[row.created_by] || `User ${row.created_by}`;
//   };
//   const getUpdatedByName = (row) => {
//     if (!row?.updated_by) return "—";
//     return userNameCache[row.updated_by] || `User ${row.updated_by}`;
//   };

//   // ─── Normalize job data ──────────────────────────────────

//   const normalizeJobData = (item) => {
//     if (!item) return null;
//     const companyId = toNumberOrEmpty(
//       item.company_id ??
//         item.Company?.company_id ??
//         item.Company?.id ??
//         item.company?.company_id ??
//         item.company?.id,
//     );
//     const jobTypeId = toNumberOrEmpty(item.job_type_id ?? item.JobType?.job_type_id);
//     const workplaceTypeId = toNumberOrEmpty(
//       item.workplacetype_id ?? item.WorkplaceType?.workplacetype_id,
//     );
//     const functionRoleId = toNumberOrEmpty(
//       item.functionrole_id ?? item.FunctionRole?.functionrole_id,
//     );

//     let companyName =
//       item.company_name ||
//       getCompanyName(item.Company) ||
//       getCompanyName(item.company);
//     if (!companyName && companyId !== "") {
//       const comp = companies.find((c) => Number(c.id) === Number(companyId));
//       if (comp) companyName = getCompanyName(comp);
//     }

//     return {
//       id: item.id || item._id,
//       title: item.title || "",
//       job_description: item.job_description || "",
//       company_id: companyId,
//       company_name: companyName,
//       job_type_id: jobTypeId,
//       jobtype_name: item.JobType?.name || item.jobtype_name || "",
//       workplacetype_id: workplaceTypeId,
//       workplacetype_name: item.WorkplaceType?.name || item.workplacetype_name || "",
//       functionrole_id: functionRoleId,
//       functionrole_name: item.FunctionRole?.name || item.functionrole_name || "",
//       experience_min: item.experience_min ?? "",
//       experience_max: item.experience_max ?? "",
//       experience_type: item.experience_type || "experience",
//       salary_min: item.salary_min ?? "",
//       salary_max: item.salary_max ?? "",
//       salary_confidential: toBoolean(item.salary_confidential),
//       job_status: item.job_status || "draft",
//       posting_type: item.posting_type || "permanent",
//       expiry_date: item.expiry_date || "",
//       auto_renew: item.auto_renew || "off",
//       reference_code: item.reference_code || "",
//       is_trending: toBoolean(item.is_trending),
//       is_status: toBoolean(item.is_status),
//       daily_application_summary: toBoolean(item.daily_application_summary),
//       notify_matching_type: item.notify_matching_type || "All matching applicants",
//       prioritize_women: toBoolean(item.prioritize_women),
//       schedule_date: item.schedule_date || null,
//       published_at: item.published_at || null,
//       slug: item.slug || "",
//       created_by: item.created_by ?? null,
//       updated_by: item.updated_by ?? null,
//       created_at: item.created_at || null,
//       updated_at: item.updated_at || null,
//     };
//   };

//   // ─── Fetch edit/view data ────────────────────────────────

//   useEffect(() => {
//     const fetchData = async () => {
//       if ((mode !== "edit" && mode !== "view") || !id) return;
//       setPageLoading(true);
//       try {
//         let item = location.state?.item;
//         if (!item) {
//           const response = await jobService.getById(id);
//           item = response?.data?.data || response?.data;
//         }
//         if (!item) throw new Error("Job data not found");
//         const normalizedData = normalizeJobData(item);
//         setData(normalizedData);
//       } catch (error) {
//         console.error("Fetch job error:", error);
//         showError("Failed to load job data");
//         navigate("/jobs");
//       } finally {
//         setPageLoading(false);
//       }
//     };
//     fetchData();
//   }, [id, mode, location.state, navigate, companies]);

//   // ─── Update company name after companies load ────────────

//   useEffect(() => {
//     if (!data?.company_id) return;
//     const company = companies.find((c) => Number(c.id) === Number(data.company_id));
//     if (!company) return;
//     const companyName =
//       company.company_name || company.CompanyUser?.company_user_email || "";
//     if (companyName && companyName !== data.company_name) {
//       setData((prev) => (prev ? { ...prev, company_name: companyName } : prev));
//     }
//   }, [companies, data?.company_id, data?.company_name]);

//   // ─── Form state ────────────────────────────────────────────

//   const getInitialData = () => {
//     if (mode === "add") {
//       return {
//         title: "",
//         job_description: "",
//         company_id: "",
//         job_type_id: "",
//         workplacetype_id: "",
//         functionrole_id: "",
//         experience_min: "",
//         experience_max: "",
//         experience_type: "experience",
//         salary_min: "",
//         salary_max: "",
//         salary_confidential: false,
//         job_status: "draft",
//         posting_type: "permanent",
//         expiry_date: "",
//         auto_renew: "off",
//         reference_code: "",
//         is_trending: false,
//         status: "active",
//       };
//     }
//     if (data) {
//       return {
//         title: data.title || "",
//         job_description: data.job_description || "",
//         company_id: data.company_id !== "" ? Number(data.company_id) : "",
//         job_type_id: data.job_type_id !== "" ? Number(data.job_type_id) : "",
//         workplacetype_id:
//           data.workplacetype_id !== "" ? Number(data.workplacetype_id) : "",
//         functionrole_id:
//           data.functionrole_id !== "" ? Number(data.functionrole_id) : "",
//         experience_min: data.experience_min ?? "",
//         experience_max: data.experience_max ?? "",
//         experience_type: data.experience_type || "experience",
//         salary_min: data.salary_min ?? "",
//         salary_max: data.salary_max ?? "",
//         salary_confidential: data.salary_confidential || false,
//         job_status: data.job_status || "draft",
//         posting_type: data.posting_type || "permanent",
//         expiry_date: data.expiry_date || "",
//         auto_renew: data.auto_renew || "off",
//         reference_code: data.reference_code || "",
//         is_trending: data.is_trending || false,
//         status: data.is_status ? "active" : "inactive",
//         // Additional view-only props
//         is_status: data.is_status,
//         company_name: data.company_name || "",
//         jobtype_name: data.jobtype_name || "",
//         workplacetype_name: data.workplacetype_name || "",
//         functionrole_name: data.functionrole_name || "",
//         created_by: data.created_by,
//         updated_by: data.updated_by,
//         created_at: data.created_at,
//         updated_at: data.updated_at,
//       };
//     }
//     return {};
//   };

//   const [formValues, setFormValues] = useState(getInitialData);
//   const [errors, setErrors] = useState({});
//   const [touched, setTouched] = useState({});

//   useEffect(() => {
//     setFormValues(getInitialData());
//   }, [data, mode]);

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     const val = type === "checkbox" ? checked : value;
//     setFormValues((prev) => ({ ...prev, [name]: val }));
//     // Clear error for field
//     if (errors[name]) {
//       setErrors((prev) => ({ ...prev, [name]: undefined }));
//     }
//   };

//   const handleBlur = (e) => {
//     const { name } = e.target;
//     setTouched((prev) => ({ ...prev, [name]: true }));
//   };

//   // Handlers for custom (non-native) inputs like the searchable select
//   const handleFieldChange = (name, value) => {
//     setFormValues((prev) => ({ ...prev, [name]: value }));
//     if (errors[name]) {
//       setErrors((prev) => ({ ...prev, [name]: undefined }));
//     }
//   };

//   const handleFieldBlur = (name) => {
//     setTouched((prev) => ({ ...prev, [name]: true }));
//   };

//   // ─── Validation ────────────────────────────────────────────

//   const getValidationRules = () => ({
//     title: {
//       required: true,
//       requiredMessage: "Job title is required",
//       minLength: 5,
//       minLengthMessage: "Job title must be at least 5 characters",
//       maxLength: 200,
//       maxLengthMessage: "Job title must be at most 200 characters",
//     },
//     company_id: {
//       required: true,
//       requiredMessage: "Please select a company",
//     },
//     job_type_id: {
//       required: true,
//       requiredMessage: "Please select a job type",
//     },
//     workplacetype_id: {
//       required: true,
//       requiredMessage: "Please select a workplace type",
//     },
//     functionrole_id: {
//       required: true,
//       requiredMessage: "Please select a function role",
//     },
//     job_status: {
//       required: true,
//       requiredMessage: "Please select a job status",
//     },
//     experience_type: {
//       required: true,
//       requiredMessage: "Please select an experience type",
//     },
//     posting_type: {
//       required: true,
//       requiredMessage: "Please select a posting type",
//     },
//     auto_renew: {
//       required: true,
//       requiredMessage: "Please select auto-renew option",
//     },
//     experience_min: {
//       custom: (value) => {
//         if (value !== "" && value !== null && value !== undefined) {
//           const num = Number(value);
//           if (Number.isNaN(num)) return "Experience minimum must be a valid number";
//           if (num < 0) return "Experience minimum cannot be negative";
//           if (num > 50) return "Experience minimum cannot exceed 50 years";
//         }
//         return null;
//       },
//     },
//     experience_max: {
//       custom: (value, formData) => {
//         if (value !== "" && value !== null && value !== undefined) {
//           const num = Number(value);
//           if (Number.isNaN(num)) return "Experience maximum must be a valid number";
//           if (num < 0) return "Experience maximum cannot be negative";
//           if (num > 50) return "Experience maximum cannot exceed 50 years";
//           if (
//             formData?.experience_min !== "" &&
//             formData?.experience_min !== null &&
//             formData?.experience_min !== undefined
//           ) {
//             const min = Number(formData.experience_min);
//             if (!Number.isNaN(min) && num < min)
//               return "Experience maximum must be >= minimum";
//           }
//         }
//         return null;
//       },
//     },
//     salary_min: {
//       custom: (value) => {
//         if (value !== "" && value !== null && value !== undefined) {
//           const num = Number(value);
//           if (Number.isNaN(num)) return "Salary minimum must be a valid number";
//           if (num < 0) return "Salary minimum cannot be negative";
//         }
//         return null;
//       },
//     },
//     salary_max: {
//       custom: (value, formData) => {
//         if (value !== "" && value !== null && value !== undefined) {
//           const num = Number(value);
//           if (Number.isNaN(num)) return "Salary maximum must be a valid number";
//           if (num < 0) return "Salary maximum cannot be negative";
//           if (
//             formData?.salary_min !== "" &&
//             formData?.salary_min !== null &&
//             formData?.salary_min !== undefined
//           ) {
//             const min = Number(formData.salary_min);
//             if (!Number.isNaN(min) && num < min)
//               return "Salary maximum must be >= minimum";
//           }
//         }
//         return null;
//       },
//     },
//   });

//   const validateField = (name, value, allValues) => {
//     const rules = getValidationRules()[name];
//     if (!rules) return null;
//     if (rules.required && (value === "" || value === null || value === undefined)) {
//       return rules.requiredMessage || `${name} is required`;
//     }
//     if (rules.minLength && value?.length < rules.minLength) {
//       return rules.minLengthMessage || `Minimum length is ${rules.minLength}`;
//     }
//     if (rules.maxLength && value?.length > rules.maxLength) {
//       return rules.maxLengthMessage || `Maximum length is ${rules.maxLength}`;
//     }
//     if (rules.custom) {
//       return rules.custom(value, allValues);
//     }
//     return null;
//   };

//   const validateAll = () => {
//     const allValues = formValues;
//     const newErrors = {};
//     const rules = getValidationRules();
//     Object.keys(rules).forEach((field) => {
//       const error = validateField(field, allValues[field], allValues);
//       if (error) newErrors[field] = error;
//     });
//     setErrors(newErrors);
//     return Object.keys(newErrors).length === 0;
//   };

//   // ─── Submit ────────────────────────────────────────────────

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!validateAll()) {
//       showError("Please fix validation errors");
//       return;
//     }

//     setLoading(true);
//     try {
//       const payload = {
//         title: formValues.title.trim(),
//         job_description: formValues.job_description?.trim() || "",
//         company_id: toNumberOrEmpty(formValues.company_id) || null,
//         job_type_id: toNumberOrEmpty(formValues.job_type_id) || null,
//         workplacetype_id: toNumberOrEmpty(formValues.workplacetype_id) || null,
//         functionrole_id: toNumberOrEmpty(formValues.functionrole_id) || null,
//         experience_min:
//           formValues.experience_min !== "" ? Number(formValues.experience_min) : null,
//         experience_max:
//           formValues.experience_max !== "" ? Number(formValues.experience_max) : null,
//         experience_type: formValues.experience_type || "experience",
//         salary_min:
//           formValues.salary_min !== "" ? Number(formValues.salary_min) : null,
//         salary_max:
//           formValues.salary_max !== "" ? Number(formValues.salary_max) : null,
//         salary_confidential: toBoolean(formValues.salary_confidential),
//         job_status: formValues.job_status || "draft",
//         posting_type: formValues.posting_type || "permanent",
//         expiry_date: formValues.expiry_date || null,
//         auto_renew: formValues.auto_renew || "off",
//         reference_code: formValues.reference_code?.trim() || null,
//         is_trending: toBoolean(formValues.is_trending),
//         is_status: formValues.status === "active",
//         daily_application_summary: true,
//         notify_matching_type: "All matching applicants",
//         prioritize_women: false,
//         schedule_date: formValues.job_status === "published" ? new Date().toISOString() : null,
//         published_at: formValues.job_status === "published" ? new Date().toISOString() : null,
//         slug: generateSlug(formValues.title.trim()),
//       };

//       if (mode === "edit" && id) {
//         payload.updated_by = userId || null;
//         await jobService.update(id, payload);
//         showSuccess("Job updated successfully");
//       } else {
//         payload.created_by = userId || null;
//         payload.updated_by = userId || null;
//         await jobService.create(payload);
//         showSuccess("Job created successfully");
//       }
//       navigate("/jobs");
//     } catch (error) {
//       console.error("Submit error:", error);
//       const msg =
//         error?.response?.data?.message ||
//         error?.response?.data?.error ||
//         error?.message ||
//         "Failed to save job";
//       showError(msg);
//     } finally {
//       setLoading(false);
//     }
//   };

//   // ─── Delete ────────────────────────────────────────────────

//   const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
//   const [deleteLoading, setDeleteLoading] = useState(false);

//   const handleDelete = async () => {
//     if (!id) return;
//     setDeleteLoading(true);
//     try {
//       await jobService.deleteJobBenefits(id);
//       await jobService.delete(id);
//       showSuccess("Job deleted successfully");
//       navigate("/jobs");
//     } catch (error) {
//       console.error("Delete error:", error);
//       showError(error?.response?.data?.message || error?.message || "Failed to delete");
//     } finally {
//       setDeleteLoading(false);
//       setIsDeleteModalOpen(false);
//     }
//   };

//   // ─── Dropdown options ──────────────────────────────────────

//   const getDropdownOptions = () => {
//     const companyOptions = companies.map((c) => ({
//       value: Number(c.id),
//       label: getCompanyName(c) || `Company ${c.id}`,
//     }));
//     if (
//       data?.company_id &&
//       !companyOptions.some((o) => Number(o.value) === Number(data.company_id))
//     ) {
//       companyOptions.unshift({
//         value: Number(data.company_id),
//         label: data.company_name || `Company ${data.company_id}`,
//       });
//     }
//     const jobTypeOptions = jobTypes.map((j) => ({
//       value: Number(j.id),
//       label: j.name || "",
//     }));
//     const workplaceTypeOptions = workplaceTypes.map((w) => ({
//       value: Number(w.id),
//       label: w.name || "",
//     }));
//     const functionRoleOptions = functionRoles.map((f) => ({
//       value: Number(f.id),
//       label: f.name || "",
//     }));
//     return { companyOptions, jobTypeOptions, workplaceTypeOptions, functionRoleOptions };
//   };

//   // ─── Render field based on definition ──────────────────────

//   const renderField = (fieldDef) => {
//     const {
//       name,
//       label,
//       type,
//       required,
//       options,
//       placeholder,
//       rows,
//       disabled,
//       viewRender,
//       color,
//       min,
//       max,
//       step,
//       searchable,
//       searchPlaceholder,
//       emptyMessage,
//     } = fieldDef;

//     const value = formValues[name] ?? "";
//     const error = errors[name];
//     const isTouched = touched[name];

//     if (mode === "view" && viewRender) {
//       return (
//         <div key={name} className="mb-4">
//           <FieldLabel>{label}</FieldLabel>
//           <div className="text-sm text-slate-700">{viewRender(value, formValues)}</div>
//         </div>
//       );
//     }

//     const commonInputClass = `w-full px-3.5 py-2.5 border ${
//       error && isTouched ? "border-red-500" : "border-slate-300"
//     } rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors bg-white`;

//     let inputElement;
//     switch (type) {
//       case "select":
//         if (searchable) {
//           inputElement = (
//             <SearchableSelect
//               name={name}
//               value={value}
//               options={options || []}
//               onChange={(val) => handleFieldChange(name, val)}
//               onBlur={() => handleFieldBlur(name)}
//               placeholder={placeholder}
//               searchPlaceholder={searchPlaceholder || `Search ${label?.toLowerCase() || "option"}...`}
//               disabled={disabled}
//               hasError={Boolean(error && isTouched)}
//               loading={loadingDropdowns}
//               emptyMessage={emptyMessage || "No options found"}
//             />
//           );
//           break;
//         }
//         inputElement = (
//           <select
//             name={name}
//             value={value}
//             onChange={handleInputChange}
//             onBlur={handleBlur}
//             disabled={disabled || loadingDropdowns}
//             className={commonInputClass}
//           >
//             <option value="">
//               {loadingDropdowns ? "Loading..." : placeholder || "Select option"}
//             </option>
//             {options?.map((opt) => (
//               <option key={opt.value} value={opt.value}>
//                 {opt.label}
//               </option>
//             ))}
//           </select>
//         );
//         break;

//       case "textarea":
//         inputElement = (
//           <textarea
//             name={name}
//             value={value}
//             onChange={handleInputChange}
//             onBlur={handleBlur}
//             rows={rows || 4}
//             placeholder={placeholder}
//             disabled={disabled}
//             className={`${commonInputClass} resize-y`}
//           />
//         );
//         break;

//       case "checkbox":
//         inputElement = (
//           <div className="flex items-center gap-3 pt-1.5">
//             <input
//               type="checkbox"
//               name={name}
//               checked={Boolean(value)}
//               onChange={handleInputChange}
//               onBlur={handleBlur}
//               disabled={disabled}
//               className={`w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 ${color || ""}`}
//             />
//             <span className="text-sm text-slate-600">{label}</span>
//           </div>
//         );
//         break;

//       case "radio":
//         inputElement = (
//           <div className="flex flex-wrap gap-4 pt-1.5">
//             {options?.map((opt) => (
//               <label key={opt.value} className="flex items-center gap-2 text-sm text-slate-700">
//                 <input
//                   type="radio"
//                   name={name}
//                   value={opt.value}
//                   checked={String(value) === String(opt.value)}
//                   onChange={handleInputChange}
//                   onBlur={handleBlur}
//                   disabled={disabled}
//                   className={`w-4 h-4 border-slate-300 text-blue-600 focus:ring-blue-500 ${color || ""}`}
//                 />
//                 {opt.label}
//               </label>
//             ))}
//           </div>
//         );
//         break;

//       case "number":
//         inputElement = (
//           <input
//             type="number"
//             name={name}
//             value={value}
//             onChange={handleInputChange}
//             onBlur={handleBlur}
//             placeholder={placeholder}
//             disabled={disabled}
//             min={min}
//             max={max}
//             step={step}
//             className={commonInputClass}
//           />
//         );
//         break;

//       case "date":
//         inputElement = (
//           <input
//             type="date"
//             name={name}
//             value={value}
//             onChange={handleInputChange}
//             onBlur={handleBlur}
//             disabled={disabled}
//             className={commonInputClass}
//           />
//         );
//         break;

//       default:
//         inputElement = (
//           <input
//             type="text"
//             name={name}
//             value={value}
//             onChange={handleInputChange}
//             onBlur={handleBlur}
//             placeholder={placeholder}
//             disabled={disabled}
//             className={commonInputClass}
//           />
//         );
//     }

//     return (
//       <div key={name} className="mb-4">
//         {type !== "checkbox" && type !== "radio" && (
//           <FieldLabel required={required}>{label}</FieldLabel>
//         )}
//         {inputElement}
//         {error && isTouched && (
//           <p className="mt-1 text-xs text-red-500">{error}</p>
//         )}
//       </div>
//     );
//   };

//   // ─── Group fields by tab ──────────────────────────────────

//   const fields = (() => {
//     if (mode === "view") {
//       return [
//         // overview (job type / workplace / function role live in Classification only)
//         ["title", "company_name", "reference_code"],
//         // classification
//         ["jobtype_name", "workplacetype_name", "functionrole_name"],
//         // compensation
//         ["salary_min", "salary_max", "salary_confidential"],
//         // description
//         ["job_description"],
//         // status (job status, posting type & trending are already shown in the hero)
//         ["expiry_date", "auto_renew", "status"],
//         // activity
//         ["created_by", "created_at", "updated_by", "updated_at"],
//       ];
//     }
//     // add/edit
//     return [
//       // overview
//       ["title", "company_id", "reference_code"],
//       // classification
//       ["job_type_id", "workplacetype_id", "functionrole_id"],
//       // compensation
//       ["salary_min", "salary_max", "salary_confidential"],
//       // description
//       ["job_description"],
//       // status
//       ["job_status", "posting_type", "expiry_date", "auto_renew", "is_trending", "status"],
//       // activity - only in edit/view, not in add
//     ];
//   })();

//   const getTabFields = (tabId) => {
//     const tabMap = {
//       overview: 0,
//       classification: 1,
//       compensation: 2,
//       description: 3,
//       status: 4,
//       activity: 5,
//     };
//     const index = tabMap[tabId];
//     if (index === undefined) return [];
//     const fieldNames = fields[index] || [];
//     const allFieldDefs = (() => {
//       if (mode === "view") {
//         const labelMap = {
//           title: "Job Title",
//           company_name: "Company",
//           reference_code: "Reference Code",
//           jobtype_name: "Job Type",
//           workplacetype_name: "Workplace Type",
//           functionrole_name: "Function Role",
//           salary_min: "Salary Min",
//           salary_max: "Salary Max",
//           salary_confidential: "Salary Confidential",
//           job_description: "Job Description",
//           job_status: "Job Status",
//           posting_type: "Posting Type",
//           expiry_date: "Expiry Date",
//           auto_renew: "Auto Renew",
//           is_trending: "Trending",
//           status: "Active",
//           created_by: "Created By",
//           created_at: "Created At",
//           updated_by: "Updated By",
//           updated_at: "Updated At",
//         };
//         return fieldNames.map((name) => ({
//           name,
//           label: labelMap[name] || name,
//           type: "text",
//           viewRender: (value, row) => {
//             if (name === "job_description") {
//               return <RichTextView html={value} />;
//             }
//             if (name === "salary_min" || name === "salary_max") {
//               return value !== "" && value !== null && value !== undefined
//                 ? `₹${Number(value).toLocaleString("en-IN")}`
//                 : "—";
//             }
//             if (name === "salary_confidential") {
//               return value ? "Confidential" : "Not Confidential";
//             }
//             if (name === "is_trending") {
//               return value ? "Trending" : "Not Trending";
//             }
//             if (name === "status") {
//               return <ViewBadge active={row?.is_status} />;
//             }
//             if (name === "job_status") {
//               return <StatusPill status={value} />;
//             }
//             if (name === "expiry_date") {
//               return value ? formatDateTime(value) : "—";
//             }
//             if (name === "created_at" || name === "updated_at") {
//               return formatDateTime(row?.[name]);
//             }
//             if (name === "created_by" || name === "updated_by") {
//               const nameFn = name === "created_by" ? getCreatedByName : getUpdatedByName;
//               return nameFn(row);
//             }
//             return value || "—";
//           },
//         }));
//       } else {
//         const {
//           companyOptions,
//           jobTypeOptions,
//           workplaceTypeOptions,
//           functionRoleOptions,
//         } = getDropdownOptions();

//         const jobStatusOptions = [
//           { value: "draft", label: "Draft" },
//           { value: "published", label: "Published" },
//           { value: "closed", label: "Closed" },
//         ];
//         const postingTypeOptions = [
//           { value: "permanent", label: "Permanent" },
//           { value: "contract", label: "Contract" },
//           { value: "walk-in", label: "Walk-in" },
//           { value: "internship", label: "Internship" },
//         ];
//         const experienceTypeOptions = [
//           { value: "experience", label: "Experience" },
//           { value: "fresher", label: "Fresher" },
//         ];
//         const autoRenewOptions = [
//           { value: "off", label: "Off" },
//           { value: "weekly", label: "Weekly" },
//           { value: "monthly", label: "Monthly" },
//         ];

//         const fieldDefs = {
//           title: {
//             name: "title",
//             label: "Job Title",
//             type: "text",
//             required: true,
//             placeholder: "e.g. Frontend Developer",
//           },
//           company_id: {
//             name: "company_id",
//             label: "Company",
//             type: "select",
//             required: true,
//             searchable: true,
//             options: companyOptions,
//             placeholder: loadingDropdowns ? "Loading companies..." : "Select company",
//             searchPlaceholder: "Search company by name...",
//             emptyMessage: "No company found",
//             disabled: loadingDropdowns,
//           },
//           reference_code: {
//             name: "reference_code",
//             label: "Reference Code",
//             type: "text",
//             placeholder: "e.g. JOB123",
//           },
//           job_type_id: {
//             name: "job_type_id",
//             label: "Job Type",
//             type: "select",
//             required: true,
//             options: jobTypeOptions,
//             placeholder: loadingDropdowns ? "Loading job types..." : "Select job type",
//             disabled: loadingDropdowns,
//           },
//           workplacetype_id: {
//             name: "workplacetype_id",
//             label: "Workplace Type",
//             type: "select",
//             required: true,
//             options: workplaceTypeOptions,
//             placeholder: loadingDropdowns ? "Loading workplace types..." : "Select workplace type",
//             disabled: loadingDropdowns,
//           },
//           functionrole_id: {
//             name: "functionrole_id",
//             label: "Function Role",
//             type: "select",
//             required: true,
//             options: functionRoleOptions,
//             placeholder: loadingDropdowns ? "Loading function roles..." : "Select function role",
//             disabled: loadingDropdowns,
//           },
//           experience_min: {
//             name: "experience_min",
//             label: "Experience Min (years)",
//             type: "number",
//             min: 0,
//             max: 50,
//             step: 1,
//             placeholder: "0",
//           },
//           experience_max: {
//             name: "experience_max",
//             label: "Experience Max (years)",
//             type: "number",
//             min: 0,
//             max: 50,
//             step: 1,
//             placeholder: "10",
//           },
//           experience_type: {
//             name: "experience_type",
//             label: "Experience Type",
//             type: "select",
//             required: true,
//             options: experienceTypeOptions,
//             placeholder: "Select experience type",
//           },
//           salary_min: {
//             name: "salary_min",
//             label: "Salary Min (₹)",
//             type: "number",
//             min: 0,
//             step: 1000,
//             placeholder: "30000",
//           },
//           salary_max: {
//             name: "salary_max",
//             label: "Salary Max (₹)",
//             type: "number",
//             min: 0,
//             step: 1000,
//             placeholder: "50000",
//           },
//           salary_confidential: {
//             name: "salary_confidential",
//             label: "Salary Confidential",
//             type: "checkbox",
//             color: "text-gray-500 focus:ring-gray-500",
//           },
//           job_description: {
//             name: "job_description",
//             label: "Job Description",
//             type: "textarea",
//             rows: 5,
//             placeholder: "Describe the role, responsibilities, requirements...",
//           },
//           job_status: {
//             name: "job_status",
//             label: "Job Status",
//             type: "select",
//             required: true,
//             options: jobStatusOptions,
//             placeholder: "Select job status",
//           },
//           posting_type: {
//             name: "posting_type",
//             label: "Posting Type",
//             type: "select",
//             required: true,
//             options: postingTypeOptions,
//             placeholder: "Select posting type",
//           },
//           expiry_date: {
//             name: "expiry_date",
//             label: "Expiry Date",
//             type: "date",
//           },
//           auto_renew: {
//             name: "auto_renew",
//             label: "Auto Renew",
//             type: "select",
//             required: true,
//             options: autoRenewOptions,
//             placeholder: "Select auto-renew option",
//           },
//           is_trending: {
//             name: "is_trending",
//             label: "Mark as Trending",
//             type: "checkbox",
//             color: "text-amber-500 focus:ring-amber-500",
//           },
//           status: {
//             name: "status",
//             label: "Active",
//             type: "radio",
//             options: [
//               { value: "active", label: "Active" },
//               { value: "inactive", label: "Inactive" },
//             ],
//             color: "text-[#2c0eee] focus:ring-[#4529f7]",
//           },
//         };

//         return fieldNames.map((name) => fieldDefs[name]).filter(Boolean);
//       }
//     })();
//     return allFieldDefs;
//   };

//   // ─── Loading state ─────────────────────────────────────────

//   if (pageLoading) {
//     return (
//       <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
//         <div className="flex flex-col items-center gap-3">
//           <div className="w-9 h-9 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
//           <p className="text-sm text-slate-400">Loading job data...</p>
//         </div>
//       </div>
//     );
//   }

//   if ((mode === "view" || mode === "edit") && !data && !pageLoading) {
//     return (
//       <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
//         <div className="text-center bg-white rounded-2xl border border-slate-200 px-10 py-12">
//           <MdErrorOutline size={40} className="text-slate-300 mx-auto mb-3" />
//           <p className="text-slate-600 font-medium">Job not found</p>
//           <button
//             onClick={() => navigate("/jobs")}
//             className="mt-3 text-blue-600 hover:underline"
//           >
//             Go back
//           </button>
//         </div>
//       </div>
//     );
//   }

//   const heroTitle =
//     mode === "add"
//       ? "Create New Job"
//       : formValues.title || "Untitled Job";
//   const companyName = formValues.company_name || formValues.company_id || "—";
//   const status = formValues.job_status || "draft";
//   const isTrending = formValues.is_trending;

//   // ─── Render ──────────────────────────────────────────────────

//   return (
//     <div className="min-h-screen pb-16">
//       <style>{RICH_CONTENT_CSS}</style>

//       {/* ─── Sticky action bar ─────────────────────────────────── */}
//       <div className="z-30 bg-white/85 backdrop-blur-md border-b border-slate-200">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
//           <div className="flex items-center gap-3 min-w-0">
//             <button
//               onClick={() => navigate("/jobs")}
//               className="p-2 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
//               aria-label="Back"
//             >
//               <MdArrowBack size={19} className="text-slate-600" />
//             </button>
//             <div className="min-w-0">
//               <p className="text-[11px] text-slate-400 leading-tight">Jobs</p>
//               <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
//                 {heroTitle}
//               </p>
//             </div>
//           </div>
//           <div className="flex items-center gap-2 flex-shrink-0">
//             {mode === "view" && (
//               <>
//                 <button
//                   type="button"
//                   onClick={() => setIsDeleteModalOpen(true)}
//                   className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
//                   title="Delete job"
//                 >
//                   <MdDelete size={19} />
//                 </button>
//                 <button
//                   type="button"
//                   onClick={() =>
//                     navigate(`/jobs/edit/${id}`, { state: { item: data } })
//                   }
//                   className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors"
//                 >
//                   <MdWork size={16} />
//                   Edit Job
//                 </button>
//               </>
//             )}
//             {(mode === "edit" || mode === "add") && (
//               <>
//                 <button
//                   type="button"
//                   onClick={() => navigate("/jobs")}
//                   className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors"
//                 >
//                   <MdCancel size={16} />
//                   Cancel
//                 </button>
//                 <button
//                   type="button"
//                   onClick={handleSubmit}
//                   disabled={loading}
//                   className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
//                 >
//                   {loading ? (
//                     <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
//                   ) : (
//                     <MdSave size={16} />
//                   )}
//                   {loading ? "Saving..." : mode === "edit" ? "Update Job" : "Create Job"}
//                 </button>
//               </>
//             )}
//           </div>
//         </div>
//       </div>

//       <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
//         {/* ─── Hero ───────────────────────────────────────────────── */}
//         <motion.div
//           initial={{ opacity: 0, y: 12 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.35, ease: "easeOut" }}
//           className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
//         >
//           <div className="relative h-44 sm:h-52 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-800">
//             <div className="absolute inset-0 bg-gradient-to-t from-slate-900/95 via-slate-900/50 to-slate-900/10" />
//           </div>

//           <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
//             <div className="flex flex-col sm:flex-row sm:items-end gap-4">
//               {/* Icon/Logo placeholder */}
//               <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center shadow-xl flex-shrink-0 border border-white/20">
//                 <MdWork size={32} className="text-white" />
//               </div>

//               <div className="flex-1 min-w-0">
//                 <div className="flex items-center gap-2 flex-wrap">
//                   <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
//                     {heroTitle}
//                   </h1>
//                   {isTrending && (
//                     <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-orange-400/20 text-orange-300 ring-1 ring-orange-400/30">
//                       <MdWhatshot size={12} />
//                       Trending
//                     </span>
//                   )}
//                 </div>
//                 <div className="mt-2 flex items-center gap-2 flex-wrap">
//                   <StatusPill status={status} />
//                   <span className="text-xs text-white/70">• {companyName}</span>
//                   {formValues.posting_type && (
//                     <span className="text-xs text-white/70 capitalize">
//                       {formValues.posting_type}
//                     </span>
//                   )}
//                 </div>
//               </div>

//               {/* Completion ring placeholder */}
//               <div className="hidden sm:block">
//                 <div className="w-14 h-14 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20 text-white text-xs font-medium">
//                   Job
//                 </div>
//               </div>
//             </div>
//           </div>
//         </motion.div>

//         {/* ─── Tabs ───────────────────────────────────────────────── */}
//         <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
//           <div className="flex overflow-x-auto border-b border-slate-200 px-2">
//             {Tabs.map((tab) => {
//               const Icon = tab.icon;
//               const active = activeTab === tab.id;
//               return (
//                 <button
//                   key={tab.id}
//                   type="button"
//                   onClick={() => setActiveTab(tab.id)}
//                   className={`relative flex items-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
//                     active ? "text-blue-600" : "text-slate-500 hover:text-slate-700"
//                   }`}
//                 >
//                   <Icon size={16} />
//                   {tab.label}
//                   {active && (
//                     <motion.span
//                       layoutId="jobs-tab-underline"
//                       className="absolute left-2 right-2 -bottom-px h-0.5 bg-blue-600 rounded-full"
//                       transition={{ type: "spring", stiffness: 500, damping: 35 }}
//                     />
//                   )}
//                 </button>
//               );
//             })}
//           </div>

//           <div className="p-5 sm:p-7">
//             <AnimatePresence mode="wait">
//               <motion.div
//                 key={activeTab}
//                 initial={{ opacity: 0, y: 6 }}
//                 animate={{ opacity: 1, y: 0 }}
//                 exit={{ opacity: 0, y: -6 }}
//                 transition={{ duration: 0.18 }}
//               >
//                 <form onSubmit={handleSubmit}>
//                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                     {getTabFields(activeTab).map((fieldDef) => {
//                       // For activity tab, we only show in view mode
//                       if (activeTab === "activity" && mode !== "view") return null;
//                       return (
//                         <div
//                           key={fieldDef.name}
//                           className={
//                             fieldDef.type === "textarea" ||
//                             fieldDef.type === "checkbox" ||
//                             fieldDef.type === "radio" ||
//                             fieldDef.name === "job_description"
//                               ? "md:col-span-2"
//                               : ""
//                           }
//                         >
//                           {renderField(fieldDef)}
//                         </div>
//                       );
//                     })}
//                   </div>
//                   {mode !== "view" && (
//                     <div className="flex gap-3 mt-6 pt-4 border-t border-slate-200">
//                       <button
//                         type="button"
//                         onClick={() => navigate("/jobs")}
//                         className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 py-2.5 px-4 rounded-lg transition-colors font-medium"
//                       >
//                         Cancel
//                       </button>
//                       <button
//                         type="submit"
//                         disabled={loading}
//                         className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-4 rounded-lg transition-colors font-medium disabled:opacity-50 shadow-sm shadow-blue-600/20"
//                       >
//                         {loading ? (
//                           <span className="flex items-center justify-center gap-2">
//                             <span className="w-4 h-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
//                             Saving...
//                           </span>
//                         ) : mode === "edit" ? (
//                           "Update Job"
//                         ) : (
//                           "Create Job"
//                         )}
//                       </button>
//                     </div>
//                   )}
//                 </form>
//               </motion.div>
//             </AnimatePresence>
//           </div>
//         </div>
//       </div>

//       {/* ─── Delete confirmation modal ──────────────────────────── */}
//       <AnimatePresence>
//         {isDeleteModalOpen && (
//           <motion.div
//             initial={{ opacity: 0 }}
//             animate={{ opacity: 1 }}
//             exit={{ opacity: 0 }}
//             className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 px-4"
//             onClick={() => !deleteLoading && setIsDeleteModalOpen(false)}
//           >
//             <motion.div
//               initial={{ opacity: 0, scale: 0.97, y: 8 }}
//               animate={{ opacity: 1, scale: 1, y: 0 }}
//               exit={{ opacity: 0, scale: 0.97, y: 8 }}
//               transition={{ duration: 0.18 }}
//               className="w-full max-w-sm rounded-2xl bg-white shadow-2xl"
//               onClick={(e) => e.stopPropagation()}
//             >
//               <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
//                 <div className="flex items-center gap-2.5">
//                   <div className="p-2 rounded-full bg-red-50">
//                     <MdWarning size={18} className="text-red-500" />
//                   </div>
//                   <h3 className="text-base font-semibold text-slate-800">Delete Job?</h3>
//                 </div>
//                 <button
//                   onClick={() => setIsDeleteModalOpen(false)}
//                   className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 transition-colors"
//                   disabled={deleteLoading}
//                 >
//                   <MdClose size={18} />
//                 </button>
//               </div>
//               <div className="px-5 py-4">
//                 <p className="text-sm text-slate-600">
//                   This will permanently remove <span className="font-medium text-slate-800">{heroTitle}</span> and its data. This action cannot be undone.
//                 </p>
//               </div>
//               <div className="flex justify-end gap-2.5 px-5 py-4 border-t border-slate-100">
//                 <button
//                   onClick={() => setIsDeleteModalOpen(false)}
//                   disabled={deleteLoading}
//                   className="px-3.5 py-2 rounded-lg text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
//                 >
//                   Keep job
//                 </button>
//                 <button
//                   onClick={handleDelete}
//                   disabled={deleteLoading}
//                   className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-60"
//                 >
//                   {deleteLoading && (
//                     <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
//                   )}
//                   {deleteLoading ? "Deleting..." : "Delete job"}
//                 </button>
//               </div>
//             </motion.div>
//           </motion.div>
//         )}
//       </AnimatePresence>
//     </div>
//   );
// };

// export default JobsForm;

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Editor } from "@tinymce/tinymce-react";
import {
  MdArrowBack,
  MdSave,
  MdCancel,
  MdDelete,
  MdWarning,
  MdClose,
  MdLanguage,
  MdCalendarToday,
  MdCategory,
  MdGroups,
  MdReceiptLong,
  MdDescription,
  MdImage,
  MdHistory,
  MdApartment,
  MdPerson,
  MdCreditCard,
  MdPermIdentity,
  MdOpenInNew,
  MdCloudUpload,
  MdWhatshot,
  MdCheckCircle,
  MdErrorOutline,
  MdPauseCircle,
  MdBlock,
  MdWork,
  MdBusiness,
  MdAttachMoney,
  MdDateRange,
  MdTrendingUp,
  MdCheck,
  MdSearch,
  MdKeyboardArrowDown,
} from "react-icons/md";
import jobService, {
  companyService,
  jobTypeService,
  workplaceTypeService,
  functionRoleService,
} from "../../services/job.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";
import { useAuth } from "../../context/AuthContext";

// ─── TinyMCE Cloud config ─────────────────────────────────────
const TINYMCE_API_KEY = "ftd4aagtfmkw0dpyqygkud9tevymqlmcdqyo8lsxhesmakc2";
const TINYMCE_SCRIPT_SRC = `https://cdn.tiny.cloud/1/${TINYMCE_API_KEY}/tinymce/7/tinymce.min.js`;

// ─── Helpers ──────────────────────────────────────────────────

const toNumberOrEmpty = (value) => {
  if (value === null || value === undefined || value === "") return "";
  const number = Number(value);
  return Number.isNaN(number) ? "" : number;
};

const toBoolean = (value) =>
  value === true || value === 1 || value === "1" || value === "true";

const getCompanyName = (company) =>
  company?.company_name ||
  company?.Company?.company_name ||
  company?.CompanyUser?.company_name ||
  company?.CompanyUser?.company_user_email ||
  company?.CompanyUser?.email ||
  "";

const parseApiDate = (dateString) => {
  if (!dateString) return null;
  if (dateString instanceof Date) return dateString;
  if (typeof dateString !== "string") return null;
  if (dateString.includes("T")) {
    const d = new Date(dateString);
    if (!Number.isNaN(d.getTime())) return d;
  }
  const match = dateString.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
  );
  if (match) {
    let [, day, month, year, hours, minutes, seconds, ampm] = match;
    hours = Number(hours);
    if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
    if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
    const d = new Date(
      Number(year),
      Number(month) - 1,
      Number(day),
      hours,
      Number(minutes),
      Number(seconds),
    );
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const d = new Date(dateString);
  return Number.isNaN(d.getTime()) ? null : d;
};

const formatDateTime = (date) => {
  if (!date) return "—";
  const parsed = typeof date === "string" ? parseApiDate(date) : date;
  if (!parsed || Number.isNaN(parsed.getTime())) return "—";
  return parsed.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const generateSlug = (title) => {
  if (!title) return "";
  return title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .substring(0, 100);
};

// ─── Company fetch helpers (fetch ALL companies, page by page) ─

const COMPANIES_PAGE_SIZE = 500;
const COMPANIES_MAX_PAGES = 40;

const extractListFromResponse = (response) => {
  const root = response?.data ?? response;
  const candidates = [
    root,
    root?.data,
    root?.results,
    root?.rows,
    root?.items,
    root?.companies,
    root?.list,
    root?.data?.data,
    root?.data?.results,
    root?.data?.rows,
    root?.data?.items,
    root?.data?.companies,
    root?.data?.list,
  ];
  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
  }
  return [];
};

const extractTotalFromResponse = (response) => {
  const root = response?.data;
  const candidates = [
    root?.total,
    root?.count,
    root?.totalCount,
    root?.total_count,
    root?.data?.total,
    root?.data?.count,
    root?.data?.totalCount,
    root?.data?.total_count,
    root?.meta?.total,
    root?.data?.meta?.total,
  ];
  for (const candidate of candidates) {
    if (candidate !== undefined && candidate !== null && !Number.isNaN(Number(candidate))) {
      return Number(candidate);
    }
  }
  return null;
};

const getCompanyId = (company) =>
  toNumberOrEmpty(
    company?.id ??
      company?.company_id ??
      company?.Company?.id ??
      company?.Company?.company_id,
  );

// Fetches every company across all pages instead of only the first page.
const fetchAllCompanies = async () => {
  const collected = [];
  const seen = new Set();
  let page = 1;
  let hasMore = true;

  while (hasMore && page <= COMPANIES_MAX_PAGES) {
    const response = await companyService.getAll({
      page,
      limit: COMPANIES_PAGE_SIZE,
      page_size: COMPANIES_PAGE_SIZE,
      per_page: COMPANIES_PAGE_SIZE,
    });

    const list = extractListFromResponse(response);
    if (!list.length) break;

    list.forEach((company) => {
      const id = getCompanyId(company);
      const key = id !== "" ? `id:${id}` : `name:${getCompanyName(company)}`;
      if (seen.has(key)) return;
      seen.add(key);
      collected.push(company);
    });

    const total = extractTotalFromResponse(response);
    if (total !== null) {
      hasMore = page * COMPANIES_PAGE_SIZE < total;
    } else {
      hasMore = list.length >= COMPANIES_PAGE_SIZE;
    }
    page += 1;
  }

  return collected;
};

// ─── Rich text (TinyMCE-style) content styles ─────────────────

const RICH_CONTENT_CSS = `
.rich-content {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  font-size: 15px;
  line-height: 1.7;
  color: #334155;
  word-wrap: break-word;
  overflow-wrap: anywhere;
}
.rich-content > *:first-child { margin-top: 0; }
.rich-content > *:last-child { margin-bottom: 0; }
.rich-content p { margin: 0 0 1em; }
.rich-content h1, .rich-content h2, .rich-content h3,
.rich-content h4, .rich-content h5, .rich-content h6 {
  color: #0f172a;
  font-weight: 700;
  line-height: 1.3;
  margin: 1.4em 0 0.6em;
}
.rich-content h1 { font-size: 2em; }
.rich-content h2 { font-size: 1.6em; }
.rich-content h3 { font-size: 1.3em; }
.rich-content h4 { font-size: 1.1em; }
.rich-content h5 { font-size: 1em; }
.rich-content h6 { font-size: 0.9em; text-transform: uppercase; letter-spacing: 0.04em; }
.rich-content strong, .rich-content b { font-weight: 700; color: #0f172a; }
.rich-content em, .rich-content i { font-style: italic; }
.rich-content u { text-decoration: underline; }
.rich-content s, .rich-content strike { text-decoration: line-through; }
.rich-content a { color: #2563eb; text-decoration: underline; }
.rich-content a:hover { color: #1d4ed8; }
.rich-content ul { list-style: disc; padding-left: 1.6em; margin: 0 0 1em; }
.rich-content ol { list-style: decimal; padding-left: 1.6em; margin: 0 0 1em; }
.rich-content ul ul { list-style: circle; }
.rich-content ul ul ul { list-style: square; }
.rich-content li { margin: 0.3em 0; }
.rich-content li > ul, .rich-content li > ol { margin: 0.3em 0 0; }
.rich-content blockquote {
  border-left: 4px solid #cbd5e1;
  background: #f8fafc;
  margin: 1em 0;
  padding: 0.6em 1em;
  color: #475569;
  border-radius: 0 8px 8px 0;
}
.rich-content hr { border: 0; border-top: 1px solid #e2e8f0; margin: 1.5em 0; }
.rich-content img { max-width: 100%; height: auto; border-radius: 8px; }
.rich-content pre {
  background: #0f172a;
  color: #e2e8f0;
  padding: 1em;
  border-radius: 10px;
  overflow-x: auto;
  font-size: 13px;
  margin: 1em 0;
}
.rich-content code {
  background: #f1f5f9;
  color: #be185d;
  padding: 0.15em 0.4em;
  border-radius: 4px;
  font-size: 0.9em;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}
.rich-content pre code { background: transparent; color: inherit; padding: 0; }
.rich-content table {
  border-collapse: collapse;
  width: 100%;
  margin: 1em 0;
  display: block;
  overflow-x: auto;
}
.rich-content th, .rich-content td {
  border: 1px solid #cbd5e1;
  padding: 8px 12px;
  text-align: left;
  vertical-align: top;
}
.rich-content th { background: #f1f5f9; font-weight: 600; color: #0f172a; }
.rich-content sub { vertical-align: sub; font-size: 0.8em; }
.rich-content sup { vertical-align: super; font-size: 0.8em; }
`;

// Decodes double-escaped HTML (e.g. "&lt;p&gt;Text&lt;/p&gt;") and strips
// dangerous tags / attributes before rendering. No extra dependency needed.
const sanitizeHtml = (html) => {
  if (!html) return "";
  let raw = String(html);

  const hasRealTags = /<\/?[a-z][\s\S]*?>/i.test(raw);
  const hasEscapedTags = /&lt;\/?[a-z][\s\S]*?&gt;/i.test(raw);
  if (!hasRealTags && hasEscapedTags) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = raw;
    raw = textarea.value;
  }

  const doc = new DOMParser().parseFromString(raw, "text/html");
  doc
    .querySelectorAll("script, style, iframe, object, embed, link, meta, form, base")
    .forEach((node) => node.remove());

  doc.body.querySelectorAll("*").forEach((el) => {
    Array.from(el.attributes).forEach((attr) => {
      const name = attr.name.toLowerCase();
      const value = attr.value.trim().toLowerCase();
      if (
        name.startsWith("on") ||
        ((name === "href" || name === "src" || name === "xlink:href") &&
          (value.startsWith("javascript:") || value.startsWith("data:text/html")))
      ) {
        el.removeAttribute(attr.name);
      }
    });
    if (el.tagName === "A") {
      el.setAttribute("target", "_blank");
      el.setAttribute("rel", "noopener noreferrer");
    }
  });

  return doc.body.innerHTML;
};

const RichTextView = ({ html }) => {
  const safe = sanitizeHtml(html);
  const hasContent =
    safe.replace(/<[^>]*>/g, "").replace(/&nbsp;/g, " ").trim().length > 0 ||
    /<img|<table|<hr/i.test(safe);

  if (!hasContent) {
    return <p className="text-sm text-slate-400">No description provided.</p>;
  }
  return <div className="rich-content" dangerouslySetInnerHTML={{ __html: safe }} />;
};

// ─── Rich text editor (Text ↔ HTML toggle) ─────────────────────
// Uses TinyMCE cloud CDN via the shared API key. The HTML tab gives
// users direct access to the raw markup at any time.
const RichTextEditorField = ({ value, onChange, height = 450 }) => {
  const [editorMode, setEditorMode] = useState("text");
  const editorRef = useRef(null);

  const syncToEditor = (nextValue) => {
    if (
      editorRef.current &&
      typeof editorRef.current.setContent === "function"
    ) {
      editorRef.current.setContent(nextValue || "", { format: "html" });
    }
  };

  const handleModeChange = (nextMode) => {
    if (nextMode === "html" && editorRef.current) {
      const currentHtml = editorRef.current.getContent();
      if (currentHtml !== value) {
        onChange(currentHtml);
      }
    }

    if (nextMode === "text") {
      syncToEditor(value || "");
    }

    setEditorMode(nextMode);
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-1 p-1 w-fit bg-slate-100 rounded-lg">
        {[
          ["text", "Text"],
          ["html", "HTML"],
        ].map(([tab, label]) => (
          <button
            key={tab}
            type="button"
            onClick={() => handleModeChange(tab)}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-all ${
              editorMode === tab
                ? "bg-white text-blue-600 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {editorMode === "text" ? (
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <Editor
            tinymceScriptSrc={TINYMCE_SCRIPT_SRC}
            licenseKey="gpl"
            value={value || ""}
            onEditorChange={onChange}
            onInit={(evt, editor) => {
              editorRef.current = editor;
              editor.setContent(value || "", { format: "html" });
            }}
            init={{
              height,
              menubar: false,
              statusbar: true,
              plugins: [
                "advlist",
                "autolink",
                "lists",
                "link",
                "image",
                "charmap",
                "preview",
                "anchor",
                "searchreplace",
                "visualblocks",
                "code",
                "fullscreen",
                "insertdatetime",
                "media",
                "table",
                "help",
                "wordcount",
              ],
              toolbar:
                "undo redo | blocks | bold italic underline strikethrough | " +
                "alignleft aligncenter alignright alignjustify | " +
                "bullist numlist outdent indent | link image table | " +
                "forecolor backcolor | removeformat code | help",
              content_style:
                "body { font-family: 'Inter', sans-serif; font-size: 14px; line-height: 1.7; } p { margin: 0 0 10px; } h1, h2, h3, h4, h5, h6 { margin: 0 0 12px; line-height: 1.3; }",
              placeholder: "Describe the role, responsibilities, requirements…",
              forced_root_block: "p",
              verify_html: false,
              cleanup: false,
            }}
          />
        </div>
      ) : (
        <textarea
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          className="w-full min-h-[350px] px-4 py-3 bg-slate-950 text-slate-100 border border-slate-200 rounded-xl text-sm font-mono placeholder-slate-400 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-slate-950 transition-all resize-y"
          spellCheck={false}
          rows={16}
          placeholder="<!-- Write HTML here -->"
        />
      )}
    </div>
  );
};

// ─── Status styles ─────────────────────────────────────────────

const STATUS_STYLES = {
  draft: {
    pill: "bg-gray-100 text-gray-700 ring-1 ring-gray-200",
    dot: "bg-gray-400",
    icon: MdPauseCircle,
  },
  published: {
    pill: "bg-green-50 text-green-700 ring-1 ring-green-200",
    dot: "bg-green-500",
    icon: MdCheckCircle,
  },
  closed: {
    pill: "bg-yellow-50 text-yellow-700 ring-1 ring-yellow-200",
    dot: "bg-yellow-500",
    icon: MdErrorOutline,
  },
};

const StatusPill = ({ status }) => {
  const style = STATUS_STYLES[status] || STATUS_STYLES.draft;
  const Icon = style.icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${style.pill}`}
    >
      <Icon size={13} />
      {status ? status.charAt(0).toUpperCase() + status.slice(1) : "Unknown"}
    </span>
  );
};

const ViewBadge = ({ active }) => (
  <span
    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
      active
        ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200"
        : "bg-slate-100 text-slate-500 ring-1 ring-slate-200"
    }`}
  >
    <span
      className={`w-1.5 h-1.5 rounded-full ${
        active ? "bg-emerald-500" : "bg-slate-400"
      }`}
    />
    {active ? "Active" : "Inactive"}
  </span>
);

// ─── Helper components ────────────────────────────────────────

const FieldLabel = ({ children, required }) => (
  <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
    {children}
    {required && <span className="text-red-500 ml-0.5">*</span>}
  </label>
);

const ReadOnlyValue = ({ children }) => (
  <div className="text-sm text-slate-700 py-2 px-3 bg-slate-50 rounded-lg border border-slate-200">
    {children || "—"}
  </div>
);

const HeroStat = ({ icon: Icon, label, value }) => (
  <div className="flex items-center gap-2.5 rounded-xl bg-white/10 backdrop-blur-sm px-3.5 py-2.5 min-w-0">
    <Icon size={16} className="text-white/70 flex-shrink-0" />
    <div className="min-w-0">
      <p className="text-[10px] text-black leading-tight">{label}</p>
      <p className="text-sm font-semibold text-black truncate leading-tight">
        {value || "—"}
      </p>
    </div>
  </div>
);

// ─── Searchable select (used for Company) ─────────────────────

const SearchableSelect = ({
  name,
  value,
  options = [],
  onChange,
  onBlur,
  placeholder = "Select option",
  searchPlaceholder = "Search...",
  disabled = false,
  hasError = false,
  loading = false,
  emptyMessage = "No options found",
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const containerRef = useRef(null);
  const searchRef = useRef(null);

  const selectedOption = useMemo(
    () => options.find((opt) => String(opt.value) === String(value ?? "")),
    [options, value],
  );

  const filteredOptions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter((opt) =>
      String(opt.label ?? "").toLowerCase().includes(q),
    );
  }, [options, query]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
        setQuery("");
        onBlur?.();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen, onBlur]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const timer = setTimeout(() => searchRef.current?.focus(), 0);
    return () => clearTimeout(timer);
  }, [isOpen]);

  const handleToggle = () => {
    if (disabled) return;
    setIsOpen((prev) => !prev);
    setQuery("");
  };

  const handleSelect = (optionValue) => {
    onChange?.(optionValue);
    setIsOpen(false);
    setQuery("");
    onBlur?.();
  };

  const handleClear = (event) => {
    event.stopPropagation();
    onChange?.("");
    setQuery("");
    onBlur?.();
  };

  const handleKeyDown = (event) => {
    if (event.key === "Escape") {
      setIsOpen(false);
      setQuery("");
      onBlur?.();
    } else if (event.key === "Enter" && isOpen) {
      event.preventDefault();
      if (filteredOptions.length > 0) handleSelect(filteredOptions[0].value);
    }
  };

  return (
    <div ref={containerRef} className="relative" onKeyDown={handleKeyDown}>
      <button
        type="button"
        name={name}
        disabled={disabled}
        onClick={handleToggle}
        className={`w-full flex items-center justify-between gap-2 px-3.5 py-2.5 border ${
          hasError ? "border-red-500" : "border-slate-300"
        } rounded-lg text-sm text-left bg-white transition-colors focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-400 ${
          disabled
            ? "opacity-60 cursor-not-allowed"
            : "cursor-pointer hover:border-slate-400"
        }`}
      >
        <span
          className={`truncate ${selectedOption ? "text-slate-800" : "text-slate-400"}`}
        >
          {selectedOption
            ? selectedOption.label
            : loading
              ? "Loading..."
              : placeholder}
        </span>
        <span className="flex items-center gap-1 flex-shrink-0">
          {selectedOption && !disabled && (
            <span
              role="button"
              tabIndex={-1}
              onClick={handleClear}
              className="p-0.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
            >
              <MdClose size={14} />
            </span>
          )}
          <MdKeyboardArrowDown
            size={18}
            className={`text-slate-400 transition-transform duration-200 ${
              isOpen ? "rotate-180" : ""
            }`}
          />
        </span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.14 }}
            className="absolute z-50 mt-1 w-full rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden"
          >
            <div className="p-2 border-b border-slate-100">
              <div className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-slate-50 border border-slate-200">
                <MdSearch size={16} className="text-slate-400 flex-shrink-0" />
                <input
                  ref={searchRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={searchPlaceholder}
                  className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery("")}
                    className="text-slate-400 hover:text-slate-600 flex-shrink-0"
                  >
                    <MdClose size={14} />
                  </button>
                )}
              </div>
            </div>
            <ul className="max-h-60 overflow-y-auto py-1">
              {filteredOptions.length === 0 ? (
                <li className="px-3.5 py-3 text-sm text-slate-400 text-center">
                  {emptyMessage}
                </li>
              ) : (
                filteredOptions.map((opt) => {
                  const isSelected = String(opt.value) === String(value ?? "");
                  return (
                    <li key={opt.value}>
                      <button
                        type="button"
                        onClick={() => handleSelect(opt.value)}
                        className={`w-full flex items-center justify-between gap-2 px-3.5 py-2 text-sm text-left transition-colors ${
                          isSelected
                            ? "bg-blue-50 text-blue-700 font-medium"
                            : "text-slate-700 hover:bg-slate-50"
                        }`}
                      >
                        <span className="truncate">{opt.label}</span>
                        {isSelected && (
                          <MdCheck size={15} className="text-blue-600 flex-shrink-0" />
                        )}
                      </button>
                    </li>
                  );
                })
              )}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Tabs = [
  { id: "overview", label: "Overview", icon: MdApartment },
  { id: "classification", label: "Classification", icon: MdCategory },
  { id: "compensation", label: "Compensation", icon: MdAttachMoney },
  { id: "description", label: "Description", icon: MdDescription },
  { id: "status", label: "Status & Features", icon: MdCheck },
  { id: "activity", label: "Activity", icon: MdHistory },
];

// ─── Main Component ────────────────────────────────────────────

const JobsForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { user } = useAuth();
  const userId = user?.id;

  // ─── Mode resolution ──────────────────────────────────────

  const resolveModeFromPath = (pathname) => {
    if (pathname.includes("/view/")) return "view";
    if (pathname.includes("/edit/")) return "edit";
    return "add";
  };

  const [mode, setMode] = useState(() => resolveModeFromPath(location.pathname));
  const [pageLoading, setPageLoading] = useState(() => {
    const initialMode = resolveModeFromPath(location.pathname);
    return initialMode === "edit" || initialMode === "view";
  });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");

  // ─── Dropdown states ───────────────────────────────────────

  const [companies, setCompanies] = useState([]);
  const [jobTypes, setJobTypes] = useState([]);
  const [workplaceTypes, setWorkplaceTypes] = useState([]);
  const [functionRoles, setFunctionRoles] = useState([]);
  const [loadingDropdowns, setLoadingDropdowns] = useState(false);
  const [userNameCache, setUserNameCache] = useState({});

  // ─── Fetch dropdowns ──────────────────────────────────────

  useEffect(() => {
    let isCancelled = false;

    const fetchDropdowns = async () => {
      setLoadingDropdowns(true);
      try {
        const [
          allCompanies,
          jobTypeResponse,
          workplaceResponse,
          functionRoleResponse,
        ] = await Promise.all([
          fetchAllCompanies(),
          jobTypeService.getAll(),
          workplaceTypeService.getAll(),
          functionRoleService.getAll(),
        ]);

        if (isCancelled) return;

        // Companies (ALL companies, de-duplicated + sorted A→Z)
        const normalizedCompanies = Array.isArray(allCompanies)
          ? allCompanies
              .map((c) => ({
                ...c,
                id: getCompanyId(c),
              }))
              .filter((c) => c.id !== "")
              .sort((a, b) =>
                (getCompanyName(a) || "").localeCompare(
                  getCompanyName(b) || "",
                  undefined,
                  { sensitivity: "base" },
                ),
              )
          : [];
        setCompanies(normalizedCompanies);

        // Job Types
        const jobTypeData = jobTypeResponse?.data?.data || jobTypeResponse?.data || [];
        const normalizedJobTypes = Array.isArray(jobTypeData)
          ? jobTypeData
              .filter(
                (item) =>
                  item.is_status !== false &&
                  item.status !== false &&
                  item.is_status !== 0,
              )
              .map((item) => ({
                ...item,
                id: toNumberOrEmpty(item.jobtype_id ?? item.job_type_id ?? item.id),
              }))
              .filter((item) => item.id !== "")
          : [];
        setJobTypes(normalizedJobTypes);

        // Workplace Types
        const workplaceData =
          workplaceResponse?.data?.data || workplaceResponse?.data || [];
        const normalizedWorkplaceTypes = Array.isArray(workplaceData)
          ? workplaceData
              .filter(
                (item) =>
                  item.is_status !== false &&
                  item.status !== false &&
                  item.is_status !== 0,
              )
              .map((item) => ({
                ...item,
                id: toNumberOrEmpty(item.workplacetype_id ?? item.workplace_type_id ?? item.id),
              }))
              .filter((item) => item.id !== "")
          : [];
        setWorkplaceTypes(normalizedWorkplaceTypes);

        // Function Roles
        const functionRoleData =
          functionRoleResponse?.data?.data || functionRoleResponse?.data || [];
        const normalizedFunctionRoles = Array.isArray(functionRoleData)
          ? functionRoleData
              .filter(
                (item) =>
                  item.is_status !== false &&
                  item.status !== false &&
                  item.is_status !== 0,
              )
              .map((item) => ({
                ...item,
                id: toNumberOrEmpty(item.functionrole_id ?? item.function_role_id ?? item.functions_roles_id ?? item.id),
              }))
              .filter((item) => item.id !== "")
          : [];
        setFunctionRoles(normalizedFunctionRoles);
      } catch (error) {
        if (isCancelled) return;
        console.error("Error loading dropdowns:", error);
        showError("Failed to load form data. Please refresh.");
      } finally {
        if (!isCancelled) setLoadingDropdowns(false);
      }
    };

    fetchDropdowns();

    return () => {
      isCancelled = true;
    };
  }, []);

  // ─── Load users ────────────────────────────────────────────

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const users = await fetchUsers();
        const userMap = {};
        Object.keys(users || {}).forEach((uid) => {
          userMap[uid] = users[uid]?.name;
        });
        setUserNameCache(userMap);
      } catch (error) {
        console.error("Failed to load users:", error);
      }
    };
    loadUsers();
  }, []);

  const getCreatedByName = (row) => {
    if (!row?.created_by) return "—";
    return userNameCache[row.created_by] || `User ${row.created_by}`;
  };
  const getUpdatedByName = (row) => {
    if (!row?.updated_by) return "—";
    return userNameCache[row.updated_by] || `User ${row.updated_by}`;
  };

  // ─── Normalize job data ──────────────────────────────────

  const normalizeJobData = (item) => {
    if (!item) return null;
    const companyId = toNumberOrEmpty(
      item.company_id ??
        item.Company?.company_id ??
        item.Company?.id ??
        item.company?.company_id ??
        item.company?.id,
    );
    const jobTypeId = toNumberOrEmpty(
      item.job_type_id ??
        item.jobtype_id ??
        item.JobType?.jobtype_id ??
        item.JobType?.job_type_id ??
        item.JobType?.id ??
        item.job_type?.jobtype_id ??
        item.job_type?.job_type_id ??
        item.job_type?.id,
    );
    const workplaceTypeId = toNumberOrEmpty(
      item.workplacetype_id ??
        item.workplace_type_id ??
        item.WorkplaceType?.workplacetype_id ??
        item.WorkplaceType?.workplace_type_id ??
        item.WorkplaceType?.id ??
        item.workplace_type?.id,
    );
    const functionRoleId = toNumberOrEmpty(
      item.functionrole_id ??
        item.function_role_id ??
        item.FunctionRole?.functionrole_id ??
        item.FunctionRole?.function_role_id ??
        item.FunctionRole?.id ??
        item.JobFunctionsRoles?.[0]?.functions_roles_id ??
        item.JobFunctionsRoles?.[0]?.functionrole_id ??
        item.JobFunctionsRoles?.[0]?.function_role_id ??
        item.JobFunctionsRoles?.[0]?.FunctionRole?.functionrole_id ??
        item.JobFunctionsRoles?.[0]?.FunctionRole?.id ??
        item.JobFunctionsRoles?.[0]?.id,
    );

    let companyName =
      item.company_name ||
      getCompanyName(item.Company) ||
      getCompanyName(item.company);
    if (!companyName && companyId !== "") {
      const comp = companies.find((c) => Number(c.id) === Number(companyId));
      if (comp) companyName = getCompanyName(comp);
    }

    return {
      id: item.id || item._id,
      title: item.title || "",
      job_description: item.job_description || "",
      company_id: companyId,
      company_name: companyName,
      job_type_id: jobTypeId,
      jobtype_name: item.JobType?.name || item.jobtype_name || "",
      workplacetype_id: workplaceTypeId,
      workplacetype_name: item.WorkplaceType?.name || item.workplacetype_name || "",
      functionrole_id: functionRoleId,
      functionrole_name:
        item.FunctionRole?.name ||
        item.JobFunctionsRoles?.[0]?.FunctionRole?.name ||
        item.functionrole_name ||
        "",
      experience_min: item.experience_min ?? "",
      experience_max: item.experience_max ?? "",
      experience_type: item.experience_type || "experience",
      salary_min: item.salary_min ?? "",
      salary_max: item.salary_max ?? "",
      salary_confidential: toBoolean(item.salary_confidential),
      job_status: item.job_status || "draft",
      posting_type: item.posting_type || "permanent",
      expiry_date: item.expiry_date || "",
      auto_renew: item.auto_renew || "off",
      reference_code: item.reference_code || "",
      is_trending: toBoolean(item.is_trending),
      is_status: toBoolean(item.is_status),
      daily_application_summary: toBoolean(item.daily_application_summary),
      notify_matching_type: item.notify_matching_type || "All matching applicants",
      prioritize_women: toBoolean(item.prioritize_women),
      schedule_date: item.schedule_date || null,
      published_at: item.published_at || null,
      slug: item.slug || "",
      created_by: item.created_by ?? null,
      updated_by: item.updated_by ?? null,
      created_at: item.created_at || null,
      updated_at: item.updated_at || null,
    };
  };

  // ─── Fetch edit/view data ────────────────────────────────

  useEffect(() => {
    const fetchData = async () => {
      if ((mode !== "edit" && mode !== "view") || !id) return;
      setPageLoading(true);
      try {
        let item = location.state?.item;
        if (!item) {
          const response = await jobService.getById(id);
          item = response?.data?.data || response?.data;
        }
        if (!item) throw new Error("Job data not found");
        const normalizedData = normalizeJobData(item);
        setData(normalizedData);
      } catch (error) {
        console.error("Fetch job error:", error);
        showError("Failed to load job data");
        navigate("/jobs");
      } finally {
        setPageLoading(false);
      }
    };
    fetchData();
  }, [id, mode, location.state, navigate, companies]);

  // ─── Update company name after companies load ────────────

  useEffect(() => {
    if (!data?.company_id) return;
    const company = companies.find((c) => Number(c.id) === Number(data.company_id));
    if (!company) return;
    const companyName =
      company.company_name || company.CompanyUser?.company_user_email || "";
    if (companyName && companyName !== data.company_name) {
      setData((prev) => (prev ? { ...prev, company_name: companyName } : prev));
    }
  }, [companies, data?.company_id, data?.company_name]);

  // ─── Form state ────────────────────────────────────────────

  const getInitialData = () => {
    if (mode === "add") {
      return {
        title: "",
        job_description: "",
        company_id: "",
        job_type_id: "",
        workplacetype_id: "",
        functionrole_id: "",
        experience_min: "",
        experience_max: "",
        experience_type: "experience",
        salary_min: "",
        salary_max: "",
        salary_confidential: false,
        job_status: "draft",
        posting_type: "permanent",
        expiry_date: "",
        auto_renew: "off",
        reference_code: "",
        is_trending: false,
        status: "active",
      };
    }
    if (data) {
      return {
        title: data.title || "",
        job_description: data.job_description || "",
        company_id: data.company_id !== "" ? Number(data.company_id) : "",
        job_type_id: data.job_type_id !== "" ? Number(data.job_type_id) : "",
        workplacetype_id:
          data.workplacetype_id !== "" ? Number(data.workplacetype_id) : "",
        functionrole_id:
          data.functionrole_id !== "" ? Number(data.functionrole_id) : "",
        experience_min: data.experience_min ?? "",
        experience_max: data.experience_max ?? "",
        experience_type: data.experience_type || "experience",
        salary_min: data.salary_min ?? "",
        salary_max: data.salary_max ?? "",
        salary_confidential: data.salary_confidential || false,
        job_status: data.job_status || "draft",
        posting_type: data.posting_type || "permanent",
        expiry_date: data.expiry_date || "",
        auto_renew: data.auto_renew || "off",
        reference_code: data.reference_code || "",
        is_trending: data.is_trending || false,
        status: data.is_status ? "active" : "inactive",
        // Additional view-only props
        is_status: data.is_status,
        company_name: data.company_name || "",
        jobtype_name: data.jobtype_name || "",
        workplacetype_name: data.workplacetype_name || "",
        functionrole_name: data.functionrole_name || "",
        created_by: data.created_by,
        updated_by: data.updated_by,
        created_at: data.created_at,
        updated_at: data.updated_at,
      };
    }
    return {};
  };

  const [formValues, setFormValues] = useState(getInitialData);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  useEffect(() => {
    setFormValues(getInitialData());
  }, [data, mode]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    const val = type === "checkbox" ? checked : value;
    setFormValues((prev) => ({ ...prev, [name]: val }));
    // Clear error for field
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
  };

  // Handlers for custom (non-native) inputs like the searchable select
  const handleFieldChange = (name, value) => {
    setFormValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleFieldBlur = (name) => {
    setTouched((prev) => ({ ...prev, [name]: true }));
  };

  // ─── Validation ────────────────────────────────────────────

  const getValidationRules = () => ({
    title: {
      required: true,
      requiredMessage: "Job title is required",
      minLength: 1,
      minLengthMessage: "Job title is required",
      maxLength: 200,
      maxLengthMessage: "Job title must be at most 200 characters",
    },
    company_id: {
      required: true,
      requiredMessage: "Please select a company",
    },
    job_type_id: {
      required: (formData) => formData?.job_status === "published",
      requiredMessage: "Please select a job type",
    },
    workplacetype_id: {
      required: (formData) => formData?.job_status === "published",
      requiredMessage: "Please select a workplace type",
    },
    functionrole_id: {
      required: (formData) => formData?.job_status === "published",
      requiredMessage: "Please select a function role",
    },
    job_status: {
      required: true,
      requiredMessage: "Please select a job status",
    },
    experience_type: {
      required: true,
      requiredMessage: "Please select an experience type",
    },
    posting_type: {
      required: true,
      requiredMessage: "Please select a posting type",
    },
    auto_renew: {
      required: true,
      requiredMessage: "Please select auto-renew option",
    },
    expiry_date: {
      required: (formData) => formData?.job_status === "published",
      requiredMessage: "Expiry date is required to publish a job",
    },
    experience_min: {
      custom: (value) => {
        if (value !== "" && value !== null && value !== undefined) {
          const num = Number(value);
          if (Number.isNaN(num)) return "Experience minimum must be a valid number";
          if (num < 0) return "Experience minimum cannot be negative";
          if (num > 50) return "Experience minimum cannot exceed 50 years";
        }
        return null;
      },
    },
    experience_max: {
      custom: (value, formData) => {
        if (value !== "" && value !== null && value !== undefined) {
          const num = Number(value);
          if (Number.isNaN(num)) return "Experience maximum must be a valid number";
          if (num < 0) return "Experience maximum cannot be negative";
          if (num > 50) return "Experience maximum cannot exceed 50 years";
          if (
            formData?.experience_min !== "" &&
            formData?.experience_min !== null &&
            formData?.experience_min !== undefined
          ) {
            const min = Number(formData.experience_min);
            if (!Number.isNaN(min) && num < min)
              return "Experience maximum must be >= minimum";
          }
        }
        return null;
      },
    },
    salary_min: {
      custom: (value) => {
        if (value !== "" && value !== null && value !== undefined) {
          const num = Number(value);
          if (Number.isNaN(num)) return "Salary minimum must be a valid number";
          if (num < 0) return "Salary minimum cannot be negative";
        }
        return null;
      },
    },
    salary_max: {
      custom: (value, formData) => {
        if (value !== "" && value !== null && value !== undefined) {
          const num = Number(value);
          if (Number.isNaN(num)) return "Salary maximum must be a valid number";
          if (num < 0) return "Salary maximum cannot be negative";
          if (
            formData?.salary_min !== "" &&
            formData?.salary_min !== null &&
            formData?.salary_min !== undefined
          ) {
            const min = Number(formData.salary_min);
            if (!Number.isNaN(min) && num < min)
              return "Salary maximum must be >= minimum";
          }
        }
        return null;
      },
    },
  });

  const validateField = (name, value, allValues) => {
    const rules = getValidationRules()[name];
    if (!rules) return null;
    const isRequired =
      typeof rules.required === "function"
        ? rules.required(allValues)
        : rules.required;
    if (
      isRequired &&
      (value === "" || value === null || value === undefined)
    ) {
      return rules.requiredMessage || `${name} is required`;
    }
    if (rules.minLength && typeof value === "string" && value.length < rules.minLength) {
      return rules.minLengthMessage || `Minimum length is ${rules.minLength}`;
    }
    if (rules.maxLength && typeof value === "string" && value.length > rules.maxLength) {
      return rules.maxLengthMessage || `Maximum length is ${rules.maxLength}`;
    }
    if (rules.custom) {
      return rules.custom(value, allValues);
    }
    return null;
  };

  const validateAll = () => {
    const allValues = formValues;
    const newErrors = {};
    const rules = getValidationRules();
    Object.keys(rules).forEach((field) => {
      const error = validateField(field, allValues[field], allValues);
      if (error) newErrors[field] = error;
    });
    setErrors(newErrors);
    return newErrors;
  };

  // ─── Submit ────────────────────────────────────────────────

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = validateAll();
    if (Object.keys(newErrors).length > 0) {
      const firstErrorMsg = Object.values(newErrors)[0];
      console.warn("Job form validation errors:", newErrors);
      showError(firstErrorMsg || "Please fix validation errors");
      return;
    }

    setLoading(true);
    try {
      const workplaceTypeId = toNumberOrEmpty(formValues.workplacetype_id) || null;
      const functionRoleId = toNumberOrEmpty(formValues.functionrole_id) || null;

      const payload = {
        title: formValues.title.trim(),
        job_description: formValues.job_description?.trim() || "",
        company_id: toNumberOrEmpty(formValues.company_id) || null,
        job_type_id: toNumberOrEmpty(formValues.job_type_id) || null,
        workplace_type_id: workplaceTypeId,
        workplacetype_id: workplaceTypeId,
        function_role_id: functionRoleId,
        functionrole_id: functionRoleId,
        functions_roles_id: functionRoleId,
        experience_min:
          formValues.experience_min !== "" ? Number(formValues.experience_min) : null,
        experience_max:
          formValues.experience_max !== "" ? Number(formValues.experience_max) : null,
        experience_type: formValues.experience_type || "experience",
        salary_min:
          formValues.salary_min !== "" ? Number(formValues.salary_min) : null,
        salary_max:
          formValues.salary_max !== "" ? Number(formValues.salary_max) : null,
        salary_confidential: toBoolean(formValues.salary_confidential),
        job_status: formValues.job_status || "draft",
        posting_type: formValues.posting_type || "permanent",
        expiry_date: formValues.expiry_date || null,
        auto_renew: formValues.auto_renew || "off",
        reference_code: formValues.reference_code?.trim() || null,
        is_trending: toBoolean(formValues.is_trending),
        is_status: formValues.status === "active",
        daily_application_summary: true,
        notify_matching_type: "All matching applicants",
        prioritize_women: false,
        schedule_date:
          formValues.job_status === "published"
            ? formValues.schedule_date || new Date().toISOString()
            : null,
        published_at:
          formValues.job_status === "published"
            ? formValues.published_at || new Date().toISOString()
            : null,
        slug: generateSlug(formValues.title.trim()),
        sub_industry_id:
          formValues.sub_industry_id || formValues.sub_industry_ids?.[0] || null,
        sub_industry_ids:
          formValues.sub_industry_ids ||
          (formValues.sub_industry_id ? [formValues.sub_industry_id] : []),
        industry_id: formValues.industry_id || null,
        skill_ids: formValues.skill_ids || [],
        skills: formValues.skill_ids || [],
        location_ids: formValues.location_ids || [],
        locations: formValues.location_ids || [],
        perks_benefits_ids: formValues.perks_benefits_ids || [],
        education_sub_category_ids: formValues.education_sub_category_ids || [],
        education_sub_category_id:
          formValues.education_sub_category_id ||
          formValues.education_sub_category_ids?.[0] ||
          null,
      };

      if (mode === "edit" && id) {
        payload.updated_by = userId || null;
        await jobService.update(id, payload);
        showSuccess("Job updated successfully");
      } else {
        payload.created_by = userId || null;
        payload.updated_by = userId || null;
        await jobService.create(payload);
        showSuccess("Job created successfully");
      }
      navigate("/jobs");
    } catch (error) {
      console.error("Submit error:", error);
      const msg =
        error?.response?.data?.message ||
        error?.response?.data?.error ||
        error?.message ||
        "Failed to save job";
      showError(msg);
    } finally {
      setLoading(false);
    }
  };

  // ─── Delete ────────────────────────────────────────────────

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const handleDelete = async () => {
    if (!id) return;
    setDeleteLoading(true);
    try {
      await jobService.deleteJobBenefits(id);
      await jobService.delete(id);
      showSuccess("Job deleted successfully");
      navigate("/jobs");
    } catch (error) {
      console.error("Delete error:", error);
      showError(error?.response?.data?.message || error?.message || "Failed to delete");
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
    }
  };

  // ─── Dropdown options ──────────────────────────────────────

  const getDropdownOptions = () => {
    const companyOptions = companies.map((c) => ({
      value: Number(c.id),
      label: getCompanyName(c) || `Company ${c.id}`,
    }));
    if (
      data?.company_id &&
      !companyOptions.some((o) => Number(o.value) === Number(data.company_id))
    ) {
      companyOptions.unshift({
        value: Number(data.company_id),
        label: data.company_name || `Company ${data.company_id}`,
      });
    }
    const jobTypeOptions = jobTypes.map((j) => ({
      value: Number(j.id),
      label: j.name || "",
    }));
    const workplaceTypeOptions = workplaceTypes.map((w) => ({
      value: Number(w.id),
      label: w.name || "",
    }));
    const functionRoleOptions = functionRoles.map((f) => ({
      value: Number(f.id),
      label: f.name || "",
    }));
    return { companyOptions, jobTypeOptions, workplaceTypeOptions, functionRoleOptions };
  };

  // ─── Render field based on definition ──────────────────────

  const renderField = (fieldDef) => {
    const {
      name,
      label,
      type,
      required,
      options,
      placeholder,
      rows,
      disabled,
      viewRender,
      color,
      min,
      max,
      step,
      searchable,
      searchPlaceholder,
      emptyMessage,
    } = fieldDef;

    const value = formValues[name] ?? "";
    const error = errors[name];
    const isTouched = touched[name];

    if (mode === "view" && viewRender) {
      return (
        <div key={name} className="mb-4">
          <FieldLabel>{label}</FieldLabel>
          <div className="text-sm text-slate-700">{viewRender(value, formValues)}</div>
        </div>
      );
    }

    const commonInputClass = `w-full px-3.5 py-2.5 border ${
      error && isTouched ? "border-red-500" : "border-slate-300"
    } rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors bg-white`;

    let inputElement;
    switch (type) {
      case "select":
        if (searchable) {
          inputElement = (
            <SearchableSelect
              name={name}
              value={value}
              options={options || []}
              onChange={(val) => handleFieldChange(name, val)}
              onBlur={() => handleFieldBlur(name)}
              placeholder={placeholder}
              searchPlaceholder={searchPlaceholder || `Search ${label?.toLowerCase() || "option"}...`}
              disabled={disabled}
              hasError={Boolean(error && isTouched)}
              loading={loadingDropdowns}
              emptyMessage={emptyMessage || "No options found"}
            />
          );
          break;
        }
        inputElement = (
          <select
            name={name}
            value={value}
            onChange={handleInputChange}
            onBlur={handleBlur}
            disabled={disabled || loadingDropdowns}
            className={commonInputClass}
          >
            <option value="">
              {loadingDropdowns ? "Loading..." : placeholder || "Select option"}
            </option>
            {options?.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        );
        break;

      case "richtext":
        inputElement = (
          <RichTextEditorField
            value={formValues[name] || ""}
            onChange={(val) => handleFieldChange(name, val)}
          />
        );
        break;

      case "textarea":
        inputElement = (
          <textarea
            name={name}
            value={value}
            onChange={handleInputChange}
            onBlur={handleBlur}
            rows={rows || 4}
            placeholder={placeholder}
            disabled={disabled}
            className={`${commonInputClass} resize-y`}
          />
        );
        break;

      case "checkbox":
        inputElement = (
          <div className="flex items-center gap-3 pt-1.5">
            <input
              type="checkbox"
              name={name}
              checked={Boolean(value)}
              onChange={handleInputChange}
              onBlur={handleBlur}
              disabled={disabled}
              className={`w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 ${color || ""}`}
            />
            <span className="text-sm text-slate-600">{label}</span>
          </div>
        );
        break;

      case "radio":
        inputElement = (
          <div className="flex flex-wrap gap-4 pt-1.5">
            {options?.map((opt) => (
              <label key={opt.value} className="flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="radio"
                  name={name}
                  value={opt.value}
                  checked={String(value) === String(opt.value)}
                  onChange={handleInputChange}
                  onBlur={handleBlur}
                  disabled={disabled}
                  className={`w-4 h-4 border-slate-300 text-blue-600 focus:ring-blue-500 ${color || ""}`}
                />
                {opt.label}
              </label>
            ))}
          </div>
        );
        break;

      case "number":
        inputElement = (
          <input
            type="number"
            name={name}
            value={value}
            onChange={handleInputChange}
            onBlur={handleBlur}
            placeholder={placeholder}
            disabled={disabled}
            min={min}
            max={max}
            step={step}
            className={commonInputClass}
          />
        );
        break;

      case "date":
        inputElement = (
          <input
            type="date"
            name={name}
            value={value}
            onChange={handleInputChange}
            onBlur={handleBlur}
            disabled={disabled}
            className={commonInputClass}
          />
        );
        break;

      default:
        inputElement = (
          <input
            type="text"
            name={name}
            value={value}
            onChange={handleInputChange}
            onBlur={handleBlur}
            placeholder={placeholder}
            disabled={disabled}
            className={commonInputClass}
          />
        );
    }

    return (
      <div key={name} className="mb-4">
        {type !== "checkbox" && type !== "radio" && (
          <FieldLabel required={required}>{label}</FieldLabel>
        )}
        {inputElement}
        {error && isTouched && (
          <p className="mt-1 text-xs text-red-500">{error}</p>
        )}
      </div>
    );
  };

  // ─── Group fields by tab ──────────────────────────────────

  const fields = (() => {
    if (mode === "view") {
      return [
        // overview (job type / workplace / function role live in Classification only)
        ["title", "company_name", "reference_code"],
        // classification
        ["jobtype_name", "workplacetype_name", "functionrole_name"],
        // compensation
        ["salary_min", "salary_max", "salary_confidential"],
        // description
        ["job_description"],
        // status (job status, posting type & trending are already shown in the hero)
        ["expiry_date", "auto_renew", "status"],
        // activity
        ["created_by", "created_at", "updated_by", "updated_at"],
      ];
    }
    // add/edit
    return [
      // overview
      ["title", "company_id", "reference_code"],
      // classification
      ["job_type_id", "workplacetype_id", "functionrole_id"],
      // compensation
      ["salary_min", "salary_max", "salary_confidential"],
      // description
      ["job_description"],
      // status
      ["job_status", "posting_type", "expiry_date", "auto_renew", "is_trending", "status"],
      // activity - only in edit/view, not in add
    ];
  })();

  const getTabFields = (tabId) => {
    const tabMap = {
      overview: 0,
      classification: 1,
      compensation: 2,
      description: 3,
      status: 4,
      activity: 5,
    };
    const index = tabMap[tabId];
    if (index === undefined) return [];
    const fieldNames = fields[index] || [];
    const allFieldDefs = (() => {
      if (mode === "view") {
        const labelMap = {
          title: "Job Title",
          company_name: "Company",
          reference_code: "Reference Code",
          jobtype_name: "Job Type",
          workplacetype_name: "Workplace Type",
          functionrole_name: "Function Role",
          salary_min: "Salary Min",
          salary_max: "Salary Max",
          salary_confidential: "Salary Confidential",
          job_description: "Job Description",
          job_status: "Job Status",
          posting_type: "Posting Type",
          expiry_date: "Expiry Date",
          auto_renew: "Auto Renew",
          is_trending: "Trending",
          status: "Active",
          created_by: "Created By",
          created_at: "Created At",
          updated_by: "Updated By",
          updated_at: "Updated At",
        };
        return fieldNames.map((name) => ({
          name,
          label: labelMap[name] || name,
          type: "text",
          viewRender: (value, row) => {
            if (name === "job_description") {
              return <RichTextView html={value} />;
            }
            if (name === "salary_min" || name === "salary_max") {
              return value !== "" && value !== null && value !== undefined
                ? `₹${Number(value).toLocaleString("en-IN")}`
                : "—";
            }
            if (name === "salary_confidential") {
              return value ? "Confidential" : "Not Confidential";
            }
            if (name === "is_trending") {
              return value ? "Trending" : "Not Trending";
            }
            if (name === "status") {
              return <ViewBadge active={row?.is_status} />;
            }
            if (name === "job_status") {
              return <StatusPill status={value} />;
            }
            if (name === "expiry_date") {
              return value ? formatDateTime(value) : "—";
            }
            if (name === "created_at" || name === "updated_at") {
              return formatDateTime(row?.[name]);
            }
            if (name === "created_by" || name === "updated_by") {
              const nameFn = name === "created_by" ? getCreatedByName : getUpdatedByName;
              return nameFn(row);
            }
            return value || "—";
          },
        }));
      } else {
        const {
          companyOptions,
          jobTypeOptions,
          workplaceTypeOptions,
          functionRoleOptions,
        } = getDropdownOptions();

        const jobStatusOptions = [
          { value: "draft", label: "Draft" },
          { value: "published", label: "Published" },
          { value: "closed", label: "Closed" },
        ];
        const postingTypeOptions = [
          { value: "permanent", label: "Permanent" },
          { value: "contract", label: "Contract" },
          { value: "walk-in", label: "Walk-in" },
          { value: "internship", label: "Internship" },
        ];
        const experienceTypeOptions = [
          { value: "experience", label: "Experience" },
          { value: "fresher", label: "Fresher" },
        ];
        const autoRenewOptions = [
          { value: "off", label: "Off" },
          { value: "weekly", label: "Weekly" },
          { value: "monthly", label: "Monthly" },
        ];

        const fieldDefs = {
          title: {
            name: "title",
            label: "Job Title",
            type: "text",
            required: true,
            placeholder: "e.g. Frontend Developer",
          },
          company_id: {
            name: "company_id",
            label: "Company",
            type: "select",
            required: true,
            searchable: true,
            options: companyOptions,
            placeholder: loadingDropdowns ? "Loading companies..." : "Select company",
            searchPlaceholder: "Search company by name...",
            emptyMessage: "No company found",
            disabled: loadingDropdowns,
          },
          reference_code: {
            name: "reference_code",
            label: "Reference Code",
            type: "text",
            placeholder: "e.g. JOB123",
          },
          job_type_id: {
            name: "job_type_id",
            label: "Job Type",
            type: "select",
            required: true,
            options: jobTypeOptions,
            placeholder: loadingDropdowns ? "Loading job types..." : "Select job type",
            disabled: loadingDropdowns,
          },
          workplacetype_id: {
            name: "workplacetype_id",
            label: "Workplace Type",
            type: "select",
            required: true,
            options: workplaceTypeOptions,
            placeholder: loadingDropdowns ? "Loading workplace types..." : "Select workplace type",
            disabled: loadingDropdowns,
          },
          functionrole_id: {
            name: "functionrole_id",
            label: "Function Role",
            type: "select",
            required: true,
            options: functionRoleOptions,
            placeholder: loadingDropdowns ? "Loading function roles..." : "Select function role",
            disabled: loadingDropdowns,
          },
          experience_min: {
            name: "experience_min",
            label: "Experience Min (years)",
            type: "number",
            min: 0,
            max: 50,
            step: 1,
            placeholder: "0",
          },
          experience_max: {
            name: "experience_max",
            label: "Experience Max (years)",
            type: "number",
            min: 0,
            max: 50,
            step: 1,
            placeholder: "10",
          },
          experience_type: {
            name: "experience_type",
            label: "Experience Type",
            type: "select",
            required: true,
            options: experienceTypeOptions,
            placeholder: "Select experience type",
          },
          salary_min: {
            name: "salary_min",
            label: "Salary Min (₹)",
            type: "number",
            min: 0,
            step: 1000,
            placeholder: "30000",
          },
          salary_max: {
            name: "salary_max",
            label: "Salary Max (₹)",
            type: "number",
            min: 0,
            step: 1000,
            placeholder: "50000",
          },
          salary_confidential: {
            name: "salary_confidential",
            label: "Salary Confidential",
            type: "checkbox",
            color: "text-gray-500 focus:ring-gray-500",
          },
          job_description: {
            name: "job_description",
            label: "Job Description",
            type: "richtext",
          },
          job_status: {
            name: "job_status",
            label: "Job Status",
            type: "select",
            required: true,
            options: jobStatusOptions,
            placeholder: "Select job status",
          },
          posting_type: {
            name: "posting_type",
            label: "Posting Type",
            type: "select",
            required: true,
            options: postingTypeOptions,
            placeholder: "Select posting type",
          },
          expiry_date: {
            name: "expiry_date",
            label: "Expiry Date",
            type: "date",
          },
          auto_renew: {
            name: "auto_renew",
            label: "Auto Renew",
            type: "select",
            required: true,
            options: autoRenewOptions,
            placeholder: "Select auto-renew option",
          },
          is_trending: {
            name: "is_trending",
            label: "Mark as Trending",
            type: "checkbox",
            color: "text-amber-500 focus:ring-amber-500",
          },
          status: {
            name: "status",
            label: "Active",
            type: "radio",
            options: [
              { value: "active", label: "Active" },
              { value: "inactive", label: "Inactive" },
            ],
            color: "text-[#2c0eee] focus:ring-[#4529f7]",
          },
        };

        return fieldNames.map((name) => fieldDefs[name]).filter(Boolean);
      }
    })();
    return allFieldDefs;
  };

  // ─── Loading state ─────────────────────────────────────────

  if (pageLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-9 h-9 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-slate-400">Loading job data...</p>
        </div>
      </div>
    );
  }

  if ((mode === "view" || mode === "edit") && !data && !pageLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="text-center bg-white rounded-2xl border border-slate-200 px-10 py-12">
          <MdErrorOutline size={40} className="text-slate-300 mx-auto mb-3" />
          <p className="text-slate-600 font-medium">Job not found</p>
          <button
            onClick={() => navigate("/jobs")}
            className="mt-3 text-blue-600 hover:underline"
          >
            Go back
          </button>
        </div>
      </div>
    );
  }

  const heroTitle =
    mode === "add"
      ? "Create New Job"
      : formValues.title || "Untitled Job";
  const companyName = formValues.company_name || formValues.company_id || "—";
  const status = formValues.job_status || "draft";
  const isTrending = formValues.is_trending;

  // ─── Render ──────────────────────────────────────────────────

  return (
    <div className="min-h-screen pb-16">
      <style>{RICH_CONTENT_CSS}</style>

      {/* ─── Sticky action bar ─────────────────────────────────── */}
      <div className="z-30 bg-white/85 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => navigate("/jobs")}
              className="p-2 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
              aria-label="Back"
            >
              <MdArrowBack size={19} className="text-slate-600" />
            </button>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400 leading-tight">Jobs</p>
              <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
                {heroTitle}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {mode === "view" && (
              <>
                <button
                  type="button"
                  onClick={() => setIsDeleteModalOpen(true)}
                  className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                  title="Delete job"
                >
                  <MdDelete size={19} />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    navigate(`/jobs/edit/${id}`, { state: { item: data } })
                  }
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors"
                >
                  <MdWork size={16} />
                  Edit Job
                </button>
              </>
            )}
            {(mode === "edit" || mode === "add") && (
              <>
                <button
                  type="button"
                  onClick={() => navigate("/jobs")}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors"
                >
                  <MdCancel size={16} />
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
                >
                  {loading ? (
                    <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <MdSave size={16} />
                  )}
                  {loading ? "Saving..." : mode === "edit" ? "Update Job" : "Create Job"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {/* ─── Hero ───────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
        >
          <div className="relative h-44 sm:h-52 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-800">
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/95 via-slate-900/50 to-slate-900/10" />
          </div>

          <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              {/* Icon/Logo placeholder */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center shadow-xl flex-shrink-0 border border-white/20">
                <MdWork size={32} className="text-white" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
                    {heroTitle}
                  </h1>
                  {isTrending && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-orange-400/20 text-orange-300 ring-1 ring-orange-400/30">
                      <MdWhatshot size={12} />
                      Trending
                    </span>
                  )}
                </div>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <StatusPill status={status} />
                  <span className="text-xs text-white/70">• {companyName}</span>
                  {formValues.posting_type && (
                    <span className="text-xs text-white/70 capitalize">
                      {formValues.posting_type}
                    </span>
                  )}
                </div>
              </div>

              {/* Completion ring placeholder */}
              <div className="hidden sm:block">
                <div className="w-14 h-14 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20 text-white text-xs font-medium">
                  Job
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ─── Tabs ───────────────────────────────────────────────── */}
        <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex overflow-x-auto border-b border-slate-200 px-2">
            {Tabs.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
                    active ? "text-blue-600" : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}
                  {active && (
                    <motion.span
                      layoutId="jobs-tab-underline"
                      className="absolute left-2 right-2 -bottom-px h-0.5 bg-blue-600 rounded-full"
                      transition={{ type: "spring", stiffness: 500, damping: 35 }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {getTabFields(activeTab).map((fieldDef) => {
                      // For activity tab, we only show in view mode
                      if (activeTab === "activity" && mode !== "view") return null;
                      return (
                        <div
                          key={fieldDef.name}
                          className={
                            fieldDef.type === "textarea" ||
                            fieldDef.type === "richtext" ||
                            fieldDef.type === "checkbox" ||
                            fieldDef.type === "radio" ||
                            fieldDef.name === "job_description"
                              ? "md:col-span-2"
                              : ""
                          }
                        >
                          {renderField(fieldDef)}
                        </div>
                      );
                    })}
                  </div>
                  {mode !== "view" && (
                    <div className="flex gap-3 mt-6 pt-4 border-t border-slate-200">
                      <button
                        type="button"
                        onClick={() => navigate("/jobs")}
                        className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 py-2.5 px-4 rounded-lg transition-colors font-medium"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={loading}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-4 rounded-lg transition-colors font-medium disabled:opacity-50 shadow-sm shadow-blue-600/20"
                      >
                        {loading ? (
                          <span className="flex items-center justify-center gap-2">
                            <span className="w-4 h-4 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                            Saving...
                          </span>
                        ) : mode === "edit" ? (
                          "Update Job"
                        ) : (
                          "Create Job"
                        )}
                      </button>
                    </div>
                  )}
                </form>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* ─── Delete confirmation modal ──────────────────────────── */}
      <AnimatePresence>
        {isDeleteModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 px-4"
            onClick={() => !deleteLoading && setIsDeleteModalOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 8 }}
              transition={{ duration: 0.18 }}
              className="w-full max-w-sm rounded-2xl bg-white shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-full bg-red-50">
                    <MdWarning size={18} className="text-red-500" />
                  </div>
                  <h3 className="text-base font-semibold text-slate-800">Delete Job?</h3>
                </div>
                <button
                  onClick={() => setIsDeleteModalOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 transition-colors"
                  disabled={deleteLoading}
                >
                  <MdClose size={18} />
                </button>
              </div>
              <div className="px-5 py-4">
                <p className="text-sm text-slate-600">
                  This will permanently remove <span className="font-medium text-slate-800">{heroTitle}</span> and its data. This action cannot be undone.
                </p>
              </div>
              <div className="flex justify-end gap-2.5 px-5 py-4 border-t border-slate-100">
                <button
                  onClick={() => setIsDeleteModalOpen(false)}
                  disabled={deleteLoading}
                  className="px-3.5 py-2 rounded-lg text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
                >
                  Keep job
                </button>
                <button
                  onClick={handleDelete}
                  disabled={deleteLoading}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-60"
                >
                  {deleteLoading && (
                    <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                  )}
                  {deleteLoading ? "Deleting..." : "Delete job"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default JobsForm;