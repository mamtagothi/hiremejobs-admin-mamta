// // pages/SubscriptionPlans.jsx
// import React, { useState, useEffect, useMemo } from "react";
// import { useNavigate } from "react-router-dom";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdVisibility,
//   MdChevronLeft,
//   MdChevronRight,
//   MdRefresh,
// } from "react-icons/md";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import { subscriptionPlanService } from "../../services/subscriptionPlan.service";
// import { showSuccess, showError } from "../../utils/toast";
// import { formatDate } from "../../utils/helpers";
// import { fetchUsers } from "../../utils/getUserName";

// // Base URL for images
// const API_BASE_URL = "https://apidata.hiremejobs.in";

// // Robust boolean coercion
// const toBool = (val, fallback = true) => {
//   if (val === undefined || val === null || val === "") return fallback;
//   if (val === true || val === 1 || val === "1" || val === "true") return true;
//   if (val === false || val === 0 || val === "0" || val === "false")
//     return false;
//   return Boolean(val);
// };

// const SubscriptionPlans = () => {
//   const navigate = useNavigate();
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [deleteId, setDeleteId] = useState(null);
//   const [deleteLoading, setDeleteLoading] = useState(false);
//   const [search, setSearch] = useState("");
//   const [page, setPage] = useState(1);
//   const [limit, setLimit] = useState(20);
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [userNameCache, setUserNameCache] = useState({});
//   const [togglingId, setTogglingId] = useState(null);
//   const [imageErrors, setImageErrors] = useState({});

//   // Get user name with caching
//   const getUserNameCached = (userId) => {
//     if (!userId) return "-";
//     return userNameCache[userId] || `User ${userId}`;
//   };

//   // Get full image URL
//   const getFullImageUrl = (value) => {
//     if (!value) return null;
//     if (typeof value !== "string") return null;

//     if (value.startsWith("http") || value.startsWith("data:image")) {
//       return value;
//     }
//     if (value.startsWith("/uploads/")) {
//       return `${API_BASE_URL}${value}`;
//     }
//     if (value.startsWith("./uploads/")) {
//       return `${API_BASE_URL}${value.substring(1)}`;
//     }
//     if (value.startsWith("/")) {
//       return `${API_BASE_URL}${value}`;
//     }
//     if (
//       !value.includes("/") &&
//       !value.includes("http") &&
//       !value.startsWith("data:")
//     ) {
//       return `${API_BASE_URL}/uploads/${value}`;
//     }
//     return value;
//   };

//   // Normalize subscription plan data
//   const normalizeSubscriptionPlan = (item) => {
//     return {
//       id: item.id || item._id,
//       plan_name: item.plan_name || "",
//       plan_code: item.plan_code || "",
//       description: item.description || "",
//       plan_type: item.plan_type || "fixed",
//       duration_days: item.duration_days || 30,
//       price: item.price || 0,
//       gst_percentage: item.gst_percentage || 18,
//       display_order: item.display_order || 1,
//       badge: item.badge || "",
//       is_popular: toBool(item.is_popular, false),
//       is_display_in_front: toBool(item.is_display_in_front, true),
//       is_free_trial: toBool(item.is_free_trial, false),
//       trial_days: item.trial_days || 7,
//       button_text: item.button_text || "Get Started",
//       button_color: item.button_color || "#FFFFFF",
//       background_color: item.background_color || "#2463EB",
//       icon: item.icon || null,
//       is_status: toBool(item.is_status, true),
//       updated_by: item.updated_by || "",
//       updated_at: item.updated_at || item.updatedAt || null,
//       created_at: item.created_at || item.createdAt || null,
//       created_by: item.created_by || "",
//     };
//   };

//   // Load subscription plans
//   const load = async () => {
//     setLoading(true);
//     try {
//       const users = await fetchUsers();
//       const userMap = {};
//       Object.keys(users).forEach((id) => {
//         userMap[id] = users[id].name;
//       });
//       setUserNameCache(userMap);

//       const r = await subscriptionPlanService.getAll({ limit: 1000 });
//       const rawData = r.data?.data || r.data?.results || r.data || [];
//       const plans = Array.isArray(rawData)
//         ? rawData.map(normalizeSubscriptionPlan)
//         : [];

//       const sortedPlans = plans.sort((a, b) => {
//         return new Date(b.created_at) - new Date(a.created_at);
//       });

//       setData(sortedPlans);
//     } catch (error) {
//       console.error("Load error:", error);
//       showError(error.message || "Failed to load subscription plans");
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     load();
//   }, []);

//   useEffect(() => {
//     setPage(1);
//   }, [search, statusFilter]);

//   const filteredData = useMemo(() => {
//     let result = data;
//     if (statusFilter !== "all") {
//       const isActive = statusFilter === "active";
//       result = result.filter((item) => item.is_status === isActive);
//     }
//     const query = search.toLowerCase().trim();
//     if (query) {
//       result = result.filter(
//         (item) =>
//           String(item.plan_name ?? "")
//             .toLowerCase()
//             .includes(query) ||
//           String(item.plan_code ?? "")
//             .toLowerCase()
//             .includes(query) ||
//           String(item.description ?? "")
//             .toLowerCase()
//             .includes(query),
//       );
//     }
//     return result;
//   }, [data, search, statusFilter]);

//   const paginatedData = filteredData.slice((page - 1) * limit, page * limit);

//   const activeCount = data.filter((r) => r.is_status === true).length;
//   const inactiveCount = data.length - activeCount;

//   const getCreatedByName = (row) => {
//     if (!row) return "-";
//     if (row.created_by) {
//       return getUserNameCached(row.created_by);
//     }
//     return "-";
//   };

//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     if (row.updated_by) {
//       return getUserNameCached(row.updated_by);
//     }
//     return "-";
//   };

//   const handleImageError = (id) => {
//     setImageErrors((prev) => ({ ...prev, [id]: true }));
//   };

//   const renderIconPreview = (value, row) => {
//     const rowId = row.id || row._id;
//     const planName = row.plan_name || "Plan";

//     if (!value) {
//       const firstLetter = planName.charAt(0).toUpperCase();
//       const colors = [
//         "#2563EB",
//         "#7C3AED",
//         "#DC2626",
//         "#059669",
//         "#D97706",
//         "#6B7280",
//       ];
//       const colorIndex = (rowId || 0) % colors.length;

//       return (
//         <div
//           className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm"
//           style={{ backgroundColor: colors[colorIndex] }}
//         >
//           {firstLetter}
//         </div>
//       );
//     }

//     if (imageErrors[rowId]) {
//       const firstLetter = planName.charAt(0).toUpperCase();
//       return (
//         <div className="w-10 h-10 rounded-lg bg-gray-200 flex items-center justify-center text-slate-500 font-bold text-sm">
//           {firstLetter}
//         </div>
//       );
//     }

//     const fullUrl = getFullImageUrl(value);

//     if (!fullUrl) {
//       const firstLetter = planName.charAt(0).toUpperCase();
//       return (
//         <div className="w-10 h-10 rounded-lg bg-gray-200 flex items-center justify-center text-slate-500 font-bold text-sm">
//           {firstLetter}
//         </div>
//       );
//     }

//     return (
//       <div className="flex items-center">
//         <div className="relative group cursor-pointer">
//           <img
//             src={fullUrl}
//             alt={planName}
//             className="w-10 h-10 object-cover rounded-lg border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
//             onError={() => handleImageError(rowId)}
//             loading="lazy"
//           />
//         </div>
//       </div>
//     );
//   };

//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       await subscriptionPlanService.delete(deleteId);
//       showSuccess("Subscription plan deleted successfully");
//       load();
//     } catch (error) {
//       console.error("Delete error:", error);
//       const message = error?.response?.data?.message || error?.message || "";
//       if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
//         showError(
//           "Cannot delete this plan because it is being used in other records.",
//         );
//       } else {
//         showError(message || "Failed to delete plan");
//       }
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   // â”€â”€â”€ FIX: Status Toggle Handler â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   // â”€â”€â”€ FIX: Status Toggle Handler â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const handleStatusToggle = async (row) => {
//     if (togglingId === row.id) return;

//     const currentStatus = row.is_status === true;
//     const newStatus = !currentStatus;

//     // Set loading state
//     setTogglingId(row.id);

//     // Optimistic update
//     setData((prev) =>
//       prev.map((item) =>
//         item.id === row.id ? { ...item, is_status: newStatus } : item,
//       ),
//     );

//     try {
//       // â”€â”€â”€ Build update data with ALL fields â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//       const updateData = {
//         plan_name: row.plan_name || "",
//         plan_code: row.plan_code || "",
//         description: row.description || "",
//         plan_type: row.plan_type || "fixed",
//         duration_days: parseInt(row.duration_days) || 30,
//         price: parseFloat(row.price) || 0,
//         gst_percentage: parseFloat(row.gst_percentage) || 18,
//         display_order: parseInt(row.display_order) || 1,
//         badge: row.badge || "",
//         is_popular: row.is_popular || false,
//         is_display_in_front:
//           row.is_display_in_front !== undefined
//             ? row.is_display_in_front
//             : true,
//         is_free_trial: row.is_free_trial || false,
//         trial_days: row.is_free_trial ? parseInt(row.trial_days) || 7 : 0,
//         button_text: row.button_text || "Get Started",
//         button_color: row.button_color || "#FFFFFF",
//         background_color: row.background_color || "#2463EB",
//         // â”€â”€â”€ FIX: service reads data.status, not data.is_status â”€â”€â”€â”€â”€â”€
//         status: newStatus,
//         icon: row.icon || null,
//       };

//       console.log("ðŸ“¤ Status toggle update data:", updateData);

//       // â”€â”€â”€ Call API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//       const response = await subscriptionPlanService.update(row.id, updateData);
//       console.log("âœ… Status toggle response:", response);

//       // â”€â”€â”€ Verify the update from response â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//       // If response contains the updated data, use it to confirm
//       if (response?.data?.is_status !== undefined) {
//         const confirmedStatus = response.data.is_status === true;
//         if (confirmedStatus !== newStatus) {
//           setData((prev) =>
//             prev.map((item) =>
//               item.id === row.id
//                 ? { ...item, is_status: confirmedStatus }
//                 : item,
//             ),
//           );
//         }
//       }

//       showSuccess(
//         `Status ${newStatus ? "activated" : "deactivated"} successfully`,
//       );
//     } catch (error) {
//       console.error("âŒ Status toggle error:", error);

//       // Revert optimistic update
//       setData((prev) =>
//         prev.map((item) =>
//           item.id === row.id ? { ...item, is_status: currentStatus } : item,
//         ),
//       );

//       showError(
//         error.response?.data?.message ||
//           error.message ||
//           "Failed to update status",
//       );
//     } finally {
//       setTogglingId(null);
//     }
//   };

//   const handleViewFeatures = (plan) => {
//     navigate(`/subscription-plans/features/${plan.id}`, {
//       state: { item: plan },
//     });
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * limit + i + 1,
//     },
//     {
//       header: "Icon",
//       key: "icon",
//       render: (value, row) => renderIconPreview(value, row),
//     },
//     {
//       header: "Plan Name",
//       key: "plan_name",
//       render: (v, row) => (
//         <div>
//           <span className="font-medium text-slate-800">{v}</span>
//           {row.badge && (
//             <span className="ml-2 px-1.5 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full font-medium">
//               {row.badge}
//             </span>
//           )}
//         </div>
//       ),
//     },
//     {
//       header: "Code",
//       key: "plan_code",
//       render: (v) => (
//         <span className="text-slate-600 text-sm font-mono">{v}</span>
//       ),
//     },
//     {
//       header: "Price",
//       key: "price",
//       render: (v) => (
//         <span className="font-semibold text-slate-900">
//           â‚¹{parseFloat(v || 0).toFixed(2)}
//         </span>
//       ),
//     },
//     {
//       header: "Duration",
//       key: "duration_days",
//       render: (v) => (
//         <span className="text-slate-600 text-sm">{v || 30} days</span>
//       ),
//     },
//     {
//       header: "Status",
//       key: "is_status",
//       render: (value, row) => {
//         const isActive = value === true;
//         const isLoading = togglingId === row.id;
//         return (
//           <button
//             onClick={() => handleStatusToggle(row)}
//             disabled={isLoading}
//             className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//               isLoading ? "opacity-50 cursor-wait" : ""
//             } ${isActive ? "bg-[#2c0eee]" : "bg-gray-300"}`}
//           >
//             <span
//               className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//                 isActive ? "translate-x-6" : "translate-x-1"
//               }`}
//             />
//           </button>
//         );
//       },
//     },
//     {
//       header: "Updated By",
//       key: "updated_by",
//       render: (_, row) => (
//         <span className="text-slate-500 text-sm font-medium">
//           {getUpdatedByName(row)}
//         </span>
//       ),
//     },
//     {
//       header: "Updated At",
//       key: "updated_at",
//       render: (v) => (
//         <span className="text-slate-500 text-sm">{formatDate(v)}</span>
//       ),
//     },
//     {
//       header: "Features",
//       key: "id",
//       render: (id, row) => (
//         <button
//           onClick={() => handleViewFeatures(row)}
//           className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#2c0eee] bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
//           title="View subscription features"
//         >
//           <MdVisibility size={15} />
//           View Features
//         </button>
//       ),
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => (
//         <div className="flex gap-1">
//           <button
//             onClick={() =>
//               navigate(`/subscription-plans/view/${row.id}`, {
//                 state: { item: row },
//               })
//             }
//             className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
//             title="View"
//           >
//             <MdVisibility size={16} />
//           </button>
//           <button
//             onClick={() =>
//               navigate(`/subscription-plans/edit/${row.id}`, {
//                 state: { item: row },
//               })
//             }
//             className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
//             title="Edit"
//           >
//             <MdEdit size={16} />
//           </button>
//           <button
//             onClick={() => setDeleteId(id)}
//             className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
//             title="Delete"
//           >
//             <MdDelete size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   const tabs = [
//     { key: "all", label: "All", count: data.length },
//     { key: "active", label: "Active", count: activeCount },
//     { key: "inactive", label: "Inactive", count: inactiveCount },
//   ];

//   const totalPages = Math.ceil(filteredData.length / limit);

//   return (
//     <div className="space-y-4">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">
//             Subscription Plans
//           </h1>
//           <p className="text-sm text-slate-500 mt-1">
//             Manage subscription plans for your application
//           </p>
//         </div>
//         <div className="flex items-center gap-3">
//           <Button
//             variant="secondary"
//             icon={MdRefresh}
//             onClick={load}
//             loading={loading}
//             disabled={loading}
//           >
//             Refresh
//           </Button>
//           <Button
//             icon={MdAdd}
//             onClick={() => navigate("/subscription-plans/add")}
//           >
//             Add Plan
//           </Button>
//         </div>
//       </div>

//       {/* Table Card */}
//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-slate-100">
//           <div className="relative w-full sm:w-72">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search plans..."
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
//             />
//           </div>

//           <div className="flex items-center gap-5 text-sm">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${statusFilter === tab.key ? "text-[#2c0eee]" : "text-slate-500 hover:text-slate-700"}`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                     statusFilter === tab.key
//                       ? "bg-slate-800 text-white shadow-sm"
//                       : "bg-slate-100 text-slate-500"
//                   }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={paginatedData}
//           loading={loading}
//           emptyMessage="No subscription plans found"
//         />

//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
//           <p className="text-xs text-slate-400">
//             Showing {filteredData.length === 0 ? 0 : (page - 1) * limit + 1}
//             {"â€“"}
//             {Math.min(page * limit, filteredData.length)} of{" "}
//             {filteredData.length} plans
//           </p>
//           <div className="flex items-center gap-3">
//             <div className="flex items-center gap-2">
//               <span className="text-xs text-slate-400">Rows:</span>
//               <select
//                 value={limit}
//                 onChange={(e) => {
//                   setLimit(Number(e.target.value));
//                   setPage(1);
//                 }}
//                 className="text-sm border border-slate-200 rounded-lg px-2 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee]"
//               >
//                 {[5, 10, 15, 20, 25, 50, 100].map((option) => (
//                   <option key={option} value={option}>
//                     {option}
//                   </option>
//                 ))}
//               </select>
//             </div>
//             <div className="flex items-center gap-1">
//               <button
//                 onClick={() => setPage(page - 1)}
//                 disabled={page === 1}
//                 className={`p-1 rounded-lg transition-colors ${
//                   page === 1
//                     ? "text-gray-300 cursor-not-allowed"
//                     : "hover:bg-slate-100 text-slate-500"
//                 }`}
//               >
//                 <MdChevronLeft size={18} />
//               </button>
//               <span className="text-sm text-slate-600 px-2">
//                 Page {page} of {totalPages || 1}
//               </span>
//               <button
//                 onClick={() => setPage(page + 1)}
//                 disabled={page === totalPages || totalPages === 0}
//                 className={`p-1 rounded-lg transition-colors ${
//                   page === totalPages || totalPages === 0
//                     ? "text-gray-300 cursor-not-allowed"
//                     : "hover:bg-slate-100 text-slate-500"
//                 }`}
//               >
//                 <MdChevronRight size={18} />
//               </button>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Confirm Dialog */}
//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Subscription Plan"
//         message="Delete this subscription plan? This action cannot be undone."
//       />
//     </div>
//   );
// };

// export default SubscriptionPlans;


import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdRefresh,
  MdClose,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { subscriptionPlanService } from "../../services/subscriptionPlan.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

// Base URL for images
const API_BASE_URL = "https://apidata.hiremejobs.in";

// Robust boolean coercion
const toBool = (val, fallback = true) => {
  if (val === undefined || val === null || val === "") return fallback;
  if (val === true || val === 1 || val === "1" || val === "true") return true;
  if (val === false || val === 0 || val === "0" || val === "false")
    return false;
  return Boolean(val);
};

// â”€â”€â”€ Response extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const extractList = (res) => {
  if (!res) return [];
  if (Array.isArray(res?.data?.data)) return res.data.data;
  if (Array.isArray(res?.data)) return res.data;
  if (Array.isArray(res)) return res;
  if (Array.isArray(res?.results)) return res.results;
  return [];
};

const extractPagination = (res) => {
  if (!res) return null;
  if (res?.pagination) return res.pagination;
  if (res?.data?.pagination) return res.data.pagination;
  return null;
};

const extractTotal = (res) => {
  if (!res) return 0;
  if (typeof res?.pagination?.total === "number") return res.pagination.total;
  if (typeof res?.data?.pagination?.total === "number")
    return res.data.pagination.total;
  if (typeof res?.total === "number") return res.total;
  if (Array.isArray(res?.data)) return res.data.length;
  if (Array.isArray(res)) return res.length;
  return 0;
};

const SubscriptionPlans = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  // pageSize mirrors API's pagination.limit â€” display only, never sent.
  const [pageSize, setPageSize] = useState(0);
  const [total, setTotal] = useState(0);
  const [paginationLinks, setPaginationLinks] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [userNameCache, setUserNameCache] = useState({});
  const [togglingId, setTogglingId] = useState(null);
  const [imageErrors, setImageErrors] = useState({});

  // Tab counts fetched from API
  const [statusCounts, setStatusCounts] = useState({
    all: 0,
    active: 0,
    inactive: 0,
  });
  const [countsLoading, setCountsLoading] = useState(false);
  const requestIdRef = useRef(0);

  // Debounce search + reset page
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    setPage(1);
  }, [statusFilter]);

  // Load users once
  useEffect(() => {
    const loadUsers = async () => {
      try {
        const users = await fetchUsers();
        const userMap = {};
        Object.keys(users || {}).forEach((id) => {
          userMap[id] = users[id].name;
        });
        setUserNameCache(userMap);
      } catch (err) {
        console.warn("Could not load users:", err);
      }
    };
    loadUsers();
  }, []);

  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  const getFullImageUrl = (value) => {
    if (!value) return null;
    if (typeof value !== "string") return null;

    if (value.startsWith("http") || value.startsWith("data:image")) return value;
    if (value.startsWith("/uploads/")) return `${API_BASE_URL}${value}`;
    if (value.startsWith("./uploads/")) return `${API_BASE_URL}${value.substring(1)}`;
    if (value.startsWith("/")) return `${API_BASE_URL}${value}`;
    if (!value.includes("/") && !value.includes("http") && !value.startsWith("data:")) {
      return `${API_BASE_URL}/uploads/${value}`;
    }
    return value;
  };

  const normalizeSubscriptionPlan = (item) => {
    return {
      id: item.id || item._id,
      plan_name: item.plan_name || "",
      plan_code: item.plan_code || "",
      description: item.description || "",
      plan_type: item.plan_type || "fixed",
      duration_days: item.duration_days || 30,
      price: item.price || 0,
      gst_percentage: item.gst_percentage || 18,
      display_order: item.display_order || 1,
      badge: item.badge || "",
      is_popular: toBool(item.is_popular, false),
      is_display_in_front: toBool(item.is_display_in_front, true),
      is_free_trial: toBool(item.is_free_trial, false),
      trial_days: item.trial_days || 7,
      button_text: item.button_text || "Get Started",
      button_color: item.button_color || "#FFFFFF",
      background_color: item.background_color || "#2463EB",
      icon: item.icon || null,
      is_status: toBool(item.is_status, true),
      updated_by: item.updated_by || "",
      updated_at: item.updated_at || item.updatedAt || null,
      created_at: item.created_at || item.createdAt || null,
      created_by: item.created_by || "",
    };
  };

  // â”€â”€â”€ Load one page from API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const load = useCallback(async () => {
    const requestId = ++requestIdRef.current;
    setLoading(true);
    try {
      const params = { page };
      if (debouncedSearch) {
        params.search = debouncedSearch;
      }
      if (statusFilter === "active") params.is_status = true;
      else if (statusFilter === "inactive") params.is_status = false;

      const r = await subscriptionPlanService.getAll(params);
      if (requestIdRef.current !== requestId) return;

      const rawData = extractList(r);
      const pagination = extractPagination(r);

      const plans = rawData.map(normalizeSubscriptionPlan);
      setData(plans);
      setPaginationLinks(pagination?.links || null);

      const serverTotal = Number(pagination?.total || 0);
      setTotal(serverTotal > 0 ? serverTotal : plans.length);

      // Adopt API's page size for display
      if (pagination?.limit && Number(pagination.limit) > 0) {
        setPageSize(Number(pagination.limit));
      }
      // Follow server clamp
      if (pagination?.page && Number(pagination.page) !== page) {
        setPage(Number(pagination.page));
      }
    } catch (error) {
      if (requestIdRef.current !== requestId) return;
      console.error("Load error:", error);
      showError(error.message || "Failed to load subscription plans");
      setData([]);
      setTotal(0);
      setPaginationLinks(null);
    } finally {
      if (requestIdRef.current === requestId) setLoading(false);
    }
  }, [page, debouncedSearch, statusFilter]);

  useEffect(() => {
    load();
  }, [load]);

  // Client-side filtering fallback for instant responsiveness & multi-field matching
  const displayData = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return data;

    return data.filter((item) =>
      [
        item.plan_name,
        item.plan_code,
        item.description,
        item.badge,
        item.plan_type,
        String(item.price || ""),
        String(item.duration_days || ""),
        item.button_text,
      ].some((val) =>
        String(val ?? "")
          .toLowerCase()
          .includes(q)
      )
    );
  }, [data, search]);

  // â”€â”€â”€ Fetch counts via limit=1 requests â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const fetchCount = useCallback(async (isStatus) => {
    const params = { page: 1, limit: 1 };
    if (isStatus === true) params.is_status = true;
    else if (isStatus === false) params.is_status = false;
    const res = await subscriptionPlanService.getAll(params);
    return extractTotal(res);
  }, []);

  const loadCounts = useCallback(async () => {
    setCountsLoading(true);
    try {
      const [all, active] = await Promise.all([
        fetchCount(null),
        fetchCount(true),
      ]);
      setStatusCounts({ all, active, inactive: Math.max(0, all - active) });
    } catch (err) {
      console.error("Failed to load counts:", err);
    } finally {
      setCountsLoading(false);
    }
  }, [fetchCount]);

  useEffect(() => {
    loadCounts();
  }, [loadCounts]);

  const refreshAll = () => {
    load();
    loadCounts();
  };

  const getCreatedByName = (row) => {
    if (!row) return "-";
    if (row.created_by) return getUserNameCached(row.created_by);
    return "-";
  };

  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by) return getUserNameCached(row.updated_by);
    return "-";
  };

  const handleImageError = (id) => {
    setImageErrors((prev) => ({ ...prev, [id]: true }));
  };

  const renderIconPreview = (value, row) => {
    const rowId = row.id || row._id;
    const planName = row.plan_name || "Plan";

    if (!value) {
      const firstLetter = planName.charAt(0).toUpperCase();
      const colors = ["#2563EB", "#7C3AED", "#DC2626", "#059669", "#D97706", "#6B7280"];
      const colorIndex = (rowId || 0) % colors.length;
      return (
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm"
          style={{ backgroundColor: colors[colorIndex] }}
        >
          {firstLetter}
        </div>
      );
    }

    if (imageErrors[rowId]) {
      const firstLetter = planName.charAt(0).toUpperCase();
      return (
        <div className="w-10 h-10 rounded-lg bg-gray-200 flex items-center justify-center text-slate-500 font-bold text-sm">
          {firstLetter}
        </div>
      );
    }

    const fullUrl = getFullImageUrl(value);
    if (!fullUrl) {
      const firstLetter = planName.charAt(0).toUpperCase();
      return (
        <div className="w-10 h-10 rounded-lg bg-gray-200 flex items-center justify-center text-slate-500 font-bold text-sm">
          {firstLetter}
        </div>
      );
    }

    return (
      <div className="flex items-center">
        <div className="relative group cursor-pointer">
          <img
            src={fullUrl}
            alt={planName}
            className="w-10 h-10 object-cover rounded-lg border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
            onError={() => handleImageError(rowId)}
            loading="lazy"
          />
        </div>
      </div>
    );
  };

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await subscriptionPlanService.delete(deleteId);
      showSuccess("Subscription plan deleted successfully");
      load();
      loadCounts();
    } catch (error) {
      console.error("Delete error:", error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
        showError("Cannot delete this plan because it is being used in other records.");
      } else {
        showError(message || "Failed to delete plan");
      }
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  const handleStatusToggle = async (row) => {
    if (togglingId === row.id) return;

    const currentStatus = row.is_status === true;
    const newStatus = !currentStatus;

    setTogglingId(row.id);
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id ? { ...item, is_status: newStatus } : item,
      ),
    );

    try {
      const updateData = {
        plan_name: row.plan_name || "",
        plan_code: row.plan_code || "",
        description: row.description || "",
        plan_type: row.plan_type || "fixed",
        duration_days: parseInt(row.duration_days) || 30,
        price: parseFloat(row.price) || 0,
        gst_percentage: parseFloat(row.gst_percentage) || 18,
        display_order: parseInt(row.display_order) || 1,
        badge: row.badge || "",
        is_popular: row.is_popular || false,
        is_display_in_front:
          row.is_display_in_front !== undefined ? row.is_display_in_front : true,
        is_free_trial: row.is_free_trial || false,
        trial_days: row.is_free_trial ? parseInt(row.trial_days) || 7 : 0,
        button_text: row.button_text || "Get Started",
        button_color: row.button_color || "#FFFFFF",
        background_color: row.background_color || "#2463EB",
        status: newStatus,
        icon: row.icon || null,
      };

      const response = await subscriptionPlanService.update(row.id, updateData);

      if (response?.data?.is_status !== undefined) {
        const confirmedStatus = response.data.is_status === true;
        if (confirmedStatus !== newStatus) {
          setData((prev) =>
            prev.map((item) =>
              item.id === row.id
                ? { ...item, is_status: confirmedStatus }
                : item,
            ),
          );
        }
      }

      showSuccess(`Status ${newStatus ? "activated" : "deactivated"} successfully`);
      loadCounts();
    } catch (error) {
      console.error("âŒ Status toggle error:", error);
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id ? { ...item, is_status: currentStatus } : item,
        ),
      );
      showError(
        error.response?.data?.message || error.message || "Failed to update status",
      );
    } finally {
      setTogglingId(null);
    }
  };

  const handleViewFeatures = (plan) => {
    navigate(`/subscription-plans/features/${plan.id}`, {
      state: { item: plan },
    });
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * (pageSize || 20) + i + 1,
    },
    {
      header: "Icon",
      key: "icon",
      render: (value, row) => renderIconPreview(value, row),
    },
    {
      header: "Plan Name",
      key: "plan_name",
      render: (v, row) => (
        <div>
          <span className="font-medium text-slate-800">{v}</span>
          {row.badge && (
            <span className="ml-2 px-1.5 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] rounded-full font-medium">
              {row.badge}
            </span>
          )}
        </div>
      ),
    },
    {
      header: "Code",
      key: "plan_code",
      render: (v) => <span className="text-slate-600 text-sm font-mono">{v}</span>,
    },
    {
      header: "Price",
      key: "price",
      render: (v) => (
        <span className="font-semibold text-slate-900">
          â‚¹{parseFloat(v || 0).toFixed(2)}
        </span>
      ),
    },
    {
      header: "Duration",
      key: "duration_days",
      render: (v) => <span className="text-slate-600 text-sm">{v || 30} days</span>,
    },
    {
      header: "Status",
      key: "is_status",
      render: (value, row) => {
        const isActive = value === true;
        const isLoading = togglingId === row.id;
        return (
          <button
            onClick={() => handleStatusToggle(row)}
            disabled={isLoading}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              isLoading ? "opacity-50 cursor-wait" : ""
            } ${isActive ? "bg-[#2c0eee]" : "bg-gray-300"}`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                isActive ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => (
        <span className="text-slate-500 text-sm font-medium">
          {getUpdatedByName(row)}
        </span>
      ),
    },
    {
      header: "Updated At",
      key: "updated_at",
      render: (v) => (
        <span className="text-slate-500 text-sm">{formatDate(v)}</span>
      ),
    },
    {
      header: "Features",
      key: "id",
      render: (id, row) => (
        <button
          onClick={() => handleViewFeatures(row)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#2c0eee] bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
          title="View subscription features"
        >
          <MdVisibility size={15} />
          View Features
        </button>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() =>
              navigate(`/subscription-plans/view/${row.id}`, {
                state: { item: row },
              })
            }
            className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() =>
              navigate(`/subscription-plans/edit/${row.id}`, {
                state: { item: row },
              })
            }
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: statusCounts.all },
    { key: "active", label: "Active", count: statusCounts.active },
    { key: "inactive", label: "Inactive", count: statusCounts.inactive },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Subscription Plans</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage subscription plans for your application
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={refreshAll}
            loading={loading || countsLoading}
            disabled={loading || countsLoading}
          >
            Refresh
          </Button>
          <Button icon={MdAdd} onClick={() => navigate("/subscription-plans/add")}>
            Add Plan
          </Button>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search plans..."
              className="w-full pl-10 pr-8 py-2.5 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#2c0eee]/20 focus:border-[#2c0eee] transition-colors"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                title="Clear search"
              >
                <MdClose size={16} />
              </button>
            )}
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? "text-slate-800"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-2 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={displayData}
          loading={loading}
          emptyMessage="No subscription plans found"
        />

        {/* Footer â€” backend pagination only */}
        <div className="px-5 py-3 border-t border-slate-100">
          <Pagination
            page={page}
            total={total}
            limit={pageSize || 20}
            links={paginationLinks}
            itemsCount={displayData.length}
            onChange={setPage}
          />
        </div>
      </div>

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Subscription Plan"
        message="Delete this subscription plan? This action cannot be undone."
      />
    </div>
  );
};

export default SubscriptionPlans;

