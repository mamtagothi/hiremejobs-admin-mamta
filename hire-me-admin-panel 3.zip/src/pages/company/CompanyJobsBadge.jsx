import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import jobService from "../../services/job.service";
import { MdWork } from "react-icons/md";

const CompanyJobsBadge = ({ companyId }) => {
  const [jobCount, setJobCount] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    const fetchCount = async () => {
      try {
        const res = await jobService.getAll({ company_id: companyId, limit: 1 });
        if (!mounted) return;
        
        let total = 0;
        const body = res?.data ?? res;
        if (body?.pagination?.total !== undefined) {
          total = body.pagination.total;
        } else if (body?.data?.pagination?.total !== undefined) {
          total = body.data.pagination.total;
        } else if (body?.total !== undefined) {
          total = body.total;
        } else if (body?.data?.total !== undefined) {
          total = body.data.total;
        } else if (Array.isArray(body?.data)) {
          total = body.data.length;
        } else if (Array.isArray(body)) {
          total = body.length;
        }
        
        setJobCount(total);
      } catch (err) {
        console.error("Failed to fetch job count for company", companyId, err);
        if (mounted) setJobCount(0);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    
    if (companyId) {
        fetchCount();
    } else {
        setLoading(false);
        setJobCount(0);
    }
    
    return () => {
      mounted = false;
    };
  }, [companyId]);

  if (loading) {
    return (
      <div className="animate-pulse h-6 w-16 bg-gray-200 rounded-md"></div>
    );
  }

  return (
    <Link
      to={`/companies/${companyId}/jobs`}
      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 transition-colors"
      title="View Jobs"
      onClick={(e) => e.stopPropagation()}
    >
      <MdWork size={12} />
      {jobCount} {jobCount === 1 ? "Job" : "Jobs"}
    </Link>
  );
};

export default CompanyJobsBadge;
