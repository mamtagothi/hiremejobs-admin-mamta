﻿import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from "recharts";
import {
  MdArrowBack,
  MdEdit,
  MdCheckCircle,
  MdVerified,
  MdLanguage,
  MdCategory,
  MdGroups,
  MdReceiptLong,
  MdDescription,
  MdImage,
  MdHistory,
  MdApartment,
  MdPerson,
  MdCreditCard,
  MdPermIdentity,
  MdOpenInNew,
  MdWhatshot,
  MdErrorOutline,
  MdPauseCircle,
  MdBlock,
  MdPayments,
  MdWork,
  MdSearch,
  MdLocationOn,
  MdOutlineFilterList,
  MdInbox,
  MdAccessTime,
  MdAttachMoney,
  MdSchool,
  MdStar,
  MdBusinessCenter,
  MdVisibility,
  MdChevronLeft,
  MdChevronRight,
  MdLock,
  MdCalendarToday,
  MdEventBusy,
  MdClose,
} from "react-icons/md";
import companyService from "../../services/company.service";
import { showError, showSuccess } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

const API_BASE =
  import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

const JOBS_PER_PAGE = 10;

import { parseApiDate, safeFormatDate, formatSalary, GENERIC_STATUS_STYLES, GenericStatusPill, StatusPill, IndexBadge, DetailRow, QuickStat, MiniStat, RichTextViewer, SectionLoading, SectionEmpty, SectionError, getImageUrl, CompletionRing, FieldLabel, ReadOnlyValue, isImageFile, getFileName, STATUS_STYLES } from "./SharedCompanyUI";
import JobsSection from "./JobsSection";
import Table from "../../components/common/Table";
import Pagination from "../../components/common/Pagination";

// ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Tabs ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
const TOP_TABS = [
  { id: "profile", label: "Profile", icon: MdApartment },
  { id: "subscription", label: "Subscription History", icon: MdPayments },
  { id: "jobs", label: "Jobs", icon: MdWork },
  { id: "search-history", label: "Search History", icon: MdSearch },
];

const PROFILE_SUB_TABS = [
  { id: "overview", label: "Overview", icon: MdApartment },
  { id: "relations", label: "Relations", icon: MdCategory },
  { id: "documents", label: "Documents", icon: MdDescription },
  { id: "media", label: "Media", icon: MdImage },
  { id: "activity", label: "Activity", icon: MdHistory },
];

// ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Subscription History Section ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
const SubscriptionHistorySection = ({ state, onRetry }) => {
  const { loading, error, items } = state;
  const [expandedId, setExpandedId] = useState(null);

  if (loading)
    return <SectionLoading label="Loading subscription history..." />;
  if (error) return <SectionError message={error} onRetry={onRetry} />;
  if (!items.length)
    return (
      <SectionEmpty
        icon={MdPayments}
        title="No subscription history"
        subtitle="This company hasn't purchased or activated any subscription plan yet."
      />
    );

  const toggleExpand = (id) =>
    setExpandedId((prev) => (prev === id ? null : id));

  return (
    <div className="space-y-4">
      {items.map((sub, idx) => {
        const planName =
          sub.SubscriptionPlan?.plan_name || sub.plan_name || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â";
        const companyName =
          sub.Company?.company_name || sub.company_name || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â";
        const status = sub.subscription_status || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â";
        const type = sub.subscription_type || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â";
        const startDate = sub.start_date;
        const expiryDate = sub.expiry_date;
        const isTrial = sub.is_trial;
        const autoRenew = sub.auto_renew;
        const cancelReason = sub.cancel_reason;
        const cancelledAt = sub.cancelled_at;
        const createdAt = sub.created_at;
        const updatedAt = sub.updated_at;
        const isStatus = sub.is_status;
        const createdBy = sub.created_by;
        const updatedBy = sub.updated_by;
        const previousPlan = sub.PreviousSubscriptionPlan?.plan_name || null;
        const nextPlan = sub.NextSubscriptionPlan?.plan_name || null;
        const isExpanded = expandedId === (sub.id || idx);

        return (
          <div
            key={sub.id || idx}
            className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm"
          >
            <button
              type="button"
              onClick={() => toggleExpand(sub.id || idx)}
              className="w-full flex items-center gap-4 px-4 py-3.5 text-left hover:bg-slate-50/60 transition-colors"
            >
              <IndexBadge index={idx + 1} />
              {/* <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                <MdPayments size={18} className="text-blue-600" />
              </div> */}
              <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-1">
                <div className="min-w-0">
                  <p className="text-[11px] text-slate-400 leading-tight">
                    Plan
                  </p>
                  <p className="text-sm font-semibold text-slate-800 truncate">
                    {planName}
                  </p>
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] text-slate-400 leading-tight">
                    Company
                  </p>
                  <p className="text-sm text-slate-700 truncate">
                    {companyName}
                  </p>
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] text-slate-400 leading-tight">
                    Type
                  </p>
                  <p className="text-sm text-slate-700">{type}</p>
                </div>
                <div className="min-w-0 flex items-center gap-2">
                  <GenericStatusPill status={status} />
                  {isTrial && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 ring-1 ring-amber-200">
                      Trial
                    </span>
                  )}
                </div>
              </div>
              <div className="hidden md:flex flex-col items-end flex-shrink-0">
                <p className="text-[11px] text-slate-400">Start</p>
                <p className="text-xs font-medium text-slate-700">
                  {startDate ? formatDate(parseApiDate(startDate)) : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                </p>
              </div>
              <div className="hidden md:flex flex-col items-end flex-shrink-0">
                <p className="text-[11px] text-slate-400">Expiry</p>
                <p className="text-xs font-medium text-slate-700">
                  {expiryDate ? formatDate(parseApiDate(expiryDate)) : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                </p>
              </div>
              <MdOpenInNew
                size={16}
                className={`text-slate-400 flex-shrink-0 transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`}
              />
            </button>

            <AnimatePresence>
              {isExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="border-t border-slate-100"
                >
                  <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    <div className="space-y-3">
                      <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                        Subscription
                      </h4>
                      <div className="space-y-2">
                        <DetailRow label="ID" value={sub.id} />
                        <DetailRow label="Type" value={type} />
                        <DetailRow
                          label="Status"
                          value={<GenericStatusPill status={status} />}
                        />
                        <DetailRow
                          label="Trial"
                          value={isTrial ? "Yes" : "No"}
                        />
                        <DetailRow
                          label="Auto Renew"
                          value={autoRenew ? "Enabled" : "Disabled"}
                        />
                        <DetailRow
                          label="Active"
                          value={isStatus ? "Yes" : "No"}
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                        Plan & Company
                      </h4>
                      <div className="space-y-2">
                        <DetailRow label="Current Plan" value={planName} />
                        <DetailRow
                          label="Previous Plan"
                          value={previousPlan || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                        />
                        <DetailRow label="Next Plan" value={nextPlan || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"} />
                        <DetailRow label="Company" value={companyName} />
                        {/* <DetailRow
                          label="Company User ID"
                          value={sub.Company?.company_user_id}
                        /> */}
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                        Dates & Audit
                      </h4>
                      <div className="space-y-2">
                        <DetailRow
                          label="Start Date"
                          value={
                            startDate
                              ? formatDate(parseApiDate(startDate))
                              : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"
                          }
                        />
                        <DetailRow
                          label="Expiry Date"
                          value={
                            expiryDate
                              ? formatDate(parseApiDate(expiryDate))
                              : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"
                          }
                        />
                        <DetailRow
                          label="Created At"
                          value={
                            createdAt
                              ? formatDate(parseApiDate(createdAt))
                              : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"
                          }
                        />
                        <DetailRow
                          label="Updated At"
                          value={
                            updatedAt
                              ? formatDate(parseApiDate(updatedAt))
                              : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"
                          }
                        />
                        <DetailRow label="Created By" value={createdBy} />
                        <DetailRow label="Updated By" value={updatedBy} />
                      </div>
                    </div>
                  </div>
                  {(cancelReason || cancelledAt) && (
                    <div className="px-5 pb-5">
                      <div className="rounded-lg bg-red-50/60 border border-red-100 p-3.5">
                        <h4 className="text-xs font-semibold text-red-600 uppercase tracking-wide mb-2">
                          Cancellation
                        </h4>
                        <div className="space-y-1.5">
                          {cancelReason && (
                            <p className="text-sm text-slate-700">
                              <span className="font-medium text-slate-500">
                                Reason:
                              </span>{" "}
                              {cancelReason}
                            </p>
                          )}
                          {cancelledAt && (
                            <p className="text-sm text-slate-700">
                              <span className="font-medium text-slate-500">
                                Cancelled At:
                              </span>{" "}
                              {formatDate(parseApiDate(cancelledAt))}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
};

// ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Jobs Section ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
// ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Search History Section (list only) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
const SearchHistorySection = ({ state, onRetry }) => {
  const { loading, error, items } = state;

  if (loading) return <SectionLoading label="Loading search history..." />;
  if (error) return <SectionError message={error} onRetry={onRetry} />;
  if (!items.length)
    return (
      <SectionEmpty
        icon={MdSearch}
        title="No search history"
        subtitle="Search keywords used for this company will appear here."
      />
    );

  return (
    <div className="space-y-2">
      {items.map((entry, idx) => {
        const keyword = entry.search_keyword || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â";
        const resultCount = entry.result_count;
        const searchedAt = entry.created_at;
        const searchType = entry.search_type;

        return (
          <div
            key={entry.id || idx}
            className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white px-4 py-3 hover:bg-slate-50/60 transition-colors"
          >
            <IndexBadge index={idx + 1} />

            {/* <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
              <MdSearch size={16} className="text-blue-600" />
            </div> */}

            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-slate-800 truncate">
                {keyword}
              </p>
              {searchType && (
                <p className="text-[11px] text-slate-400 mt-0.5 truncate capitalize">
                  {searchType}
                </p>
              )}
            </div>

            <span className="text-[11px] text-slate-400 flex-shrink-0">
              {searchedAt ? formatDate(parseApiDate(searchedAt)) : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
            </span>
          </div>
        );
      })}
    </div>
  );
};

// ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Main Component ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
const ViewCompany = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [initialData, setInitialData] = useState(null);
  const [viewData, setViewData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userNameCache, setUserNameCache] = useState({});
  const [statusUpdatingId, setStatusUpdatingId] = useState(null);

  const [activeTab, setActiveTab] = useState("profile");
  const [showTabs, setShowTabs] = useState(false);
  const [jobsAnalyticsVisible, setJobsAnalyticsVisible] = useState(false);
  const [jobsAnalyticsState, setJobsAnalyticsState] = useState({
    data: [],
    loading: false,
    error: null,
    pagination: {
      page: 1,
      limit: 10,
      total: 0,
      totalPages: 0,
    }
  });

  useEffect(() => {
    if (!jobsAnalyticsVisible || !id) return;
    
    let isMounted = true;
    const fetchJobs = async () => {
      setJobsAnalyticsState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const token = localStorage.getItem('token');
        const res = await fetch(`${API_BASE}/jobs?company_id=${id}&page=${jobsAnalyticsState.pagination.page}&limit=${jobsAnalyticsState.pagination.limit}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        const json = await res.json();
        
        if (!isMounted) return;

        if (!res.ok || !json.success) {
           throw new Error(json.message || "Failed to fetch jobs");
        }
        
        setJobsAnalyticsState(prev => ({
          ...prev,
          data: json.data || [],
          loading: false,
          error: null,
          pagination: {
             page: json.pagination?.page || prev.pagination.page,
             limit: json.pagination?.limit || prev.pagination.limit,
             total: json.pagination?.total || 0,
             totalPages: json.pagination?.totalPages || 0,
          }
        }));
      } catch (err) {
        if (!isMounted) return;
        setJobsAnalyticsState(prev => ({
          ...prev,
          loading: false,
          error: err.message
        }));
      }
    };
    fetchJobs();
    
    return () => { isMounted = false; };
  }, [jobsAnalyticsVisible, id, jobsAnalyticsState.pagination.page, jobsAnalyticsState.pagination.limit]);
  const [activeProfileTab, setActiveProfileTab] = useState("overview");

  const [subscriptionState, setSubscriptionState] = useState({
    loading: false,
    loaded: false,
    items: [],
    error: null,
  });

  const [jobsState, setJobsState] = useState({
    loading: false,
    loaded: false,
    items: [],
    error: null,
  });
  const [jobsPagination, setJobsPagination] = useState({
    page: 1,
    limit: JOBS_PER_PAGE,
    total: 0,
    totalPages: 1,
  });

  const [searchHistoryState, setSearchHistoryState] = useState({
    loading: false,
    loaded: false,
    items: [],
    error: null,
  });

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Is this company approved? (drives tab visibility) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const isApproved = viewData?.company_status === "active";

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Load users ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const loadUsers = async () => {
    try {
      const users = await fetchUsers();
      setUserNameCache(users);
    } catch (err) {
      console.error("Failed to load users:", err);
    }
  };

  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId]?.name || `User ${userId}`;
  };

  const getCreatedByName = (row) =>
    !row ? "-" : row.created_by ? getUserNameCached(row.created_by) : "-";
  const getUpdatedByName = (row) =>
    !row ? "-" : row.updated_by ? getUserNameCached(row.updated_by) : "-";

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Approve / status ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const handleCompanyStatusChange = async (id, newStatus) => {
    const prevData = viewData;
    setViewData({ ...viewData, company_status: newStatus });
    setInitialData({ ...initialData, company_status: newStatus });
    setStatusUpdatingId(id);

    try {
      await companyService.update(id, {
        company_status: newStatus,
        updated_by: viewData?.updated_by || 1,
      });
      showSuccess(
        newStatus === "active"
          ? "Company approved successfully"
          : "Company approval removed",
      );
      const response = await companyService.getById(id);
      const data = response?.data || response;
      if (data) {
        setViewData(data);
        setInitialData((prev) => ({
          ...prev,
          company_status: data.company_status || newStatus,
        }));
      }
    } catch (err) {
      setViewData(prevData);
      setInitialData((prev) => ({
        ...prev,
        company_status: prevData?.company_status || prev?.company_status,
      }));
      showError(err.message || "Failed to update status");
    } finally {
      setStatusUpdatingId(null);
    }
  };

  const handleToggleApprove = () => {
    if (!viewData?.id) return;
    const nextStatus =
      viewData.company_status === "active" ? "pending" : "active";
    handleCompanyStatusChange(viewData.id, nextStatus);
  };

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Fetch company ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  useEffect(() => {
    const fetchCompany = async () => {
      setLoading(true);
      try {
        await loadUsers();
        const response = await companyService.getById(id);
        const data = response?.data || response;

        if (data) {
          const createdAt = data.created_at
            ? parseApiDate(data.created_at)
            : null;
          const updatedAt = data.updated_at
            ? parseApiDate(data.updated_at)
            : null;

          const formData = {
            id: data.id || "",
            company_name: data.company_name || "",
            profile_type: data.profile_type || "company",
            slug: data.slug || "",
            website: Array.isArray(data.website)
              ? data.website.join(", ")
              : data.website || "",
            founded_year: data.founded_year || "",
            about_company: data.about_company || "",
            gst_number: data.gst_number || "",
            company_user_email:
              data.CompanyUser?.company_user_email ||
              data.CompanyUser?.email ||
              data.company_user_email ||
              "-",
            company_user_id:
              data.company_user_id || data.CompanyUser?.company_user_id || "-",
            industry_name:
              data.Industries?.[0]?.industry_name ||
              data.Industry?.industry_name ||
              data.industry_name ||
              "-",
            industry_id:
              data.industry_id ||
              data.Industries?.[0]?.industry_id ||
              data.Industry?.industry_id ||
              "-",
            company_size_name:
              data.CompanySize?.company_size_name ||
              data.company_size_name ||
              "-",
            logo: data.logo || null,
            banner_image: data.banner_image || null,
            company_status: data.company_status || "inactive",
            is_trending: data.is_trending || false,
            profile_completion: data.profile_completion ?? 0,
            profile_completion_percentage:
              data.profile_completion_percentage ??
              data.profile_completion ??
              0,
            last_completion_calculated_at:
              data.last_completion_calculated_at || null,
            company_register_document_type:
              data.company_register_document_type || "-",
            company_register_document: data.company_register_document || null,
            company_pan_card: data.company_pan_card || "-",
            company_pan_card_image: data.company_pan_card_image || null,
            owner_adharcard: data.owner_adharcard || "-",
            owner_adharcard_image: data.owner_adharcard_image || null,
            industries: data.Industries || [],
            subIndustries: data.SubIndustries || [],
            created_by: data.created_by || null,
            updated_by: data.updated_by || null,
            created_at: createdAt,
            updated_at: updatedAt,
          };

          setInitialData(formData);
          setViewData(data);
        } else {
          showError("Company not found");
          navigate("/companies");
        }
      } catch (error) {
        console.error("Fetch error:", error);
        showError(error.message || "Failed to load company data");
        navigate("/companies");
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchCompany();
  }, [id, navigate]);

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Fetch subscription history ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const fetchSubscriptionHistory = async () => {
    setSubscriptionState((s) => ({ ...s, loading: true, error: null }));
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `${API_BASE}/company-subscriptions?company_id=${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json = await res.json();
      const data = json.data || json || [];
      setSubscriptionState({
        loading: false,
        loaded: true,
        items: Array.isArray(data) ? data : [],
        error: null,
      });
    } catch (err) {
      console.error("Subscription history fetch error:", err);
      setSubscriptionState({
        loading: false,
        loaded: true,
        items: [],
        error: err.message || "Failed to load subscription history",
      });
    }
  };

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Fetch jobs (paginated) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const fetchJobs = async (page = 1) => {
    setJobsState((s) => ({ ...s, loading: true, error: null }));
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `${API_BASE}/jobs?company_id=${id}&page=${page}&limit=${JOBS_PER_PAGE}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);

      const json = await res.json();
      const data = json.data || json || [];
      const pag = json.pagination || {};

      setJobsState({
        loading: false,
        loaded: true,
        items: Array.isArray(data) ? data : [],
        error: null,
      });

      setJobsPagination({
        page: pag.page || page,
        limit: pag.limit || JOBS_PER_PAGE,
        total: pag.total || data.length,
        totalPages: pag.totalPages || 1,
      });
    } catch (err) {
      console.error("Jobs fetch error:", err);
      setJobsState({
        loading: false,
        loaded: true,
        items: [],
        error: err.message || "Failed to load jobs",
      });
    }
  };

  const handleJobsPageChange = (newPage) => {
    if (newPage < 1 || newPage > jobsPagination.totalPages) return;
    if (newPage === jobsPagination.page) return;
    setJobsPagination((p) => ({ ...p, page: newPage }));
    fetchJobs(newPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Fetch candidate-search-logs ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const fetchSearchHistory = async () => {
    setSearchHistoryState((s) => ({ ...s, loading: true, error: null }));
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `${API_BASE}/candidate-search-logs?company_id=${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      );
      if (!res.ok) throw new Error(`HTTP error ${res.status}`);
      const json = await res.json();
      const data = json.data || json || [];
      setSearchHistoryState({
        loading: false,
        loaded: true,
        items: Array.isArray(data) ? data : [],
        error: null,
      });
    } catch (err) {
      console.error("Search history fetch error:", err);
      setSearchHistoryState({
        loading: false,
        loaded: true,
        items: [],
        error: err.message || "Failed to load search history",
      });
    }
  };

  // --- Fetch company dashboard stats -----------------------------
  const [dashboardStats, setDashboardStats] = useState({
    loading: true,
    data: null,
    error: null,
  });

  useEffect(() => {
    if (!id || !isApproved) return;
    let mounted = true;
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch(`${API_BASE}/company-dashboard/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });
        if (!res.ok) throw new Error("Failed to fetch dashboard stats");
        const json = await res.json();
        if (mounted) {
          setDashboardStats({ loading: false, data: json.data || json, error: null });
        }
      } catch (err) {
        if (mounted) {
          setDashboardStats({ loading: false, data: null, error: err.message });
        }
      }
    };
    fetchStats();
    return () => { mounted = false; };
  }, [id, isApproved]);

  // Lazy-load data for whichever top-level tab is active (only relevant once approved)
  useEffect(() => {
    if (!id || !isApproved) return;
    if (activeTab === "subscription" && !subscriptionState.loaded) {
      fetchSubscriptionHistory();
    }
    if (activeTab === "jobs" && !jobsState.loaded) {
      fetchJobs(1);
    }
    if (activeTab === "search-history" && !searchHistoryState.loaded) {
      fetchSearchHistory();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, id, isApproved]);

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Gate: force Profile tab whenever the company isn't approved ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  // Runs on mount, on status changes (Approve/un-approve), and whenever
  // activeTab changes, so a non-Profile tab can never stay selected
  // for a company that isn't active.
  useEffect(() => {
    if (!isApproved && activeTab !== "profile") {
      setActiveTab("profile");
    }
  }, [isApproved, activeTab]);

  const handleEdit = () => navigate(`/companies/edit/${id}`);
  const handleViewJob = (jobId) => {
    if (!jobId) return;
    navigate(`/jobs/view/${jobId}`);
  };

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Render helpers ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  const renderDocPreview = (path, alt, size = "w-28 h-20") => {
    if (!path)
      return (
        <div
          className={`${size} rounded-lg border border-dashed border-slate-300 flex items-center justify-center text-[11px] text-slate-400`}
        >
          No image
        </div>
      );
    const fullUrl = getImageUrl(path);
    const fileName = getFileName(path);
    const isImage = isImageFile(path);
    return (
      <div className={`relative group ${size} flex-shrink-0`}>
        {isImage ? (
          <img
            src={fullUrl}
            alt={alt}
            className="w-full h-full object-cover rounded-lg border border-slate-200 shadow-sm"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
        ) : (
          <div className="w-full h-full rounded-lg border border-slate-200 bg-slate-50 flex flex-col items-center justify-center p-2">
            <MdDescription size={24} className="text-slate-400" />
            <span className="text-[10px] text-slate-500 text-center truncate w-full mt-1">
              {fileName}
            </span>
          </div>
        )}
        <button
          type="button"
          onClick={() => window.open(fullUrl, "_blank")}
          className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/50 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200"
        >
          <span className="text-white text-xs font-medium flex items-center gap-1">
            <MdOpenInNew size={13} /> {isImage ? "View" : "Open"}
          </span>
        </button>
      </div>
    );
  };

  const renderImage = (
    path,
    alt,
    className = "w-24 h-24 object-cover rounded-lg",
  ) => {
    if (!path) return <span className="text-gray-400">No image</span>;
    const fullUrl = getImageUrl(path);
    const isImage = isImageFile(path);
    const fileName = getFileName(path);
    if (!isImage) {
      return (
        <div className="relative group inline-block">
          <div
            className={`${className} border border-gray-200 shadow-sm bg-slate-50 flex flex-col items-center justify-center p-4`}
          >
            <MdDescription size={32} className="text-slate-400" />
            <span className="text-xs text-slate-500 text-center truncate w-full mt-2">
              {fileName}
            </span>
          </div>
          <button
            onClick={() => window.open(fullUrl, "_blank")}
            className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center text-white"
            title="Open document"
          >
            <span className="text-xs flex items-center gap-1">
              <MdOpenInNew size={14} /> Open
            </span>
          </button>
        </div>
      );
    }
    return (
      <div className="relative group inline-block">
        <img
          src={fullUrl}
          alt={alt}
          className={`${className} border border-gray-200 shadow-sm`}
          onError={(e) => {
            e.target.style.display = "none";
          }}
        />
        <button
          onClick={() => window.open(fullUrl, "_blank")}
          className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center text-white"
          title="View full image"
        >
          <span className="text-xs">View</span>
        </button>
      </div>
    );
  };

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Loading ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-9 h-9 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-slate-400">Loading company details...</p>
        </div>
      </div>
    );
  }

  if (!initialData || !viewData) return null;

  const completionPct =
    parseInt(initialData.profile_completion_percentage) || 0;
  const heroName = initialData.company_name?.trim() || "Unnamed Company";
  const initials = heroName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");
  const approved = viewData.company_status === "active";
  const isTogglingThisCompany = statusUpdatingId === viewData?.id;

  // Only show Profile tab until the company is approved; unlock the rest once active
  const visibleTopTabs = approved
    ? TOP_TABS
    : TOP_TABS.filter((tab) => tab.id === "profile");

  // ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Main render ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
  return (
    <div className="min-h-screen pb-16">
      {/* Sticky action bar */}
      <div className=" bg-white/85 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => navigate("/companies")}
              className="p-2 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
              aria-label="Back"
            >
              <MdArrowBack size={19} className="text-slate-600" />
            </button>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400 leading-tight">
                Companies
              </p>
              <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
                {heroName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={handleToggleApprove}
              disabled={isTogglingThisCompany}
              className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                approved
                  ? "bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
                  : "bg-white text-slate-700 border border-slate-300 hover:bg-slate-50"
              }`}
            >
              {approved ? (
                <MdVerified size={18} />
              ) : (
                <MdCheckCircle size={18} />
              )}
              {isTogglingThisCompany
                ? "Updating..."
                : approved
                  ? "Approved"
                  : "Approve"}
            </button>
            <button
              onClick={handleEdit}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors"
            >
              <MdEdit size={18} />
              Edit Company
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        <div className="mb-4 flex justify-end">
          <button
            onClick={() => {
              setShowTabs((prev) => {
                const nextState = !prev;
                if (nextState) setActiveTab("profile");
                return nextState;
              });
            }}
            className={`inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-lg shadow-sm border transition-colors ${
              showTabs 
                ? "bg-slate-100 text-slate-700 border-slate-200" 
                : "bg-white hover:bg-slate-50 text-slate-700 border-slate-200"
            }`}
          >
            {showTabs ? (
              <MdClose size={18} className="text-slate-500" />
            ) : (
              <MdApartment size={18} className="text-slate-500" />
            )}
            {showTabs ? "Close Profile" : "Profile"}
          </button>
        </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[
            { 
              title: "All Active Jobs", 
              value: dashboardStats.loading ? "..." : (dashboardStats.data?.jobs?.published ?? 0), 
              icon: MdWork, color: "text-blue-600", bgColor: "bg-blue-50" 
            },
            { 
              title: "Candidates Applied", 
              value: dashboardStats.loading ? "..." : (dashboardStats.data?.total_job_applications ?? 0), 
              icon: MdGroups, color: "text-emerald-600", bgColor: "bg-emerald-50" 
            },
            { 
              title: "Candidate Searches", 
              value: dashboardStats.loading ? "..." : (dashboardStats.data?.total_candidate_searches ?? 0), 
              icon: MdSearch, color: "text-purple-600", bgColor: "bg-purple-50" 
            },
            { 
              title: "Resume Downloads", 
              value: dashboardStats.loading ? "..." : (dashboardStats.data?.total_resume_downloads ?? 0), 
              icon: MdDescription, color: "text-orange-600", bgColor: "bg-orange-50" 
            }
          ].map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div 
                key={idx}
                className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md transition-shadow cursor-pointer flex items-center gap-4 group"
              >
                <div className={`w-12 h-12 rounded-lg ${stat.bgColor} ${stat.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                  <Icon size={24} />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-500 mb-0.5">{stat.title}</p>
                  <h4 className="text-2xl font-bold text-slate-800 leading-none">{stat.value}</h4>
                </div>
              </div>
            );
          })}
        </div>

                {(() => {
          const subData = dashboardStats.data?.subscription || {};
          const features = Array.isArray(subData.features) ? subData.features : [];

          const jobFeature = features.find((f) => f.feature_name === "Job posting") || {};
          const resumeFeature = features.find((f) => f.feature_name === "Resume Database Access") || {};
          
          const planName = dashboardStats.loading ? "..." : (subData.plan_name || "---");
          const startDate = dashboardStats.loading ? "..." : (subData.start_date ? formatDate(parseApiDate(subData.start_date)) : "---");
          const endDate = dashboardStats.loading ? "..." : (subData.expiry_date ? formatDate(parseApiDate(subData.expiry_date)) : "---");
          
          const mockSubscriptionUsage = {
            planName,
            startDate,
            endDate,
            jobs: { 
              total: dashboardStats.loading ? "..." : (jobFeature.allocated_value ?? 0), 
              used: dashboardStats.loading ? "..." : (jobFeature.used_value ?? 0), 
              remaining: dashboardStats.loading ? "..." : (jobFeature.remaining_value ?? 0)
            },
            resumeDownloads: { 
              total: dashboardStats.loading ? "..." : (resumeFeature.allocated_value ?? 0), 
              used: dashboardStats.loading ? "..." : (resumeFeature.used_value ?? 0), 
              remaining: dashboardStats.loading ? "..." : (resumeFeature.remaining_value ?? 0)
            },
          };
          
          const jobsPct = (jobFeature.allocated_value > 0 && !dashboardStats.loading) 
            ? Math.min((jobFeature.used_value / jobFeature.allocated_value) * 100, 100) 
            : 0;
            
          const resumePct = (resumeFeature.allocated_value > 0 && !dashboardStats.loading) 
            ? Math.min((resumeFeature.used_value / resumeFeature.allocated_value) * 100, 100) 
            : 0;

          return (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6 w-full">
              <div className="flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
                {/* Card 1: Subscription Plan */}
                <div className="p-5 flex-1 lg:w-1/3">
                 <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                       <MdPayments size={20} />
                    </div>
                    <div>
                       <h4 className="text-sm font-semibold text-slate-800">Subscription Plan</h4>
                       <p className="text-lg font-bold text-indigo-600 leading-tight">{mockSubscriptionUsage.planName}</p>
                    </div>
                 </div>
                 <div className="flex items-center justify-between text-sm">
                    <div>
                      <p className="text-slate-500 text-xs mb-0.5">Start Date</p>
                      <p className="font-semibold text-slate-700">{mockSubscriptionUsage.startDate}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-slate-500 text-xs mb-0.5">End Date</p>
                      <p className="font-semibold text-slate-700">{mockSubscriptionUsage.endDate}</p>
                    </div>
                 </div>
                </div>

                {/* Card 2: Jobs Usage */}
                <div className="p-5 flex flex-col justify-between flex-1 lg:w-1/3">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                       <h4 className="text-sm font-semibold text-slate-800">Jobs Usage</h4>
                       <span className="text-xs font-medium text-slate-500">{mockSubscriptionUsage.jobs.used} / {mockSubscriptionUsage.jobs.total} Used</span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden mb-3">
                       <div className="h-full bg-blue-500 rounded-full transition-all duration-500" style={{ width: `${jobsPct}%` }} />
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-auto">
                     <span className="text-slate-500">Remaining</span>
                     <span className="font-bold text-slate-700">{mockSubscriptionUsage.jobs.remaining} Jobs</span>
                  </div>
                </div>

                {/* Card 3: Resume Downloads */}
                <div className="p-5 flex flex-col justify-between flex-1 lg:w-1/3">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                       <h4 className="text-sm font-semibold text-slate-800">Resume Downloads</h4>
                       <span className="text-xs font-medium text-slate-500">{mockSubscriptionUsage.resumeDownloads.used} / {mockSubscriptionUsage.resumeDownloads.total} Used</span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden mb-3">
                       <div className="h-full bg-orange-500 rounded-full transition-all duration-500" style={{ width: `${resumePct}%` }} />
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm mt-auto">
                     <span className="text-slate-500">Remaining</span>
                     <span className="font-bold text-slate-700">{mockSubscriptionUsage.resumeDownloads.remaining} Downloads</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {/* Job Analytics Graph */}
        {(() => {
          if (dashboardStats.loading) {
            return (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6 p-5 w-full h-80 flex items-center justify-center">
                <span className="opacity-50 font-medium text-slate-500">Loading chart...</span>
              </div>
            );
          }
          
          const dbData = dashboardStats.data || {};
          const analyticsData = [
            {
              name: "Total Jobs",
              value: dbData.jobs?.total ?? 0,
            },
            {
              name: "Applied Jobs",
              value: dbData.total_job_applications ?? 0,
            },
            { name: "Saved Jobs", value: dbData.total_save ?? 0, },
            {
              name: "Shared Jobs",
              value: dbData.total_share_jobs ?? 0,
            },
            { name: "Selected Jobs", value: dbData.total_selected ?? 0, }
          ];

          return (
            <div 
              className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6 p-5 w-full cursor-pointer hover:shadow-md transition-all duration-200 relative overflow-hidden group"
              onClick={() => setJobsAnalyticsVisible(true)}
            >
              <div className="absolute inset-0 bg-slate-50/0 group-hover:bg-slate-50/50 transition-colors pointer-events-none z-10"></div>
              <h4 className="text-base font-semibold text-slate-800 mb-1">Job Analytics</h4>
              <p className="text-xs text-slate-500 mb-6">Overview of job activity</p>
              
              <div className="w-full h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analyticsData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#64748b', fontSize: 12 }} 
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#64748b', fontSize: 12 }}
                      allowDecimals={false}
                    />
                    <RechartsTooltip 
                      cursor={{ fill: '#f8fafc' }}
                      contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      labelStyle={{ fontWeight: 600, color: '#334155', marginBottom: '4px' }}
                      itemStyle={{ color: '#4f46e5', fontWeight: 500 }}
                    />
                    <Bar dataKey="value" fill="#4f46e5" radius={[4, 4, 0, 0]} maxBarSize={60} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          );
        })()}

        {/* Job Analytics Details Table drill-down */}
        <AnimatePresence>
          {jobsAnalyticsVisible && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6 overflow-hidden">
                <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
                  <div>
                    <h4 className="text-base font-semibold text-slate-800 mb-1">Job Analytics Details</h4>
                    <p className="text-xs text-slate-500">Job-wise application, save, share and selection activity</p>
                  </div>
                  <button 
                    onClick={() => setJobsAnalyticsVisible(false)}
                    className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors flex items-center justify-center gap-1 text-xs font-semibold"
                  >
                    <MdClose size={16} />
                    Close
                  </button>
                </div>
                
                <div className="p-0 sm:p-5">
                  {jobsAnalyticsState.error ? (
                    <div className="p-8 text-center text-red-500 flex flex-col items-center gap-2">
                       <MdEventBusy size={32} className="text-red-400" />
                       {jobsAnalyticsState.error}
                    </div>
                  ) : jobsAnalyticsState.loading ? (
                    <div className="p-5 flex flex-col gap-3">
                       <div className="h-12 bg-slate-100 rounded-lg animate-pulse w-full"></div>
                       <div className="h-12 bg-slate-100 rounded-lg animate-pulse w-full"></div>
                       <div className="h-12 bg-slate-100 rounded-lg animate-pulse w-full"></div>
                    </div>
                  ) : jobsAnalyticsState.data.length === 0 ? (
                    <div className="p-12 text-center flex flex-col items-center justify-center text-slate-500 font-medium">
                       <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                           <MdBusinessCenter size={24} className="text-slate-400" />
                       </div>
                       No jobs found
                    </div>
                  ) : (
                    <div className="w-full overflow-x-auto">
                      <div className="min-w-[700px]">
                        <Table
                          columns={[
                            { header: "Job Name", key: "title", render: (value, row) => <span className="font-semibold text-slate-800 max-w-[200px] block truncate" title={row?.title}>{row?.title}</span> },
                            { header: "Total Apply", key: "application_count" },
                            { header: "Total Save", key: "job_saved_count" },
                            { header: "Total Shared", key: "job_share_count" },
                            { header: "Total Selected Candidate", key: "selected_count" },
                          ]}
                          data={jobsAnalyticsState.data || []}
                        />
                      </div>
                    </div>
                  )}

                  {!jobsAnalyticsState.loading && !jobsAnalyticsState.error && jobsAnalyticsState.data.length > 0 && (
                    <div className="mt-5 px-5 sm:px-0">
                      <Pagination
                        page={jobsAnalyticsState.pagination.page}
                        total={jobsAnalyticsState.pagination.total}
                        limit={jobsAnalyticsState.pagination.limit}
                        onChange={(newPage) => setJobsAnalyticsState(prev => ({ ...prev, pagination: { ...prev.pagination, page: newPage } }))}
                      />
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hero */}
        {/* <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
        >
          <div className="relative h-44 sm:h-52">
            {initialData.banner_image ? (
              <img
                src={getImageUrl(initialData.banner_image)}
                alt="Banner"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = "none";
                }}
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-800" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/95 via-slate-900/50 to-slate-900/10" />
          </div>

          <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-1.5 shadow-xl flex-shrink-0">
                {initialData.logo ? (
                  <img
                    src={getImageUrl(initialData.logo)}
                    alt="Logo"
                    className="w-full h-full object-cover rounded-xl"
                    onError={(e) => {
                      e.target.style.display = "none";
                    }}
                  />
                ) : (
                  <div className="w-full h-full rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-lg">
                    {initials || <MdApartment size={22} />}
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
                    {heroName}
                  </h1>
                  {initialData.is_trending && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-orange-400/20 text-orange-300 ring-1 ring-orange-400/30">
                      <MdWhatshot size={12} />
                      Trending
                    </span>
                  )}
                </div>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <StatusPill status={initialData.company_status} />
                  <span className="text-xs text-white/70 capitalize">
                    {initialData.profile_type || "company"}
                  </span>
                  {initialData.website && (
                    <a
                      href={
                        initialData.website.startsWith("http")
                          ? initialData.website
                          : `https://${initialData.website}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-white/80 hover:text-white transition-colors"
                    >
                      <MdLanguage size={13} />
                      Website
                      <MdOpenInNew size={11} />
                    </a>
                  )}
                </div>
              </div>

              <div className="hidden sm:block">
                <CompletionRing percentage={completionPct} />
              </div>
            </div>
          </div>
        </motion.div> */}

        {/* Approval hint banner ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â only while not yet approved */}
        {!approved && (
          <div className="mt-4 flex items-center gap-2.5 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3">
            <MdLock size={16} className="text-amber-600 flex-shrink-0" />
            <p className="text-xs text-amber-700">
              <span className="font-semibold">Subscription History, Jobs</span>{" "}
              and <span className="font-semibold">Search History</span> unlock
              automatically once you approve this company.
            </p>
          </div>
        )}

        {/* Top-level Tabs */}
        {showTabs && (
        <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex w-full border-b border-slate-200 bg-slate-50/60">
            {visibleTopTabs.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex-1 flex items-center justify-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
                    active
                      ? "text-blue-600"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}

                  {active && (
                    <motion.span
                      layoutId="view-company-top-tab-underline"
                      className="absolute left-2 right-2 -bottom-px h-0.5 bg-blue-600 rounded-full"
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                {/* Profile */}
                {activeTab === "profile" && (
                  <div>
                    <div className="flex overflow-x-auto gap-1 border-b border-slate-200 mb-6 -mt-1">
                      {PROFILE_SUB_TABS.map((tab) => {
                        const Icon = tab.icon;
                        const active = activeProfileTab === tab.id;
                        return (
                          <button
                            key={tab.id}
                            type="button"
                            onClick={() => setActiveProfileTab(tab.id)}
                            className={`relative flex items-center gap-1.5 px-3.5 py-2.5 text-[13px] font-medium whitespace-nowrap transition-colors ${
                              active
                                ? "text-blue-600"
                                : "text-slate-500 hover:text-slate-700"
                            }`}
                          >
                            <Icon size={15} />
                            {tab.label}
                            {active && (
                              <motion.span
                                layoutId="view-company-profile-sub-tab-underline"
                                className="absolute left-2 right-2 -bottom-px h-0.5 bg-blue-600 rounded-full"
                                transition={{
                                  type: "spring",
                                  stiffness: 500,
                                  damping: 35,
                                }}
                              />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <AnimatePresence mode="wait">
                      <motion.div
                        key={activeProfileTab}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -6 }}
                        transition={{ duration: 0.18 }}
                      >
                        {/* Overview */}
                        {activeProfileTab === "overview" && (
                          <div className="space-y-5">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                              <div className="sm:col-span-2">
                                <FieldLabel>Company name</FieldLabel>
                                <ReadOnlyValue>
                                  {initialData.company_name}
                                </ReadOnlyValue>
                              </div>
                              <div>
                                <FieldLabel>Slug</FieldLabel>
                                <ReadOnlyValue>
                                  {initialData.slug || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                </ReadOnlyValue>
                              </div>
                              <div>
                                <FieldLabel>Website</FieldLabel>
                                <ReadOnlyValue>
                                  {initialData.website ? (
                                    <a
                                      href={initialData.website}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-blue-600 hover:underline"
                                    >
                                      {initialData.website}
                                    </a>
                                  ) : (
                                    "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"
                                  )}
                                </ReadOnlyValue>
                              </div>
                              <div>
                                <FieldLabel>Founded year</FieldLabel>
                                <ReadOnlyValue>
                                  {initialData.founded_year || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                </ReadOnlyValue>
                              </div>
                              <div>
                                <FieldLabel>GST number</FieldLabel>
                                <ReadOnlyValue>
                                  {initialData.gst_number || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                </ReadOnlyValue>
                              </div>
                            </div>

                            <div>
                              <FieldLabel>About company</FieldLabel>
                              <RichTextViewer
                                value={initialData.about_company || ""}
                              />
                            </div>

                            <div className="border-t border-slate-100 pt-5 grid grid-cols-1 sm:grid-cols-2 gap-5">
                              <div>
                                <FieldLabel>Company status</FieldLabel>
                                <StatusPill
                                  status={initialData.company_status}
                                />
                              </div>
                              <div>
                                <FieldLabel>Trending</FieldLabel>
                                <div className="flex items-center gap-3 pt-1.5">
                                  <span className="text-sm text-slate-600">
                                    {initialData.is_trending
                                      ? "Shown in trending companies"
                                      : "Not marked as trending"}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Relations */}
                        {activeProfileTab === "relations" && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <div className="sm:col-span-2">
                              <FieldLabel>Company user</FieldLabel>
                              <div className="flex items-center gap-2.5 text-sm text-slate-700 py-2.5 px-3.5 bg-slate-50 rounded-lg border border-slate-200">
                                <MdPerson
                                  size={16}
                                  className="text-slate-400"
                                />
                                {initialData.company_user_email || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                <span className="ml-auto text-[11px] text-slate-400">
                                  Read-only
                                </span>
                              </div>
                            </div>
                            <div>
                              <FieldLabel>Industry</FieldLabel>
                              <ReadOnlyValue>
                                {initialData.industry_name}
                              </ReadOnlyValue>
                            </div>
                            <div>
                              <FieldLabel>Sub-industries</FieldLabel>
                              <ReadOnlyValue>
                                {Array.isArray(initialData.subIndustries) &&
                                initialData.subIndustries.length > 0
                                  ? initialData.subIndustries
                                      .map(
                                        (sub) =>
                                          sub.sub_industry_name || sub.name,
                                      )
                                      .join(", ")
                                  : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                              </ReadOnlyValue>
                            </div>
                            <div>
                              <FieldLabel>Company size</FieldLabel>
                              <ReadOnlyValue>
                                {initialData.company_size_name}
                              </ReadOnlyValue>
                            </div>
                          </div>
                        )}

                        {/* Documents */}
                        {activeProfileTab === "documents" && (
                          <div className="space-y-6">
                            <div className="flex flex-col sm:flex-row sm:items-center gap-4 pb-5 border-b border-slate-100">
                              <div className="flex-1">
                                <FieldLabel>
                                  Registration document type
                                </FieldLabel>
                                <ReadOnlyValue>
                                  {initialData.company_register_document_type}
                                </ReadOnlyValue>
                              </div>
                              <div className="flex-1">
                                <FieldLabel>Registration document</FieldLabel>
                                <div className="mt-1">
                                  {initialData.company_register_document ? (
                                    renderImage(
                                      initialData.company_register_document,
                                      "Registration Document",
                                      "w-32 h-24 object-cover rounded-lg",
                                    )
                                  ) : (
                                    <span className="text-gray-400">
                                      No document
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col sm:flex-row sm:items-center gap-4 pb-5 border-b border-slate-100">
                              <div className="flex-1">
                                <FieldLabel>GST Number</FieldLabel>
                                <div className="flex items-center gap-2 text-sm text-slate-700 py-2.5 px-3.5 bg-slate-50 rounded-lg border border-slate-200">
                                  <MdReceiptLong
                                    size={16}
                                    className="text-slate-400"
                                  />
                                  {initialData.gst_number || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                </div>
                              </div>
                              <div className="flex-1" />
                            </div>

                            <div className="flex flex-col sm:flex-row gap-5 pb-5 border-b border-slate-100">
                              <div className="flex-1">
                                <FieldLabel>PAN card number</FieldLabel>
                                <div className="flex items-center gap-2 font-mono text-sm bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
                                  <MdCreditCard
                                    size={16}
                                    className="text-slate-400"
                                  />
                                  {initialData.company_pan_card || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                </div>
                              </div>
                              <div>
                                <FieldLabel>PAN card image</FieldLabel>
                                {renderDocPreview(
                                  initialData.company_pan_card_image,
                                  "PAN card",
                                )}
                              </div>
                            </div>

                            <div className="flex flex-col sm:flex-row gap-5">
                              <div className="flex-1">
                                <FieldLabel>Owner Aadhar number</FieldLabel>
                                <div className="flex items-center gap-2 font-mono text-sm bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
                                  <MdPermIdentity
                                    size={16}
                                    className="text-slate-400"
                                  />
                                  {initialData.owner_adharcard || "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                </div>
                              </div>
                              <div>
                                <FieldLabel>Owner Aadhar image</FieldLabel>
                                {renderDocPreview(
                                  initialData.owner_adharcard_image,
                                  "Aadhar card",
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Media */}
                        {activeProfileTab === "media" && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <div>
                              <FieldLabel>Logo</FieldLabel>
                              <div className="mt-1">
                                {renderImage(
                                  initialData.logo,
                                  "Logo",
                                  "w-28 h-28 object-cover rounded-lg",
                                )}
                              </div>
                            </div>
                            <div>
                              <FieldLabel>Banner image</FieldLabel>
                              <div className="mt-1">
                                {renderImage(
                                  initialData.banner_image,
                                  "Banner",
                                  "w-full sm:w-64 h-28 object-cover rounded-lg",
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Activity */}
                        {activeProfileTab === "activity" && (
                          <div className="space-y-6">
                            <div>
                              <FieldLabel>Profile completion</FieldLabel>
                              <div className="flex items-center gap-4 mb-1">
                                <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden">
                                  <motion.div
                                    initial={{ width: 0 }}
                                    animate={{ width: `${completionPct}%` }}
                                    transition={{
                                      duration: 0.8,
                                      ease: "easeOut",
                                    }}
                                    className={`h-full rounded-full ${
                                      completionPct === 100
                                        ? "bg-emerald-500"
                                        : completionPct >= 50
                                          ? "bg-blue-500"
                                          : "bg-amber-500"
                                    }`}
                                  />
                                </div>
                                <span className="text-sm font-semibold text-slate-700 w-12 text-right">
                                  {completionPct}%
                                </span>
                              </div>
                              <p className="text-xs text-slate-400">
                                Score: {initialData.profile_completion}/100 Ãƒâ€šÃ‚Â·
                                Last calculated{" "}
                                {initialData.last_completion_calculated_at
                                  ? formatDate(
                                      parseApiDate(
                                        initialData.last_completion_calculated_at,
                                      ),
                                    )
                                  : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                              </p>
                            </div>

                            <div className="border-t border-slate-100 pt-5">
                              <div className="relative pl-6">
                                <div className="absolute left-[7px] top-1 bottom-1 w-px bg-slate-200" />
                                <div className="relative pb-6">
                                  <div className="absolute -left-6 top-0.5 w-3.5 h-3.5 rounded-full bg-blue-500 ring-4 ring-blue-100" />
                                  <p className="text-sm font-semibold text-slate-700">
                                    Created
                                  </p>
                                  <p className="text-sm text-slate-500 mt-0.5">
                                    {getCreatedByName(viewData)}
                                  </p>
                                  <p className="text-xs text-slate-400 mt-0.5">
                                    {initialData.created_at
                                      ? formatDate(initialData.created_at)
                                      : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                  </p>
                                </div>
                                <div className="relative">
                                  <div className="absolute -left-6 top-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-4 ring-emerald-100" />
                                  <p className="text-sm font-semibold text-slate-700">
                                    Last updated
                                  </p>
                                  <p className="text-sm text-slate-500 mt-0.5">
                                    {getUpdatedByName(viewData)}
                                  </p>
                                  <p className="text-xs text-slate-400 mt-0.5">
                                    {initialData.updated_at
                                      ? formatDate(initialData.updated_at)
                                      : "ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â"}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    </AnimatePresence>
                  </div>
                )}

                {/* Subscription History */}
                {activeTab === "subscription" && approved && (
                  <SubscriptionHistorySection
                    state={subscriptionState}
                    onRetry={fetchSubscriptionHistory}
                  />
                )}

                {/* Jobs */}
                {activeTab === "jobs" && approved && (
                  <JobsSection
                    state={jobsState}
                    pagination={jobsPagination}
                    onPageChange={handleJobsPageChange}
                    onRetry={() => fetchJobs(jobsPagination.page)}
                    onViewJob={handleViewJob}
                  />
                )}

                {/* Search History */}
                {activeTab === "search-history" && approved && (
                  <SearchHistorySection
                    state={searchHistoryState}
                    onRetry={fetchSearchHistory}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
        )}
      </div>
    </div>
  );
};

export default ViewCompany;















