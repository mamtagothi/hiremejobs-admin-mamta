import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MdArrowBack } from "react-icons/md";
import jobService from "../../services/job.service";
import companyService from "../../services/company.service";
import JobsSection from "./JobsSection";

const JOBS_PER_PAGE = 10;

const CompanyJobs = () => {
  const { companyId } = useParams();
  const navigate = useNavigate();

  const [company, setCompany] = useState(null);
  
  const [jobsState, setJobsState] = useState({
    loading: true,
    loaded: false,
    items: [],
    error: null,
  });

  const [pagination, setPagination] = useState({
    page: 1,
    limit: JOBS_PER_PAGE,
    total: 0,
    totalPages: 1,
  });

  useEffect(() => {
    let mounted = true;
    const fetchCompany = async () => {
      try {
        const res = await companyService.getById(companyId);
        if (mounted) setCompany(res.data?.data || res.data || res);
      } catch (err) {
        console.error("Failed to load company details:", err);
      }
    };
    if (companyId) fetchCompany();
    return () => { mounted = false; };
  }, [companyId]);

  const loadJobs = async (page = 1) => {
    try {
      setJobsState((prev) => ({ ...prev, loading: true, error: null }));
      const response = await jobService.getAll({ 
        company_id: companyId, 
        page, 
        limit: JOBS_PER_PAGE 
      });

      const body = response?.data ?? response;
      const dataItems = Array.isArray(body?.data?.data) 
        ? body.data.data 
        : Array.isArray(body?.data) 
          ? body.data 
          : Array.isArray(body) 
            ? body 
            : [];

      let total = 0;
      if (body?.pagination?.total !== undefined) {
        total = body.pagination.total;
      } else if (body?.data?.pagination?.total !== undefined) {
        total = body.data.pagination.total;
      } else if (body?.total !== undefined) {
        total = body.total;
      } else if (body?.data?.total !== undefined) {
        total = body.data.total;
      } else {
        total = dataItems.length;
      }

      setJobsState({
        loading: false,
        loaded: true,
        items: dataItems,
        error: null,
      });

      setPagination({
        page,
        limit: JOBS_PER_PAGE,
        total,
        totalPages: Math.ceil((total || 0) / JOBS_PER_PAGE) || 1,
      });
    } catch (err) {
      setJobsState({
        loading: false,
        loaded: true,
        items: [],
        error: err.response?.data?.message || err.message || "Failed to load jobs",
      });
    }
  };

  useEffect(() => {
    if (companyId) loadJobs(1);
  }, [companyId]);

  const handlePageChange = (newPage) => {
    loadJobs(newPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-white rounded-2xl shadow-[0_2px_12px_rgba(0,0,0,0.06)] border border-slate-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-200">
          <div className="flex items-center gap-3">
             <button
                onClick={() => navigate(-1)}
                className="p-2 -ml-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
             >
                <MdArrowBack size={20} />
             </button>
             <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {company?.company_name ? `${company.company_name} Jobs` : "Company Jobs"}
                </h1>
                <p className="text-sm text-slate-500 mt-1">
                  Viewing all job postings created by this company
                </p>
             </div>
          </div>
        </div>
        
        <div className="p-6 bg-slate-50/50 min-h-[400px]">
          <JobsSection 
            state={jobsState} 
            pagination={pagination}
            onPageChange={handlePageChange}
            onRetry={() => loadJobs(pagination.page)}
          />
        </div>
      </div>
    </div>
  );
};

export default CompanyJobs;

