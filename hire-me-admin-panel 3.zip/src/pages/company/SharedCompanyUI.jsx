import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MdErrorOutline, MdInbox, MdCheckCircle, MdPauseCircle, MdBlock, MdWork, MdSearch, MdLocationOn, MdChevronLeft, MdChevronRight } from "react-icons/md";
import { formatDate } from "../../utils/helpers";

const API_BASE = import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

// ─── Helpers ────────────────────────────────────────────────────
export const getImageUrl = (path) => {
  if (!path) return null;
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  return `${API_BASE}${path}`;
};

export const isImageFile = (path) => {
  if (!path) return false;
  const exts = [
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".webp",
    ".bmp",
    ".svg",
    ".avif",
  ];
  return exts.some((ext) => path.toLowerCase().endsWith(ext));
};

export const getFileName = (path) => {
  if (!path) return "Document";
  return path.split("/").pop() || "Document";
};

export const parseApiDate = (dateString) => {
  if (!dateString) return null;
  if (dateString instanceof Date)
    return isNaN(dateString.getTime()) ? null : dateString;
  if (typeof dateString !== "string") return null;

  const str = dateString.trim();
  if (!str) return null;

  if (str.includes("T")) {
    const d = new Date(str);
    if (!isNaN(d.getTime())) return d;
  }

  // DD/MM/YYYY or DD-MM-YYYY with optional time & am/pm
  const dmyMatch = str.match(
    /^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:[,\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?)?$/i,
  );
  if (dmyMatch) {
    let [_, day, month, year, hours, minutes, seconds, ampm] = dmyMatch;
    let h = hours ? parseInt(hours, 10) : 0;
    let m = minutes ? parseInt(minutes, 10) : 0;
    let s = seconds ? parseInt(seconds, 10) : 0;
    if (ampm) {
      if (ampm.toLowerCase() === "pm" && h < 12) h += 12;
      if (ampm.toLowerCase() === "am" && h === 12) h = 0;
    }
    const parsed = new Date(
      parseInt(year, 10),
      parseInt(month, 10) - 1,
      parseInt(day, 10),
      h,
      m,
      s,
    );
    if (!isNaN(parsed.getTime())) return parsed;
  }

  // YYYY-MM-DD or YYYY/MM/DD
  const ymdMatch = str.match(
    /^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})(?:[,\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?)?$/i,
  );
  if (ymdMatch) {
    let [_, year, month, day, hours, minutes, seconds, ampm] = ymdMatch;
    let h = hours ? parseInt(hours, 10) : 0;
    let m = minutes ? parseInt(minutes, 10) : 0;
    let s = seconds ? parseInt(seconds, 10) : 0;
    if (ampm) {
      if (ampm.toLowerCase() === "pm" && h < 12) h += 12;
      if (ampm.toLowerCase() === "am" && h === 12) h = 0;
    }
    const parsed = new Date(
      parseInt(year, 10),
      parseInt(month, 10) - 1,
      parseInt(day, 10),
      h,
      m,
      s,
    );
    if (!isNaN(parsed.getTime())) return parsed;
  }

  const d = new Date(str);
  return !isNaN(d.getTime()) ? d : null;
};

export const safeFormatDate = (dateVal) => {
  if (!dateVal) return "—";
  const parsed = parseApiDate(dateVal);
  if (!parsed) return "—";
  const formatted = formatDate(parsed);
  return formatted && formatted !== "-" ? formatted : "—";
};

export const formatSalary = (min, max, type) => {
  if (!min && !max) return "—";
  const format = (val) => {
    const num = parseFloat(val);
    if (isNaN(num)) return "—";
    if (num >= 10000000) return `₹${(num / 10000000).toFixed(1)}Cr`;
    if (num >= 100000) return `₹${(num / 100000).toFixed(1)}L`;
    if (num >= 1000) return `₹${(num / 1000).toFixed(0)}K`;
    return `₹${num}`;
  };
  const suffix = type === "annual" ? "/yr" : type === "monthly" ? "/mo" : "";
  if (min && max) return `${format(min)} - ${format(max)}${suffix}`;
  return `${format(min || max)}${suffix}`;
};

// ─── Status styles ──────────────────────────────────────────────
export const STATUS_STYLES = {
  active: {
    pill: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
    icon: MdCheckCircle,
  },
  pending: {
    pill: "bg-amber-50 text-amber-700 ring-1 ring-amber-200",
    icon: MdPauseCircle,
  },
  blocked: {
    pill: "bg-red-50 text-red-700 ring-1 ring-red-200",
    icon: MdBlock,
  },
  inactive: {
    pill: "bg-slate-100 text-slate-500 ring-1 ring-slate-200",
    icon: MdErrorOutline,
  },
};

export const GENERIC_STATUS_STYLES = {
  active: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
  open: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
  live: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
  published: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
  pending: "bg-amber-50 text-amber-700 ring-1 ring-amber-200",
  trial: "bg-amber-50 text-amber-700 ring-1 ring-amber-200",
  draft: "bg-slate-100 text-slate-500 ring-1 ring-slate-200",
  paused: "bg-slate-100 text-slate-500 ring-1 ring-slate-200",
  expired: "bg-red-50 text-red-700 ring-1 ring-red-200",
  cancelled: "bg-red-50 text-red-700 ring-1 ring-red-200",
  closed: "bg-red-50 text-red-700 ring-1 ring-red-200",
  blocked: "bg-red-50 text-red-700 ring-1 ring-red-200",
};

export const StatusPill = ({ status }) => {
  const style = STATUS_STYLES[status] || STATUS_STYLES.inactive;
  const Icon = style.icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${style.pill}`}
    >
      <Icon size={13} />
      {status ? status.charAt(0).toUpperCase() + status.slice(1) : "Unknown"}
    </span>
  );
};

export const GenericStatusPill = ({ status }) => {
  const key = (status || "").toLowerCase();
  const style =
    GENERIC_STATUS_STYLES[key] ||
    "bg-slate-100 text-slate-500 ring-1 ring-slate-200";
  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold capitalize ${style}`}
    >
      {status || "Unknown"}
    </span>
  );
};

// ─── Completion ring ────────────────────────────────────────────
export const CompletionRing = ({ percentage = 0, size = 60, strokeWidth = 5 }) => {
  const clamped = Math.min(100, Math.max(0, Number(percentage) || 0));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clamped / 100) * circumference;
  return (
    <div
      className="relative flex-shrink-0"
      style={{ width: size, height: size }}
      title={`Profile ${clamped}% complete`}
    >
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          fill="none"
          className="stroke-white/25"
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          className="stroke-emerald-400"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[11px] font-bold text-white">{clamped}%</span>
      </div>
    </div>
  );
};

// ─── Shared pieces ──────────────────────────────────────────────
export const FieldLabel = ({ children }) => (
  <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
    {children}
  </label>
);

export const ReadOnlyValue = ({ children }) => (
  <div className="text-sm text-slate-700 py-2 px-3 bg-slate-50 rounded-lg border border-slate-200">
    {children || "—"}
  </div>
);

export const RichTextViewer = ({ value }) => {
  const [editorMode, setEditorMode] = useState("text");
  return (
    <div className="w-full bg-slate-50 rounded-lg border border-slate-200 overflow-hidden">
      <div className="flex items-center gap-1 border-b border-slate-200 bg-slate-100 px-2 py-1.5">
        {["text", "html"].map((mode) => (
          <button
            key={mode}
            type="button"
            onClick={() => setEditorMode(mode)}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              editorMode === mode
                ? "bg-white text-slate-800 shadow-sm border border-slate-200"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            {mode === "text" ? "Text" : "HTML"}
          </button>
        ))}
      </div>
      {editorMode === "text" ? (
        <div className="w-full p-4">
          {value ? (
            <div
              className="prose prose-sm max-w-none text-slate-700 [&_a]:text-blue-600 [&_a]:underline [&_img]:rounded-lg"
              dangerouslySetInnerHTML={{ __html: value }}
            />
          ) : (
            <span className="text-slate-400">—</span>
          )}
        </div>
      ) : (
        <pre className="whitespace-pre-wrap break-words p-4 font-mono text-xs text-slate-700 bg-slate-950/5 min-h-[120px]">
          {value || ""}
        </pre>
      )}
    </div>
  );
};

export const SectionLoading = ({ label = "Loading..." }) => (
  <div className="flex flex-col items-center justify-center gap-3 py-16">
    <div className="w-8 h-8 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
    <p className="text-sm text-slate-400">{label}</p>
  </div>
);

export const SectionEmpty = ({ icon: Icon = MdInbox, title, subtitle }) => (
  <div className="flex flex-col items-center justify-center gap-2 py-16 text-center">
    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-1">
      <Icon size={22} className="text-slate-400" />
    </div>
    <p className="text-sm font-semibold text-slate-600">{title}</p>
    {subtitle && <p className="text-xs text-slate-400 max-w-sm">{subtitle}</p>}
  </div>
);

export const SectionError = ({ message, onRetry }) => (
  <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
    <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center">
      <MdErrorOutline size={22} className="text-red-400" />
    </div>
    <p className="text-sm font-semibold text-slate-600">
      Couldn't load this section
    </p>
    <p className="text-xs text-slate-400 max-w-sm">{message}</p>
    {onRetry && (
      <button
        type="button"
        onClick={onRetry}
        className="mt-1 text-xs font-semibold text-blue-600 hover:text-blue-700"
      >
        Try again
      </button>
    )}
  </div>
);

export const DetailRow = ({ label, value }) => (
  <div className="flex items-center justify-between gap-2 text-sm">
    <span className="text-slate-400 flex-shrink-0">{label}</span>
    <span className="text-slate-700 font-medium text-right truncate">
      {value ?? "—"}
    </span>
  </div>
);

export const QuickStat = ({ icon: Icon, label, value }) => (
  <div className="flex items-center gap-2.5 rounded-xl bg-slate-50 border border-slate-200 px-3.5 py-2.5">
    <Icon size={16} className="text-slate-400 flex-shrink-0" />
    <div className="min-w-0">
      <p className="text-[10px] text-slate-500 leading-tight">{label}</p>
      <p className="text-sm font-semibold text-slate-700 truncate">{value}</p>
    </div>
  </div>
);

export const MiniStat = ({ label, value, color, bg }) => (
  <div className={`rounded-lg ${bg} px-3 py-2 text-center`}>
    <p className={`text-lg font-bold ${color}`}>{value}</p>
    <p className="text-[10px] text-slate-500">{label}</p>
  </div>
);

export const IndexBadge = ({ index }) => (
  <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center text-xs font-bold flex-shrink-0 ring-1 ring-slate-200">
    {index}
  </div>
);

// ─── Pagination ─────────────────────────────────────────────────
export const Pagination = ({
  currentPage,
  totalPages,
  total,
  limit,
  onPageChange,
  loading,
}) => {
  if (!totalPages || totalPages <= 1) return null;

  const start = (currentPage - 1) * limit + 1;
  const end = Math.min(currentPage * limit, total);

  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(totalPages, startPage + maxVisible - 1);
    if (endPage - startPage + 1 < maxVisible) {
      startPage = Math.max(1, endPage - maxVisible + 1);
    }
    for (let i = startPage; i <= endPage; i += 1) pages.push(i);
    return pages;
  };

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-5 mt-2 border-t border-slate-100">
      <p className="text-xs text-slate-500">
        Showing <span className="font-semibold text-slate-700">{start}</span>
        {" – "}
        <span className="font-semibold text-slate-700">{end}</span>
        {" of "}
        <span className="font-semibold text-slate-700">{total}</span> jobs
      </p>

      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1 || loading}
          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          aria-label="Previous page"
        >
          <MdChevronLeft size={16} />
        </button>

        {getPageNumbers().map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => onPageChange(p)}
            disabled={loading}
            className={`min-w-[32px] h-8 px-2 text-xs font-semibold rounded-lg transition-colors disabled:cursor-not-allowed ${
              p === currentPage
                ? "bg-blue-600 text-white shadow-sm shadow-blue-600/20"
                : "text-slate-600 hover:bg-slate-100"
            }`}
          >
            {p}
          </button>
        ))}

        <button
          type="button"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages || loading}
          className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          aria-label="Next page"
        >
          <MdChevronRight size={16} />
        </button>
      </div>
    </div>
  );
};