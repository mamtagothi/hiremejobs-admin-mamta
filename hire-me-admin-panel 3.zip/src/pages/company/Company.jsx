﻿// import { useState, useEffect, useMemo, useCallback, useRef } from "react";
// import { useNavigate } from "react-router-dom";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import Pagination from "../../components/common/Pagination";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import companyService from "../../services/company.service";
// import { showSuccess, showError } from "../../utils/toast";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdRefresh,
//   MdVisibility,
//   MdBusiness,
//   MdPerson,
// } from "react-icons/md";
// import { useAuth } from "../../context/AuthContext";
// import { fetchUsers } from "../../utils/getUserName";

// // â”€â”€â”€ Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// const PROFILE_TYPE_PARAM = "profile_type";
// const MAX_PAGES = 500; // safety cap (500 pages Ã— API page size)
// const FETCH_CONCURRENCY = 4; // pages requested at the same time

// const PROFILE_TYPES = [
//   { key: "company", label: "Company", icon: MdBusiness },
//   { key: "consultant", label: "Consultant", icon: MdPerson },
// ];

// const STATUS_OPTIONS = [
//   { value: "active", label: "Active" },
//   { value: "inactive", label: "Inactive" },
//   { value: "blocked", label: "Blocked" },
//   { value: "pending", label: "Pending" },
// ];

// const STATUS_STYLES = {
//   active: "bg-green-50 text-green-700 border-green-200 focus:ring-green-100",
//   inactive: "bg-slate-100 text-slate-600 border-gray-200 focus:ring-gray-100",
//   blocked: "bg-red-50 text-red-700 border-red-200 focus:ring-red-100",
//   pending: "bg-amber-50 text-amber-700 border-amber-200 focus:ring-amber-100",
// };

// // â”€â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// const getImageUrl = (path) => {
//   if (!path) return null;
//   if (path.startsWith("http://") || path.startsWith("https://")) return path;
//   const base = import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";
//   return `${base}${path}`;
// };

// const parseApiDate = (dateString) => {
//   if (!dateString) return null;
//   if (dateString instanceof Date) return dateString;
//   if (typeof dateString === "string" && dateString.includes("T")) {
//     const d = new Date(dateString);
//     if (!isNaN(d)) return d;
//   }
//   const match = dateString.match(
//     /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
//   );
//   if (match) {
//     let [_, day, month, year, hours, minutes, seconds, ampm] = match;
//     hours = parseInt(hours);
//     if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
//     if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
//     return new Date(
//       parseInt(year),
//       parseInt(month) - 1,
//       parseInt(day),
//       hours,
//       parseInt(minutes),
//       parseInt(seconds),
//     );
//   }
//   const d = new Date(dateString);
//   return !isNaN(d) ? d : null;
// };

// const formatDate = (date) => {
//   if (!date) return "â€”";
//   const parsed = typeof date === "string" ? parseApiDate(date) : date;
//   if (!parsed || isNaN(parsed)) return "â€”";
//   return parsed.toLocaleDateString("en-IN", {
//     day: "2-digit",
//     month: "short",
//     year: "numeric",
//   });
// };

// // â”€â”€â”€ Response extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// const extractList = (res) => {
//   if (!res) return [];
//   if (Array.isArray(res)) return res;
//   if (Array.isArray(res.data?.data)) return res.data.data;
//   if (Array.isArray(res.data)) return res.data;
//   if (Array.isArray(res.results)) return res.results;
//   return [];
// };

// const extractPagination = (res) => {
//   if (!res) return null;
//   if (res.pagination) return res.pagination;
//   if (res.data?.pagination) return res.data.pagination;
//   return null;
// };

// const normalizeProfileType = (value) => {
//   const v = String(value || "").trim().toLowerCase();
//   return v === "consultant" ? "consultant" : "company";
// };

// // De-duplicate raw API rows by id (keeps first occurrence + API order)
// const dedupeById = (rows) => {
//   const seen = new Set();
//   const unique = [];
//   rows.forEach((item) => {
//     const id = item?.id ?? item?._id;
//     if (id == null) return;
//     const key = String(id);
//     if (!seen.has(key)) {
//       seen.add(key);
//       unique.push(item);
//     }
//   });
//   return unique;
// };

// // â”€â”€â”€ Fetch EVERY page for a given set of query params â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// // `baseParams` is {} for "everything" or { profile_type: "consultant" } etc.
// // Returns { items, apiTotal } â€” or null if the request became stale.
// //
// // Accuracy guards:
// //  â€¢ reads total / totalPages from the API's own `pagination` block
// //  â€¢ verifies the server really honoured `page` (page 2 must come back as
// //    page 2) â€” otherwise we throw a clear error instead of silently
// //    showing just the first page
// //  â€¢ fetches remaining pages in small parallel batches (no request storm)
// //  â€¢ keeps going past `totalPages` if fewer rows than `total` were received
// const fetchAllPages = async (baseParams, isStale) => {
//   const fetchPage = async (pageNo) => {
//     const res = await companyService.getAll({ page: pageNo, ...baseParams });
//     return { list: extractList(res), meta: extractPagination(res) };
//   };

//   // Step 1: page 1 â†’ discover real pagination
//   const first = await fetchPage(1);
//   if (isStale()) return null;

//   const apiLimit = Number(first.meta?.limit) || first.list.length || 20;
//   const apiTotal = Number(first.meta?.total) || first.list.length;
//   const apiTotalPages = Math.min(
//     Math.max(
//       Number(first.meta?.totalPages) || Math.ceil(apiTotal / apiLimit) || 1,
//       1,
//     ),
//     MAX_PAGES,
//   );

//   const pages = [first.list];

//   if (apiTotalPages > 1) {
//     // Step 2: probe page 2 â€” make sure the server honours `page`
//     const second = await fetchPage(2);
//     if (isStale()) return null;

//     const firstIds = new Set(first.list.map((r) => String(r?.id ?? r?._id)));
//     const metaPage = Number(second.meta?.page);
//     const pageHonoured = metaPage
//       ? metaPage === 2
//       : second.list.length === 0 ||
//         second.list.some((r) => !firstIds.has(String(r?.id ?? r?._id)));

//     if (!pageHonoured) {
//       throw new Error(
//         "The server ignored the `page` parameter, so only the first page could be loaded. " +
//           "Check getAll() in company.service.js â€” it must send { params: { page } } as a normal query string (?page=2).",
//       );
//     }
//     pages.push(second.list);

//     // Step 3: remaining pages, a few at a time
//     const remaining = [];
//     for (let p = 3; p <= apiTotalPages; p++) remaining.push(p);
//     for (let i = 0; i < remaining.length; i += FETCH_CONCURRENCY) {
//       const batch = remaining.slice(i, i + FETCH_CONCURRENCY);
//       const results = await Promise.all(batch.map((p) => fetchPage(p)));
//       if (isStale()) return null;
//       results.forEach((r) => pages.push(r.list));
//     }
//   }

//   let items = dedupeById(pages.flat());

//   // Step 4: safety net â€” if we still have fewer rows than the API's total,
//   // keep probing pages beyond totalPages until nothing new arrives.
//   let nextPage = apiTotalPages + 1;
//   while (items.length < apiTotal && nextPage <= MAX_PAGES) {
//     const r = await fetchPage(nextPage);
//     if (isStale()) return null;
//     const before = items.length;
//     items = dedupeById([...items, ...r.list]);
//     if (r.list.length === 0 || items.length === before) break;
//     nextPage++;
//   }

//   return { items, apiTotal };
// };

// const Companies = () => {
//   const navigate = useNavigate();
//   const { user } = useAuth();
//   const userId = user?.id || 1;

//   const [profileTab, setProfileTab] = useState("company");
//   const [page, setPage] = useState(1);
//   const [pageSize, setPageSize] = useState(20);

//   const [search, setSearch] = useState("");
//   const [debouncedSearch, setDebouncedSearch] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");

//   // â”€â”€â”€ Store the two datasets separately â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const [companiesData, setCompaniesData] = useState([]);
//   const [consultantsData, setConsultantsData] = useState([]);

//   const [loading, setLoading] = useState(true);
//   const [deleteId, setDeleteId] = useState(null);
//   const [deleteLoading, setDeleteLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [userNameCache, setUserNameCache] = useState({});
//   const [statusUpdatingId, setStatusUpdatingId] = useState(null);

//   const requestIdRef = useRef(0);

//   // â”€â”€â”€ Debounce search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     const t = setTimeout(() => {
//       setDebouncedSearch(search.trim());
//       setPage(1);
//     }, 400);
//     return () => clearTimeout(t);
//   }, [search]);

//   useEffect(() => {
//     setPage(1);
//   }, [statusFilter, profileTab]);

//   // â”€â”€â”€ Load users for "Updated By" â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     const loadUsers = async () => {
//       try {
//         const users = await fetchUsers();
//         setUserNameCache(users || {});
//       } catch (err) {
//         console.error("Failed to load users:", err);
//       }
//     };
//     loadUsers();
//   }, []);

//   const getUserNameCached = (id) => {
//     if (!id) return "-";
//     return userNameCache[id]?.name || `User ${id}`;
//   };

//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     if (row.updated_by_name) return row.updated_by_name;
//     return row.updated_by ? getUserNameCached(row.updated_by) : "-";
//   };

//   const normalizeCompany = (item) => ({
//     id: item.id,
//     company_name: item.company_name || "",
//     slug: item.slug || "",
//     logo: item.logo || null,
//     banner_image: item.banner_image || null,
//     website: item.website || "",
//     founded_year: item.founded_year || "",
//     about_company: item.about_company || "",
//     gst_number: item.gst_number || "",
//     company_status: item.company_status || "inactive",
//     profile_type: normalizeProfileType(item.profile_type),
//     is_status:
//       item.is_status === true ||
//       item.is_status === "true" ||
//       item.is_status === 1,
//     is_trending:
//       item.is_trending === true ||
//       item.is_trending === "true" ||
//       item.is_trending === 1,
//     profile_completion_percentage: item.profile_completion_percentage || "0.00",
//     created_by: item.created_by || null,
//     updated_by: item.updated_by || null,
//     updated_by_name:
//       item.Company?.CompanyUser?.full_name ||
//       item.CompanyUser?.full_name ||
//       item.updated_by_name ||
//       null,
//     created_at: item.created_at || null,
//     updated_at: item.updated_at || null,
//     industry_name:
//       item.Industry?.industry_name ||
//       item.Industry?.name ||
//       item.industry_name ||
//       null,
//     Industries: item.Industries || [],
//     SubIndustries: item.SubIndustries || [],
//     company_size_name:
//       item.CompanySize?.company_size_name ||
//       item.CompanySize?.name ||
//       item.company_size_name ||
//       null,
//     company_user_email:
//       item.CompanyUser?.company_user_email ||
//       item.CompanyUser?.email ||
//       item.company_user_email ||
//       null,
//     reference_code: item.reference_code || item.referenceCode || null,
//   });

//   // â”€â”€â”€ Load EVERY company + consultant â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   // The un-filtered list is the source of truth (it can't miss rows whose
//   // profile_type is empty / unexpected). The two typed requests are merged in
//   // as well, so a row can never be lost whichever way the API filters.
//   // Rows are then split by their own `profile_type` (anything that is not
//   // "consultant" counts as a company) â†’ Company + Consultant = all rows.
//   const load = useCallback(async () => {
//     const requestId = ++requestIdRef.current;
//     const isStale = () => requestIdRef.current !== requestId;

//     setLoading(true);
//     setError(null);

//     try {
//       const [allRes, companyRes, consultantRes] = await Promise.all([
//         fetchAllPages({}, isStale),
//         fetchAllPages({ [PROFILE_TYPE_PARAM]: "company" }, isStale),
//         fetchAllPages({ [PROFILE_TYPE_PARAM]: "consultant" }, isStale),
//       ]);

//       if (isStale() || !allRes || !companyRes || !consultantRes) return;

//       const merged = dedupeById([
//         ...allRes.items,
//         ...companyRes.items,
//         ...consultantRes.items,
//       ]);

//       const normalized = merged.map(normalizeCompany);
//       const companiesNormalized = normalized.filter(
//         (c) => c.profile_type === "company",
//       );
//       const consultantsNormalized = normalized.filter(
//         (c) => c.profile_type === "consultant",
//       );

//       console.log("[Companies] API totals:", {
//         all: allRes.apiTotal,
//         company: companyRes.apiTotal,
//         consultant: consultantRes.apiTotal,
//       });
//       console.log("[Companies] loaded:", {
//         unique: normalized.length,
//         companies: companiesNormalized.length,
//         consultants: consultantsNormalized.length,
//       });

//       setCompaniesData(companiesNormalized);
//       setConsultantsData(consultantsNormalized);
//     } catch (err) {
//       if (isStale()) return;
//       console.error("Load error:", err);
//       let errorMessage = "Failed to load companies";
//       if (
//         err.message?.includes("NetworkError") ||
//         err.message?.includes("Failed to fetch")
//       ) {
//         errorMessage = "Network error: Unable to connect to the server.";
//       } else if (err.status === 401 || err.status === 403) {
//         errorMessage = "Access denied. Please log in again.";
//       } else if (err.status === 404) {
//         errorMessage = "API endpoint not found. Please check the API URL.";
//       } else if (err.message) {
//         errorMessage = err.message;
//       }
//       setError(errorMessage);
//       showError(errorMessage);
//     } finally {
//       if (!isStale()) setLoading(false);
//     }
//   }, []);

//   useEffect(() => {
//     load();
//     return () => {
//       requestIdRef.current++;
//     };
//   }, [load]);

//   // â”€â”€â”€ Data for the currently active tab â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const currentData = useMemo(
//     () => (profileTab === "company" ? companiesData : consultantsData),
//     [profileTab, companiesData, consultantsData],
//   );

//   // â”€â”€â”€ Filter + paginate client-side â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const filteredData = useMemo(() => {
//     let result = currentData;

//     if (statusFilter === "trending") {
//       result = result.filter((c) => c.is_trending);
//     } else if (statusFilter !== "all") {
//       result = result.filter((c) => c.company_status === statusFilter);
//     }

//     if (debouncedSearch) {
//       const q = debouncedSearch.toLowerCase();
//       result = result.filter((c) =>
//         (c.company_name || "").toLowerCase().includes(q),
//       );
//     }

//     return result;
//   }, [currentData, statusFilter, debouncedSearch]);

//   const total = filteredData.length;

//   // Keep the page valid (e.g. after a delete / filter shrinks the list)
//   const totalPages = Math.max(1, Math.ceil(total / pageSize));
//   const safePage = Math.min(Math.max(page, 1), totalPages);

//   useEffect(() => {
//     if (page !== safePage) setPage(safePage);
//   }, [page, safePage]);

//   const paginatedData = useMemo(() => {
//     const start = (safePage - 1) * pageSize;
//     return filteredData.slice(start, start + pageSize);
//   }, [filteredData, safePage, pageSize]);

//   // â”€â”€â”€ Tab counts â€” accurate because each dataset is type-scoped â”€
//   const statusCounts = useMemo(() => {
//     const build = (items) => {
//       return {
//         all: items.length,
//         active: items.filter((c) => c.company_status === "active").length,
//         inactive: items.filter((c) => c.company_status === "inactive").length,
//         blocked: items.filter((c) => c.company_status === "blocked").length,
//         pending: items.filter((c) => c.company_status === "pending").length,
//         trending: items.filter((c) => c.is_trending).length,
//       };
//     };

//     return {
//       company: build(companiesData),
//       consultant: build(consultantsData),
//     };
//   }, [companiesData, consultantsData]);

//   // â”€â”€â”€ Handlers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const handleProfileTabChange = (key) => {
//     if (key === profileTab) return;
//     setProfileTab(key);
//     setStatusFilter("all");
//   };

//   const refreshAll = () => {
//     load();
//   };

//   // Patch one row (ids are unique across both datasets)
//   const patchItem = (id, patch) => {
//     const apply = (prev) =>
//       prev.map((c) => (c.id === id ? { ...c, ...patch } : c));
//     setCompaniesData(apply);
//     setConsultantsData(apply);
//   };

//   const handleCompanyStatusChange = async (id, newStatus) => {
//     const prevStatus = currentData.find((c) => c.id === id)?.company_status;

//     patchItem(id, { company_status: newStatus });
//     setStatusUpdatingId(id);

//     try {
//       await companyService.update(id, {
//         company_status: newStatus,
//         updated_by: userId,
//       });
//       showSuccess(`Company status updated to ${newStatus}`);
//     } catch (err) {
//       patchItem(id, { company_status: prevStatus });
//       showError(err.message || "Failed to update status");
//     } finally {
//       setStatusUpdatingId(null);
//     }
//   };

//   const handleTrendingToggle = async (id, currentTrending) => {
//     const newTrending = !currentTrending;

//     patchItem(id, { is_trending: newTrending });

//     try {
//       await companyService.update(id, {
//         is_trending: newTrending,
//         updated_by: userId,
//       });
//       showSuccess(`Trending updated to ${newTrending ? "Yes" : "No"}`);
//     } catch (err) {
//       patchItem(id, { is_trending: currentTrending });
//       showError(err.message || "Failed to update trending");
//     }
//   };

//   const openAdd = () => navigate("/companies/add");
//   const openEdit = (item) => navigate(`/companies/edit/${item.id}`);
//   const openView = (item) => navigate(`/companies/view/${item.id}`);

//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       await companyService.delete(deleteId);
//       showSuccess("Company deleted successfully");
//       // Remove locally then reload for accuracy
//       const removeItem = (prev) => prev.filter((c) => c.id !== deleteId);
//       setCompaniesData(removeItem);
//       setConsultantsData(removeItem);
//       load();
//     } catch (err) {
//       console.error("Delete error:", err);
//       showError(err.message || "Failed to delete company");
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   // Filter-row counts = TOTAL across both profile tabs (companies + consultants)
//   const sumCounts = (key) =>
//     (statusCounts.company?.[key] ?? 0) + (statusCounts.consultant?.[key] ?? 0);
//   const activeCounts = {
//     all: sumCounts("all"),
//     active: sumCounts("active"),
//     inactive: sumCounts("inactive"),
//     blocked: sumCounts("blocked"),
//     pending: sumCounts("pending"),
//     trending: sumCounts("trending"),
//   };
//   // Keep the Trending tab visible while it is the selected filter
//   const hasTrending = activeCounts.trending > 0 || statusFilter === "trending";
//   const tabs = [
//     { key: "all", label: "All", count: activeCounts.all },
//     { key: "active", label: "Active", count: activeCounts.active },
//     { key: "inactive", label: "Inactive", count: activeCounts.inactive },
//     { key: "blocked", label: "Blocked", count: activeCounts.blocked },
//     { key: "pending", label: "Pending", count: activeCounts.pending },
//     ...(hasTrending
//       ? [{ key: "trending", label: "Trending", count: activeCounts.trending }]
//       : []),
//   ];

//   // â”€â”€â”€ Table Columns â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (safePage - 1) * pageSize + i + 1,
//     },
//     {
//       header: "Logo",
//       key: "logo",
//       render: (logo) =>
//         logo ? (
//           <img
//             src={getImageUrl(logo)}
//             alt="logo"
//             className="w-9 h-9 object-cover rounded border border-slate-200"
//             onError={(e) => {
//               e.target.style.display = "none";
//             }}
//           />
//         ) : (
//           <div className="w-9 h-9 rounded border border-slate-200 bg-slate-50 flex items-center justify-center text-gray-300">
//             <svg
//               width="16"
//               height="16"
//               viewBox="0 0 24 24"
//               fill="none"
//               stroke="currentColor"
//               strokeWidth="2"
//             >
//               <rect x="3" y="3" width="18" height="18" rx="2" />
//               <circle cx="8.5" cy="8.5" r="1.5" />
//               <path d="M21 15l-5-5L5 21" />
//             </svg>
//           </div>
//         ),
//     },
//     {
//       header: profileTab === "consultant" ? "Consultant" : "Company",
//       key: "company_name",
//       render: (v, row) => (
//         <div>
//           <span className="font-medium text-slate-800">{v}</span>
//           <div className="text-xs text-slate-400">{row.slug}</div>
//           {row.reference_code && (
//             <div className="text-xs text-slate-400 font-mono">
//               Ref: {row.reference_code}
//             </div>
//           )}
//         </div>
//       ),
//     },
//     {
//       header: "Email",
//       key: "company_user_email",
//       render: (v) => <span className="text-sm text-slate-500">{v || "â€”"}</span>,
//     },
//     {
//       header: "Industries",
//       key: "Industries",
//       render: (_, row) => {
//         const industries = row.Industries || [];
//         if (!industries || industries.length === 0) {
//           return <span className="text-sm text-slate-400">â€”</span>;
//         }
//         return (
//           <div className="flex flex-wrap gap-1.5">
//             {industries.map((ind, idx) => (
//               <span
//                 key={idx}
//                 className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200"
//                 title={ind.industry_name || ind.name}
//               >
//                 <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
//                 {ind.industry_name || ind.name || "Unknown"}
//               </span>
//             ))}
//           </div>
//         );
//       },
//     },
//     {
//       header: "Size",
//       key: "company_size_name",
//       render: (v) => <span className="text-sm text-slate-500">{v || "â€”"}</span>,
//     },
//     {
//       header: "Trending",
//       key: "is_trending",
//       render: (is_trending, row) => (
//         <button
//           onClick={() => handleTrendingToggle(row.id, is_trending)}
//           className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//             is_trending ? "bg-amber-500" : "bg-gray-300"
//           }`}
//         >
//           <span
//             className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//               is_trending ? "translate-x-6" : "translate-x-1"
//             }`}
//           />
//         </button>
//       ),
//     },
//     {
//       header: "Status",
//       key: "company_status",
//       render: (status, row) => (
//         <select
//           value={status}
//           disabled={statusUpdatingId === row.id}
//           onChange={(e) => handleCompanyStatusChange(row.id, e.target.value)}
//           className={`text-xs font-medium px-2.5 py-1.5 rounded-lg border focus:outline-none focus:ring-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors ${
//             STATUS_STYLES[status] || STATUS_STYLES.inactive
//           }`}
//         >
//           {STATUS_OPTIONS.map((opt) => (
//             <option key={opt.value} value={opt.value}>
//               {opt.label}
//             </option>
//           ))}
//         </select>
//       ),
//     },
//     {
//       header: "Updated By",
//       key: "updated_by",
//       render: (_, row) => (
//         <div className="flex items-center gap-1.5">
//           <span className="text-slate-600 text-sm font-medium">
//             {getUpdatedByName(row)}
//           </span>
//         </div>
//       ),
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => (
//         <div className="flex gap-1">
//           <button
//             onClick={() => openView(row)}
//             className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors text-sm font-medium whitespace-nowrap"
//             title="View Company Details"
//           >
//             <MdVisibility size={16} />
//             <span>View Company Details</span>
//           </button>
//           <button
//             onClick={() => openEdit(row)}
//             className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"
//             title="Edit"
//           >
//             <MdEdit size={16} />
//           </button>
//           <button
//             onClick={() => setDeleteId(id)}
//             className="p-1.5 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
//             title="Delete"
//           >
//             <MdDelete size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   if (error) {
//     return (
//       <div className="space-y-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Companies</h1>
//           <p className="text-sm text-slate-500 mt-1">
//             Manage registered companies
//           </p>
//         </div>
//         <div className="bg-white rounded-xl border border-red-200 shadow-sm overflow-hidden p-8 text-center">
//           <h3 className="text-lg font-medium text-slate-900 mb-2">
//             Failed to Load Companies
//           </h3>
//           <p className="text-slate-600 max-w-md mx-auto whitespace-pre-line">
//             {error}
//           </p>
//           <button
//             onClick={() => load()}
//             className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
//           >
//             Retry
//           </button>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-4">
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Companies</h1>
//           <p className="text-sm text-slate-500 mt-1">
//             Manage registered companies and consultants
//           </p>
//         </div>
//         <div className="flex items-center gap-2">
//           <Button
//             variant="secondary"
//             icon={MdRefresh}
//             onClick={refreshAll}
//             loading={loading}
//           >
//             Refresh
//           </Button>
//           <Button icon={MdAdd} onClick={openAdd}>
//             Add Company
//           </Button>
//         </div>
//       </div>

//       {/* Top-level Company / Consultant tabs */}
//       <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl w-full sm:w-fit">
//         {PROFILE_TYPES.map(({ key, label, icon: Icon }) => {
//           const isActive = profileTab === key;
//           const count = statusCounts[key]?.all ?? 0;
//           return (
//             <button
//               key={key}
//               onClick={() => handleProfileTabChange(key)}
//               className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all flex-1 sm:flex-initial ${
//                 isActive
//                   ? "bg-white text-blue-600 shadow-sm"
//                   : "text-slate-500 hover:text-slate-700"
//               }`}
//             >
//               <Icon size={16} />
//               {label}
//               <span
//                 className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                   isActive
//                     ? "bg-blue-50 text-blue-600"
//                     : "bg-gray-200 text-slate-500"
//                 }`}
//               >
//                 {count}
//               </span>
//             </button>
//           );
//         })}
//       </div>

//       {/* Table Card */}
//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-slate-100">
//           <div className="relative w-full sm:w-72">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder={`Search ${
//                 profileTab === "consultant" ? "consultants" : "companies"
//               }...`}
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-colors"
//             />
//           </div>

//           <div className="flex items-center gap-5 text-sm flex-wrap">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${
//                   statusFilter === tab.key
//                     ? tab.key === "trending"
//                       ? "text-amber-600"
//                       : "text-blue-600"
//                     : "text-slate-500 hover:text-slate-700"
//                 }`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                     statusFilter === tab.key
//                       ? tab.key === "trending"
//                         ? "bg-amber-50 text-amber-600"
//                         : "bg-blue-50 text-blue-600"
//                       : "bg-slate-100 text-slate-500"
//                   }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={paginatedData}
//           loading={loading}
//           emptyMessage={
//             profileTab === "consultant"
//               ? "No consultants found"
//               : "No companies found"
//           }
//         />

//         <div className="px-5 py-3 border-t border-slate-100">
//           <Pagination
//             page={safePage}
//             total={total}
//             limit={pageSize}
//             itemsCount={paginatedData.length}
//             onChange={setPage}
//           />
//         </div>
//       </div>

//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Company"
//         message="Delete this company? This action cannot be undone."
//       />
//     </div>
//   );
// };

// export default Companies;

import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import companyService from "../../services/company.service";
import { showSuccess, showError } from "../../utils/toast";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdRefresh,
  MdVisibility,
  MdBusiness,
  MdPerson,
} from "react-icons/md";
import { useAuth } from "../../context/AuthContext";
import { fetchUsers } from "../../utils/getUserName";
import CompanyJobsBadge from "./CompanyJobsBadge";

// â”€â”€â”€ Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const PROFILE_TYPE_PARAM = "profile_type";
const MAX_PAGES = 500; // safety cap (500 pages Ã— API page size)
const FETCH_CONCURRENCY = 4; // pages requested at the same time

const PROFILE_TYPES = [
  { key: "company", label: "Company", icon: MdBusiness },
  { key: "consultant", label: "Consultant", icon: MdPerson },
];

const STATUS_OPTIONS = [
  { value: "active", label: "Active" },
  { value: "inactive", label: "Inactive" },
  { value: "blocked", label: "Blocked" },
  { value: "pending", label: "Pending" },
];

const STATUS_STYLES = {
  active: "bg-green-50 text-green-700 border-green-200 focus:ring-green-100",
  inactive: "bg-slate-100 text-slate-600 border-gray-200 focus:ring-gray-100",
  blocked: "bg-red-50 text-red-700 border-red-200 focus:ring-red-100",
  pending: "bg-amber-50 text-amber-700 border-amber-200 focus:ring-amber-100",
};

// â”€â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const getImageUrl = (path) => {
  if (!path) return null;
  if (path.startsWith("http://") || path.startsWith("https://")) return path;
  const base = import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";
  return `${base}${path}`;
};

const parseApiDate = (dateString) => {
  if (!dateString) return null;
  if (dateString instanceof Date) return dateString;
  if (typeof dateString === "string" && dateString.includes("T")) {
    const d = new Date(dateString);
    if (!isNaN(d)) return d;
  }
  const match = dateString.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2}):(\d{2})\s*(am|pm)$/i,
  );
  if (match) {
    let [_, day, month, year, hours, minutes, seconds, ampm] = match;
    hours = parseInt(hours);
    if (ampm.toLowerCase() === "pm" && hours < 12) hours += 12;
    if (ampm.toLowerCase() === "am" && hours === 12) hours = 0;
    return new Date(
      parseInt(year),
      parseInt(month) - 1,
      parseInt(day),
      hours,
      parseInt(minutes),
      parseInt(seconds),
    );
  }
  const d = new Date(dateString);
  return !isNaN(d) ? d : null;
};

const formatDate = (date) => {
  if (!date) return "â€”";
  const parsed = typeof date === "string" ? parseApiDate(date) : date;
  if (!parsed || isNaN(parsed)) return "â€”";
  return parsed.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

// â”€â”€â”€ Response extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const extractList = (res) => {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.data?.data)) return res.data.data;
  if (Array.isArray(res.data)) return res.data;
  if (Array.isArray(res.results)) return res.results;
  return [];
};

const extractPagination = (res) => {
  if (!res) return null;
  if (res.pagination) return res.pagination;
  if (res.data?.pagination) return res.data.pagination;
  return null;
};

const normalizeProfileType = (value) => {
  const v = String(value || "").trim().toLowerCase();
  return v === "consultant" ? "consultant" : "company";
};

// De-duplicate raw API rows by id (keeps first occurrence + API order)
const dedupeById = (rows) => {
  const seen = new Set();
  const unique = [];
  rows.forEach((item) => {
    const id = item?.id ?? item?._id;
    if (id == null) return;
    const key = String(id);
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(item);
    }
  });
  return unique;
};

// â”€â”€â”€ Fetch EVERY page for a given set of query params â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// `baseParams` is {} for "everything" or { profile_type: "consultant" } etc.
// Returns { items, apiTotal } â€” or null if the request became stale.
//
// Accuracy guards:
//  â€¢ reads total / totalPages from the API's own `pagination` block
//  â€¢ verifies the server really honoured `page` (page 2 must come back as
//    page 2) â€” otherwise we throw a clear error instead of silently
//    showing just the first page
//  â€¢ fetches remaining pages in small parallel batches (no request storm)
//  â€¢ keeps going past `totalPages` if fewer rows than `total` were received
const fetchAllPages = async (baseParams, isStale) => {
  const fetchPage = async (pageNo) => {
    const res = await companyService.getAll({ page: pageNo, ...baseParams });
    return { list: extractList(res), meta: extractPagination(res) };
  };

  // Step 1: page 1 â†’ discover real pagination
  const first = await fetchPage(1);
  if (isStale()) return null;

  const apiLimit = Number(first.meta?.limit) || first.list.length || 20;
  const apiTotal = Number(first.meta?.total) || first.list.length;
  const apiTotalPages = Math.min(
    Math.max(
      Number(first.meta?.totalPages) || Math.ceil(apiTotal / apiLimit) || 1,
      1,
    ),
    MAX_PAGES,
  );

  const pages = [first.list];

  if (apiTotalPages > 1) {
    // Step 2: probe page 2 â€” make sure the server honours `page`
    const second = await fetchPage(2);
    if (isStale()) return null;

    const firstIds = new Set(first.list.map((r) => String(r?.id ?? r?._id)));
    const metaPage = Number(second.meta?.page);
    const pageHonoured = metaPage
      ? metaPage === 2
      : second.list.length === 0 ||
        second.list.some((r) => !firstIds.has(String(r?.id ?? r?._id)));

    if (!pageHonoured) {
      throw new Error(
        "The server ignored the `page` parameter, so only the first page could be loaded. " +
          "Check getAll() in company.service.js â€” it must send { params: { page } } as a normal query string (?page=2).",
      );
    }
    pages.push(second.list);

    // Step 3: remaining pages, a few at a time
    const remaining = [];
    for (let p = 3; p <= apiTotalPages; p++) remaining.push(p);
    for (let i = 0; i < remaining.length; i += FETCH_CONCURRENCY) {
      const batch = remaining.slice(i, i + FETCH_CONCURRENCY);
      const results = await Promise.all(batch.map((p) => fetchPage(p)));
      if (isStale()) return null;
      results.forEach((r) => pages.push(r.list));
    }
  }

  let items = dedupeById(pages.flat());

  // Step 4: safety net â€” if we still have fewer rows than the API's total,
  // keep probing pages beyond totalPages until nothing new arrives.
  let nextPage = apiTotalPages + 1;
  while (items.length < apiTotal && nextPage <= MAX_PAGES) {
    const r = await fetchPage(nextPage);
    if (isStale()) return null;
    const before = items.length;
    items = dedupeById([...items, ...r.list]);
    if (r.list.length === 0 || items.length === before) break;
    nextPage++;
  }

  return { items, apiTotal };
};

// â”€â”€â”€ Normalize one API row â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const normalizeCompany = (item) => ({
  id: item.id,
  company_name: item.company_name || "",
  slug: item.slug || "",
  logo: item.logo || null,
  banner_image: item.banner_image || null,
  website: item.website || "",
  founded_year: item.founded_year || "",
  about_company: item.about_company || "",
  gst_number: item.gst_number || "",
  company_status: item.company_status || "inactive",
  profile_type: normalizeProfileType(item.profile_type),
  is_status:
    item.is_status === true || item.is_status === "true" || item.is_status === 1,
  is_trending:
    item.is_trending === true ||
    item.is_trending === "true" ||
    item.is_trending === 1,
  profile_completion_percentage: item.profile_completion_percentage || "0.00",
  created_by: item.created_by || null,
  updated_by: item.updated_by || null,
  updated_by_name:
    item.Company?.CompanyUser?.full_name ||
    item.CompanyUser?.full_name ||
    item.updated_by_name ||
    null,
  created_at: item.created_at || null,
  updated_at: item.updated_at || null,
  industry_name:
    item.Industry?.industry_name ||
    item.Industry?.name ||
    item.industry_name ||
    null,
  Industries: item.Industries || [],
  SubIndustries: item.SubIndustries || [],
  company_size_name:
    item.CompanySize?.company_size_name ||
    item.CompanySize?.name ||
    item.company_size_name ||
    null,
  company_user_email:
    item.CompanyUser?.company_user_email ||
    item.CompanyUser?.email ||
    item.company_user_email ||
    null,
  reference_code: item.reference_code || item.referenceCode || null,
});

const describeError = (err) => {
  let errorMessage = "Failed to load companies";
  if (
    err?.message?.includes("NetworkError") ||
    err?.message?.includes("Failed to fetch")
  ) {
    errorMessage = "Network error: Unable to connect to the server.";
  } else if (err?.status === 401 || err?.status === 403) {
    errorMessage = "Access denied. Please log in again.";
  } else if (err?.status === 404) {
    errorMessage = "API endpoint not found. Please check the API URL.";
  } else if (err?.message) {
    errorMessage = err.message;
  }
  return errorMessage;
};

const EMPTY_PAGES = { company: {}, consultant: {} };
const EMPTY_TOTALS = { company: null, consultant: null };
const EMPTY_FULL = { company: null, consultant: null };

const Companies = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const userId = user?.id || 1;

  const [profileTab, setProfileTab] = useState("company");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // â”€â”€â”€ Server-paginated data â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // pagesByType[type][pageNo] = rows of that ONE page (fetched only when
  // the user opens that page, then cached). totals[type] = API total.
  const [pagesByType, setPagesByType] = useState(EMPTY_PAGES);
  const [totals, setTotals] = useState(EMPTY_TOTALS);

  // â”€â”€â”€ Full dataset (loaded ONLY when a status filter / search is used,
  //     because those need every row to be accurate) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [fullData, setFullData] = useState(EMPTY_FULL);

  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [error, setError] = useState(null);
  const [userNameCache, setUserNameCache] = useState({});
  const [statusUpdatingId, setStatusUpdatingId] = useState(null);

  const epochRef = useRef(0); // bumped on refresh â†’ ignores old responses
  const inflightRef = useRef(new Set()); // "type:page" currently loading
  const fullPromiseRef = useRef(null); // full load currently running

  // â”€â”€â”€ Debounce search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    setPage(1);
  }, [statusFilter, profileTab]);

  // â”€â”€â”€ Load users for "Updated By" â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    const loadUsers = async () => {
      try {
        const users = await fetchUsers();
        setUserNameCache(users || {});
      } catch (err) {
        console.error("Failed to load users:", err);
      }
    };
    loadUsers();
  }, []);

  const getUserNameCached = (id) => {
    if (!id) return "-";
    return userNameCache[id]?.name || `User ${id}`;
  };

  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by_name) return row.updated_by_name;
    return row.updated_by ? getUserNameCached(row.updated_by) : "-";
  };

  const handleLoadError = useCallback((err) => {
    console.error("Load error:", err);
    const message = describeError(err);
    setError(message);
    showError(message);
  }, []);

  // â”€â”€â”€ Load ONE page of ONE profile type (only when needed) â”€â”€â”€â”€â”€â”€
  const loadPage = useCallback(
    async (type, pageNo) => {
      const key = `${type}:${pageNo}`;
      if (inflightRef.current.has(key)) return;
      inflightRef.current.add(key);
      const epoch = epochRef.current;

      try {
        const res = await companyService.getAll({
          page: pageNo,
          [PROFILE_TYPE_PARAM]: type,
        });
        if (epochRef.current !== epoch) return;

        const meta = extractPagination(res);
        const metaPage = Number(meta?.page);
        if (metaPage && metaPage !== pageNo) {
          throw new Error(
            "The server ignored the `page` parameter. Check getAll() in company.service.js â€” it must send { params: { page } } as a normal query string (?page=2).",
          );
        }

        const rows = dedupeById(extractList(res)).map(normalizeCompany);
        const apiTotal =
          meta?.total != null && !isNaN(Number(meta.total))
            ? Number(meta.total)
            : null;
        const apiLimit = Number(meta?.limit);

        setPagesByType((prev) => ({
          ...prev,
          [type]: { ...prev[type], [pageNo]: rows },
        }));
        setTotals((prev) => ({
          ...prev,
          [type]: apiTotal ?? prev[type] ?? rows.length,
        }));
        if (apiLimit > 0) setPageSize(apiLimit);
      } catch (err) {
        if (epochRef.current === epoch) handleLoadError(err);
      } finally {
        if (epochRef.current === epoch) inflightRef.current.delete(key);
      }
    },
    [handleLoadError],
  );

  // â”€â”€â”€ Load EVERY row of both types (filters / search / status counts) â”€
  const ensureFullData = useCallback(async () => {
    if (fullPromiseRef.current) return;
    const epoch = epochRef.current;
    const isStale = () => epochRef.current !== epoch;

    const run = (async () => {
      try {
        const [companies, consultants] = await Promise.all([
          fetchAllPages({ [PROFILE_TYPE_PARAM]: "company" }, isStale),
          fetchAllPages({ [PROFILE_TYPE_PARAM]: "consultant" }, isStale),
        ]);
        if (isStale() || !companies || !consultants) return;

        console.log("[Companies] full data loaded:", {
          companies: companies.items.length,
          consultants: consultants.items.length,
          apiTotals: {
            company: companies.apiTotal,
            consultant: consultants.apiTotal,
          },
        });

        setFullData({
          company: companies.items.map(normalizeCompany),
          consultant: consultants.items.map(normalizeCompany),
        });
      } catch (err) {
        if (!isStale()) handleLoadError(err);
      }
    })();

    fullPromiseRef.current = run;
  }, [handleLoadError]);

  // â”€â”€â”€ Are we in "filtered" mode? â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const filterActive = statusFilter !== "all" || !!debouncedSearch;

  const typeTotal = (type) =>
    fullData[type] ? fullData[type].length : totals[type];

  const total = filterActive ? null : totals[profileTab];
  // (filtered total is computed below once filteredData exists)

  // â”€â”€â”€ Client-side filter â€” ONLY used in filtered mode â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const filteredData = useMemo(() => {
    if (!filterActive) return [];
    let result = fullData[profileTab] || [];

    if (statusFilter === "trending") {
      result = result.filter((c) => c.is_trending);
    } else if (statusFilter !== "all") {
      result = result.filter((c) => c.company_status === statusFilter);
    }

    if (debouncedSearch) {
      const q = debouncedSearch.toLowerCase();
      result = result.filter((c) =>
        (c.company_name || "").toLowerCase().includes(q),
      );
    }

    return result;
  }, [filterActive, fullData, profileTab, statusFilter, debouncedSearch]);

  const fullReady = !!fullData.company && !!fullData.consultant;

  // Total rows for the pagination footer (null while unknown)
  const viewTotal = filterActive
    ? fullData[profileTab]
      ? filteredData.length
      : null
    : total;

  // Keep the page valid (e.g. after a delete / filter shrinks the list)
  const totalPages =
    viewTotal == null ? 1 : Math.max(1, Math.ceil(viewTotal / pageSize));
  const safePage =
    viewTotal == null
      ? Math.max(page, 1)
      : Math.min(Math.max(page, 1), totalPages);

  useEffect(() => {
    if (page !== safePage) setPage(safePage);
  }, [page, safePage]);

  // â”€â”€â”€ Fetch only what the screen needs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // 1) the page being viewed (normal mode)
  // 2) page 1 of each type once, just to learn the totals for the badges
  useEffect(() => {
    if (error) return;

    if (!filterActive && !pagesByType[profileTab][safePage]) {
      loadPage(profileTab, safePage);
    }
    ["company", "consultant"].forEach((type) => {
      if (totals[type] === null && !fullData[type]) loadPage(type, 1);
    });
  }, [
    error,
    filterActive,
    profileTab,
    safePage,
    pagesByType,
    totals,
    fullData,
    loadPage,
  ]);

  // 3) load full data to have accurate status counts for tabs
  useEffect(() => {
    if (error || fullReady) return;
    ensureFullData();
  }, [error, fullReady, ensureFullData]);

  // â”€â”€â”€ The rows shown in the table â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const paginatedData = useMemo(() => {
    if (!filterActive) return pagesByType[profileTab][safePage] || [];
    const start = (safePage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filterActive, pagesByType, profileTab, safePage, pageSize, filteredData]);

  const loading =
    !error &&
    (filterActive ? !fullData[profileTab] : !pagesByType[profileTab][safePage]);

  // â”€â”€â”€ Status counts (need every row â†’ available once fullData is loaded) â”€
  const statusCounts = useMemo(() => {
    if (!fullData.company || !fullData.consultant) return null;
    const build = (items) => ({
      all: items.length,
      active: items.filter((c) => c.company_status === "active").length,
      inactive: items.filter((c) => c.company_status === "inactive").length,
      blocked: items.filter((c) => c.company_status === "blocked").length,
      pending: items.filter((c) => c.company_status === "pending").length,
      trending: items.filter((c) => c.is_trending).length,
    });
    return {
      company: build(fullData.company),
      consultant: build(fullData.consultant),
    };
  }, [fullData]);

  // â”€â”€â”€ Handlers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const handleProfileTabChange = (key) => {
    if (key === profileTab) return;
    setProfileTab(key);
    setStatusFilter("all");
  };

  // Throw everything away and load again (Refresh / after delete)
  const refreshAll = () => {
    epochRef.current++;
    inflightRef.current.clear();
    fullPromiseRef.current = null;
    setError(null);
    setPagesByType(EMPTY_PAGES);
    setTotals(EMPTY_TOTALS);
    setFullData(EMPTY_FULL);
  };

  // Patch one row everywhere it is cached (ids are unique across types)
  const patchItem = (id, patch) => {
    const apply = (rows) =>
      rows.map((c) => (c.id === id ? { ...c, ...patch } : c));
    const applyPages = (pages) =>
      Object.fromEntries(
        Object.entries(pages).map(([k, rows]) => [k, apply(rows)]),
      );

    setPagesByType((prev) => ({
      company: applyPages(prev.company),
      consultant: applyPages(prev.consultant),
    }));
    setFullData((prev) => ({
      company: prev.company ? apply(prev.company) : null,
      consultant: prev.consultant ? apply(prev.consultant) : null,
    }));
  };

  const handleCompanyStatusChange = async (id, newStatus) => {
    const prevStatus = paginatedData.find((c) => c.id === id)?.company_status;

    patchItem(id, { company_status: newStatus });
    setStatusUpdatingId(id);

    try {
      await companyService.update(id, {
        company_status: newStatus,
        updated_by: userId,
      });
      showSuccess(`Company status updated to ${newStatus}`);
    } catch (err) {
      patchItem(id, { company_status: prevStatus });
      showError(err.message || "Failed to update status");
    } finally {
      setStatusUpdatingId(null);
    }
  };

  const handleTrendingToggle = async (id, currentTrending) => {
    const newTrending = !currentTrending;

    patchItem(id, { is_trending: newTrending });

    try {
      await companyService.update(id, {
        is_trending: newTrending,
        updated_by: userId,
      });
      showSuccess(`Trending updated to ${newTrending ? "Yes" : "No"}`);
    } catch (err) {
      patchItem(id, { is_trending: currentTrending });
      showError(err.message || "Failed to update trending");
    }
  };

  const openAdd = () => navigate("/companies/add");
  const openEdit = (item) => navigate(`/companies/edit/${item.id}`);
  const openView = (item) => navigate(`/companies/view/${item.id}`);

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await companyService.delete(deleteId);
      showSuccess("Company deleted successfully");
      // page boundaries shift after a delete â†’ reload the current view
      refreshAll();
    } catch (err) {
      console.error("Delete error:", err);
      showError(err.message || "Failed to delete company");
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  // â”€â”€â”€ Status counts for current profile tab â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const currentTabCounts = useMemo(() => {
    const items = fullData[profileTab] || pagesByType[profileTab]?.[1] || [];
    const isFullReady = !!fullData[profileTab];
    const totalCount = isFullReady ? items.length : (totals[profileTab] ?? items.length);

    return {
      all: totalCount,
      active: items.filter((c) => String(c.company_status || "").toLowerCase() === "active").length,
      inactive: items.filter((c) => String(c.company_status || "").toLowerCase() === "inactive").length,
      blocked: items.filter((c) => String(c.company_status || "").toLowerCase() === "blocked").length,
      pending: items.filter((c) => String(c.company_status || "").toLowerCase() === "pending").length,
      trending: items.filter((c) => c.is_trending).length,
    };
  }, [fullData, profileTab, pagesByType, totals]);

  const tabs = [
    { key: "all", label: "All", count: currentTabCounts.all },
    { key: "active", label: "Active", count: currentTabCounts.active },
    { key: "inactive", label: "Inactive", count: currentTabCounts.inactive },
    { key: "blocked", label: "Blocked", count: currentTabCounts.blocked },
    { key: "pending", label: "Pending", count: currentTabCounts.pending },
    { key: "trending", label: "Trending", count: currentTabCounts.trending },
  ];

  // â”€â”€â”€ Table Columns â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (safePage - 1) * pageSize + i + 1,
    },
    {
      header: "Logo",
      key: "logo",
      render: (logo) =>
        logo ? (
          <img
            src={getImageUrl(logo)}
            alt="logo"
            className="w-9 h-9 object-cover rounded border border-slate-200"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
        ) : (
          <div className="w-9 h-9 rounded border border-slate-200 bg-slate-50 flex items-center justify-center text-gray-300">
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <circle cx="8.5" cy="8.5" r="1.5" />
              <path d="M21 15l-5-5L5 21" />
            </svg>
          </div>
        ),
    },
    {
      header: profileTab === "consultant" ? "Consultant" : "Company",
      key: "company_name",
      render: (v, row) => (
        <div>
          <span className="font-medium text-slate-800">{v}</span>
          <div className="text-xs text-slate-400">{row.slug}</div>
          {row.reference_code && (
            <div className="text-xs text-slate-400 font-mono">
              Ref: {row.reference_code}
            </div>
          )}
        </div>
      ),
    },
    {
      header: "Email",
      key: "company_user_email",
      render: (v) => <span className="text-sm text-slate-500">{v || "â€”"}</span>,
    },
    {
      header: "Industries",
      key: "Industries",
      render: (_, row) => {
        const industries = row.Industries || [];
        if (!industries || industries.length === 0) {
          return <span className="text-sm text-slate-400">â€”</span>;
        }
        return (
          <div className="flex flex-wrap gap-1.5">
            {industries.map((ind, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200"
                title={ind.industry_name || ind.name}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                {ind.industry_name || ind.name || "Unknown"}
              </span>
            ))}
          </div>
        );
      },
    },
    {
      header: "Size",
      key: "company_size_name",
      render: (v) => <span className="text-sm text-slate-500">{v || "â€”"}</span>,
    },
    {
      header: "Trending",
      key: "is_trending",
      render: (is_trending, row) => (
        <button
          onClick={() => handleTrendingToggle(row.id, is_trending)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            is_trending ? "bg-amber-500" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              is_trending ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Status",
      key: "company_status",
      render: (status, row) => (
        <select
          value={status}
          disabled={statusUpdatingId === row.id}
          onChange={(e) => handleCompanyStatusChange(row.id, e.target.value)}
          className={`text-xs font-medium px-2.5 py-1.5 rounded-lg border focus:outline-none focus:ring-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors ${
            STATUS_STYLES[status] || STATUS_STYLES.inactive
          }`}
        >
          {STATUS_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      ),
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => (
        <div className="flex items-center gap-1.5">
          <span className="text-slate-600 text-sm font-medium">
            {getUpdatedByName(row)}
          </span>
        </div>
      ),
    },
    {
      header: "Jobs",
      key: "jobs",
      render: (_, row) => <CompanyJobsBadge companyId={row.id} />,
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() => openView(row)}
            className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors text-sm font-medium whitespace-nowrap"
            title="View Company Details"
          >
            <MdVisibility size={16} />
            {/* <span>View Company Details</span> */}
          </button>
          <button
            onClick={() => openEdit(row)}
            className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  if (error) {
    return (
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Companies</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage registered companies
          </p>
        </div>
        <div className="bg-white rounded-xl border border-red-200 shadow-sm overflow-hidden p-8 text-center">
          <h3 className="text-lg font-medium text-slate-900 mb-2">
            Failed to Load Companies
          </h3>
          <p className="text-slate-600 max-w-md mx-auto whitespace-pre-line">
            {error}
          </p>
          <button
            onClick={() => load()}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Companies</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage registered companies and consultants
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={refreshAll}
            loading={loading}
          >
            Refresh
          </Button>
          <Button icon={MdAdd} onClick={openAdd}>
            Add Company
          </Button>
        </div>
      </div>

      {/* Top-level Company / Consultant tabs */}
      <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl w-full sm:w-fit">
        {PROFILE_TYPES.map(({ key, label, icon: Icon }) => {
          const isActive = profileTab === key;
          const count = typeTotal(key);
          return (
            <button
              key={key}
              onClick={() => handleProfileTabChange(key)}
              className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all flex-1 sm:flex-initial ${
                isActive
                  ? "bg-white text-blue-600 shadow-sm"
                  : "text-slate-500 hover:text-slate-700"
              }`}
            >
              <Icon size={16} />
              {label}
              <span
                className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                  isActive
                    ? "bg-blue-50 text-blue-600"
                    : "bg-gray-200 text-slate-500"
                }`}
              >
                {count ?? "â€¦"}
              </span>
            </button>
          );
        })}
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`Search ${
                profileTab === "consultant" ? "consultants" : "companies"
              }...`}
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm flex-wrap">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? tab.key === "trending"
                      ? "text-amber-600"
                      : "text-blue-600"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? tab.key === "trending"
                        ? "bg-amber-50 text-amber-600"
                        : "bg-blue-50 text-blue-600"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count ?? 0}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage={
            profileTab === "consultant"
              ? "No consultants found"
              : "No companies found"
          }
        />

        <div className="px-5 py-3 border-t border-slate-100">
          <Pagination
            page={safePage}
            total={viewTotal ?? 0}
            limit={pageSize}
            itemsCount={paginatedData.length}
            onChange={setPage}
          />
        </div>
      </div>

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Company"
        message="Delete this company? This action cannot be undone."
      />
    </div>
  );
};

export default Companies;

