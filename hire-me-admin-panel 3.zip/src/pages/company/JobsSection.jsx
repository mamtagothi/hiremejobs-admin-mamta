﻿import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MdWork, MdWhatshot, MdVisibility, MdAttachMoney, MdAccessTime, MdBusinessCenter, MdCalendarToday, MdEventBusy, MdStar, MdLocationOn, MdCheckCircle, MdSchool, MdOpenInNew } from "react-icons/md";
import { SectionLoading, SectionError, SectionEmpty, formatSalary, safeFormatDate, IndexBadge, GenericStatusPill, QuickStat, MiniStat, RichTextViewer, DetailRow, parseApiDate } from "./SharedCompanyUI";
import Pagination from "../../components/common/Pagination";

const JOBS_PER_PAGE = 10;

// â”€â”€â”€ Jobs Section â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const JobsSection = ({
  state,
  pagination,
  onPageChange,
  onRetry,
  onViewJob,
}) => {
  const { loading, error, items } = state;
  const [expandedId, setExpandedId] = useState(null);

  const toggleExpand = (id) =>
    setExpandedId((prev) => (prev === id ? null : id));

  const startIndex =
    ((pagination?.page || 1) - 1) * (pagination?.limit || JOBS_PER_PAGE);

  return (
    <div>
      {loading ? (
        <SectionLoading label="Loading jobs..." />
      ) : error ? (
        <SectionError message={error} onRetry={onRetry} />
      ) : !items.length ? (
        <SectionEmpty
          icon={MdWork}
          title="No jobs posted yet"
          subtitle="Jobs posted by this company will show up here."
        />
      ) : (
        <div className="space-y-4">
          {items.map((job, idx) => {
            const title = job.title || "Untitled role";
            const status = job.job_status || "â€”";
            const companyName = job.Company?.company_name || "â€”";
            const salary = formatSalary(
              job.salary_min,
              job.salary_max,
              job.salary_type,
            );
            const experience =
              job.experience_min && job.experience_max
                ? `${job.experience_min}-${job.experience_max} yrs`
                : job.experience_min
                  ? `${job.experience_min}+ yrs`
                  : "â€”";
            const jobType = job.posting_type || "â€”";
            const isTrending = job.is_trending;
            const publishedAt =
              job.published_at ||
              job.publish_date ||
              job.schedule_date ||
              job.created_at ||
              job.createdAt ||
              job.updated_at ||
              job.updatedAt;
            const expiryDate =
              job.expiry_date ||
              job.job_expire_date ||
              job.expired_at ||
              job.expire_date ||
              job.expiryDate;
            const viewCount = job.view_count || 0;
            const applicationCount = job.application_count || 0;
            const shortlistedCount = job.shortlisted_count || 0;
            const interviewCount = job.interview_count || 0;
            const selectedCount = job.selected_count || 0;
            const rejectedCount = job.rejected_count || 0;

            const skills =
              job.JobSkills?.map((s) => s.Skill?.skill_name).filter(Boolean) ||
              [];
            const locations =
              job.JobLocations?.map(
                (l) => l.location_name || l.Location?.location_name,
              ).filter(Boolean) || [];
            const perks =
              job.JobPerkBenefits?.map((p) => p.PerksBenefit?.name).filter(
                Boolean,
              ) || [];
            const industries =
              job.JobIndustries?.map((i) => i.SubIndustry?.name).filter(
                Boolean,
              ) || [];
            const functionsRoles =
              job.JobFunctionsRoles?.map((f) => f.FunctionRole?.name).filter(
                Boolean,
              ) || [];
            const educations =
              job.JobEducations?.map(
                (e) => e.EducationSubCategory?.name,
              ).filter(Boolean) || [];

            const isExpanded = expandedId === (job.id || idx);
            const displayIndex = startIndex + idx + 1;

            return (
              <div
                key={job.id || idx}
                className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm"
              >
                <button
                  type="button"
                  onClick={() => toggleExpand(job.id || idx)}
                  className="w-full flex items-center gap-4 px-4 py-3.5 text-left hover:bg-slate-50/60 transition-colors"
                >
                  <IndexBadge index={displayIndex} />
                  {/* <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <MdWork size={18} className="text-blue-600" />
                  </div> */}
                  <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-1">
                    <div className="min-w-0">
                      <p className="text-[11px] text-slate-400 leading-tight">
                        Job Title
                      </p>
                      <p className="text-sm font-semibold text-slate-800 truncate">
                        {title}
                      </p>
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] text-slate-400 leading-tight">
                        Company
                      </p>
                      <p className="text-sm text-slate-700 truncate">
                        {companyName}
                      </p>
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] text-slate-400 leading-tight">
                        Salary
                      </p>
                      <p className="text-sm text-slate-700 truncate">
                        {salary}
                      </p>
                    </div>
                    <div className="min-w-0 flex items-center gap-2">
                      <GenericStatusPill status={status} />
                      {isTrending && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-orange-50 text-orange-700 ring-1 ring-orange-200">
                          <MdWhatshot size={10} />
                          Trending
                        </span>
                      )}
                    </div>
                  </div>
                  {/* <div className="hidden lg:flex flex-col items-end flex-shrink-0">
                    <p className="text-[11px] text-slate-400">Experience</p>
                    <p className="text-xs font-medium text-slate-700">
                      {experience}
                    </p>
                  </div> */}
                  <div className="hidden md:flex flex-col items-end flex-shrink-0">
                    <p className="text-[11px] text-slate-400">Published Date</p>
                    <p className="text-xs font-medium text-slate-700">
                      {safeFormatDate(publishedAt)}
                    </p>
                  </div>
                  <div className="hidden md:flex flex-col items-end flex-shrink-0">
                    <p className="text-[11px] text-slate-400">Expire Date</p>
                    <p className="text-xs font-medium text-slate-700">
                      {safeFormatDate(expiryDate)}
                    </p>
                  </div>
                  <MdVisibility
                    size={18}
                    className="text-slate-400 hover:text-slate-600 flex-shrink-0 transition-colors"
                  />
                </button>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="border-t border-slate-100"
                    >
                      <div className="p-5 space-y-6">
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                          <QuickStat
                            icon={MdAttachMoney}
                            label="Salary"
                            value={salary}
                          />
                          <QuickStat
                            icon={MdAccessTime}
                            label="Experience"
                            value={experience}
                          />
                          <QuickStat
                            icon={MdBusinessCenter}
                            label="Job Type"
                            value={jobType}
                          />
                          <QuickStat
                            icon={MdVisibility}
                            label="Views"
                            value={viewCount}
                          />
                          <QuickStat
                            icon={MdCalendarToday}
                            label="Published Date"
                            value={safeFormatDate(publishedAt)}
                          />
                          <QuickStat
                            icon={MdEventBusy}
                            label="Expire Date"
                            value={safeFormatDate(expiryDate)}
                          />
                        </div>

                        <div>
                          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                            Application Stats
                          </h4>
                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                            <MiniStat
                              label="Total"
                              value={applicationCount}
                              color="text-blue-600"
                              bg="bg-blue-50"
                            />
                            <MiniStat
                              label="Shortlisted"
                              value={shortlistedCount}
                              color="text-amber-600"
                              bg="bg-amber-50"
                            />
                            <MiniStat
                              label="Interview"
                              value={interviewCount}
                              color="text-purple-600"
                              bg="bg-purple-50"
                            />
                            <MiniStat
                              label="Selected"
                              value={selectedCount}
                              color="text-emerald-600"
                              bg="bg-emerald-50"
                            />
                            <MiniStat
                              label="Rejected"
                              value={rejectedCount}
                              color="text-red-600"
                              bg="bg-red-50"
                            />
                          </div>
                        </div>

                        <div>
                          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                            Job Description
                          </h4>
                          <RichTextViewer value={job.job_description || ""} />
                        </div>

                        {skills.length > 0 && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                              Required Skills
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {skills.map((skill, i) => (
                                <span
                                  key={i}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 text-[11px] font-medium ring-1 ring-indigo-200"
                                >
                                  <MdStar size={11} />
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {locations.length > 0 && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                              Locations
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {locations.map((loc, i) => (
                                <span
                                  key={i}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-[11px] font-medium"
                                >
                                  <MdLocationOn size={11} />
                                  {loc}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {perks.length > 0 && (
                          <div>
                            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                              Perks & Benefits
                            </h4>
                            <div className="flex flex-wrap gap-2">
                              {perks.map((perk, i) => (
                                <span
                                  key={i}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-medium ring-1 ring-emerald-200"
                                >
                                  <MdCheckCircle size={11} />
                                  {perk}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                          {educations.length > 0 && (
                            <div>
                              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                                Education
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {educations.map((edu, i) => (
                                  <span
                                    key={i}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-[11px] font-medium"
                                  >
                                    <MdSchool size={11} />
                                    {edu}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                          {industries.length > 0 && (
                            <div>
                              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                                Industry
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {industries.map((ind, i) => (
                                  <span
                                    key={i}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-[11px] font-medium"
                                  >
                                    {ind}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                          {functionsRoles.length > 0 && (
                            <div className="sm:col-span-2">
                              <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                                Function / Role
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {functionsRoles.map((fn, i) => (
                                  <span
                                    key={i}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 text-[11px] font-medium ring-1 ring-purple-200"
                                  >
                                    <MdBusinessCenter size={11} />
                                    {fn}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-4 border-t border-slate-100">
                          <DetailRow
                            label="Published"
                            value={safeFormatDate(publishedAt)}
                          />
                          <DetailRow
                            label="Expires"
                            value={safeFormatDate(expiryDate)}
                          />
                        </div>

                        {/* <div className="flex justify-end pt-2">
                          <button
                            type="button"
                            onClick={() => onViewJob?.(job.id)}
                            className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors"
                          >
                            <MdOpenInNew size={16} />
                            View Full Job
                          </button>
                        </div> */}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      )}

      {!loading && !error && items.length > 0 && pagination && (
        <Pagination
          currentPage={pagination.page}
          totalPages={pagination.totalPages}
          total={pagination.total}
          limit={pagination.limit}
          onPageChange={onPageChange}
          loading={loading}
        />
      )}
    </div>
  );
};

export default JobsSection;

