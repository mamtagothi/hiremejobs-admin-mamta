﻿import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import skillsService from "../../services/skills.service";
import { showSuccess, showError } from "../../utils/toast";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdRefresh,
  MdVisibility,
} from "react-icons/md";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

const Skills = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [statusFilter, setStatusFilter] = useState("all");
  const [userNameCache, setUserNameCache] = useState({});
  const [togglingId, setTogglingId] = useState(null);

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  // Reset page when search or status filter changes
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, statusFilter]);

  // Get user name with caching
  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    const key = String(userId);
    return userNameCache[key] || `User ${userId}`;
  };

  // Get display name for updated by
  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by) {
      return getUserNameCached(row.updated_by);
    }
    return "-";
  };

  // Normalize API response
  const normalizeSkill = (item) => ({
    id: item.id,
    skill_name: item.skill_name || "",
    status: item.status === true || item.status === "true" || item.status === 1,
    is_trending:
      item.is_trending === true ||
      item.is_trending === "true" ||
      item.is_trending === 1,
    created_by: item.created_by || null,
    updated_by: item.updated_by || null,
    created_at: item.created_at || null,
    updated_at: item.updated_at || null,
  });

  const [paginationLinks, setPaginationLinks] = useState(null);
  const [totalItems, setTotalItems] = useState(0);

  const load = async () => {
    setLoading(true);
    try {
      if (Object.keys(userNameCache).length === 0) {
        try {
          const users = await fetchUsers();
          const userMap = {};
          Object.keys(users || {}).forEach((id) => {
            userMap[id] = users[id].name;
          });
          setUserNameCache(userMap);
        } catch (e) {
          console.warn("Could not fetch user names cache:", e);
        }
      }

      const params = { page, limit };
      if (debouncedSearch) {
        params.search = debouncedSearch;
      }

      const r = await skillsService.getAll(params);
      const body = r?.data;
      const rawData =
        body?.data?.data || body?.data || body?.results || body || [];
      const skills = Array.isArray(rawData) ? rawData.map(normalizeSkill) : [];

      const links = body?.pagination?.links || body?.links || r?.links || null;
      const total =
        body?.pagination?.total || body?.total || r?.total || skills.length;

      setData(skills);
      setPaginationLinks(links);
      setTotalItems(total);
    } catch (err) {
      console.error("Load error:", err);
      showError(err.message || "Failed to load skills");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [page, limit, debouncedSearch]);

  const filteredData = useMemo(() => {
    let result = data;
    if (statusFilter !== "all") {
      result = result.filter((item) =>
        statusFilter === "active" ? item.status === true : item.status !== true
      );
    }
    const query = debouncedSearch.toLowerCase().trim();
    if (query) {
      result = result.filter((item) =>
        String(item.skill_name ?? "")
          .toLowerCase()
          .includes(query)
      );
    }
    return result;
  }, [data, debouncedSearch, statusFilter]);

  const paginatedData = useMemo(() => {
    if (paginationLinks || (totalItems > data.length && data.length <= limit)) {
      return filteredData;
    }
    return filteredData.slice((page - 1) * limit, page * limit);
  }, [filteredData, page, limit, paginationLinks, totalItems, data.length]);

  const activeCount = useMemo(
    () => data.filter((s) => s.status === true).length,
    [data]
  );
  const inactiveCount = useMemo(
    () => data.length - activeCount,
    [data, activeCount]
  );

  // Navigation handlers
  const openAdd = () => {
    navigate("/skills/add");
  };

  const openEdit = (item) => {
    navigate(`/skills/edit/${item.id}`);
  };

  const openView = (item) => {
    navigate(`/skills/view/${item.id}`);
  };

  // Handle delete
  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await skillsService.delete(deleteId);
      showSuccess("Skill deleted successfully");
      load();
    } catch (err) {
      console.error("Delete error:", err);
      showError(err.message || "Failed to delete skill");
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  // Toggle status optimistically (0ms delay)
  const handleStatusToggle = async (row) => {
    if (togglingId === row.id) return;
    const currentStatus = row.status === true;
    const newStatus = !currentStatus;

    setTogglingId(row.id);
    // Optimistic UI update
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id ? { ...item, status: newStatus } : item
      )
    );

    try {
      await skillsService.update(row.id, { status: newStatus });
      showSuccess(`Status updated to ${newStatus ? "active" : "inactive"}`);
    } catch (err) {
      console.error("Status toggle error:", err);
      // Revert on failure
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id ? { ...item, status: currentStatus } : item
        )
      );
      showError(err.message || "Failed to update status");
    } finally {
      setTogglingId(null);
    }
  };

  // Toggle trending optimistically (0ms delay)
  const handleTrendingToggle = async (row) => {
    if (togglingId === `trending-${row.id}`) return;
    const currentTrending = row.is_trending === true;
    const newTrending = !currentTrending;

    setTogglingId(`trending-${row.id}`);
    // Optimistic UI update
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id ? { ...item, is_trending: newTrending } : item
      )
    );

    try {
      await skillsService.update(row.id, { is_trending: newTrending });
      showSuccess(`Trending updated to ${newTrending ? "Yes" : "No"}`);
    } catch (err) {
      console.error("Trending toggle error:", err);
      // Revert on failure
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id ? { ...item, is_trending: currentTrending } : item
        )
      );
      showError(err.message || "Failed to update trending");
    } finally {
      setTogglingId(null);
    }
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Skill Name",
      key: "skill_name",
      render: (v) => (
        <span className="font-medium capitalize text-slate-800">{v}</span>
      ),
    },
    {
      header: "Trending",
      key: "is_trending",
      render: (is_trending, row) => (
        <button
          onClick={() => handleTrendingToggle(row)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            is_trending ? "bg-amber-500" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              is_trending ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Status",
      key: "status",
      render: (status, row) => (
        <button
          onClick={() => handleStatusToggle(row)}
          className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
            status ? "bg-[#2c0eee]" : "bg-gray-300"
          }`}
        >
          <span
            className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
              status ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      ),
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => {
        const name = getUpdatedByName(row);
        return (
          <span className="text-slate-700 text-sm font-medium">{name}</span>
        );
      },
    },
    {
      header: "Updated At",
      key: "updated_at",
      render: (v) => (
        <span className="text-slate-500 text-sm">{v ? formatDate(v) : "â€”"}</span>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() => openView(row)}
            className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() => openEdit(row)}
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: data.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Skills</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage skills used across job listings
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={load}
            loading={loading}
          >
            Refresh
          </Button>
          <Button icon={MdAdd} onClick={openAdd}>
            Add Skill
          </Button>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search skills..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${statusFilter === tab.key ? "text-blue-600" : "text-slate-500 hover:text-slate-700"}`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${statusFilter === tab.key ? "bg-slate-800 text-white shadow-sm" : "bg-slate-100 text-slate-500"}`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No skills found"
        />

        {/* Footer */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3 border-t border-slate-100">
          <p className="text-xs text-slate-400">
            Showing {totalItems === 0 ? 0 : (page - 1) * limit + 1}
            {"â€“"}
            {Math.min(page * limit, totalItems)} of {totalItems} skills
          </p>
          <Pagination
            page={page}
            total={totalItems}
            limit={limit}
            links={paginationLinks}
            onChange={setPage}
            onLimitChange={(newLimit) => {
              setLimit(newLimit);
              setPage(1);
            }}
          />
        </div>
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Skill"
        message="Delete this skill? It may affect associated data."
      />
    </div>
  );
};

export default Skills;


