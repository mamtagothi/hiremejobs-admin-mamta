import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  MdArrowBack,
  MdEdit,
  MdDelete,
  MdMarkEmailUnread,
  MdCheckCircle,
  MdCancel,
  MdContentCopy,
  MdCode,
  MdSend,
  MdBlock,
} from "react-icons/md";
import Button from "../../components/common/Button";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import emailTemplateService from "../../services/emailTemplate.service";
import { showSuccess, showError } from "../../utils/toast";

const ViewEmailTemplate = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [template, setTemplate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [activeTab, setActiveTab] = useState("preview"); // "preview", "code", "text"

  useEffect(() => {
    loadTemplate();
  }, [id]);

  const loadTemplate = async () => {
    setLoading(true);
    try {
      const res = await emailTemplateService.getById(id);
      const data = res?.data || res;

      if (!data) {
        showError("Email template not found!");
        navigate("/email-templates");
        return;
      }

      setTemplate(data);
    } catch (error) {
      console.error("Error loading email template:", error);
      showError(error.message || "Failed to load email template");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleSend = async () => {
    if (!template || toggling) return;
    setToggling(true);
    const newSendState = !template.email_send;

    // Optimistic update
    setTemplate((prev) => ({ ...prev, email_send: newSendState }));

    try {
      await emailTemplateService.toggleEmailSend(template.id);
      showSuccess(`Email dispatch ${newSendState ? "enabled" : "disabled"}`);
    } catch (error) {
      console.error("Toggle email send error:", error);
      showError(error.message || "Failed to toggle email send");
      // Revert update
      setTemplate((prev) => ({ ...prev, email_send: !newSendState }));
    } finally {
      setToggling(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!template) return;
    setDeleteLoading(true);
    try {
      await emailTemplateService.delete(template.id);
      showSuccess("Email template deleted successfully!");
      navigate("/email-templates");
    } catch (error) {
      console.error("Delete template error:", error);
      showError(error.message || "Failed to delete email template");
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleCopyKey = () => {
    if (!template?.template_key) return;
    navigator.clipboard.writeText(template.template_key);
    showSuccess(`Copied "${template.template_key}" to clipboard!`);
  };

  if (loading) {
    return (
      <div className="p-8 text-center text-gray-500 min-h-[400px] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-[#F61D25] border-t-transparent rounded-full animate-spin"></div>
          <p className="font-medium text-gray-700">Loading email template details...</p>
        </div>
      </div>
    );
  }

  if (!template) return null;

  // Variables parsing
  let variables = [];
  if (Array.isArray(template.variables_json)) {
    variables = template.variables_json;
  } else if (typeof template.variables_json === "string") {
    try {
      variables = JSON.parse(template.variables_json);
    } catch {
      variables = template.variables_json.split(",").map((v) => v.trim()).filter(Boolean);
    }
  }

  return (
    <div className="p-4 sm:p-6 max-w-[1400px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => navigate("/email-templates")}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
            title="Back to list"
          >
            <MdArrowBack size={24} />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-gray-900">{template.template_name}</h1>
              <span className="font-mono text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded-md border border-gray-200 flex items-center gap-1">
                {template.template_key}
                <button
                  type="button"
                  onClick={handleCopyKey}
                  className="text-gray-400 hover:text-indigo-600"
                  title="Copy Key"
                >
                  <MdContentCopy size={12} />
                </button>
              </span>
            </div>
            <p className="text-sm text-gray-500 mt-0.5">
              Subject: <span className="font-medium text-gray-800">{template.subject}</span>
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            onClick={handleToggleSend}
            loading={toggling}
            className={`flex items-center gap-2 ${
              template.email_send ? "text-emerald-700 hover:bg-emerald-50" : "text-amber-700 hover:bg-amber-50"
            }`}
          >
            {template.email_send ? <MdSend size={18} /> : <MdBlock size={18} />}
            {template.email_send ? "Dispatch Enabled" : "Dispatch Disabled"}
          </Button>

          <Button
            onClick={() => navigate(`/email-templates/edit/${template.id}`)}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white"
          >
            <MdEdit size={18} /> Edit Template
          </Button>

          <Button
            onClick={() => setDeleteOpen(true)}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white"
          >
            <MdDelete size={18} /> Delete
          </Button>
        </div>
      </div>

      {/* Main Details Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Information Summary Card */}
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-gray-900 border-b pb-3 flex items-center gap-2">
              <MdMarkEmailUnread className="text-[#F61D25]" size={20} /> Template Summary
            </h2>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-1 border-b border-gray-100">
                <span className="text-gray-500">Recipient Type</span>
                <span className="font-semibold text-gray-800 uppercase text-xs px-2 py-0.5 rounded bg-gray-100">
                  {template.recipient_type || "all"}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-gray-100">
                <span className="text-gray-500">Dispatch Status</span>
                <span className={`font-semibold text-xs px-2 py-0.5 rounded ${
                  template.email_send ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                }`}>
                  {template.email_send ? "Active Sending" : "Sending Disabled"}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-gray-100">
                <span className="text-gray-500">Active Status</span>
                <span className={`font-semibold text-xs px-2 py-0.5 rounded ${
                  template.status ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                }`}>
                  {template.status ? "Active" : "Inactive"}
                </span>
              </div>

              {template.created_at && (
                <div className="flex justify-between py-1 border-b border-gray-100">
                  <span className="text-gray-500">Created Date</span>
                  <span className="text-gray-800">{new Date(template.created_at).toLocaleDateString()}</span>
                </div>
              )}
            </div>
          </div>

          {/* Dynamic Variables Card */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-3">
            <h2 className="text-base font-bold text-gray-900 flex items-center justify-between">
              <span>Dynamic Placeholders</span>
              <span className="text-xs text-gray-500">{variables.length} variables</span>
            </h2>

            <div className="flex flex-wrap gap-2 pt-1">
              {variables.length === 0 ? (
                <p className="text-xs text-gray-400 italic">No variables associated with this template.</p>
              ) : (
                variables.map((v) => (
                  <span
                    key={v}
                    className="font-mono text-xs bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md border border-indigo-200"
                  >
                    {`{{${v}}}`}
                  </span>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Column: HTML Rendered Email Preview & Raw Code */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h2 className="text-base font-bold text-gray-900">Email Content Preview</h2>

              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setActiveTab("preview")}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    activeTab === "preview"
                      ? "bg-white text-[#F61D25] shadow-xs"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                >
                  Visual Preview
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab("code")}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    activeTab === "code"
                      ? "bg-white text-gray-900 shadow-xs"
                      : "text-gray-600 hover:text-gray-900"
                  }`}
                >
                  Raw HTML
                </button>
                {template.body_text && (
                  <button
                    type="button"
                    onClick={() => setActiveTab("text")}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      activeTab === "text"
                        ? "bg-white text-gray-900 shadow-xs"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Plain Text
                  </button>
                )}
              </div>
            </div>

            {/* Simulated Email Frame */}
            {activeTab === "preview" && (
              <div className="border border-gray-200 rounded-xl overflow-hidden shadow-inner">
                {/* Email Client Top Bar */}
                <div className="bg-gray-100 px-4 py-3 border-b border-gray-200 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500 font-medium">To: <span className="text-gray-800 font-semibold">&lt;recipient@example.com&gt;</span></span>
                    <span className="text-gray-400 font-mono text-[11px]">System Email Simulator</span>
                  </div>
                  <div className="text-gray-900 font-bold text-sm">
                    Subject: {template.subject}
                  </div>
                </div>

                {/* Email HTML Render Body */}
                <div
                  className="p-6 bg-white min-h-[350px] prose max-w-none text-gray-800"
                  dangerouslySetInnerHTML={{ __html: template.body_html || "<p>No HTML content</p>" }}
                />
              </div>
            )}

            {/* Raw HTML Code Tab */}
            {activeTab === "code" && (
              <pre className="p-4 bg-gray-900 text-emerald-400 font-mono text-xs rounded-xl overflow-x-auto min-h-[350px] whitespace-pre-wrap break-words">
                {template.body_html}
              </pre>
            )}

            {/* Plain Text Tab */}
            {activeTab === "text" && (
              <div className="p-4 bg-gray-50 border border-gray-200 rounded-xl text-xs text-gray-800 font-mono min-h-[250px] whitespace-pre-wrap">
                {template.body_text || "No plain text alternative supplied."}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Delete Dialog */}
      <ConfirmDialog
        isOpen={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleDeleteConfirm}
        title="Delete Email Template"
        message={`Are you sure you want to delete "${template.template_name}" (${template.template_key})?`}
        loading={deleteLoading}
        confirmLabel="Delete Template"
        variant="danger"
      />
    </div>
  );
};

export default ViewEmailTemplate;