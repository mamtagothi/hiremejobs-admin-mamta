﻿import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdRefresh,
  MdMarkEmailUnread,
  MdCheckCircle,
  MdCancel,
  MdContentCopy,
  MdSend,
  MdBlock,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import Pagination from "../../components/common/Pagination";
import emailTemplateService from "../../services/emailTemplate.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";

const toBool = (val, fallback = true) => {
  if (val === undefined || val === null || val === "") return fallback;
  if (val === true || val === 1 || val === "1" || val === "true") return true;
  if (val === false || val === 0 || val === "0" || val === "false") return false;
  return Boolean(val);
};

const EmailTemplates = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [recipientFilter, setRecipientFilter] = useState("all");
  const [emailSendFilter, setEmailSendFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [togglingId, setTogglingId] = useState(null);

  const normalizeTemplate = (item) => {
    return {
      id: item.id || item._id,
      template_key: item.template_key || "",
      template_name: item.template_name || "",
      subject: item.subject || "",
      body_html: item.body_html || "",
      body_text: item.body_text || "",
      recipient_type: item.recipient_type || "all",
      variables_json: item.variables_json || null,
      email_send: toBool(item.email_send, true),
      status: toBool(item.status, true),
      created_at: item.created_at || item.createdAt || null,
      updated_at: item.updated_at || item.updatedAt || null,
    };
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const response = await emailTemplateService.getAll();
      let rawList = [];
      if (response?.data) {
        rawList = Array.isArray(response.data) ? response.data : [response.data];
      } else if (Array.isArray(response)) {
        rawList = response;
      }

      const templates = rawList.map(normalizeTemplate);
      setData(templates);
      console.log(`ðŸ“§ Loaded ${templates.length} Email Templates`);
    } catch (error) {
      console.error("Load email templates error:", error);
      showError(error.message || "Failed to load email templates");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Copy template key helper
  const handleCopyKey = (key, e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(key);
    showSuccess(`Copied "${key}" to clipboard!`);
  };

  // Toggle Email Send Handler
  const handleToggleSend = async (item) => {
    if (togglingId) return;
    setTogglingId(item.id);
    const newSendState = !item.email_send;

    // Optimistic UI update
    setData((prev) =>
      prev.map((t) => (t.id === item.id ? { ...t, email_send: newSendState } : t))
    );

    try {
      const res = await emailTemplateService.toggleEmailSend(item.id);
      showSuccess(
        res?.message ||
          `Email dispatch ${newSendState ? "enabled" : "disabled"} for "${item.template_name}"`
      );
    } catch (error) {
      console.error("Toggle email send error:", error);
      showError(error.message || "Failed to toggle email send");
      // Revert optimistic update
      setData((prev) =>
        prev.map((t) => (t.id === item.id ? { ...t, email_send: !newSendState } : t))
      );
    } finally {
      setTogglingId(null);
    }
  };

  // Delete Handler
  const handleDeleteConfirm = async () => {
    if (!deleteId) return;
    setDeleteLoading(true);
    try {
      await emailTemplateService.delete(deleteId);
      showSuccess("Email template deleted successfully!");
      setData((prev) => prev.filter((item) => item.id !== deleteId));
      setDeleteId(null);
    } catch (error) {
      console.error("Delete template error:", error);
      showError(error.message || "Failed to delete email template");
    } finally {
      setDeleteLoading(false);
    }
  };

  // Filtered & Search Data
  const filteredData = useMemo(() => {
    return data.filter((item) => {
      // Search
      const searchLower = search.toLowerCase().trim();
      const matchesSearch =
        !searchLower ||
        item.template_name.toLowerCase().includes(searchLower) ||
        item.template_key.toLowerCase().includes(searchLower) ||
        item.subject.toLowerCase().includes(searchLower);

      // Recipient Filter
      const matchesRecipient =
        recipientFilter === "all" || item.recipient_type === recipientFilter;

      // Email Send Filter
      const matchesEmailSend =
        emailSendFilter === "all" ||
        (emailSendFilter === "enabled" && item.email_send) ||
        (emailSendFilter === "disabled" && !item.email_send);

      // Status Filter
      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "active" && item.status) ||
        (statusFilter === "inactive" && !item.status);

      return matchesSearch && matchesRecipient && matchesEmailSend && matchesStatus;
    });
  }, [data, search, recipientFilter, emailSendFilter, statusFilter]);

  // Paginated data
  const paginatedData = useMemo(() => {
    const start = (page - 1) * limit;
    return filteredData.slice(start, start + limit);
  }, [filteredData, page, limit]);

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [search, recipientFilter, emailSendFilter, statusFilter]);

  // Recipient badge styling
  const getRecipientBadge = (type) => {
    const config = {
      candidate: { bg: "bg-blue-50", text: "text-blue-700", border: "border-blue-200", label: "Candidate" },
      employer: { bg: "bg-purple-50", text: "text-purple-700", border: "border-purple-200", label: "Employer" },
      admin: { bg: "bg-amber-50", text: "text-amber-700", border: "border-amber-200", label: "Admin" },
      all: { bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200", label: "All Users" },
    };
    const c = config[type] || config.all;
    return (
      <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold border ${c.bg} ${c.text} ${c.border}`}>
        {c.label}
      </span>
    );
  };

  // Table Columns Definition
  const columns = [
    {
      header: "S.No",
      key: "sno",
      render: (_, __, index) => (page - 1) * limit + index + 1,
    },
    {
      header: "Template Name & Key",
      key: "template_name",
      render: (_, row) => (
        <div className="flex flex-col gap-1 min-w-[200px]">
          <span className="font-semibold text-slate-900 text-sm">
            {row.template_name || "â€”"}
          </span>
          <div className="flex items-center gap-1.5">
            <span className="inline-flex items-center gap-1 font-mono text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200">
              {row.template_key}
            </span>
            <button
              type="button"
              onClick={(e) => handleCopyKey(row.template_key, e)}
              className="text-slate-400 hover:text-indigo-600 transition-colors"
              title="Copy key"
            >
              <MdContentCopy size={13} />
            </button>
          </div>
        </div>
      ),
    },
    {
      header: "Subject",
      key: "subject",
      render: (subject) => (
        <span className="text-sm font-medium text-slate-800 line-clamp-2 max-w-[280px]">
          {subject || "â€”"}
        </span>
      ),
    },
    {
      header: "Recipient Type",
      key: "recipient_type",
      render: (type) => getRecipientBadge(type),
    },
    {
      header: "Email Dispatch",
      key: "email_send",
      render: (_, row) => {
        const isToggling = togglingId === row.id;
        return (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleToggleSend(row)}
              disabled={isToggling}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                row.email_send ? "bg-emerald-500" : "bg-gray-300"
              } ${isToggling ? "opacity-50 cursor-wait" : "cursor-pointer"}`}
              title={row.email_send ? "Click to disable sending" : "Click to enable sending"}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  row.email_send ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </button>
            <span className={`text-xs font-medium ${row.email_send ? "text-emerald-700" : "text-slate-500"}`}>
              {row.email_send ? "Sending On" : "Disabled"}
            </span>
          </div>
        );
      },
    },
    {
      header: "Status",
      key: "status",
      render: (status) => (
        <span
          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
            status
              ? "bg-green-100 text-green-800 border border-green-200"
              : "bg-red-100 text-red-800 border border-red-200"
          }`}
        >
          {status ? (
            <>
              <MdCheckCircle size={12} /> Active
            </>
          ) : (
            <>
              <MdCancel size={12} /> Inactive
            </>
          )}
        </span>
      ),
    },
    {
      header: "Actions",
      key: "actions",
      render: (_, row) => (
        <div className="flex items-center gap-1.5 whitespace-nowrap">
          <button
            type="button"
            onClick={() => navigate(`/email-templates/view/${row.id}`)}
            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="View Details & Preview"
          >
            <MdVisibility size={18} />
          </button>
          <button
            type="button"
            onClick={() => navigate(`/email-templates/edit/${row.id}`)}
            className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
            title="Edit Template"
          >
            <MdEdit size={18} />
          </button>
          <button
            type="button"
            onClick={() => setDeleteId(row.id)}
            className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Delete Template"
          >
            <MdDelete size={18} />
          </button>
        </div>
      ),
    },
  ];

  // Stats computation
  const stats = useMemo(() => {
    return {
      total: data.length,
      sendingOn: data.filter((d) => d.email_send).length,
      sendingOff: data.filter((d) => !d.email_send).length,
      active: data.filter((d) => d.status).length,
    };
  }, [data]);

  return (
    <div className="p-4 sm:p-6 max-w-[1600px] mx-auto space-y-6">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-[#F61D25]/10 to-[#F61D25]/20 rounded-xl flex items-center justify-center text-[#F61D25]">
            <MdMarkEmailUnread size={26} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Email Templates</h1>
            <p className="text-sm text-slate-500">
              Manage automated email body HTML, subject lines, variables, and dispatch settings.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            onClick={loadData}
            loading={loading}
            className="flex items-center gap-2"
          >
            <MdRefresh size={18} /> Refresh
          </Button>
          <Button
            onClick={() => navigate("/email-templates/add")}
            className="flex items-center gap-2 bg-[#F61D25] hover:bg-[#d81920] text-white"
          >
            <MdAdd size={20} /> Add Email Template
          </Button>
        </div>
      </div>

      {/* Quick Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Templates</p>
            <p className="text-2xl font-bold text-slate-900 mt-1">{stats.total}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <MdMarkEmailUnread size={20} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Dispatch Enabled</p>
            <p className="text-2xl font-bold text-emerald-600 mt-1">{stats.sendingOn}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <MdSend size={20} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Dispatch Disabled</p>
            <p className="text-2xl font-bold text-amber-600 mt-1">{stats.sendingOff}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
            <MdBlock size={20} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Status</p>
            <p className="text-2xl font-bold text-indigo-600 mt-1">{stats.active}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <MdCheckCircle size={20} />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
        <div className="relative flex-1 min-w-[240px]">
          <MdSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Search by name, key or subject..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Recipient Filter */}
          <select
            value={recipientFilter}
            onChange={(e) => setRecipientFilter(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
          >
            <option value="all">All Recipients</option>
            <option value="candidate">Candidate</option>
            <option value="employer">Employer</option>
            <option value="admin">Admin</option>
          </select>

          {/* Email Send Filter */}
          <select
            value={emailSendFilter}
            onChange={(e) => setEmailSendFilter(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
          >
            <option value="all">All Dispatch Status</option>
            <option value="enabled">Dispatch Enabled</option>
            <option value="disabled">Dispatch Disabled</option>
          </select>

          {/* Active Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No email templates found matching your criteria."
        />
        <Pagination
          page={page}
          total={filteredData.length}
          limit={limit}
          onChange={(newPage) => setPage(newPage)}
          onLimitChange={(newLimit) => setLimit(newLimit)}
          itemsCount={filteredData.length}
        />
      </div>

      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        isOpen={Boolean(deleteId)}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDeleteConfirm}
        title="Delete Email Template"
        message="Are you sure you want to delete this email template? Automated emails using this template key may fail to send."
        loading={deleteLoading}
        confirmLabel="Delete Template"
        variant="danger"
      />
    </div>
  );
};

export default EmailTemplates;
