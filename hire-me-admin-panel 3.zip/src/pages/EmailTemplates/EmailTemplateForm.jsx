import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Editor } from "@tinymce/tinymce-react";
import {
  MdArrowBack,
  MdSave,
  MdMarkEmailUnread,
  MdAdd,
  MdClose,
  MdCode,
  MdVisibility,
  MdOutlineTextFormat,
  MdCheckCircle,
  MdInfoOutline,
} from "react-icons/md";
import Button from "../../components/common/Button";
import { emailTemplateService } from "../../services/emailTemplate.service";
import { showSuccess, showError } from "../../utils/toast";

const TINYMCE_API_KEY = "ftd4aagtfmkw0dpyqygkud9tevymqlmcdqyo8lsxhesmakc2";

const RECIPIENT_TYPES = [
  { value: "all", label: "All Users / System Wide" },
  { value: "candidate", label: "Candidates" },
  { value: "employer", label: "Employers / Companies" },
  { value: "admin", label: "Admin Users" },
];

const PRESET_VARIABLES = [
  "user_name",
  "candidate_name",
  "employer_name",
  "company_name",
  "job_title",
  "verification_link",
  "reset_password_link",
  "otp_code",
  "application_status",
  "support_email",
];

const EmailTemplateForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  const editorRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [editorMode, setEditorMode] = useState("rich"); // "rich", "code", "preview"

  // Form state
  const [formData, setFormData] = useState({
    template_key: "",
    template_name: "",
    subject: "",
    body_html: "<h2>Welcome {{user_name}}!</h2>\n<p>Thank you for registering with <strong>HireMe</strong>.</p>",
    body_text: "",
    recipient_type: "all",
    variables_json: ["user_name", "job_title", "company_name"],
    email_send: true,
    status: true,
  });

  const [newVarInput, setNewVarInput] = useState("");

  // Load existing template if editing
  useEffect(() => {
    if (isEdit) {
      loadTemplate();
    }
  }, [id]);

  const loadTemplate = async () => {
    setLoading(true);
    try {
      const res = await emailTemplateService.getById(id);
      const data = res?.data || res;

      if (!data) {
        showError("Email template not found!");
        navigate("/email-templates");
        return;
      }

      let parsedVars = [];
      if (Array.isArray(data.variables_json)) {
        parsedVars = data.variables_json;
      } else if (typeof data.variables_json === "string") {
        try {
          parsedVars = JSON.parse(data.variables_json);
        } catch {
          parsedVars = data.variables_json.split(",").map((v) => v.trim()).filter(Boolean);
        }
      }

      setFormData({
        template_key: data.template_key || "",
        template_name: data.template_name || "",
        subject: data.subject || "",
        body_html: data.body_html || "",
        body_text: data.body_text || "",
        recipient_type: data.recipient_type || "all",
        variables_json: Array.isArray(parsedVars) ? parsedVars : [],
        email_send: data.email_send !== undefined ? Boolean(data.email_send) : true,
        status: data.status !== undefined ? Boolean(data.status) : true,
      });
    } catch (error) {
      console.error("Error loading email template:", error);
      showError(error.message || "Failed to load email template");
    } finally {
      setLoading(false);
    }
  };

  // Field change helper
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  // Automatically convert template_key to UPPERCASE_SNAKE_CASE on creation
  const handleKeyChange = (e) => {
    const val = e.target.value
      .toUpperCase()
      .replace(/[^A-Z0-9_]/g, "_")
      .replace(/_+/g, "_");
    setFormData((prev) => ({ ...prev, template_key: val }));
  };

  // Add dynamic variable tag
  const handleAddVariable = (varName) => {
    const nameToAdd = (varName || newVarInput).trim().toLowerCase().replace(/[^a-z0-9_]/g, "_");
    if (!nameToAdd) return;
    if (formData.variables_json.includes(nameToAdd)) {
      showError(`Variable "{{${nameToAdd}}}" is already in the list`);
      return;
    }
    setFormData((prev) => ({
      ...prev,
      variables_json: [...prev.variables_json, nameToAdd],
    }));
    setNewVarInput("");
  };

  // Remove dynamic variable tag
  const handleRemoveVariable = (varName) => {
    setFormData((prev) => ({
      ...prev,
      variables_json: prev.variables_json.filter((v) => v !== varName),
    }));
  };

  // Insert variable tag into editor or subject
  const insertVariableToEditor = (varName) => {
    const tag = `{{${varName}}}`;
    if (editorRef.current && editorMode === "rich") {
      editorRef.current.insertContent(tag);
      showSuccess(`Inserted "${tag}" into HTML body`);
    } else {
      navigator.clipboard.writeText(tag);
      showSuccess(`Copied "${tag}" to clipboard! Paste it wherever needed.`);
    }
  };

  // Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!formData.template_key && !isEdit) {
      showError("Template Key is required (e.g. WELCOME_EMAIL)");
      return;
    }
    if (!formData.template_name.trim()) {
      showError("Template Name is required");
      return;
    }
    if (!formData.subject.trim()) {
      showError("Email Subject line is required");
      return;
    }
    if (!formData.body_html.trim()) {
      showError("HTML Body content is required");
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        template_key: formData.template_key,
        template_name: formData.template_name,
        subject: formData.subject,
        body_html: formData.body_html,
        body_text: formData.body_text || null,
        recipient_type: formData.recipient_type,
        variables_json: formData.variables_json,
        email_send: formData.email_send,
        status: formData.status,
      };

      if (isEdit) {
        await emailTemplateService.update(id, payload);
        showSuccess("Email template updated successfully!");
      } else {
        await emailTemplateService.create(payload);
        showSuccess("Email template created successfully!");
      }
      navigate("/email-templates");
    } catch (error) {
      console.error("Save template error:", error);
      showError(error.message || "Failed to save email template");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 text-center text-gray-500 min-h-[400px] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-[#F61D25] border-t-transparent rounded-full animate-spin"></div>
          <p className="font-medium text-gray-700">Loading email template details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-[1400px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={() => navigate("/email-templates")}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
            title="Back to list"
          >
            <MdArrowBack size={24} />
          </button>
          <div>
            <h1 className="text-xl font-bold text-gray-900">
              {isEdit ? "Edit Email Template" : "Add New Email Template"}
            </h1>
            <p className="text-sm text-gray-500">
              {isEdit
                ? `Updating template key: ${formData.template_key}`
                : "Create a new automated email notification template with dynamic placeholders."}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            onClick={() => navigate("/email-templates")}
            type="button"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            loading={submitting}
            className="flex items-center gap-2 bg-[#F61D25] hover:bg-[#d81920] text-white"
          >
            <MdSave size={20} /> {isEdit ? "Update Template" : "Create Template"}
          </Button>
        </div>
      </div>

      {/* Main Form Layout */}
      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Essential Settings & Variables (1 Col) */}
        <div className="space-y-6">
          {/* General Information Card */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <h2 className="text-base font-bold text-gray-900 border-b pb-3 flex items-center gap-2">
              <MdMarkEmailUnread className="text-[#F61D25]" size={20} /> Template Meta Information
            </h2>

            {/* Template Key */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Template Key <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="template_key"
                value={formData.template_key}
                onChange={handleKeyChange}
                disabled={isEdit}
                placeholder="e.g. WELCOME_EMAIL"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono bg-gray-50 uppercase focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25] disabled:opacity-60"
              />
              <p className="text-[11px] text-gray-500 mt-1">
                Unique identifier used by backend services to trigger emails.
              </p>
            </div>

            {/* Template Name */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Template Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="template_name"
                value={formData.template_name}
                onChange={handleChange}
                placeholder="e.g. Candidate Welcome Email"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
              />
            </div>

            {/* Recipient Type */}
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-1">
                Target Recipient Type
              </label>
              <select
                name="recipient_type"
                value={formData.recipient_type}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
              >
                {RECIPIENT_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Switches */}
            <div className="pt-2 border-t space-y-3">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <span className="text-sm font-semibold text-gray-900">Automated Dispatch</span>
                  <p className="text-xs text-gray-500">Allow system to send emails for this template</p>
                </div>
                <input
                  type="checkbox"
                  name="email_send"
                  checked={formData.email_send}
                  onChange={handleChange}
                  className="w-4 h-4 text-[#F61D25] focus:ring-[#F61D25] rounded"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <span className="text-sm font-semibold text-gray-900">Active Status</span>
                  <p className="text-xs text-gray-500">Mark template as active or inactive</p>
                </div>
                <input
                  type="checkbox"
                  name="status"
                  checked={formData.status}
                  onChange={handleChange}
                  className="w-4 h-4 text-[#F61D25] focus:ring-[#F61D25] rounded"
                />
              </label>
            </div>
          </div>

          {/* Dynamic Variables Card */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <div>
              <h2 className="text-base font-bold text-gray-900 flex items-center justify-between">
                <span>Dynamic Variables</span>
                <span className="text-xs font-normal text-gray-500">
                  {formData.variables_json.length} Variables
                </span>
              </h2>
              <p className="text-xs text-gray-500 mt-1">
                Click any variable tag to insert <code className="bg-gray-100 text-red-600 px-1 py-0.5 rounded">{"{{var}}"}</code> into the editor.
              </p>
            </div>

            {/* Variable Tag Pills */}
            <div className="flex flex-wrap gap-2 max-h-[180px] overflow-y-auto p-2 bg-gray-50 rounded-xl border border-gray-200">
              {formData.variables_json.length === 0 ? (
                <p className="text-xs text-gray-400 italic py-2">No variables added yet.</p>
              ) : (
                formData.variables_json.map((v) => (
                  <span
                    key={v}
                    onClick={() => insertVariableToEditor(v)}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono font-medium bg-white text-indigo-700 border border-indigo-200 shadow-2xs hover:bg-indigo-50 cursor-pointer transition-all group"
                    title={`Click to insert {{${v}}}`}
                  >
                    <span>{`{{${v}}}`}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveVariable(v);
                      }}
                      className="text-gray-400 hover:text-red-600"
                    >
                      <MdClose size={13} />
                    </button>
                  </span>
                ))
              )}
            </div>

            {/* Add Custom Variable Input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newVarInput}
                onChange={(e) => setNewVarInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddVariable();
                  }
                }}
                placeholder="e.g. user_name"
                className="flex-1 px-3 py-1.5 border border-gray-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
              />
              <button
                type="button"
                onClick={() => handleAddVariable()}
                className="px-3 py-1.5 bg-gray-900 text-white rounded-lg text-xs font-medium hover:bg-gray-800 transition-colors flex items-center gap-1"
              >
                <MdAdd size={16} /> Add Tag
              </button>
            </div>

            {/* Presets Suggestions */}
            <div>
              <p className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                Suggested Presets:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {PRESET_VARIABLES.filter((pv) => !formData.variables_json.includes(pv)).slice(0, 6).map((pv) => (
                  <button
                    key={pv}
                    type="button"
                    onClick={() => handleAddVariable(pv)}
                    className="text-[11px] font-mono bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-0.5 rounded border border-gray-200 transition-colors"
                  >
                    + {pv}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Subject, Body HTML Editor & Text (2 Cols) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Subject Line Card */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-3">
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider">
              Email Subject Line <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              placeholder="e.g. Welcome to HireMe, {{user_name}}!"
              className="w-full px-4 py-2.5 border border-gray-300 rounded-xl text-base font-medium text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
            />
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <MdInfoOutline size={14} className="text-indigo-500" />
              You can include placeholders like <code className="bg-gray-100 px-1 py-0.5 rounded text-indigo-700">{"{{user_name}}"}</code> directly in the subject line.
            </p>
          </div>

          {/* HTML Body Editor Card */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b pb-3">
              <div>
                <h2 className="text-base font-bold text-gray-900">HTML Body Content</h2>
                <p className="text-xs text-gray-500">Design email body with formatted rich text or custom HTML tags.</p>
              </div>

              {/* Editor Tabs: Rich Text / Raw HTML / Live Preview */}
              <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl w-fit">
                <button
                  type="button"
                  onClick={() => setEditorMode("rich")}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${editorMode === "rich"
                      ? "bg-white text-gray-900 shadow-xs"
                      : "text-gray-600 hover:text-gray-900"
                    }`}
                >
                  <MdOutlineTextFormat size={16} /> Rich Text
                </button>
                <button
                  type="button"
                  onClick={() => setEditorMode("code")}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${editorMode === "code"
                      ? "bg-white text-gray-900 shadow-xs"
                      : "text-gray-600 hover:text-gray-900"
                    }`}
                >
                  <MdCode size={16} /> Raw HTML
                </button>
                <button
                  type="button"
                  onClick={() => setEditorMode("preview")}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${editorMode === "preview"
                      ? "bg-white text-[#F61D25] shadow-xs"
                      : "text-gray-600 hover:text-gray-900"
                    }`}
                >
                  <MdVisibility size={16} /> Preview
                </button>
              </div>
            </div>

            {/* Mode 1: Rich Text Editor (TinyMCE) */}
            {editorMode === "rich" && (
              <div className="border border-gray-200 rounded-xl overflow-hidden min-h-[360px]">
                <Editor
                  apiKey={TINYMCE_API_KEY}
                  onInit={(_, editor) => (editorRef.current = editor)}
                  value={formData.body_html}
                  onEditorChange={(newContent) =>
                    setFormData((prev) => ({ ...prev, body_html: newContent }))
                  }
                  init={{
                    height: 380,
                    menubar: true,
                    plugins: [
                      "anchor", "autolink", "charmap", "codesample", "emoticons",
                      "image", "link", "lists", "media", "searchreplace", "table",
                      "visualblocks", "wordcount", "code"
                    ],
                    toolbar:
                      "undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bullist indent outdent | emoticons charmap | code clearformatting",
                    content_style:
                      "body { font-family: Inter, Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6; }",
                  }}
                />
              </div>
            )}

            {/* Mode 2: Raw HTML Textarea */}
            {editorMode === "code" && (
              <textarea
                name="body_html"
                value={formData.body_html}
                onChange={handleChange}
                rows={16}
                placeholder="<html><body><h1>Title</h1></body></html>"
                className="w-full p-4 border border-gray-300 rounded-xl font-mono text-xs text-gray-800 bg-gray-900 text-emerald-400 focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
              />
            )}

            {/* Mode 3: Live HTML Preview Box */}
            {editorMode === "preview" && (
              <div className="border border-gray-200 rounded-xl p-4 bg-gray-50 min-h-[380px] space-y-3">
                <div className="bg-white p-3 rounded-lg border border-gray-200 text-xs text-gray-600 flex items-center justify-between">
                  <span><strong>Subject:</strong> {formData.subject || "(No subject)"}</span>
                  <span className="text-gray-400 font-mono text-[11px]">Interactive Live Preview</span>
                </div>
                <div
                  className="bg-white p-6 rounded-xl border border-gray-200 min-h-[300px] shadow-inner prose max-w-none text-gray-800"
                  dangerouslySetInnerHTML={{
                    __html: formData.body_html || "<p class='text-gray-400 italic'>No HTML body content written yet.</p>",
                  }}
                />
              </div>
            )}
          </div>

          {/* Optional Plain Text Body Card */}
          <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider">
                Plain Text Fallback (Optional)
              </label>
              <span className="text-xs text-gray-400">Used for legacy email clients</span>
            </div>
            <textarea
              name="body_text"
              value={formData.body_text}
              onChange={handleChange}
              rows={4}
              placeholder="Plain text content without HTML tags..."
              className="w-full p-3 border border-gray-300 rounded-xl text-xs text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#F61D25]/20 focus:border-[#F61D25]"
            />
          </div>
        </div>

        {/* Bottom Form Actions Bar */}
        <div className="lg:col-span-3 bg-white p-5 rounded-2xl border border-gray-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-gray-500">
            Please ensure Template Key, Name, Subject and HTML Body (<span className="text-red-500">*</span>) are filled before saving.
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <Button
              variant="secondary"
              onClick={() => navigate("/email-templates")}
              type="button"
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              onClick={handleSubmit}
              loading={submitting}
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-[#F61D25] hover:bg-[#d81920] text-white px-6 py-2.5 rounded-xl font-semibold text-sm shadow-md transition-all"
            >
              <MdSave size={20} /> {isEdit ? "Update Email Template" : "Create Email Template"}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default EmailTemplateForm;