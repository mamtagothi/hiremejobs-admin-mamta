﻿// import React, { useState, useEffect, useCallback, useRef } from "react";
// import { useNavigate } from "react-router-dom";
// import { useAuth } from "../../context/AuthContext";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdVisibility,
//   MdLocalOffer,
//   MdPercent,
//   MdAttachMoney,
//   MdCalendarToday,
//   MdPerson,
//   MdUpdate,
// } from "react-icons/md";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import Pagination from "../../components/common/Pagination";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import { subscriptionPlanOfferService } from "../../services/subscriptionPlanOffer.service";
// import { subscriptionPlanService } from "../../services/subscriptionPlan.service";
// import { showSuccess, showError } from "../../utils/toast";
// import { formatDate } from "../../utils/helpers";
// import { fetchUsers } from "../../utils/getUserName";

// // â”€â”€â”€ Response extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// const extractList = (res) => {
//   if (!res) return [];
//   if (Array.isArray(res?.data?.data)) return res.data.data;
//   if (Array.isArray(res?.data)) return res.data;
//   if (Array.isArray(res)) return res;
//   if (Array.isArray(res?.results)) return res.results;
//   return [];
// };

// const extractPagination = (res) => {
//   if (!res) return null;
//   if (res?.pagination) return res.pagination;
//   if (res?.data?.pagination) return res.data.pagination;
//   return null;
// };

// const extractTotal = (res) => {
//   if (!res) return 0;
//   if (typeof res?.pagination?.total === "number") return res.pagination.total;
//   if (typeof res?.data?.pagination?.total === "number")
//     return res.data.pagination.total;
//   if (typeof res?.total === "number") return res.total;
//   if (Array.isArray(res?.data)) return res.data.length;
//   if (Array.isArray(res)) return res.length;
//   return 0;
// };

// // â”€â”€â”€ Plan ID normalization (handles arrays, JSON strings, CSV) â”€
// const normalizePlanIds = (value) => {
//   if (value === null || value === undefined || value === "") return [];

//   let values = [];
//   if (Array.isArray(value)) {
//     values = value;
//   } else if (typeof value === "string" && value.trim().startsWith("[")) {
//     try {
//       const parsed = JSON.parse(value);
//       values = Array.isArray(parsed) ? parsed : [parsed];
//     } catch {
//       values = [value];
//     }
//   } else if (typeof value === "string" && value.includes(",")) {
//     values = value.split(",");
//   } else {
//     values = [value];
//   }

//   return [
//     ...new Set(
//       values
//         .map((item) => {
//           if (item && typeof item === "object") {
//             return item.subscription_plan_id ?? item.id ?? item._id;
//           }
//           return item;
//         })
//         .map(Number)
//         .filter((val) => Number.isInteger(val) && val > 0),
//     ),
//   ];
// };

// const SubscriptionPlanOffers = () => {
//   const navigate = useNavigate();
//   const { user } = useAuth();
//   const userId = user?.id;

//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [deleteId, setDeleteId] = useState(null);
//   const [deleteLoading, setDeleteLoading] = useState(false);
//   const [search, setSearch] = useState("");
//   const [debouncedSearch, setDebouncedSearch] = useState("");
//   const [page, setPage] = useState(1);
//   // pageSize mirrors API's pagination.limit â€” display only, never sent.
//   const [pageSize, setPageSize] = useState(0);
//   const [total, setTotal] = useState(0);
//   const [paginationLinks, setPaginationLinks] = useState(null);
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [userNameCache, setUserNameCache] = useState({});

//   // Map of planId -> plan object for resolving names in the table
//   const [plansById, setPlansById] = useState({});

//   // Tab counts fetched from API
//   const [statusCounts, setStatusCounts] = useState({
//     all: 0,
//     active: 0,
//     inactive: 0,
//   });
//   const [countsLoading, setCountsLoading] = useState(false);
//   const requestIdRef = useRef(0);

//   // â”€â”€â”€ Debounce search + reset page â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     const t = setTimeout(() => {
//       setDebouncedSearch(search.trim());
//       setPage(1);
//     }, 400);
//     return () => clearTimeout(t);
//   }, [search]);

//   useEffect(() => {
//     setPage(1);
//   }, [statusFilter]);

//   // â”€â”€â”€ Load users once â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     const loadUsers = async () => {
//       try {
//         const users = await fetchUsers();
//         const userMap = {};
//         Object.keys(users || {}).forEach((id) => {
//           userMap[id] = users[id].name;
//         });
//         setUserNameCache(userMap);
//       } catch (err) {
//         console.warn("Could not load users:", err);
//       }
//     };
//     loadUsers();
//   }, []);

//   // â”€â”€â”€ Load all subscription plans once for name resolution â”€â”€â”€â”€
//   useEffect(() => {
//     let mounted = true;
//     const loadPlans = async () => {
//       try {
//         const response = await subscriptionPlanService.getAll({ limit: 1000 });
//         const rawData =
//           response?.data?.data ??
//           response?.data?.results ??
//           response?.data ??
//           [];
//         const list = Array.isArray(rawData) ? rawData : [];

//         const map = {};
//         list.forEach((plan) => {
//           const planId = Number(
//             plan.id ?? plan._id ?? plan.subscription_plan_id,
//           );
//           if (Number.isInteger(planId) && planId > 0) {
//             map[planId] = {
//               id: planId,
//               name: plan.plan_name ?? "Unnamed Plan",
//               code: plan.plan_code ?? "",
//               price: Number(plan.price ?? 0),
//             };
//           }
//         });

//         if (mounted) setPlansById(map);
//       } catch (error) {
//         console.error("Failed to load subscription plans:", error);
//         if (mounted) setPlansById({});
//       }
//     };
//     loadPlans();
//     return () => {
//       mounted = false;
//     };
//   }, []);

//   const getUserNameCached = (userId) => {
//     if (userId === null || userId === undefined || userId === "") return "-";
//     const key = String(userId);
//     return userNameCache[key] || userNameCache[userId] || `User ${userId}`;
//   };

//   const normalizeOffer = (item) => {
//     // Resolve plan IDs from any of the possible shapes
//     const planIds = normalizePlanIds(
//       item.subscription_plan_id ??
//         item.subscription_plan_ids ??
//         item.subscription_plan ??
//         item.SubscriptionPlan?.id ??
//         item.SubscriptionPlan?._id ??
//         null,
//     );

//     // Also handle case where API returns plans array (or single object)
//     let apiPlans = [];
//     if (Array.isArray(item.subscription_plans)) {
//       apiPlans = item.subscription_plans;
//     } else if (Array.isArray(item.SubscriptionPlans)) {
//       apiPlans = item.SubscriptionPlans;
//     } else if (
//       item.SubscriptionPlan &&
//       typeof item.SubscriptionPlan === "object"
//     ) {
//       apiPlans = [item.SubscriptionPlan];
//     }

//     const apiPlanMap = {};
//     apiPlans.forEach((p) => {
//       const pid = Number(p?.id ?? p?._id ?? p?.subscription_plan_id);
//       if (Number.isInteger(pid) && pid > 0) {
//         apiPlanMap[pid] = {
//           id: pid,
//           name: p.plan_name ?? "Unnamed Plan",
//           code: p.plan_code ?? "",
//           price: Number(p.price ?? 0),
//         };
//       }
//     });

//     return {
//       id: item.id || item._id,
//       subscription_plan_id: planIds,
//       apiPlanMap,
//       offer_name: item.offer_name || "",
//       offer_type: item.offer_type || "",
//       offer_value: parseFloat(item.offer_value) || 0,
//       start_date: item.start_date || null,
//       end_date: item.end_date || null,
//       coupon_required:
//         item.coupon_required === 1 || item.coupon_required === true,
//       status: item.status === 1 || item.status === true,
//       is_status: item.status === 1 || item.status === true,
//       created_by: item.created_by || null,
//       updated_by: item.updated_by || null,
//       createdAt: item.created_at || item.createdAt || null,
//       updatedAt: item.updated_at || item.updatedAt || null,
//       created_at_raw: item.created_at || null,
//       updated_at_raw: item.updated_at || null,
//       raw: item,
//     };
//   };

//   const getStatusValue = (row) => {
//     if (row.is_status !== undefined) {
//       return row.is_status;
//     }
//     if (row.status !== undefined) {
//       return row.status === 1 || row.status === true;
//     }
//     return true;
//   };

//   // â”€â”€â”€ Resolve a plan by ID (prefer API response, fallback to catalog) â”€
//   const resolvePlan = (planId, row) => {
//     if (row?.apiPlanMap && row.apiPlanMap[planId]) {
//       return row.apiPlanMap[planId];
//     }
//     if (plansById[planId]) {
//       return plansById[planId];
//     }
//     return {
//       id: planId,
//       name: `Plan ${planId}`,
//       code: "",
//       price: 0,
//     };
//   };

//   // â”€â”€â”€ Load one page from API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const load = useCallback(async () => {
//     const requestId = ++requestIdRef.current;
//     setLoading(true);
//     try {
//       const params = { page };
//       if (debouncedSearch) params.search = debouncedSearch;
//       if (statusFilter === "active") params.status = 1;
//       else if (statusFilter === "inactive") params.status = 0;

//       const r = await subscriptionPlanOfferService.getAll(params);
//       if (requestIdRef.current !== requestId) return;

//       const rawData = extractList(r);
//       const pagination = extractPagination(r);

//       const offers = rawData.map(normalizeOffer);

//       setData(offers);
//       setPaginationLinks(pagination?.links || null);

//       const serverTotal = Number(pagination?.total || 0);
//       setTotal(serverTotal > 0 ? serverTotal : offers.length);

//       // Adopt API's page size for display
//       if (pagination?.limit && Number(pagination.limit) > 0) {
//         setPageSize(Number(pagination.limit));
//       }
//       // Follow server clamp
//       if (pagination?.page && Number(pagination.page) !== page) {
//         setPage(Number(pagination.page));
//       }
//     } catch (error) {
//       if (requestIdRef.current !== requestId) return;
//       console.error("Load error:", error);
//       showError(error.message || "Failed to load subscription plan offers");
//       setData([]);
//       setTotal(0);
//       setPaginationLinks(null);
//     } finally {
//       if (requestIdRef.current === requestId) setLoading(false);
//     }
//   }, [page, debouncedSearch, statusFilter]);

//   useEffect(() => {
//     load();
//   }, [load]);

//   // â”€â”€â”€ Tab counts via limit=1 requests â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const fetchCount = useCallback(async (status) => {
//     const params = { page: 1, limit: 1 };
//     if (status === "active") params.status = 1;
//     else if (status === "inactive") params.status = 0;
//     const res = await subscriptionPlanOfferService.getAll(params);
//     return extractTotal(res);
//   }, []);

//   const loadCounts = useCallback(async () => {
//     setCountsLoading(true);
//     try {
//       const [all, active] = await Promise.all([
//         fetchCount("all"),
//         fetchCount("active"),
//       ]);
//       setStatusCounts({ all, active, inactive: Math.max(0, all - active) });
//     } catch (err) {
//       console.error("Failed to load counts:", err);
//     } finally {
//       setCountsLoading(false);
//     }
//   }, [fetchCount]);

//   useEffect(() => {
//     loadCounts();
//   }, [loadCounts]);

//   const refreshAll = () => {
//     load();
//     loadCounts();
//   };

//   // â”€â”€â”€ Display helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const getCreatedByName = (row) => {
//     if (!row) return "-";
//     const userIdValue = row.created_by ?? row.updated_by ?? null;
//     return userIdValue !== null &&
//       userIdValue !== undefined &&
//       userIdValue !== ""
//       ? getUserNameCached(userIdValue)
//       : "-";
//   };

//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     const userIdValue = row.updated_by ?? row.created_by ?? null;
//     return userIdValue !== null &&
//       userIdValue !== undefined &&
//       userIdValue !== ""
//       ? getUserNameCached(userIdValue)
//       : "-";
//   };

//   const formatDateDisplay = (date) => {
//     if (!date) return "-";
//     if (typeof date === "string" && date.includes("/")) {
//       return date.split(",")[0].trim();
//     }
//     const parsedDate = new Date(date);
//     if (isNaN(parsedDate.getTime())) return "-";
//     return parsedDate.toLocaleDateString("en-GB");
//   };

//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       await subscriptionPlanOfferService.delete(deleteId);
//       showSuccess("Offer deleted successfully");
//       load();
//       loadCounts();
//     } catch (error) {
//       console.error("Delete error:", error);
//       const message = error?.response?.data?.message || error?.message || "";
//       if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
//         showError(
//           "Cannot delete this offer because it is being used in other records.",
//         );
//       } else {
//         showError(message || "Failed to delete offer");
//       }
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   const handleStatusToggle = async (row) => {
//     const currentStatus = getStatusValue(row);
//     const newStatus = !currentStatus;

//     if (!row?.id) {
//       showError("Offer ID is missing");
//       return;
//     }

//     const planIds = Array.isArray(row.subscription_plan_id)
//       ? row.subscription_plan_id
//       : normalizePlanIds(row.subscription_plan_id);

//     if (planIds.length === 0) {
//       showError("At least one subscription plan ID is required");
//       return;
//     }

//     if (!userId) {
//       showError("User ID is missing. Please login again.");
//       return;
//     }

//     try {
//       const payload = {
//         // Always send array so multi-plan offers stay intact
//         subscription_plan_id: planIds,
//         status: newStatus ? 1 : 0,
//         updated_by: Number(userId),
//       };

//       console.log("STATUS TOGGLE PAYLOAD:", payload);

//       await subscriptionPlanOfferService.update(row.id, payload);

//       showSuccess(
//         `Status ${newStatus ? "activated" : "deactivated"} successfully`,
//       );

//       await load();
//       await loadCounts();
//     } catch (error) {
//       console.error("Status toggle error:", error);
//       console.error("STATUS API RESPONSE:", error?.response?.data);

//       showError(
//         error?.response?.data?.message ||
//           error?.response?.data?.error ||
//           error?.message ||
//           "Failed to update status",
//       );
//     }
//   };

//   const isOfferActive = (row) => {
//     if (!row.start_date || !row.end_date) return false;
//     const now = new Date();
//     const start = new Date(row.start_date);
//     const end = new Date(row.end_date);
//     return now >= start && now <= end;
//   };

//   const getOfferTypeIcon = (type) => {
//     switch (type) {
//       case "percentage":
//         return <MdPercent className="text-[#4529f7]" />;
//       case "fixed":
//         return <MdAttachMoney className="text-green-500" />;
//       case "free_trial":
//         return <MdCalendarToday className="text-orange-500" />;
//       default:
//         return <MdLocalOffer className="text-slate-500" />;
//     }
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * (pageSize || 20) + i + 1,
//     },
//     {
//       header: "Offer Name",
//       key: "offer_name",
//       render: (v) => <span className="font-medium text-slate-800">{v}</span>,
//     },
//     {
//       header: "Plans",
//       key: "plans",
//       render: (_, row) => {
//         const planIds = Array.isArray(row.subscription_plan_id)
//           ? row.subscription_plan_id
//           : [];

//         if (planIds.length === 0) {
//           return <span className="text-slate-400">-</span>;
//         }

//         const visible = planIds.slice(0, 2);
//         const remaining = planIds.length - visible.length;

//         return (
//           <div className="flex flex-wrap items-center gap-1 max-w-[260px]">
//             {visible.map((planId) => {
//               const plan = resolvePlan(planId, row);
//               return (
//                 <span
//                   key={planId}
//                   className="inline-flex items-center px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 text-xs font-medium ring-1 ring-blue-100 max-w-[140px]"
//                   title={plan.name}
//                 >
//                   <span className="truncate">{plan.name}</span>
//                 </span>
//               );
//             })}
//             {remaining > 0 && (
//               <span
//                 className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-xs font-medium"
//                 title={planIds
//                   .map((id) => resolvePlan(id, row).name)
//                   .join(", ")}
//               >
//                 +{remaining} more
//               </span>
//             )}
//           </div>
//         );
//       },
//     },
//     {
//       header: "Type",
//       key: "offer_type",
//       render: (v, row) => (
//         <span className="inline-flex items-center gap-1.5 capitalize text-slate-600">
//           {getOfferTypeIcon(v)}
//           {v || "-"}
//         </span>
//       ),
//     },
//     {
//       header: "Value",
//       key: "offer_value",
//       render: (v, row) => {
//         const num = parseFloat(v);
//         const formatted = isNaN(num) ? "0.00" : num.toFixed(2);
//         return (
//           <span className="font-semibold text-[#2c0eee]">
//             {row.offer_type === "percentage"
//               ? `${formatted}%`
//               : `â‚¹${formatted}`}
//           </span>
//         );
//       },
//     },
//     {
//       header: "Period",
//       key: "start_date",
//       render: (_, row) => (
//         <div className="text-sm">
//           <span className="text-slate-500">{formatDate(row.start_date)}</span>
//           <span className="text-gray-300 mx-1">â†’</span>
//           <span className="text-slate-500">{formatDate(row.end_date)}</span>
//         </div>
//       ),
//     },
//     {
//       header: "Coupon Required",
//       key: "coupon_required",
//       render: (v) => (
//         <span
//           className={`text-sm font-medium ${
//             v ? "text-[#2c0eee]" : "text-slate-400"
//           }`}
//         >
//           {v ? "Yes" : "No"}
//         </span>
//       ),
//     },
//     {
//       header: "Live",
//       key: "is_live",
//       render: (_, row) => {
//         const isActive = getStatusValue(row);
//         const isCurrentlyActive = isOfferActive(row);
//         return (
//           <span
//             className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
//               isCurrentlyActive && isActive
//                 ? "bg-green-50 text-green-700"
//                 : "bg-slate-100 text-slate-500"
//             }`}
//           >
//             <span
//               className={`w-1.5 h-1.5 rounded-full ${
//                 isCurrentlyActive && isActive ? "bg-green-500" : "bg-gray-400"
//               }`}
//             />
//             {isCurrentlyActive && isActive ? "Live" : "Inactive"}
//           </span>
//         );
//       },
//     },
//     {
//       header: "Status",
//       key: "status",
//       render: (status, row) => {
//         const isActive = getStatusValue(row);
//         return (
//           <button
//             onClick={() => handleStatusToggle(row)}
//             className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//               isActive ? "bg-[#2c0eee]" : "bg-gray-300"
//             }`}
//           >
//             <span
//               className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//                 isActive ? "translate-x-6" : "translate-x-1"
//               }`}
//             />
//           </button>
//         );
//       },
//     },
//     {
//       header: "Updated By",
//       key: "updated_by",
//       render: (_, row) => (
//         <div className="flex items-center gap-1.5">
//           <span className="text-slate-600 text-sm font-medium">
//             {row.updated_by ? getUpdatedByName(row) : "-"}
//           </span>
//         </div>
//       ),
//     },
//     {
//       header: "Updated At",
//       key: "updatedAt",
//       render: (v) => (
//         <span className="text-slate-500 text-sm">{formatDate(v)}</span>
//       ),
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => (
//         <div className="flex gap-1">
//           <button
//             onClick={() =>
//               navigate(`/subscription-plan-offers/view/${row.id}`, {
//                 state: { item: row },
//               })
//             }
//             className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
//             title="View"
//           >
//             <MdVisibility size={16} />
//           </button>
//           <button
//             onClick={() =>
//               navigate(`/subscription-plan-offers/edit/${row.id}`, {
//                 state: { item: row },
//               })
//             }
//             className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
//             title="Edit"
//           >
//             <MdEdit size={16} />
//           </button>
//           <button
//             onClick={() => setDeleteId(id)}
//             className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
//             title="Delete"
//           >
//             <MdDelete size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   const tabs = [
//     { key: "all", label: "All", count: statusCounts.all },
//     { key: "active", label: "Active", count: statusCounts.active },
//     { key: "inactive", label: "Inactive", count: statusCounts.inactive },
//   ];

//   return (
//     <div className="space-y-4">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">
//             Subscription Plan Offers
//           </h1>
//           <p className="text-sm text-slate-500 mt-1">
//             Manage offers and discounts for subscription plans
//           </p>
//         </div>
//         <div className="flex items-center gap-3">
//           <Button
//             variant="secondary"
//             icon={MdUpdate}
//             onClick={refreshAll}
//             loading={loading || countsLoading}
//             disabled={loading || countsLoading}
//           >
//             Refresh
//           </Button>
//           <Button
//             icon={MdAdd}
//             onClick={() => navigate("/subscription-plan-offers/add")}
//           >
//             Add Offer
//           </Button>
//         </div>
//       </div>

//       {/* Table Card */}
//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         {/* Top bar: search + tabs */}
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
//           <div className="relative w-full sm:w-72">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search offers..."
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
//             />
//           </div>

//           <div className="flex items-center gap-5 text-sm">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${
//                   statusFilter === tab.key
//                     ? "text-[#2c0eee]"
//                     : "text-slate-500 hover:text-slate-700"
//                 }`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                     statusFilter === tab.key
//                       ? "bg-slate-800 text-white shadow-sm"
//                       : "bg-slate-100 text-slate-500"
//                   }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={data}
//           loading={loading}
//           emptyMessage="No subscription plan offers found"
//         />

//         {/* Footer â€” backend pagination only */}
//         <div className="px-5 py-3 border-t border-slate-100">
//           <Pagination
//             page={page}
//             total={total}
//             limit={pageSize || 20}
//             links={paginationLinks}
//             itemsCount={data.length}
//             onChange={setPage}
//           />
//         </div>
//       </div>

//       {/* Confirm Dialog */}
//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Offer"
//         message="Delete this offer? This action cannot be undone."
//       />
//     </div>
//   );
// };

// export default SubscriptionPlanOffers;

import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdLocalOffer,
  MdPercent,
  MdAttachMoney,
  MdCalendarToday,
  MdUpdate,
  MdClose,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { subscriptionPlanOfferService } from "../../services/subscriptionPlanOffer.service";
import { subscriptionPlanService } from "../../services/subscriptionPlan.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

// â”€â”€â”€ Response extractors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const extractList = (res) => {
  if (!res) return [];
  if (Array.isArray(res?.data?.data)) return res.data.data;
  if (Array.isArray(res?.data)) return res.data;
  if (Array.isArray(res)) return res;
  if (Array.isArray(res?.results)) return res.results;
  return [];
};

const extractPagination = (res) => {
  if (!res) return null;
  if (res?.pagination) return res.pagination;
  if (res?.data?.pagination) return res.data.pagination;
  return null;
};

const extractTotal = (res) => {
  if (!res) return 0;
  if (typeof res?.pagination?.total === "number") return res.pagination.total;
  if (typeof res?.data?.pagination?.total === "number")
    return res.data.pagination.total;
  if (typeof res?.total === "number") return res.total;
  if (Array.isArray(res?.data)) return res.data.length;
  if (Array.isArray(res)) return res.length;
  return 0;
};

const normalizePlanIds = (value) => {
  if (value === null || value === undefined || value === "") return [];
  let values = [];
  if (Array.isArray(value)) values = value;
  else if (typeof value === "string" && value.trim().startsWith("[")) {
    try {
      const parsed = JSON.parse(value);
      values = Array.isArray(parsed) ? parsed : [parsed];
    } catch {
      values = [value];
    }
  } else if (typeof value === "string" && value.includes(",")) {
    values = value.split(",");
  } else values = [value];

  return [
    ...new Set(
      values
        .map((item) => {
          if (item && typeof item === "object") {
            return item.subscription_plan_id ?? item.id ?? item._id;
          }
          return item;
        })
        .map(Number)
        .filter((val) => Number.isInteger(val) && val > 0),
    ),
  ];
};

// â”€â”€â”€ Group rows that belong to the same logical offer â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// Backend creates one row per plan. We group them by:
//   offer_name + offer_type + offer_value + start_date + end_date + created_at
// created_at is the strongest signal â€” rows created in the same batch share
// the exact same timestamp (down to the second).
const getGroupKey = (item) => {
  if (!item) return "";
  const name = String(item.offer_name ?? "").trim().toLowerCase();
  const type = String(item.offer_type ?? "");
  const value = String(item.offer_value ?? "");
  const start = String(item.start_date ?? "");
  const end = String(item.end_date ?? "");
  const created = String(
    item.created_at ?? item.createdAt ?? "",
  ).toLowerCase();
  return `${name}|${type}|${value}|${start}|${end}|${created}`;
};

const groupOffers = (offers) => {
  const map = new Map();
  offers.forEach((row) => {
    const key = getGroupKey(row);
    if (!map.has(key)) {
      map.set(key, {
        ...row,
        ids: [row.id],
        plan_ids: [row.subscription_plan_id],
      });
    } else {
      const group = map.get(key);
      group.ids.push(row.id);
      group.plan_ids.push(row.subscription_plan_id);
    }
  });
  return Array.from(map.values());
};

const SubscriptionPlanOffers = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const userId = user?.id;

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(0);
  const [total, setTotal] = useState(0);
  const [paginationLinks, setPaginationLinks] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [userNameCache, setUserNameCache] = useState({});
  const [plansById, setPlansById] = useState({});
  const [togglingIds, setTogglingIds] = useState(new Set());
  const requestIdRef = useRef(0);

  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [search]);

  useEffect(() => {
    setPage(1);
  }, [statusFilter]);

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const users = await fetchUsers();
        const userMap = {};
        Object.keys(users || {}).forEach((id) => {
          userMap[id] = users[id].name;
        });
        setUserNameCache(userMap);
      } catch (err) {
        console.warn("Could not load users:", err);
      }
    };
    loadUsers();
  }, []);

  useEffect(() => {
    let mounted = true;
    const loadPlans = async () => {
      try {
        const response = await subscriptionPlanService.getAll({ limit: 1000 });
        const rawData =
          response?.data?.data ??
          response?.data?.results ??
          response?.data ??
          [];
        const list = Array.isArray(rawData) ? rawData : [];
        const map = {};
        list.forEach((plan) => {
          const planId = Number(plan.id ?? plan._id ?? plan.subscription_plan_id);
          if (Number.isInteger(planId) && planId > 0) {
            map[planId] = {
              id: planId,
              name: plan.plan_name ?? "Unnamed Plan",
              code: plan.plan_code ?? "",
              price: Number(plan.price ?? 0),
            };
          }
        });
        if (mounted) setPlansById(map);
      } catch (error) {
        console.error("Failed to load subscription plans:", error);
        if (mounted) setPlansById({});
      }
    };
    loadPlans();
    return () => {
      mounted = false;
    };
  }, []);

  const getUserNameCached = (userId) => {
    if (userId === null || userId === undefined || userId === "") return "-";
    const key = String(userId);
    return userNameCache[key] || userNameCache[userId] || `User ${userId}`;
  };

const normalizeBoolean = (value) =>
  value === true || value === 1 || value === "1" || value === "true";

const normalizeOffer = (item) => ({
  id: item.id || item._id,
  subscription_plan_id:
    item.subscription_plan_id ?? item.SubscriptionPlan?.id ?? "",
  offer_name: item.offer_name || "",
  offer_type: item.offer_type || "",
  offer_value: parseFloat(item.offer_value) || 0,
  start_date: item.start_date || null,
  end_date: item.end_date || null,
  coupon_required: normalizeBoolean(item.coupon_required),
  status: normalizeBoolean(item.status ?? item.is_status),
  is_status: normalizeBoolean(item.status ?? item.is_status),
  created_by: item.created_by || null,
  updated_by: item.updated_by || null,
  createdAt: item.created_at || item.createdAt || null,
  created_at: item.created_at || item.createdAt || null,
  updatedAt: item.updated_at || item.updatedAt || null,
});

const getStatusValue = (row) => {
  if (!row) return false;
  if (row.is_status !== undefined) return normalizeBoolean(row.is_status);
  if (row.status !== undefined) return normalizeBoolean(row.status);
  return true;
};

  const resolvePlan = (planId, row) => {
    if (row?.apiPlanMap && row.apiPlanMap[planId]) return row.apiPlanMap[planId];
    if (plansById[planId]) return plansById[planId];
    return { id: planId, name: `Plan ${planId}`, code: "", price: 0 };
  };

  const load = useCallback(async () => {
    const requestId = ++requestIdRef.current;
    setLoading(true);
    try {
      const r = await subscriptionPlanOfferService.getAll({ limit: 1000 });
      if (requestIdRef.current !== requestId) return;

      const rawData = extractList(r);
      const pagination = extractPagination(r);

      const offers = rawData.map(normalizeOffer);
      const grouped = groupOffers(offers);

      setData(grouped);
      setPaginationLinks(pagination?.links || null);

      const serverTotal = Number(pagination?.total || 0);
      setTotal(serverTotal > 0 ? serverTotal : grouped.length);

      if (pagination?.limit && Number(pagination.limit) > 0) {
        setPageSize(Number(pagination.limit));
      }
    } catch (error) {
      if (requestIdRef.current !== requestId) return;
      console.error("Load error:", error);
      showError(error.message || "Failed to load subscription plan offers");
      setData([]);
      setTotal(0);
      setPaginationLinks(null);
    } finally {
      if (requestIdRef.current === requestId) setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // Compute status counts accurately from loaded data
  const statusCounts = useMemo(() => {
    const all = data.length;
    const active = data.filter((item) => getStatusValue(item) === true).length;
    const inactive = Math.max(0, all - active);
    return { all, active, inactive };
  }, [data]);

  // Client-side filtering for status tab & multi-field search
  const displayData = useMemo(() => {
    let list = data;

    // Filter by status tab (all / active / inactive)
    if (statusFilter === "active") {
      list = list.filter((item) => getStatusValue(item) === true);
    } else if (statusFilter === "inactive") {
      list = list.filter((item) => getStatusValue(item) === false);
    }

    // Filter by search query
    const q = search.trim().toLowerCase();
    if (!q) return list;

    return list.filter((item) => {
      const planNames = (item.plan_ids || [])
        .map((planId) => resolvePlan(planId, item)?.name || "")
        .join(" ");

      return [
        item.offer_name,
        item.offer_type,
        String(item.offer_value || ""),
        planNames,
        item.coupon_required ? "yes coupon" : "no coupon",
      ].some((val) =>
        String(val ?? "")
          .toLowerCase()
          .includes(q)
      );
    });
  }, [data, statusFilter, search, plansById]);

  const refreshAll = () => {
    load();
  };

  const getUpdatedByName = (row) => {
    if (!row) return "-";
    const userIdValue = row.updated_by ?? row.created_by ?? null;
    return userIdValue !== null && userIdValue !== undefined && userIdValue !== ""
      ? getUserNameCached(userIdValue)
      : "-";
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleteLoading(true);
    try {
      for (const rowId of deleteTarget.ids) {
        try {
          await subscriptionPlanOfferService.delete(rowId);
        } catch (err) {
          console.warn(`Delete failed for row ${rowId}:`, err);
        }
      }
      showSuccess("Offer deleted successfully");
      load();
    } catch (error) {
      console.error("Delete error:", error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
        showError(
          "Cannot delete this offer because it is being used in other records.",
        );
      } else {
        showError(message || "Failed to delete offer");
      }
    } finally {
      setDeleteTarget(null);
      setDeleteLoading(false);
    }
  };

  // â”€â”€â”€ Toggle status for entire group â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const handleStatusToggle = async (row) => {
    const primaryId = row?.ids?.[0] || row?.id;
    if (!primaryId || togglingIds.has(primaryId)) return;

    if (!userId) {
      showError("User ID is missing. Please login again.");
      return;
    }
    if (!Array.isArray(row.ids) || row.ids.length === 0) {
      showError("Offer IDs are missing");
      return;
    }

    const currentStatus = getStatusValue(row);
    const newStatus = !currentStatus;

    setTogglingIds((prev) => new Set(prev).add(primaryId));

    // Optimistic UI update for 0ms delay
    setData((prevData) =>
      prevData.map((item) => {
        if (item.ids?.includes(primaryId) || item.id === primaryId) {
          return {
            ...item,
            status: newStatus,
            is_status: newStatus,
          };
        }
        return item;
      })
    );

    try {
      await Promise.all(
        row.ids.map((rowId, i) =>
          subscriptionPlanOfferService.update(rowId, {
            subscription_plan_id: row.plan_ids[i],
            status: newStatus ? 1 : 0,
            updated_by: Number(userId),
          })
        )
      );

      showSuccess(
        `Status ${newStatus ? "activated" : "deactivated"} successfully`
      );
    } catch (error) {
      console.error("Status toggle error:", error);
      // Rollback optimistic update on error
      setData((prevData) =>
        prevData.map((item) => {
          if (item.ids?.includes(primaryId) || item.id === primaryId) {
            return {
              ...item,
              status: currentStatus,
              is_status: currentStatus,
            };
          }
          return item;
        })
      );
      showError(
        error?.response?.data?.message ||
          error?.response?.data?.error ||
          error?.message ||
          "Failed to update status"
      );
    } finally {
      setTogglingIds((prev) => {
        const next = new Set(prev);
        next.delete(primaryId);
        return next;
      });
    }
  };

  const isOfferActive = (row) => {
    if (!row.start_date || !row.end_date) return false;
    const now = new Date();
    const start = new Date(row.start_date);
    const end = new Date(row.end_date);
    return now >= start && now <= end;
  };

  const getOfferTypeIcon = (type) => {
    switch (type) {
      case "percentage":
        return <MdPercent className="text-[#4529f7]" />;
      case "fixed":
        return <MdAttachMoney className="text-green-500" />;
      case "free_trial":
        return <MdCalendarToday className="text-orange-500" />;
      default:
        return <MdLocalOffer className="text-slate-500" />;
    }
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * (pageSize || 20) + i + 1,
    },
    {
      header: "Offer Name",
      key: "offer_name",
      render: (v) => <span className="font-medium text-slate-800">{v}</span>,
    },
    {
      header: "Plans",
      key: "plans",
      render: (_, row) => {
        const planIds = row.plan_ids || [];
        if (planIds.length === 0) {
          return <span className="text-slate-400">-</span>;
        }
        const visible = planIds.slice(0, 2);
        const remaining = planIds.length - visible.length;
        return (
          <div className="flex flex-wrap items-center gap-1 max-w-[260px]">
            {visible.map((planId) => {
              const plan = resolvePlan(planId, row);
              return (
                <span
                  key={planId}
                  className="inline-flex items-center px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 text-xs font-medium ring-1 ring-blue-100 max-w-[140px]"
                  title={plan.name}
                >
                  <span className="truncate">{plan.name}</span>
                </span>
              );
            })}
            {remaining > 0 && (
              <span
                className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-xs font-medium"
                title={planIds.map((id) => resolvePlan(id, row).name).join(", ")}
              >
                +{remaining} more
              </span>
            )}
          </div>
        );
      },
    },
    {
      header: "Type",
      key: "offer_type",
      render: (v) => (
        <span className="inline-flex items-center gap-1.5 capitalize text-slate-600">
          {getOfferTypeIcon(v)}
          {v || "-"}
        </span>
      ),
    },
    {
      header: "Value",
      key: "offer_value",
      render: (v, row) => {
        const num = parseFloat(v);
        const formatted = isNaN(num) ? "0.00" : num.toFixed(2);
        return (
          <span className="font-semibold text-[#2c0eee]">
            {row.offer_type === "percentage" ? `${formatted}%` : `â‚¹${formatted}`}
          </span>
        );
      },
    },
    {
      header: "Period",
      key: "start_date",
      render: (_, row) => (
        <div className="text-sm">
          <span className="text-slate-500">{formatDate(row.start_date)}</span>
          <span className="text-gray-300 mx-1">â†’</span>
          <span className="text-slate-500">{formatDate(row.end_date)}</span>
        </div>
      ),
    },
    {
      header: "Coupon Required",
      key: "coupon_required",
      render: (v) => (
        <span
          className={`text-sm font-medium ${
            v ? "text-[#2c0eee]" : "text-slate-400"
          }`}
        >
          {v ? "Yes" : "No"}
        </span>
      ),
    },
    {
      header: "Live",
      key: "is_live",
      render: (_, row) => {
        const isActive = getStatusValue(row);
        const isCurrentlyActive = isOfferActive(row);
        return (
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
              isCurrentlyActive && isActive
                ? "bg-green-50 text-green-700"
                : "bg-slate-100 text-slate-500"
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isCurrentlyActive && isActive ? "bg-green-500" : "bg-gray-400"
              }`}
            />
            {isCurrentlyActive && isActive ? "Live" : "Inactive"}
          </span>
        );
      },
    },
    {
      header: "Status",
      key: "status",
      render: (status, row) => {
        const isActive = getStatusValue(row);
        const primaryId = row?.ids?.[0] || row?.id;
        const isToggling = togglingIds.has(primaryId);
        return (
          <button
            onClick={() => handleStatusToggle(row)}
            disabled={isToggling}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
              isToggling ? "opacity-50 cursor-not-allowed" : "cursor-pointer"
            } ${isActive ? "bg-[#2c0eee]" : "bg-gray-300"}`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
                isActive ? "translate-x-6" : "translate-x-1"
              }`}
            />
          </button>
        );
      },
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => (
        <span className="text-slate-600 text-sm font-medium">
          {row.updated_by ? getUpdatedByName(row) : "-"}
        </span>
      ),
    },
    {
      header: "Updated At",
      key: "updatedAt",
      render: (v) => (
        <span className="text-slate-500 text-sm">{formatDate(v)}</span>
      ),
    },
    {
      header: "Actions",
      key: "actions",
      render: (_, row) => (
        <div className="flex gap-1">
          <button
            onClick={() =>
              navigate(`/subscription-plan-offers/view/${row.ids[0]}`, {
                state: { item: row },
              })
            }
            className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() =>
              navigate(`/subscription-plan-offers/edit/${row.ids[0]}`, {
                state: { item: row },
              })
            }
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteTarget(row)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: statusCounts.all },
    { key: "active", label: "Active", count: statusCounts.active },
    { key: "inactive", label: "Inactive", count: statusCounts.inactive },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Subscription Plan Offers
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage offers and discounts for subscription plans
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="secondary"
            icon={MdUpdate}
            onClick={refreshAll}
            loading={loading}
            disabled={loading}
          >
            Refresh
          </Button>
          <Button
            icon={MdAdd}
            onClick={() => navigate("/subscription-plan-offers/add")}
          >
            Add Offer
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search offers..."
              className="w-full pl-9 pr-8 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                title="Clear search"
              >
                <MdClose size={16} />
              </button>
            )}
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? "text-[#2c0eee]"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={displayData}
          loading={loading}
          emptyMessage="No subscription plan offers found"
        />

        <div className="px-5 py-3 border-t border-slate-100">
          <Pagination
            page={page}
            total={total}
            limit={pageSize || 20}
            links={paginationLinks}
            itemsCount={displayData.length}
            onChange={setPage}
          />
        </div>
      </div>

      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Offer"
        message="Delete this offer? This will remove all plans attached to it. This action cannot be undone."
      />
    </div>
  );
};

export default SubscriptionPlanOffers;
