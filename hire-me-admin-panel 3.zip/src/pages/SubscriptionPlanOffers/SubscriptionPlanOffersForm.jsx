import React, { useEffect, useRef, useState } from "react";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  MdArrowBack,
  MdSave,
  MdCancel,
  MdDelete,
  MdWarning,
  MdClose,
  MdApartment,
  MdCategory,
  MdAttachMoney,
  MdCheckCircle,
  MdErrorOutline,
  MdInfo,
  MdAssignment,
  MdDateRange,
  MdKeyboardArrowDown,
  MdSearch,
} from "react-icons/md";

import { subscriptionPlanOfferService } from "../../services/subscriptionPlanOffer.service";
import { subscriptionPlanService } from "../../services/subscriptionPlan.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";
import { useAuth } from "../../context/AuthContext";

// ─── Helpers ────────────────────────────────────────────────
const normalizeBoolean = (value) =>
  value === true || value === 1 || value === "1" || value === "true";

const normalizePlanIds = (value) => {
  if (value === null || value === undefined || value === "") return [];
  let values = [];
  if (Array.isArray(value)) values = value;
  else if (typeof value === "string" && value.trim().startsWith("[")) {
    try {
      const parsed = JSON.parse(value);
      values = Array.isArray(parsed) ? parsed : [parsed];
    } catch {
      values = [value];
    }
  } else if (typeof value === "string" && value.includes(",")) {
    values = value.split(",");
  } else values = [value];

  return [
    ...new Set(
      values
        .map((item) => {
          if (item && typeof item === "object") {
            return item.subscription_plan_id ?? item.id ?? item._id;
          }
          return item;
        })
        .map(Number)
        .filter((val) => Number.isInteger(val) && val > 0),
    ),
  ];
};

const formatCurrency = (value) => {
  const number = Number(value);
  if (!Number.isFinite(number)) return "0.00";
  return number.toFixed(2);
};

const getGroupKey = (item) => {
  if (!item) return "";
  const name = String(item.offer_name ?? "").trim().toLowerCase();
  const type = String(item.offer_type ?? "");
  const value = String(item.offer_value ?? "");
  const start = String(item.start_date ?? "");
  const end = String(item.end_date ?? "");
  const created = String(
    item.created_at ?? item.createdAt ?? "",
  ).toLowerCase();
  return `${name}|${type}|${value}|${start}|${end}|${created}`;
};

// ─── Status styles ─────────────────────────────────────────────
const STATUS_STYLES = {
  active: {
    pill: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200",
    icon: MdCheckCircle,
  },
  inactive: {
    pill: "bg-slate-100 text-slate-500 ring-1 ring-slate-200",
    icon: MdErrorOutline,
  },
};

const StatusPill = ({ status }) => {
  const style = STATUS_STYLES[status] || STATUS_STYLES.inactive;
  const Icon = style.icon;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${style.pill}`}
    >
      <Icon size={13} />
      {status ? status.charAt(0).toUpperCase() + status.slice(1) : "Unknown"}
    </span>
  );
};

const FieldLabel = ({ children, required }) => (
  <label className="block text-[13px] font-medium text-slate-600 mb-1.5">
    {children}
    {required && <span className="text-red-500 ml-0.5">*</span>}
  </label>
);

const ReadOnlyValue = ({ children }) => (
  <div className="text-sm text-slate-700 py-2 px-3 bg-slate-50 rounded-lg border border-slate-200">
    {children || "—"}
  </div>
);

const Toggle = ({ checked, onChange, name, disabled }) => (
  <label
    className={`relative inline-flex items-center ${disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer"}`}
  >
    <input
      type="checkbox"
      name={name}
      checked={checked || false}
      onChange={onChange}
      disabled={disabled}
      className="sr-only peer"
    />
    <div className="w-11 h-6 bg-slate-300 peer-checked:bg-blue-600 rounded-full transition-colors duration-300 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-5 after:w-5 after:shadow after:transition-transform after:duration-300 peer-checked:after:translate-x-5" />
  </label>
);

// ─── Multi-select dropdown for plans ────────────────────────
const PlanMultiSelect = ({ options, selectedIds, onToggle, onRemove, disabled }) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const containerRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
        setSearch("");
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredOptions = options.filter((opt) =>
    opt.label.toLowerCase().includes(search.toLowerCase()),
  );
  const selectedOptions = options.filter((opt) => selectedIds.includes(opt.value));

  return (
    <div className="relative" ref={containerRef}>
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
        className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg text-sm text-left bg-white flex items-center justify-between gap-2 focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
      >
        <div className="flex flex-wrap gap-1.5 flex-1 min-w-0 py-0.5">
          {selectedOptions.length === 0 ? (
            <span className="text-slate-400">
              {disabled ? "Loading plans..." : "Select plan(s)"}
            </span>
          ) : (
            selectedOptions.map((opt) => (
              <span
                key={opt.value}
                className="inline-flex items-center gap-1 pl-2 pr-1 py-0.5 rounded-md text-xs font-medium bg-blue-50 text-blue-700 ring-1 ring-blue-200"
              >
                {opt.shortLabel}
                <span
                  role="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemove(opt.value);
                  }}
                  className="p-0.5 rounded hover:bg-blue-100 hover:text-blue-900"
                >
                  <MdClose size={12} />
                </span>
              </span>
            ))
          )}
        </div>
        <MdKeyboardArrowDown
          size={18}
          className={`flex-shrink-0 text-slate-400 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </button>

      <AnimatePresence>
        {open && !disabled && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.12 }}
            className="absolute z-20 mt-1.5 w-full bg-white border border-slate-200 rounded-lg shadow-lg overflow-hidden"
          >
            <div className="p-2 border-b border-slate-100 flex items-center gap-2">
              <MdSearch size={16} className="text-slate-400 flex-shrink-0" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search plans..."
                autoFocus
                className="w-full text-sm focus:outline-none"
              />
              {selectedIds.length > 0 && (
                <button
                  type="button"
                  onClick={() => selectedIds.forEach((id) => onRemove(id))}
                  className="text-xs font-medium text-slate-400 hover:text-red-500 flex-shrink-0"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="max-h-56 overflow-y-auto py-1">
              {filteredOptions.length === 0 ? (
                <p className="px-3.5 py-2.5 text-sm text-slate-400">No plans found</p>
              ) : (
                filteredOptions.map((opt) => {
                  const checked = selectedIds.includes(opt.value);
                  return (
                    <label
                      key={opt.value}
                      className="flex items-center gap-2.5 px-3.5 py-2 text-sm hover:bg-slate-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => onToggle(opt.value)}
                        className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-2 focus:ring-blue-100"
                      />
                      <span className="text-slate-700">{opt.label}</span>
                    </label>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const TABS = [
  { id: "overview", label: "Overview", icon: MdAssignment },
  { id: "status", label: "Status & Activity", icon: MdInfo },
];

// ─── Main Component ──────────────────────────────────────────
const SubscriptionPlanOffersForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { user } = useAuth();
  const userId = user?.id;

  const [mode, setMode] = useState("add");
  const [loading, setLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(false);
  const [data, setData] = useState(null);
  const [subscriptionPlans, setSubscriptionPlans] = useState([]);
  const [loadingPlans, setLoadingPlans] = useState(false);
  const [userNameCache, setUserNameCache] = useState({});
  const [activeTab, setActiveTab] = useState("overview");
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [formValues, setFormValues] = useState({});
  // All rows in this logical offer group: [{id, planId}, ...]
  const [groupRows, setGroupRows] = useState([]);

  useEffect(() => {
    const path = location.pathname;
    if (path.includes("/view/")) setMode("view");
    else if (path.includes("/edit/")) setMode("edit");
    else setMode("add");
  }, [location.pathname]);

  // Load subscription plans
  useEffect(() => {
    let mounted = true;
    const loadPlans = async () => {
      setLoadingPlans(true);
      try {
        const response = await subscriptionPlanService.getAll({ limit: 1000 });
        const rawData =
          response?.data?.data ?? response?.data?.results ?? response?.data ?? [];
        const plans = Array.isArray(rawData) ? rawData : [];
        if (mounted) setSubscriptionPlans(plans);
      } catch (error) {
        console.error("Failed to fetch subscription plans:", error);
        if (mounted) setSubscriptionPlans([]);
      } finally {
        if (mounted) setLoadingPlans(false);
      }
    };
    loadPlans();
    return () => {
      mounted = false;
    };
  }, []);

  // Load users
  useEffect(() => {
    let mounted = true;
    const loadUsers = async () => {
      try {
        const users = await fetchUsers();
        if (!users || typeof users !== "object") return;
        const userMap = {};
        Object.keys(users).forEach((key) => {
          userMap[key] =
            users[key]?.name || users[key]?.username || `User ${key}`;
        });
        if (mounted) setUserNameCache(userMap);
      } catch (error) {
        console.error("Failed to load users:", error);
      }
    };
    loadUsers();
    return () => {
      mounted = false;
    };
  }, []);

  // ─── Fetch offer data (fresh from API) ────────────────────
  // Always fetches ALL offers, finds the one matching the URL id, and
  // groups all siblings sharing the same metadata key.
  useEffect(() => {
    let mounted = true;
    const fetchOffer = async () => {
      if ((mode !== "edit" && mode !== "view") || !id) return;
      setPageLoading(true);
      try {
        const targetId = Number(id);

        // Fetch ALL offers (no pagination) so we can find every sibling
        const allRes = await subscriptionPlanOfferService.getAll({
          page: 1,
          limit: 10000,
        });
        const allData =
          allRes?.data?.data ??
          allRes?.data?.results ??
          allRes?.data ??
          allRes?.results ??
          allRes;
        const allOffers = Array.isArray(allData) ? allData : [];

        if (allOffers.length === 0) {
          throw new Error("No offers found");
        }

        // Find the target row
        const targetRow = allOffers.find(
          (o) => Number(o.id ?? o._id) === targetId,
        );

        if (!targetRow) {
          throw new Error("Offer not found");
        }

        // Group rows that share the same metadata as the target
        const key = getGroupKey(targetRow);
        const siblings = allOffers.filter((o) => getGroupKey(o) === key);
        const source = siblings.length > 0 ? siblings : [targetRow];

        // Build row list — each row's id plus its single plan id
        const rows = source
          .map((r) => ({
            id: Number(r.id ?? r._id),
            planId: Number(r.subscription_plan_id),
          }))
          .filter((r) => Number.isInteger(r.id) && Number.isInteger(r.planId));

        // De-duplicate by row id
        const seen = new Set();
        const uniqueRows = [];
        rows.forEach((r) => {
          if (!seen.has(r.id)) {
            seen.add(r.id);
            uniqueRows.push(r);
          }
        });

        setGroupRows(uniqueRows);

        const planIds = uniqueRows.map((r) => r.planId);

        const normalizedData = {
          id: targetRow.id ?? targetRow._id ?? targetId,
          subscription_plan_id: planIds,
          offer_name: targetRow.offer_name ?? "",
          offer_type: String(targetRow.offer_type ?? ""),
          offer_value: Number.isFinite(Number(targetRow.offer_value))
            ? Number(targetRow.offer_value)
            : 0,
          start_date: targetRow.start_date ?? null,
          end_date: targetRow.end_date ?? null,
          coupon_required: normalizeBoolean(targetRow.coupon_required),
          status: normalizeBoolean(targetRow.status ?? targetRow.is_status),
          is_status: normalizeBoolean(targetRow.status ?? targetRow.is_status),
          created_by: targetRow.created_by ?? null,
          updated_by: targetRow.updated_by ?? null,
          created_at: targetRow.created_at ?? targetRow.createdAt ?? null,
          updated_at: targetRow.updated_at ?? targetRow.updatedAt ?? null,
          raw: targetRow,
        };

        if (mounted) setData(normalizedData);
      } catch (error) {
        console.error("Fetch offer error:", error);
        if (mounted) {
          showError(
            error?.response?.data?.message ||
              error?.message ||
              "Failed to load offer data",
          );
          navigate("/subscription-plan-offers");
        }
      } finally {
        if (mounted) setPageLoading(false);
      }
    };
    fetchOffer();
    return () => {
      mounted = false;
    };
  }, [id, mode, navigate]);

  const getUserNameCached = (userIdValue) => {
    if (userIdValue === null || userIdValue === undefined || userIdValue === "")
      return "—";
    const key = String(userIdValue);
    return (
      userNameCache[key] || userNameCache[userIdValue] || `User ${userIdValue}`
    );
  };

  const getCreatedByDisplayName = (row) => {
    const v = row?.created_by ?? row?.updated_by ?? null;
    return v === null || v === undefined || v === "" ? "—" : getUserNameCached(v);
  };
  const getUpdatedByDisplayName = (row) => {
    const v = row?.updated_by ?? row?.created_by ?? null;
    return v === null || v === undefined || v === "" ? "—" : getUserNameCached(v);
  };
  const getStatusValue = (row) => {
    if (!row) return true;
    return normalizeBoolean(row.is_status ?? row.status);
  };

  useEffect(() => {
    const initial = getInitialData();
    setFormValues(initial);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, mode]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === "checkbox") {
      setFormValues((prev) => ({ ...prev, [name]: checked }));
    } else {
      setFormValues((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handlePlanToggle = (planId) => {
    setFormValues((prev) => {
      const current = normalizePlanIds(prev.subscription_plan_id);
      const next = current.includes(planId)
        ? current.filter((existingId) => existingId !== planId)
        : [...current, planId];
      return { ...prev, subscription_plan_id: next };
    });
  };

  const validate = () => {
    const planIds = normalizePlanIds(formValues.subscription_plan_id);
    if (planIds.length === 0) {
      showError("Please select at least one subscription plan");
      return false;
    }
    if (!formValues.offer_name?.trim()) {
      showError("Offer name is required");
      return false;
    }
    if (!formValues.offer_type) {
      showError("Please select an offer type");
      return false;
    }
    const offerValue = Number(formValues.offer_value);
    if (!Number.isFinite(offerValue) || offerValue < 0) {
      showError("Please enter a valid offer value");
      return false;
    }
    if (formValues.offer_type === "percentage" && offerValue > 100) {
      showError("Percentage offer value must be between 0 and 100");
      return false;
    }
    if (formValues.offer_type === "free_trial" && !Number.isInteger(offerValue)) {
      showError("Free trial value must be a whole number");
      return false;
    }
    if (!formValues.start_date || !formValues.end_date) {
      showError("Start and End dates are required");
      return false;
    }
    const start = new Date(formValues.start_date);
    const end = new Date(formValues.end_date);
    if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      showError("Please enter valid dates");
      return false;
    }
    if (end < start) {
      showError("End date must be after start date");
      return false;
    }
    return true;
  };

  // ─── Submit ────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const selectedPlanIds = normalizePlanIds(formValues.subscription_plan_id);

      const metadata = {
        offer_name: formValues.offer_name.trim(),
        offer_type: formValues.offer_type,
        offer_value: Number(formValues.offer_value).toFixed(2),
        start_date: formValues.start_date,
        end_date: formValues.end_date,
        coupon_required: normalizeBoolean(formValues.coupon_required),
        status: formValues.status === "active",
        updated_by: userId,
      };

      if (mode === "add") {
        // Create: send array — backend creates one row per plan
        await subscriptionPlanOfferService.create({
          ...metadata,
          subscription_plan_id: selectedPlanIds,
          created_by: userId,
        });
        showSuccess("Offer created successfully");
      } else {
        // Edit: delete all existing rows then create fresh ones.
        // This is the safest way given the backend's "one row per plan" model
        // and its inability to accept arrays on update.
        for (const row of groupRows) {
          try {
            await subscriptionPlanOfferService.delete(row.id);
          } catch (err) {
            console.warn(`Delete row ${row.id} failed:`, err);
          }
        }

        await subscriptionPlanOfferService.create({
          ...metadata,
          subscription_plan_id: selectedPlanIds,
          created_by: userId,
        });
        showSuccess("Offer updated successfully");
      }

      navigate("/subscription-plan-offers");
    } catch (error) {
      console.error("Submit error:", error);
      const message =
        error?.response?.data?.message ||
        error?.response?.data?.error ||
        error?.message ||
        "Failed to save offer";
      showError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      for (const row of groupRows) {
        try {
          await subscriptionPlanOfferService.delete(row.id);
        } catch (err) {
          console.warn(`Delete row ${row.id} failed:`, err);
        }
      }
      showSuccess("Offer deleted successfully");
      navigate("/subscription-plan-offers");
    } catch (error) {
      console.error("Delete error:", error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
        showError(
          "Cannot delete this offer because it is being used in other records.",
        );
      } else {
        showError(message || "Failed to delete offer");
      }
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
    }
  };

  const normalizeDateOnly = (value) => {
    if (!value) return "";
    if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value))
      return value;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const getInitialData = () => {
    if (mode === "add") {
      return {
        subscription_plan_id: [],
        offer_name: "",
        offer_type: "",
        offer_value: 0,
        start_date: "",
        end_date: "",
        coupon_required: false,
        status: "active",
      };
    }
    if (data) {
      const planIds = normalizePlanIds(data.subscription_plan_id);
      const initial = {
        subscription_plan_id: planIds,
        offer_name: data.offer_name ?? "",
        offer_type: String(data.offer_type ?? ""),
        offer_value: data.offer_value ?? 0,
        start_date: normalizeDateOnly(data.start_date),
        end_date: normalizeDateOnly(data.end_date),
        coupon_required: normalizeBoolean(data.coupon_required),
        status: getStatusValue(data) ? "active" : "inactive",
      };
      if (mode === "view") {
        initial.created_by = data.created_by ?? null;
        initial.updated_by = data.updated_by ?? null;
        initial.created_at = data.created_at ?? null;
        initial.updated_at = data.updated_at ?? null;
      }
      return initial;
    }
    return {
      subscription_plan_id: [],
      offer_name: "",
      offer_type: "",
      offer_value: 0,
      start_date: "",
      end_date: "",
      coupon_required: false,
      status: "active",
    };
  };

  const isViewMode = mode === "view";
  const isEditMode = mode === "edit";
  const isAddMode = mode === "add";

  const planOptions = subscriptionPlans
    .map((plan) => {
      const planId = Number(plan.id ?? plan._id ?? plan.subscription_plan_id);
      if (!Number.isInteger(planId) || planId <= 0) return null;
      return {
        value: planId,
        label: `${plan.plan_name ?? "Unnamed Plan"} (₹${formatCurrency(plan.price ?? 0)})`,
        shortLabel: plan.plan_name ?? `Plan ${planId}`,
      };
    })
    .filter(Boolean);

  const selectedPlanIds = normalizePlanIds(formValues.subscription_plan_id);

  const offerName = formValues.offer_name?.trim() || "New Offer";
  const offerTypeStr = String(formValues.offer_type || "");
  const offerTypeDisplay = offerTypeStr
    ? offerTypeStr.charAt(0).toUpperCase() + offerTypeStr.slice(1)
    : "—";

  const offerValueDisplay = (() => {
    const val = Number(formValues.offer_value);
    if (!Number.isFinite(val)) return "—";
    if (offerTypeStr === "percentage") return `${val.toFixed(2)}%`;
    return `₹${val.toFixed(2)}`;
  })();

  const dateRangeDisplay = (() => {
    if (formValues.start_date && formValues.end_date) {
      return `${formatDate(formValues.start_date)} – ${formatDate(formValues.end_date)}`;
    }
    return "—";
  })();

  const planNamesDisplay = (() => {
    if (selectedPlanIds.length === 0) return "—";
    return selectedPlanIds
      .map((planId) => {
        const opt = planOptions.find((o) => o.value === planId);
        return opt?.shortLabel || `Plan ${planId}`;
      })
      .join(", ");
  })();

  const statusValue = formValues.status || "active";
  const couponRequired = normalizeBoolean(formValues.coupon_required);

  const initials = offerName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");

  const renderTabContent = () => {
    const offerTypeOptions = [
      { value: "percentage", label: "Percentage (%)" },
      { value: "fixed", label: "Fixed Amount (₹)" },
      { value: "free_trial", label: "Free Trial" },
    ];

    switch (activeTab) {
      case "overview":
        return (
          <div className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="sm:col-span-2">
                <FieldLabel required>Subscription Plan(s)</FieldLabel>
                {isViewMode ? (
                  selectedPlanIds.length === 0 ? (
                    <ReadOnlyValue>—</ReadOnlyValue>
                  ) : (
                    <div className="flex flex-wrap gap-1.5 py-1">
                      {selectedPlanIds.map((planId) => {
                        const opt = planOptions.find((o) => o.value === planId);
                        return (
                          <span
                            key={planId}
                            className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700 ring-1 ring-blue-200"
                          >
                            {opt?.shortLabel || `Plan ${planId}`}
                          </span>
                        );
                      })}
                    </div>
                  )
                ) : (
                  <PlanMultiSelect
                    options={planOptions}
                    selectedIds={selectedPlanIds}
                    onToggle={handlePlanToggle}
                    onRemove={handlePlanToggle}
                    disabled={loadingPlans}
                  />
                )}
                {!isViewMode && (
                  <p className="mt-1 text-xs text-slate-400">
                    Select one or more plans this offer applies to
                  </p>
                )}
              </div>

              <div>
                <FieldLabel required>Offer Name</FieldLabel>
                {isViewMode ? (
                  <ReadOnlyValue>{formValues.offer_name || "—"}</ReadOnlyValue>
                ) : (
                  <input
                    type="text"
                    name="offer_name"
                    value={formValues.offer_name || ""}
                    onChange={handleInputChange}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors"
                    placeholder="e.g. Summer Sale 2026"
                  />
                )}
              </div>

              <div>
                <FieldLabel required>Offer Type</FieldLabel>
                {isViewMode ? (
                  <ReadOnlyValue>{offerTypeDisplay}</ReadOnlyValue>
                ) : (
                  <select
                    name="offer_type"
                    value={formValues.offer_type || ""}
                    onChange={handleInputChange}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors"
                  >
                    <option value="">Select offer type</option>
                    {offerTypeOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <FieldLabel required>Offer Value</FieldLabel>
                {isViewMode ? (
                  <ReadOnlyValue>{offerValueDisplay}</ReadOnlyValue>
                ) : (
                  <input
                    type="number"
                    name="offer_value"
                    value={formValues.offer_value || ""}
                    onChange={handleInputChange}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors"
                    placeholder="Enter offer value"
                    min="0"
                    step="0.01"
                  />
                )}
              </div>

              <div>
                <FieldLabel required>Start Date</FieldLabel>
                {isViewMode ? (
                  <ReadOnlyValue>
                    {formValues.start_date ? formatDate(formValues.start_date) : "—"}
                  </ReadOnlyValue>
                ) : (
                  <input
                    type="date"
                    name="start_date"
                    value={formValues.start_date || ""}
                    onChange={handleInputChange}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors"
                  />
                )}
              </div>

              <div>
                <FieldLabel required>End Date</FieldLabel>
                {isViewMode ? (
                  <ReadOnlyValue>
                    {formValues.end_date ? formatDate(formValues.end_date) : "—"}
                  </ReadOnlyValue>
                ) : (
                  <input
                    type="date"
                    name="end_date"
                    value={formValues.end_date || ""}
                    onChange={handleInputChange}
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-100 focus:border-blue-400 transition-colors"
                  />
                )}
              </div>
            </div>

            <div className="border-t border-slate-200 pt-5">
              <FieldLabel>Coupon Required</FieldLabel>
              {isViewMode ? (
                <ReadOnlyValue>
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                      couponRequired
                        ? "bg-blue-50 text-[#2c0eee]"
                        : "bg-slate-50 text-slate-500"
                    }`}
                  >
                    {couponRequired ? "Yes" : "No"}
                  </span>
                </ReadOnlyValue>
              ) : (
                <div className="flex items-center gap-3">
                  <Toggle
                    name="coupon_required"
                    checked={formValues.coupon_required}
                    onChange={handleInputChange}
                  />
                  <span className="text-sm text-slate-600">
                    {formValues.coupon_required
                      ? "Coupon required"
                      : "No coupon needed"}
                  </span>
                </div>
              )}
            </div>
          </div>
        );

      case "status":
        return (
          <div className="space-y-6 max-w-xl">
            <div>
              <FieldLabel required>Status</FieldLabel>
              {isViewMode ? (
                <ReadOnlyValue>
                  <StatusPill status={statusValue} />
                </ReadOnlyValue>
              ) : (
                <div className="flex flex-wrap gap-6 pt-1">
                  {["active", "inactive"].map((s) => (
                    <label key={s} className="flex items-center gap-2.5 cursor-pointer">
                      <input
                        type="radio"
                        name="status"
                        value={s}
                        checked={formValues.status === s}
                        onChange={handleInputChange}
                        className="w-4 h-4 border-slate-300 text-blue-600 focus:ring-2 focus:ring-blue-100"
                      />
                      <span className="text-sm text-slate-700 capitalize">{s}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {(mode === "view" || mode === "edit") && (
              <div className="border-t border-slate-200 pt-5 space-y-5">
                <div>
                  <FieldLabel>Created By</FieldLabel>
                  <ReadOnlyValue>{getCreatedByDisplayName(data)}</ReadOnlyValue>
                </div>
                <div>
                  <FieldLabel>Created At</FieldLabel>
                  <ReadOnlyValue>
                    {data?.created_at ? formatDate(data.created_at) : "—"}
                  </ReadOnlyValue>
                </div>
                <div>
                  <FieldLabel>Last Updated By</FieldLabel>
                  <ReadOnlyValue>{getUpdatedByDisplayName(data)}</ReadOnlyValue>
                </div>
                <div>
                  <FieldLabel>Last Updated At</FieldLabel>
                  <ReadOnlyValue>
                    {data?.updated_at ? formatDate(data.updated_at) : "—"}
                  </ReadOnlyValue>
                </div>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (pageLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-9 h-9 border-[3px] border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-slate-400">Loading offer data...</p>
        </div>
      </div>
    );
  }

  if ((mode === "view" || mode === "edit") && !data && !pageLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#F4F5FA]">
        <div className="text-center bg-white rounded-2xl border border-slate-200 shadow-sm px-10 py-12">
          <MdErrorOutline size={40} className="text-slate-300 mx-auto mb-3" />
          <p className="text-slate-600 font-medium">Offer not found</p>
          <button
            onClick={() => navigate("/subscription-plan-offers")}
            className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <MdArrowBack size={16} />
            Back to offers
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-16">
      <div className="bg-white/85 backdrop-blur-md border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => navigate("/subscription-plan-offers")}
              className="p-2 rounded-lg hover:bg-slate-100 transition-colors flex-shrink-0"
              aria-label="Back"
            >
              <MdArrowBack size={19} className="text-slate-600" />
            </button>
            <div className="min-w-0">
              <p className="text-[11px] text-slate-400 leading-tight">Plan Offers</p>
              <p className="text-sm font-semibold text-slate-800 truncate leading-tight max-w-[45vw]">
                {offerName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {isViewMode ? (
              <>
                {mode !== "add" && (
                  <button
                    type="button"
                    onClick={() => setIsDeleteModalOpen(true)}
                    className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                    title="Delete offer"
                  >
                    <MdDelete size={19} />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() =>
                    navigate(`/subscription-plan-offers/edit/${id}`)
                  }
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors"
                >
                  <MdSave size={16} />
                  Edit Offer
                </button>
              </>
            ) : (
              <>
                {mode !== "add" && (
                  <button
                    type="button"
                    onClick={() => setIsDeleteModalOpen(true)}
                    className="p-2 rounded-lg text-red-500 hover:bg-red-50 transition-colors"
                    title="Delete offer"
                  >
                    <MdDelete size={19} />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => navigate("/subscription-plan-offers")}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors"
                >
                  <MdCancel size={16} />
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm shadow-blue-600/20 transition-colors disabled:opacity-50"
                >
                  {loading ? (
                    <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <MdSave size={16} />
                  )}
                  {loading ? "Saving..." : isEditMode ? "Update Offer" : "Create Offer"}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="relative rounded-2xl overflow-hidden shadow-lg shadow-slate-900/5"
        >
          <div className="relative h-44 sm:h-52">
            <div className="w-full h-full bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-800" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/95 via-slate-900/50 to-slate-900/10" />
          </div>

          <div className="absolute inset-x-0 bottom-0 px-5 sm:px-7 pb-5 pt-3">
            <div className="flex flex-col sm:flex-row sm:items-end gap-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white p-1.5 shadow-xl flex-shrink-0">
                <div className="w-full h-full rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-lg">
                  {initials || <MdAssignment size={22} />}
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-bold text-white truncate max-w-full">
                    {offerName}
                  </h1>
                  {couponRequired && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-400/20 text-blue-300 ring-1 ring-blue-400/30">
                      Coupon Required
                    </span>
                  )}
                </div>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <StatusPill status={statusValue} />
                  <span className="text-xs text-white/70">Type: {offerTypeDisplay}</span>
                  <span className="text-xs text-white/70">• {offerValueDisplay}</span>
                  <span className="text-xs text-white/70">• {dateRangeDisplay}</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdApartment size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Plan(s)</p>
              <p className="text-sm font-semibold text-slate-700 truncate" title={planNamesDisplay}>
                {planNamesDisplay}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdCategory size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Type</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {offerTypeDisplay}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdAttachMoney size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Value</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {offerValueDisplay}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-white/80 backdrop-blur-sm px-3.5 py-2.5 border border-slate-200 shadow-sm">
            <MdDateRange size={16} className="text-slate-400 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-slate-500 leading-tight">Date Range</p>
              <p className="text-sm font-semibold text-slate-700 truncate">
                {dateRangeDisplay}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="flex overflow-x-auto border-b border-slate-200 px-2">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center gap-1.5 px-4 py-3.5 text-sm font-medium whitespace-nowrap transition-colors ${
                    active ? "text-blue-600" : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <Icon size={16} />
                  {tab.label}
                  {active && (
                    <motion.span
                      layoutId="offer-tab-underline"
                      className="absolute left-2 right-2 -bottom-px h-0.5 bg-blue-600 rounded-full"
                      transition={{ type: "spring", stiffness: 500, damping: 35 }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-5 sm:p-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18 }}
              >
                {renderTabContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {!isViewMode && (
          <button
            type="button"
            onClick={() => navigate("/subscription-plan-offers")}
            className="sm:hidden mt-4 w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-medium rounded-lg transition-colors"
          >
            <MdCancel size={16} />
            Cancel
          </button>
        )}
      </div>

      <AnimatePresence>
        {isDeleteModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 px-4"
            onClick={() => !deleteLoading && setIsDeleteModalOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 8 }}
              transition={{ duration: 0.18 }}
              className="w-full max-w-sm rounded-2xl bg-white shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-full bg-red-50">
                    <MdWarning size={18} className="text-red-500" />
                  </div>
                  <h3 className="text-base font-semibold text-slate-800">
                    Delete Offer?
                  </h3>
                </div>
                <button
                  onClick={() => setIsDeleteModalOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 transition-colors"
                  disabled={deleteLoading}
                >
                  <MdClose size={18} />
                </button>
              </div>
              <div className="px-5 py-4">
                <p className="text-sm text-slate-600">
                  This will permanently remove <span className="font-medium text-slate-800">{offerName}</span>{" "}
                  and all its plans. This action cannot be undone.
                </p>
              </div>
              <div className="flex justify-end gap-2.5 px-5 py-4 border-t border-slate-100">
                <button
                  onClick={() => setIsDeleteModalOpen(false)}
                  disabled={deleteLoading}
                  className="px-3.5 py-2 rounded-lg text-sm font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
                >
                  Keep offer
                </button>
                <button
                  onClick={handleDelete}
                  disabled={deleteLoading}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-60"
                >
                  {deleteLoading && (
                    <span className="w-3.5 h-3.5 border-2 border-white/60 border-t-transparent rounded-full animate-spin" />
                  )}
                  {deleteLoading ? "Deleting..." : "Delete offer"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SubscriptionPlanOffersForm;