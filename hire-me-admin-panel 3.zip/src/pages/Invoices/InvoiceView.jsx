import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import {
  MdArrowBack,
  MdPrint,
  MdDownload,
  MdEdit,
  MdBusiness,
  MdErrorOutline,
  MdPictureAsPdf,
  MdVisibility,
  MdRefresh,
  MdContentCopy,
} from "react-icons/md";
import { invoiceService } from "../../services/invoice.service";
import companyService from "../../services/company.service";
import { subscriptionTransactionService } from "../../services/subscriptionTransaction.service";
import { formatDate } from "../../utils/helpers";
import toast from "react-hot-toast";

// Helper to convert number to Indian Currency Words
const numberToWords = (num) => {
  if (!num || isNaN(num)) return "Zero Rupees Only";
  const a = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
  ];
  const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  const inWords = (n) => {
    if (n < 20) return a[n];
    if (n < 100) return b[Math.floor(n / 10)] + (n % 10 !== 0 ? " " + a[n % 10] : "");
    if (n < 1000)
      return (
        a[Math.floor(n / 100)] +
        " Hundred" +
        (n % 100 !== 0 ? " and " + inWords(n % 100) : "")
      );
    if (n < 100000)
      return (
        inWords(Math.floor(n / 1000)) +
        " Thousand" +
        (n % 1000 !== 0 ? " " + inWords(n % 1000) : "")
      );
    if (n < 10000000)
      return (
        inWords(Math.floor(n / 100000)) +
        " Lakh" +
        (n % 100000 !== 0 ? " " + inWords(n % 100000) : "")
      );
    return (
      inWords(Math.floor(n / 10000000)) +
      " Crore" +
      (n % 10000000 !== 0 ? " " + inWords(n % 10000000) : "")
    );
  };

  const integerPart = Math.floor(num);
  const decimalPart = Math.round((num - integerPart) * 100);

  let str = "Rupees " + inWords(integerPart);
  if (decimalPart > 0) {
    str += " and " + inWords(decimalPart) + " Paise";
  }
  return str + " Only";
};

const InvoiceView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const invoiceRef = useRef(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [company, setCompany] = useState(null);
  const [transaction, setTransaction] = useState(null);
  const [viewTab, setViewTab] = useState("preview"); // "preview" | "pdf"
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    fetchInvoiceData();
  }, [id]);

  const fetchInvoiceData = async () => {
    setLoading(true);
    setError(null);
    try {
      let invData = location.state?.item || null;

      // 1. Try single item fetch (GET /invoices/:id)
      if (!invData) {
        try {
          const response = await invoiceService.getById(id);
          invData = response?.data?.data || response?.data || response;
        } catch (singleFetchErr) {
          console.warn("GET /invoices/:id failed, falling back to list fetch...", singleFetchErr);
        }
      }

      // 2. Fallback: Search in GET /invoices list
      if (!invData) {
        try {
          const listRes = await invoiceService.getAll({ limit: 1000 });
          const rawList = listRes?.data?.data || listRes?.data?.results || listRes?.data || listRes || [];
          if (Array.isArray(rawList)) {
            invData = rawList.find(
              (item) =>
                String(item.id) === String(id) ||
                String(item._id) === String(id) ||
                String(item.invoice_no) === String(id)
            );
          }
        } catch (listErr) {
          console.error("Fallback list fetch failed:", listErr);
        }
      }

      if (!invData) {
        setError(`Invoice #${id} not found.`);
        setLoading(false);
        return;
      }

      setInvoice(invData);

      // 3. Fetch Company details safely
      const companyId =
        invData.company_id ||
        invData.Company?.id ||
        invData.Company?.company_id;
      if (companyId) {
        try {
          const compRes = await companyService.getById(companyId);
          const compData = compRes?.data?.data || compRes?.data || compRes;
          if (compData) setCompany(compData);
          else if (invData.Company) setCompany(invData.Company);
        } catch (cErr) {
          if (invData.Company) setCompany(invData.Company);
        }
      } else if (invData.Company) {
        setCompany(invData.Company);
      }

      // 4. Fetch Transaction details safely
      const transId =
        invData.transaction_id ||
        invData.SubscriptionTransaction?.id ||
        invData.SubscriptionTransaction?.transaction_id;
      if (transId) {
        try {
          const transRes = await subscriptionTransactionService.getById(transId);
          const transData = transRes?.data?.data || transRes?.data || transRes;
          if (transData) setTransaction(transData);
          else if (invData.SubscriptionTransaction) setTransaction(invData.SubscriptionTransaction);
        } catch (tErr) {
          if (invData.SubscriptionTransaction) setTransaction(invData.SubscriptionTransaction);
        }
      } else if (invData.SubscriptionTransaction) {
        setTransaction(invData.SubscriptionTransaction);
      }
    } catch (err) {
      console.error("Error loading invoice:", err);
      setError(err?.message || "Failed to load invoice details.");
    } finally {
      setLoading(false);
    }
  };

  const getStatusConfig = (statusStr) => {
    const s = (statusStr || "Pending").toLowerCase();
    switch (s) {
      case "paid":
      case "success":
      case "completed":
        return {
          label: "PAID",
          badgeBg: "bg-emerald-50 text-emerald-800 border-emerald-300",
          dotColor: "bg-emerald-600",
          stampText: "PAID",
          stampStyle: "text-emerald-700/20 border-emerald-700/25",
        };
      case "pending":
        return {
          label: "PENDING",
          badgeBg: "bg-amber-50 text-amber-800 border-amber-300",
          dotColor: "bg-amber-600",
          stampText: "PENDING",
          stampStyle: "text-amber-700/20 border-amber-700/25",
        };
      case "overdue":
        return {
          label: "OVERDUE",
          badgeBg: "bg-rose-50 text-rose-800 border-rose-300",
          dotColor: "bg-rose-600",
          stampText: "OVERDUE",
          stampStyle: "text-rose-700/20 border-rose-700/25",
        };
      default:
        return {
          label: statusStr?.toUpperCase() || "PENDING",
          badgeBg: "bg-slate-100 text-slate-700 border-slate-300",
          dotColor: "bg-slate-500",
          stampText: statusStr?.toUpperCase() || "PENDING",
          stampStyle: "text-slate-700/20 border-slate-700/25",
        };
    }
  };

  // ─── 1. ISOLATED PRINT HANDLER (ONLY prints the Invoice Canvas) ──────
  const handlePrint = () => {
    const printContent = document.getElementById("printable-invoice");
    if (!printContent) {
      toast.error("Invoice element not found.");
      return;
    }

    // Create an isolated print popup window
    const printWindow = window.open("", "_blank", "width=900,height=900");
    if (!printWindow) {
      toast.error("Please allow popups to print invoice.");
      return;
    }

    const invNo = invoice?.invoice_no || `INV-${id}`;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice - ${invNo}</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <style>
            @media print {
              @page {
                size: A4;
                margin: 10mm;
              }
              body {
                background: white !important;
                color: #0f172a !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
              }
            }
          </style>
        </head>
        <body class="bg-white p-6 font-sans">
          <div class="max-w-[850px] mx-auto border border-slate-200 p-8 shadow-none rounded-none">
            ${printContent.innerHTML}
          </div>
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                window.close();
              }, 400);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // ─── 2. DIRECT PDF DOWNLOAD HANDLER (No Print Window Trigger) ─────────
  const handleDownload = async () => {
    if (downloading) return;
    setDownloading(true);
    const fileName = `Invoice-${invoice?.invoice_no || id}.pdf`;

    // Case A: If backend PDF URL exists, download file directly via Blob
    if (invoice?.pdf_url) {
      try {
        const pdfUrl = invoiceService.getPdfUrl(invoice.pdf_url);
        toast.loading("Downloading PDF file...", { id: "pdf-dl" });
        const res = await fetch(pdfUrl);
        if (!res.ok) throw new Error("Failed to fetch PDF file");
        const blob = await res.blob();
        const blobUrl = window.URL.createObjectURL(blob);

        const a = document.createElement("a");
        a.href = blobUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(blobUrl);

        toast.success("PDF downloaded successfully!", { id: "pdf-dl" });
        setDownloading(false);
        return;
      } catch (err) {
        console.warn("Direct backend PDF download failed, fallback to client generation...", err);
      }
    }

    // Case B: Convert the Invoice HTML DOM directly into PDF using html2pdf.js
    const element = document.getElementById("printable-invoice");
    if (!element) {
      toast.error("Invoice canvas not found.");
      setDownloading(false);
      return;
    }

    toast.loading("Generating PDF download...", { id: "pdf-dl" });

    try {
      // Dynamically load html2pdf.js if not present
      if (!window.html2pdf) {
        await new Promise((resolve, reject) => {
          const script = document.createElement("script");
          script.src = "https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js";
          script.onload = resolve;
          script.onerror = reject;
          document.head.appendChild(script);
        });
      }

      const opt = {
        margin: [8, 8, 8, 8],
        filename: fileName,
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
      };

      await window.html2pdf().set(opt).from(element).save();
      toast.success("PDF downloaded successfully!", { id: "pdf-dl" });
    } catch (pdfErr) {
      console.error("PDF generation failed:", pdfErr);
      toast.error("Failed to generate PDF file. Opening print view instead.", { id: "pdf-dl" });
      handlePrint();
    } finally {
      setDownloading(false);
    }
  };

  const handleCopyInvoiceNo = () => {
    const invNo = invoice?.invoice_no || `INV-${id}`;
    navigator.clipboard.writeText(invNo);
    toast.success("Invoice number copied!");
  };

  if (loading) {
    return (
      <div className="min-h-[75vh] flex flex-col items-center justify-center space-y-4">
        <div className="w-10 h-10 border-3 border-slate-300 border-t-slate-800 rounded-full animate-spin" />
        <p className="text-xs font-medium text-slate-500 tracking-wide uppercase">Loading Tax Invoice #{id}...</p>
      </div>
    );
  }

  if (error || !invoice) {
    return (
      <div className="max-w-xl mx-auto my-16 p-8 bg-white rounded-xl border border-slate-200 shadow-sm text-center space-y-4">
        <div className="w-14 h-14 mx-auto rounded-full bg-slate-100 text-slate-600 flex items-center justify-center">
          <MdErrorOutline size={30} />
        </div>
        <h2 className="text-lg font-bold text-slate-900">Invoice Record Not Found</h2>
        <p className="text-slate-500 text-sm max-w-sm mx-auto">{error || "The requested invoice could not be located."}</p>
        <div className="flex justify-center gap-3 pt-2">
          <button
            onClick={() => navigate("/invoices")}
            className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-200 transition-colors flex items-center gap-2"
          >
            <MdArrowBack size={16} /> Return to Invoices
          </button>
          <button
            onClick={fetchInvoiceData}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors flex items-center gap-2"
          >
            <MdRefresh size={16} /> Retry
          </button>
        </div>
      </div>
    );
  }

  const statusConfig = getStatusConfig(invoice.invoice_status);
  const pdfFullUrl = invoice.pdf_url ? invoiceService.getPdfUrl(invoice.pdf_url) : null;

  // Amount parsing
  const subtotal = parseFloat(invoice.subtotal) || 0;
  const gst = parseFloat(invoice.gst) || 0;
  const cgst = gst / 2;
  const sgst = gst / 2;
  const grandTotal = parseFloat(invoice.grand_total) || subtotal + gst;

  const companyName =
    company?.company_name ||
    invoice.Company?.company_name ||
    `Company ID #${invoice.company_id || "N/A"}`;
  const companyGst =
    invoice.gst_number ||
    company?.gst_number ||
    company?.gst_no ||
    "27AAAAA0000A1Z9";
  const billingAddress =
    invoice.billing_address ||
    company?.company_address ||
    company?.address ||
    "Mumbai, Maharashtra, India";

  const planName =
    transaction?.SubscriptionPlan?.plan_name ||
    transaction?.plan_name ||
    "HireMe Jobs Platform Subscription Service";
  const transactionNo =
    invoice.transaction_no ||
    transaction?.transaction_no ||
    transaction?.payment_reference ||
    `PAY-${invoice.transaction_id || id}`;

  return (
    <div className="bg-[#F8FAFC] min-h-screen -m-6 p-4 sm:p-8 font-sans text-slate-800">
      {/* ─── Top Corporate Action Header (Non-Printable) ────────── */}
      <div className="no-print max-w-[850px] mx-auto mb-6 bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/invoices")}
            className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors"
            title="Back to Invoices"
          >
            <MdArrowBack size={18} />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">TAX INVOICE</span>
              <span className="text-slate-300">•</span>
              <h1 className="text-base font-bold text-slate-900 font-mono">
                #{invoice.invoice_no || `INV-${id}`}
              </h1>
              <span
                onClick={handleCopyInvoiceNo}
                className="cursor-pointer text-slate-400 hover:text-slate-700 transition-colors p-0.5"
                title="Copy Invoice Number"
              >
                <MdContentCopy size={14} />
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Generated on {formatDate(invoice.created_at || invoice.createdAt)}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {pdfFullUrl && (
            <div className="bg-slate-100 p-0.5 rounded-lg flex items-center text-xs font-medium mr-1">
              <button
                onClick={() => setViewTab("preview")}
                className={`px-3 py-1 rounded-md transition-all flex items-center gap-1 ${
                  viewTab === "preview"
                    ? "bg-white text-slate-900 shadow-sm font-semibold"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <MdVisibility size={14} /> Document
              </button>
              <button
                onClick={() => setViewTab("pdf")}
                className={`px-3 py-1 rounded-md transition-all flex items-center gap-1 ${
                  viewTab === "pdf"
                    ? "bg-white text-slate-900 shadow-sm font-semibold"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <MdPictureAsPdf size={14} /> PDF File
              </button>
            </div>
          )}

          <button
            onClick={() => navigate(`/invoices/edit/${id}`)}
            className="px-3.5 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors flex items-center gap-1.5"
          >
            <MdEdit size={15} /> Edit
          </button>

          <button
            onClick={handlePrint}
            className="px-3.5 py-1.5 rounded-lg bg-slate-100 border border-slate-300 text-slate-800 hover:bg-slate-200 text-xs font-semibold transition-colors flex items-center gap-1.5"
          >
            <MdPrint size={15} /> Print
          </button>

          <button
            onClick={handleDownload}
            disabled={downloading}
            className="px-4 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-sm disabled:opacity-60"
          >
            <MdDownload size={15} /> {downloading ? "Downloading..." : "Download PDF"}
          </button>
        </div>
      </div>

      {/* ─── PDF File Mode Preview (If PDF File Selected) ─────────── */}
      {viewTab === "pdf" && pdfFullUrl ? (
        <div className="no-print max-w-[850px] mx-auto bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-600 px-1">
            <span className="font-semibold flex items-center gap-1.5">
              <MdPictureAsPdf className="text-red-500" size={16} /> Attached File: {invoice.pdf_url}
            </span>
            <a
              href={pdfFullUrl}
              target="_blank"
              rel="noreferrer"
              className="text-slate-900 underline font-semibold hover:text-blue-600"
            >
              Open File ↗
            </a>
          </div>
          <div className="w-full h-[750px] rounded-lg border border-slate-200 overflow-hidden bg-slate-50">
            <iframe src={pdfFullUrl} title="Invoice PDF" className="w-full h-full border-0" />
          </div>
        </div>
      ) : (
        /* ─── Realistic Corporate TAX INVOICE Canvas ──────────────── */
        <div className="flex justify-center">
          <div
            id="printable-invoice"
            ref={invoiceRef}
            className="w-full max-w-[850px] bg-white rounded-none sm:rounded-lg border border-slate-200 shadow-xl shadow-slate-200/60 p-8 sm:p-12 space-y-8 relative overflow-hidden text-slate-800"
          >
            {/* Subtle Watermark Stamp */}
            <div
              className={`absolute top-12 right-12 select-none transform rotate-[-12deg] pointer-events-none font-black text-4xl sm:text-5xl tracking-widest border-4 px-6 py-1.5 rounded-lg uppercase ${statusConfig.stampStyle}`}
            >
              {statusConfig.stampText}
            </div>

            {/* ─── Header Section: Logo & Document Title ──────────── */}
            <div className="flex flex-col sm:flex-row justify-between items-start gap-6 border-b border-slate-200 pb-8">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded bg-slate-900 text-white font-extrabold text-lg flex items-center justify-center">
                    H
                  </div>
                  <span className="text-2xl font-black tracking-tight text-slate-900">
                    HireMe Jobs
                  </span>
                </div>
                <p className="text-xs font-semibold text-slate-600">
                  HireMe Jobs Technologies Private Limited
                </p>
                <p className="text-[11px] text-slate-500 max-w-xs leading-relaxed">
                  Corporate Office: Level 5, Cyber Tech Hub, Bandra-Kurla Complex, Mumbai - 400051, Maharashtra.
                </p>
                <p className="text-[11px] text-slate-500">
                  <span className="font-semibold text-slate-700">GSTIN:</span> 27AAAAA0000A1Z5 | <span className="font-semibold text-slate-700">PAN:</span> AAAAA0000A
                </p>
              </div>

              {/* Tax Invoice Header Box */}
              <div className="sm:text-right space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400 block">
                  ORIGINAL FOR RECIPIENT
                </span>
                <h2 className="text-2xl font-black tracking-tight text-slate-900 uppercase">
                  TAX INVOICE
                </h2>
                <div className="pt-2 text-xs space-y-1">
                  <p>
                    <span className="text-slate-500">Invoice No:</span>{" "}
                    <span className="font-mono font-bold text-slate-900">
                      {invoice.invoice_no || `INV-${String(id).padStart(5, "0")}`}
                    </span>
                  </p>
                  <p>
                    <span className="text-slate-500">Invoice Date:</span>{" "}
                    <span className="font-semibold text-slate-800">
                      {formatDate(invoice.created_at || invoice.createdAt)}
                    </span>
                  </p>
                  {invoice.due_date && (
                    <p>
                      <span className="text-slate-500">Payment Due:</span>{" "}
                      <span className="font-semibold text-slate-800">
                        {formatDate(invoice.due_date)}
                      </span>
                    </p>
                  )}
                  <p>
                    <span className="text-slate-500">Status:</span>{" "}
                    <span className={`inline-flex items-center gap-1 font-bold text-[11px] px-2 py-0.5 rounded border ${statusConfig.badgeBg}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${statusConfig.dotColor}`} />
                      {statusConfig.label}
                    </span>
                  </p>
                </div>
              </div>
            </div>

            {/* ─── Billed To & Billed From Grid ───────────────────── */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs border-b border-slate-200 pb-8">
              {/* Customer / Client Info */}
              <div className="space-y-1.5">
                <span className="font-bold text-slate-400 uppercase tracking-wider text-[10px] block">
                  Billed To (Customer Details)
                </span>
                <h3 className="text-sm font-bold text-slate-900">{companyName}</h3>
                <p className="text-slate-600 leading-relaxed whitespace-pre-line">
                  {billingAddress}
                </p>
                <div className="pt-1 space-y-0.5 font-mono text-slate-700">
                  <p><span className="font-sans font-medium text-slate-500">GSTIN:</span> {companyGst}</p>
                  <p><span className="font-sans font-medium text-slate-500">State / Code:</span> Maharashtra (27)</p>
                  {company?.email && (
                    <p><span className="font-sans font-medium text-slate-500">Email:</span> {company.email}</p>
                  )}
                </div>
              </div>

              {/* Supply Details / Transaction Ref */}
              <div className="space-y-1.5 sm:text-right">
                <span className="font-bold text-slate-400 uppercase tracking-wider text-[10px] block">
                  Place of Supply & References
                </span>
                <p className="text-slate-700">
                  <span className="text-slate-500">Place of Supply:</span> Maharashtra (27)
                </p>
                <p className="text-slate-700">
                  <span className="text-slate-500">Reverse Charge:</span> No
                </p>
                <p className="text-slate-700 font-mono">
                  <span className="font-sans text-slate-500">Ref ID:</span> {transactionNo}
                </p>
                <p className="text-slate-700">
                  <span className="text-slate-500">Payment Mode:</span> {transaction?.payment_gateway || "Razorpay Online"}
                </p>
              </div>
            </div>

            {/* ─── Line Items Table (Corporate Spec) ─────────────── */}
            <div className="space-y-4">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100/90 text-slate-700 border-y border-slate-200 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-2.5 px-3 w-10 text-center border-r border-slate-200">#</th>
                    <th className="py-2.5 px-4 border-r border-slate-200">Particulars / Service Description</th>
                    <th className="py-2.5 px-3 text-center border-r border-slate-200">SAC Code</th>
                    <th className="py-2.5 px-3 text-center border-r border-slate-200">Qty</th>
                    <th className="py-2.5 px-3 text-right border-r border-slate-200">Rate (₹)</th>
                    <th className="py-2.5 px-4 text-right">Taxable Amount (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800">
                  <tr className="align-top">
                    <td className="py-4 px-3 text-center font-mono text-slate-400 border-r border-slate-200">1</td>
                    <td className="py-4 px-4 border-r border-slate-200">
                      <p className="font-bold text-slate-900">{planName}</p>
                      <p className="text-[11px] text-slate-500 mt-1">
                        Recruitment Platform Plan Services for Candidate Sourcing & Job Listings.
                      </p>
                    </td>
                    <td className="py-4 px-3 text-center font-mono text-slate-600 border-r border-slate-200">
                      998311
                    </td>
                    <td className="py-4 px-3 text-center font-mono text-slate-700 border-r border-slate-200">
                      1
                    </td>
                    <td className="py-4 px-3 text-right font-mono text-slate-800 border-r border-slate-200">
                      {subtotal.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-4 px-4 text-right font-mono font-bold text-slate-900">
                      {subtotal.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* ─── Tax Calculation Grid ─────────────────────────── */}
              <div className="flex flex-col sm:flex-row justify-between items-start gap-6 pt-4 border-t border-slate-200">
                {/* Amount in Words */}
                <div className="space-y-3 max-w-sm">
                  <div className="bg-slate-50 p-3 rounded border border-slate-200 text-xs">
                    <span className="font-bold text-slate-500 text-[10px] uppercase block tracking-wider mb-1">
                      Total Amount in Words
                    </span>
                    <p className="font-semibold text-slate-900 italic leading-relaxed">
                      {numberToWords(grandTotal)}
                    </p>
                  </div>

                  <div className="text-[11px] text-slate-500 space-y-1">
                    <p><span className="font-semibold text-slate-700">Bank Name:</span> HDFC Bank Ltd.</p>
                    <p><span className="font-semibold text-slate-700">A/C Name:</span> HireMe Jobs Technologies Pvt Ltd</p>
                    <p><span className="font-semibold text-slate-700">A/C No:</span> 50200012345678 | <span className="font-semibold text-slate-700">IFSC:</span> HDFC0001234</p>
                  </div>
                </div>

                {/* Subtotal & GST Calculation Table */}
                <div className="w-full sm:w-72 text-xs space-y-2">
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Subtotal (Taxable Value):</span>
                    <span className="font-mono font-semibold text-slate-900">
                      ₹{subtotal.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                    <span>CGST @ 9%:</span>
                    <span className="font-mono text-slate-900">
                      ₹{cgst.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                    <span>SGST @ 9%:</span>
                    <span className="font-mono text-slate-900">
                      ₹{sgst.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="flex justify-between py-2 border-t-2 border-slate-900 text-slate-900 font-bold">
                    <span className="text-sm">Total Invoice Value:</span>
                    <span className="text-sm font-mono">
                      ₹{grandTotal.toLocaleString("en-IN", { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* ─── Footer Declaration & Signatory ──────────────────── */}
            <div className="pt-8 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-end gap-6 text-[11px] text-slate-500">
              <div className="space-y-1 max-w-sm">
                <p className="font-bold text-slate-700">Declaration & Terms:</p>
                <p>1. We declare that this invoice shows the actual price of the services described.</p>
                <p>2. Subject to Mumbai Jurisdiction only.</p>
                <p>3. This is an electronically generated Tax Invoice under GST law.</p>
              </div>

              <div className="text-center sm:text-right space-y-3">
                <p className="font-bold text-slate-800 text-xs">For HireMe Jobs Technologies Pvt Ltd</p>
                <div className="h-12 flex items-center justify-end">
                  <span className="font-serif italic font-bold text-[#1E293B] text-base border-b border-slate-400 px-4 py-1">
                    Authorized Signatory
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Authorised Signatory / Stamp</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvoiceView;
