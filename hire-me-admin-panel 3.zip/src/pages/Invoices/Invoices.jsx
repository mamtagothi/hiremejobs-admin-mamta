﻿// import React, { useState, useEffect, useCallback, useRef } from "react";
// import { useNavigate } from "react-router-dom";
// import {
//   MdAdd,
//   MdEdit,
//   MdDelete,
//   MdSearch,
//   MdVisibility,
//   MdPictureAsPdf,
//   MdBusiness,
// } from "react-icons/md";
// import Table from "../../components/common/Table";
// import Button from "../../components/common/Button";
// import Pagination from "../../components/common/Pagination";
// import ConfirmDialog from "../../components/common/ConfirmDialog";
// import { invoiceService } from "../../services/invoice.service";
// import { showSuccess, showError } from "../../utils/toast";
// import { formatDate } from "../../utils/helpers";
// import { fetchUsers } from "../../utils/getUserName";

// // â”€â”€â”€ Response extractors â€” tolerate every shape â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// //
// // Two cases we must handle:
// //   A) axios response (NOT unwrapped): r = { data: { success, pagination, data: [...] } }
// //   B) interceptor-unwrapped body:     r = { success, pagination, data: [...] }
// //
// // In case B, `r.data` is the items array â€” NOT the body â€” so we
// // must check `r.pagination` BEFORE `r.data.pagination`.

// const extractList = (res) => {
//   if (!res) return [];
//   if (Array.isArray(res)) return res; // already an array
//   if (Array.isArray(res.data?.data)) return res.data.data; // case A
//   if (Array.isArray(res.data)) return res.data; // case B (r.data = items)
//   if (Array.isArray(res.results)) return res.results;
//   return [];
// };

// const extractPagination = (res) => {
//   if (!res) return null;
//   if (res.pagination) return res.pagination; // case B
//   if (res.data?.pagination) return res.data.pagination; // case A
//   return null;
// };

// const extractTotal = (res) => {
//   if (!res) return 0;
//   if (typeof res.pagination?.total === "number") return res.pagination.total;
//   if (typeof res.data?.pagination?.total === "number")
//     return res.data.pagination.total;
//   if (typeof res.total === "number") return res.total;
//   if (Array.isArray(res.data)) return res.data.length;
//   if (Array.isArray(res)) return res.length;
//   return 0;
// };

// const Invoices = () => {
//   const navigate = useNavigate();

//   // â”€â”€â”€ Data & pagination state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [deleteId, setDeleteId] = useState(null);
//   const [deleteLoading, setDeleteLoading] = useState(false);

//   // Filters
//   const [search, setSearch] = useState("");
//   const [debouncedSearch, setDebouncedSearch] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");

//   // Pagination â€” API-driven
//   const [page, setPage] = useState(1);
//   const [pageSize, setPageSize] = useState(0);
//   const [totalItems, setTotalItems] = useState(0);
//   const [paginationLinks, setPaginationLinks] = useState(null);

//   // User name cache
//   const [userNameCache, setUserNameCache] = useState({});

//   // Race guard
//   const requestIdRef = useRef(0);

//   // Tab counts (fetched from API)
//   const [statusCounts, setStatusCounts] = useState({
//     all: 0,
//     active: 0,
//     inactive: 0,
//   });
//   const [countsLoading, setCountsLoading] = useState(false);

//   // â”€â”€â”€ User name helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const getUserNameCached = (userId) => {
//     if (!userId) return "-";
//     return userNameCache[userId] || `User ${userId}`;
//   };

//   const normalizeInvoice = (item) => ({
//     id: item.id || item._id,
//     invoice_no: item.invoice_no || "",
//     gst_number: item.gst_number || "",
//     billing_address: item.billing_address || "",
//     subtotal: parseFloat(item.subtotal) || 0,
//     gst: parseFloat(item.gst) || 0,
//     grand_total: parseFloat(item.grand_total) || 0,
//     pdf_url: item.pdf_url || null,
//     invoice_status: item.invoice_status || "",
//     due_date: item.due_date || null,
//     is_trending: item.is_trending === 1 || item.is_trending === true,
//     is_status: item.is_status === 1 || item.is_status === true,
//     status: item.is_status === 1 || item.is_status === true,
//     created_by: item.created_by || null,
//     updated_by: item.updated_by || null,
//     createdAt: item.created_at || item.createdAt || null,
//     updatedAt: item.updated_at || item.updatedAt || null,
//     Company: item.Company || null,
//     company_name: item.Company?.company_name || "",
//     company_id: item.Company?.company_id || "",
//     raw: item,
//   });

//   const getStatusValue = (row) => {
//     if (row.is_status !== undefined) return row.is_status;
//     if (row.status !== undefined) {
//       return row.status === 1 || row.status === true;
//     }
//     return true;
//   };

//   // â”€â”€â”€ Debounce search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     const t = setTimeout(() => {
//       setDebouncedSearch(search.trim());
//       setPage(1);
//     }, 400);
//     return () => clearTimeout(t);
//   }, [search]);

//   // Reset page when status filter changes
//   useEffect(() => {
//     setPage(1);
//   }, [statusFilter]);

//   // â”€â”€â”€ Load users once â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   useEffect(() => {
//     let cancelled = false;
//     (async () => {
//       try {
//         const users = await fetchUsers();
//         if (!cancelled) {
//           const userMap = {};
//           Object.keys(users || {}).forEach((id) => {
//             userMap[id] = users[id].name;
//           });
//           setUserNameCache(userMap);
//         }
//       } catch (e) {
//         console.warn("Could not fetch user names cache:", e);
//       }
//     })();
//     return () => {
//       cancelled = true;
//     };
//   }, []);

//   // â”€â”€â”€ Load one page of invoices â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const load = useCallback(async () => {
//     const requestId = ++requestIdRef.current;
//     setLoading(true);
//     try {
//       const params = { page };
//       if (debouncedSearch) params.search = debouncedSearch;
//       if (statusFilter === "active") params.is_status = 1;
//       else if (statusFilter === "inactive") params.is_status = 0;

//       const r = await invoiceService.getAll(params);
//       if (requestIdRef.current !== requestId) return;

//       // â­ Pass `r` (the raw response) to BOTH extractors. Do NOT do
//       //    `r.data ?? r` first â€” that breaks case B where r.data is
//       //    the items array and pagination lives on `r` itself.
//       const rawData = extractList(r);
//       const pagination = extractPagination(r);

//       console.log("[Invoices] API pagination:", pagination);
//       console.log("[Invoices] rows received:", rawData.length);

//       const invoices = rawData.map(normalizeInvoice);

//       setData(invoices);
//       setPaginationLinks(pagination?.links || null);

//       const serverTotal = Number(pagination?.total || 0);
//       setTotalItems(serverTotal > 0 ? serverTotal : invoices.length);

//       if (pagination?.limit && Number(pagination.limit) > 0) {
//         setPageSize(Number(pagination.limit));
//       }
//       if (pagination?.page && Number(pagination.page) !== page) {
//         setPage(Number(pagination.page));
//       }
//     } catch (error) {
//       if (requestIdRef.current !== requestId) return;
//       console.error("Load error:", error);
//       showError(error.message || "Failed to load invoices");
//       setData([]);
//       setTotalItems(0);
//       setPaginationLinks(null);
//     } finally {
//       if (requestIdRef.current === requestId) setLoading(false);
//     }
//   }, [page, debouncedSearch, statusFilter]);

//   useEffect(() => {
//     load();
//   }, [load]);

//   // â”€â”€â”€ Fetch a single count via limit=1 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
//   const fetchCount = useCallback(async (isStatus) => {
//     const params = { page: 1, limit: 1 };
//     if (isStatus === 1) params.is_status = 1;
//     else if (isStatus === 0) params.is_status = 0;
//     const res = await invoiceService.getAll(params);
//     return extractTotal(res);
//   }, []);

//   const loadCounts = useCallback(async () => {
//     setCountsLoading(true);
//     try {
//       const [all, active, inactive] = await Promise.all([
//         fetchCount(null),
//         fetchCount(1),
//         fetchCount(0),
//       ]);
//       setStatusCounts({ all, active, inactive });
//     } catch (err) {
//       console.error("Failed to load invoice counts:", err);
//     } finally {
//       setCountsLoading(false);
//     }
//   }, [fetchCount]);

//   useEffect(() => {
//     loadCounts();
//   }, [loadCounts]);

//   const refreshAll = () => {
//     load();
//     loadCounts();
//   };

//   const getInvoiceStatusColor = (status) => {
//     const statusMap = {
//       Paid: "green",
//       paid: "green",
//       Pending: "yellow",
//       pending: "yellow",
//       Overdue: "red",
//       overdue: "red",
//       Cancelled: "gray",
//       cancelled: "gray",
//     };
//     return statusMap[status] || "purple";
//   };

//   const getUpdatedByName = (row) => {
//     if (!row) return "-";
//     if (row.updated_by) return getUserNameCached(row.updated_by);
//     return "-";
//   };

//   const handleDelete = async () => {
//     setDeleteLoading(true);
//     try {
//       await invoiceService.delete(deleteId);
//       showSuccess("Invoice deleted successfully");
//       load();
//       loadCounts();
//     } catch (error) {
//       console.error("Delete error:", error);
//       showError(error.message || "Failed to delete invoice");
//     } finally {
//       setDeleteId(null);
//       setDeleteLoading(false);
//     }
//   };

//   const handleStatusToggle = async (row) => {
//     const currentStatus = getStatusValue(row);
//     const newStatus = !currentStatus;
//     try {
//       await invoiceService.update(row.id, { is_status: newStatus ? 1 : 0 });
//       showSuccess(
//         `Status ${newStatus ? "activated" : "deactivated"} successfully`
//       );
//       load();
//       loadCounts();
//     } catch (error) {
//       console.error("Status toggle error:", error);
//       showError(
//         error.response?.data?.message ||
//           error.message ||
//           "Failed to update status"
//       );
//     }
//   };

//   const handleTrendingToggle = async (row) => {
//     const newValue = !row.is_trending;
//     try {
//       await invoiceService.update(row.id, { is_trending: newValue ? 1 : 0 });
//       showSuccess(`Trending ${newValue ? "enabled" : "disabled"} successfully`);
//       load();
//     } catch (error) {
//       console.error("Trending toggle error:", error);
//       showError(
//         error.response?.data?.message ||
//           error.message ||
//           "Failed to update trending"
//       );
//     }
//   };

//   const handleDownloadPdf = (row) => {
//     if (!row.pdf_url) {
//       showError("No PDF file available");
//       return;
//     }
//     const pdfUrl = row.pdf_url.startsWith("http")
//       ? row.pdf_url
//       : `https://apidata.hiremejobs.in${row.pdf_url}`;
//     if (pdfUrl) {
//       window.open(pdfUrl, "_blank");
//     } else {
//       showError("Invalid PDF URL");
//     }
//   };

//   const columns = [
//     {
//       header: "#",
//       key: "id",
//       render: (_, __, i) => (page - 1) * (pageSize || 20) + i + 1,
//     },
//     {
//       header: "Invoice",
//       key: "invoice_no",
//       render: (v, row) => (
//         <div>
//           <span className="font-medium text-slate-800">{v}</span>
//           <div className="flex items-center gap-1 mt-0.5">
//             <span
//               className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-medium bg-${getInvoiceStatusColor(row.invoice_status)}-50 text-${getInvoiceStatusColor(row.invoice_status)}-700`}
//             >
//               {row.invoice_status || "Unknown"}
//             </span>
//             {row.pdf_url && (
//               <button
//                 onClick={() => handleDownloadPdf(row)}
//                 className="text-[#4529f7] hover:text-[#2c0eee]"
//                 title="Download PDF"
//               >
//                 <MdPictureAsPdf size={14} />
//               </button>
//             )}
//           </div>
//         </div>
//       ),
//     },
//     {
//       header: "Company",
//       key: "company_name",
//       render: (v, row) => (
//         <div className="flex items-center gap-1">
//           <MdBusiness size={14} className="text-slate-400" />
//           <span className="text-slate-700">{v || "-"}</span>
//         </div>
//       ),
//     },
//     {
//       header: "Amount",
//       key: "grand_total",
//       render: (v, row) => (
//         <div>
//           <span className="font-semibold text-slate-800">
//             â‚¹{v?.toFixed(2)}
//           </span>
//           <span className="text-xs text-slate-400 ml-1">
//             (Subtotal: â‚¹{row.subtotal?.toFixed(2)})
//           </span>
//         </div>
//       ),
//     },
//     {
//       header: "GST",
//       key: "gst",
//       render: (v) => <span className="text-slate-600">â‚¹{v?.toFixed(2)}</span>,
//     },
//     {
//       header: "Due Date",
//       key: "due_date",
//       render: (v) => {
//         const dueDate = new Date(v);
//         const today = new Date();
//         const isOverdue = dueDate < today;
//         return (
//           <span
//             className={`text-sm ${isOverdue ? "text-red-500" : "text-slate-500"}`}
//           >
//             {formatDate(v)}
//             {isOverdue && (
//               <span className="ml-1 text-xs text-red-500">(Overdue)</span>
//             )}
//           </span>
//         );
//       },
//     },
//     {
//       header: "Trending",
//       key: "is_trending",
//       render: (value, row) => (
//         <button
//           onClick={() => handleTrendingToggle(row)}
//           className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//             value ? "bg-yellow-500" : "bg-gray-300"
//           }`}
//         >
//           <span
//             className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//               value ? "translate-x-6" : "translate-x-1"
//             }`}
//           />
//         </button>
//       ),
//     },
//     {
//       header: "Status",
//       key: "status",
//       render: (status, row) => {
//         const isActive = getStatusValue(row);
//         return (
//           <button
//             onClick={() => handleStatusToggle(row)}
//             className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
//               isActive ? "bg-[#2c0eee]" : "bg-gray-300"
//             }`}
//           >
//             <span
//               className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
//                 isActive ? "translate-x-6" : "translate-x-1"
//               }`}
//             />
//           </button>
//         );
//       },
//     },
//     {
//       header: "Updated By",
//       key: "updated_by",
//       render: (_, row) => (
//         <span className="text-slate-500 text-sm font-medium">
//           {getUpdatedByName(row)}
//         </span>
//       ),
//     },
//     {
//       header: "Update At",
//       key: "updatedAt",
//       render: (v) => (
//         <span className="text-slate-500 text-sm">{formatDate(v)}</span>
//       ),
//     },
//     {
//       header: "Actions",
//       key: "id",
//       render: (id, row) => (
//         <div className="flex gap-1">
//           <button
//             onClick={() =>
//               navigate(`/invoices/view/${row.id}`, { state: { item: row } })
//             }
//             className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
//             title="View"
//           >
//             <MdVisibility size={16} />
//           </button>
//           <button
//             onClick={() =>
//               navigate(`/invoices/edit/${row.id}`, { state: { item: row } })
//             }
//             className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
//             title="Edit"
//           >
//             <MdEdit size={16} />
//           </button>
//           <button
//             onClick={() => setDeleteId(id)}
//             className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
//             title="Delete"
//           >
//             <MdDelete size={16} />
//           </button>
//         </div>
//       ),
//     },
//   ];

//   const tabs = [
//     { key: "all", label: "All", count: statusCounts.all },
//     { key: "active", label: "Active", count: statusCounts.active },
//     { key: "inactive", label: "Inactive", count: statusCounts.inactive },
//   ];

//   return (
//     <div className="space-y-4">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
//         <div>
//           <h1 className="text-2xl font-bold text-slate-900">Invoices</h1>
//           <p className="text-sm text-slate-500 mt-1">Manage all invoices</p>
//         </div>
//         <div className="flex items-center gap-2">
//           <Button
//             variant="secondary"
//             icon={MdAdd}
//             onClick={refreshAll}
//             loading={loading || countsLoading}
//           >
//             Refresh
//           </Button>
//           <Button icon={MdAdd} onClick={() => navigate("/invoices/add")}>
//             Add Invoice
//           </Button>
//         </div>
//       </div>

//       {/* Table Card */}
//       <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
//         {/* Top bar: search + tabs */}
//         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
//           <div className="relative w-full sm:w-72">
//             <MdSearch
//               size={18}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
//             />
//             <input
//               type="text"
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               placeholder="Search invoices..."
//               className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
//             />
//           </div>

//           <div className="flex items-center gap-5 text-sm">
//             {tabs.map((tab) => (
//               <button
//                 key={tab.key}
//                 onClick={() => setStatusFilter(tab.key)}
//                 className={`flex items-center gap-1.5 font-medium transition-colors ${
//                   statusFilter === tab.key
//                     ? "text-[#2c0eee]"
//                     : "text-slate-500 hover:text-slate-700"
//                 }`}
//               >
//                 {tab.label}
//                 <span
//                   className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
//                     statusFilter === tab.key
//                       ? "bg-slate-800 text-white shadow-sm"
//                       : "bg-slate-100 text-slate-500"
//                   }`}
//                 >
//                   {tab.count}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </div>

//         <Table
//           columns={columns}
//           data={data}
//           loading={loading}
//           emptyMessage="No invoices found"
//         />

//         {/* Footer â€” API-driven pagination */}
//         <div className="px-5 py-3 border-t border-slate-100">
//           <Pagination
//             page={page}
//             total={totalItems}
//             limit={pageSize || 20}
//             links={paginationLinks}
//             itemsCount={data.length}
//             onChange={setPage}
//           />
//         </div>
//       </div>

//       {/* Confirm Dialog */}
//       <ConfirmDialog
//         isOpen={!!deleteId}
//         onClose={() => setDeleteId(null)}
//         onConfirm={handleDelete}
//         loading={deleteLoading}
//         title="Delete Invoice"
//         message="Delete this invoice? This action cannot be undone."
//       />
//     </div>
//   );
// };

// export default Invoices;



import React, { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdPictureAsPdf,
  MdBusiness,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { invoiceService } from "../../services/invoice.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

// â”€â”€â”€ Response extractors â€” handle both axios-wrapped and unwrapped â”€
const extractList = (res) => {
  if (!res) return [];
  if (Array.isArray(res)) return res;
  if (Array.isArray(res.data?.data)) return res.data.data;
  if (Array.isArray(res.data)) return res.data;
  if (Array.isArray(res.results)) return res.results;
  return [];
};

const extractPagination = (res) => {
  if (!res) return null;
  if (res.pagination) return res.pagination;
  if (res.data?.pagination) return res.data.pagination;
  return null;
};

const extractTotal = (res) => {
  if (!res) return 0;
  if (typeof res.pagination?.total === "number") return res.pagination.total;
  if (typeof res.data?.pagination?.total === "number")
    return res.data.pagination.total;
  if (typeof res.total === "number") return res.total;
  if (Array.isArray(res.data)) return res.data.length;
  if (Array.isArray(res)) return res.length;
  return 0;
};

const Invoices = () => {
  const navigate = useNavigate();

  // â”€â”€â”€ Data & UI state â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Filters
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Pagination â€” API-driven
  const [page, setPage] = useState(1);
  // pageSize mirrors API's pagination.limit â€” display only.
  const [pageSize, setPageSize] = useState(0);
  // â­ These two were missing â€” that's what caused the crash.
  const [totalItems, setTotalItems] = useState(0);
  const [paginationLinks, setPaginationLinks] = useState(null);

  // User name cache
  const [userNameCache, setUserNameCache] = useState({});

  // Race-guard
  const requestIdRef = useRef(0);

  // Tab counts from the API (accurate across all pages)
  const [statusCounts, setStatusCounts] = useState({
    all: 0,
    active: 0,
    inactive: 0,
  });
  const [countsLoading, setCountsLoading] = useState(false);

  // â”€â”€â”€ User name helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  const normalizeInvoice = (item) => ({
    id: item.id || item._id,
    invoice_no: item.invoice_no || "",
    gst_number: item.gst_number || "",
    billing_address: item.billing_address || "",
    subtotal: parseFloat(item.subtotal) || 0,
    gst: parseFloat(item.gst) || 0,
    grand_total: parseFloat(item.grand_total) || 0,
    pdf_url: item.pdf_url || null,
    invoice_status: item.invoice_status || "",
    due_date: item.due_date || null,
    is_trending: item.is_trending === 1 || item.is_trending === true,
    is_status: item.is_status === 1 || item.is_status === true,
    status: item.is_status === 1 || item.is_status === true,
    created_by: item.created_by || null,
    updated_by: item.updated_by || null,
    createdAt: item.created_at || item.createdAt || null,
    updatedAt: item.updated_at || item.updatedAt || null,
    Company: item.Company || null,
    company_name: item.Company?.company_name || "",
    company_id: item.Company?.company_id || "",
    raw: item,
  });

  const getStatusValue = (row) => {
    if (row.is_status !== undefined) return row.is_status;
    if (row.status !== undefined) {
      return row.status === 1 || row.status === true;
    }
    return true;
  };

  // â”€â”€â”€ Debounce search â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedSearch(search.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [search]);

  // Reset page when status filter changes
  useEffect(() => {
    setPage(1);
  }, [statusFilter]);

  // â”€â”€â”€ Load users once â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const users = await fetchUsers();
        if (!cancelled) {
          const userMap = {};
          Object.keys(users || {}).forEach((id) => {
            userMap[id] = users[id].name;
          });
          setUserNameCache(userMap);
        }
      } catch (e) {
        console.warn("Could not fetch user names cache:", e);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // â”€â”€â”€ Load one page of invoices â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const load = useCallback(async () => {
    const requestId = ++requestIdRef.current;
    setLoading(true);
    try {
      // Only `page` is sent â€” the API controls page size.
      const params = { page };
      if (debouncedSearch) params.search = debouncedSearch;
      if (statusFilter === "active") params.is_status = 1;
      else if (statusFilter === "inactive") params.is_status = 0;

      console.log("[Invoices] fetch params:", params);

      const r = await invoiceService.getAll(params);
      if (requestIdRef.current !== requestId) return;

      const rawData = extractList(r);
      const pagination = extractPagination(r);

      console.log("[Invoices] pagination:", pagination);
      console.log("[Invoices] rows received:", rawData.length);

      const invoices = rawData.map(normalizeInvoice);

      setData(invoices);
      setPaginationLinks(pagination?.links || null);

      const serverTotal = Number(pagination?.total || 0);
      setTotalItems(serverTotal > 0 ? serverTotal : invoices.length);

      // Adopt the API's page size for display.
      if (pagination?.limit && Number(pagination.limit) > 0) {
        setPageSize(Number(pagination.limit));
      }
      // Follow server if it clamps the page.
      if (pagination?.page && Number(pagination.page) !== page) {
        setPage(Number(pagination.page));
      }
    } catch (error) {
      if (requestIdRef.current !== requestId) return;
      console.error("Load error:", error);
      showError(error.message || "Failed to load invoices");
      setData([]);
      setTotalItems(0);
      setPaginationLinks(null);
    } finally {
      if (requestIdRef.current === requestId) setLoading(false);
    }
  }, [page, debouncedSearch, statusFilter]);

  useEffect(() => {
    load();
  }, [load]);

  // â”€â”€â”€ Fetch one count via limit=1 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const fetchCount = useCallback(async (isStatus) => {
    const params = { page: 1, limit: 1 };
    if (isStatus === 1) params.is_status = 1;
    else if (isStatus === 0) params.is_status = 0;
    const res = await invoiceService.getAll(params);
    return extractTotal(res);
  }, []);

  const loadCounts = useCallback(async () => {
    setCountsLoading(true);
    try {
      const [all, active, inactive] = await Promise.all([
        fetchCount(null),
        fetchCount(1),
        fetchCount(0),
      ]);
      setStatusCounts({ all, active, inactive });
    } catch (err) {
      console.error("Failed to load invoice counts:", err);
    } finally {
      setCountsLoading(false);
    }
  }, [fetchCount]);

  useEffect(() => {
    loadCounts();
  }, [loadCounts]);

  const refreshAll = () => {
    load();
    loadCounts();
  };

  const getInvoiceStatusColor = (status) => {
    const statusMap = {
      Paid: "green",
      paid: "green",
      Pending: "yellow",
      pending: "yellow",
      Overdue: "red",
      overdue: "red",
      Cancelled: "gray",
      cancelled: "gray",
    };
    return statusMap[status] || "purple";
  };

  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by) return getUserNameCached(row.updated_by);
    return "-";
  };

  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await invoiceService.delete(deleteId);
      showSuccess("Invoice deleted successfully");
      load();
      loadCounts();
    } catch (error) {
      console.error("Delete error:", error);
      showError(error.message || "Failed to delete invoice");
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  const handleStatusToggle = async (row) => {
    const currentStatus = getStatusValue(row);
    const newStatus = !currentStatus;

    try {
      await invoiceService.update(row.id, { is_status: newStatus ? 1 : 0 });
      showSuccess(
        `Status ${newStatus ? "activated" : "deactivated"} successfully`
      );
      load();
      loadCounts();
    } catch (error) {
      console.error("Status toggle error:", error);
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update status"
      );
    }
  };

  const handleTrendingToggle = async (row) => {
    const newValue = !row.is_trending;

    try {
      await invoiceService.update(row.id, { is_trending: newValue ? 1 : 0 });
      showSuccess(`Trending ${newValue ? "enabled" : "disabled"} successfully`);
      load();
    } catch (error) {
      console.error("Trending toggle error:", error);
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update trending"
      );
    }
  };

  const handleDownloadPdf = (row) => {
    if (!row.pdf_url) {
      showError("No PDF file available");
      return;
    }
    const pdfUrl = row.pdf_url.startsWith("http")
      ? row.pdf_url
      : `https://apidata.hiremejobs.in${row.pdf_url}`;
    if (pdfUrl) {
      window.open(pdfUrl, "_blank");
    } else {
      showError("Invalid PDF URL");
    }
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * (pageSize || 20) + i + 1,
    },
    {
      header: "Invoice",
      key: "invoice_no",
      render: (v, row) => (
        <div>
          <span className="font-medium text-slate-800">{v}</span>
          <div className="flex items-center gap-1 mt-0.5">
            <span
              className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-medium bg-${getInvoiceStatusColor(row.invoice_status)}-50 text-${getInvoiceStatusColor(row.invoice_status)}-700`}
            >
              {row.invoice_status || "Unknown"}
            </span>
            {row.pdf_url && (
              <button
                onClick={() => handleDownloadPdf(row)}
                className="text-[#4529f7] hover:text-[#2c0eee]"
                title="Download PDF"
              >
                <MdPictureAsPdf size={14} />
              </button>
            )}
          </div>
        </div>
      ),
    },
    {
      header: "Company",
      key: "company_name",
      render: (v, row) => (
        <div className="flex items-center gap-1">
          <MdBusiness size={14} className="text-slate-400" />
          <span className="text-slate-700">{v || "-"}</span>
        </div>
      ),
    },
    {
      header: "Amount",
      key: "grand_total",
      render: (v, row) => (
        <div>
          <span className="font-semibold text-slate-800">
            â‚¹{v?.toFixed(2)}
          </span>
          <span className="text-xs text-slate-400 ml-1">
            (Subtotal: â‚¹{row.subtotal?.toFixed(2)})
          </span>
        </div>
      ),
    },
    {
      header: "GST",
      key: "gst",
      render: (v) => <span className="text-slate-600">â‚¹{v?.toFixed(2)}</span>,
    },
    // {
    //   header: "Due Date",
    //   key: "due_date",
    //   render: (v) => {
    //     const dueDate = new Date(v);
    //     const today = new Date();
    //     const isOverdue = dueDate < today;
    //     return (
    //       <span
    //         className={`text-sm ${isOverdue ? "text-red-500" : "text-slate-500"}`}
    //       >
    //         {formatDate(v)}
    //         {isOverdue && (
    //           <span className="ml-1 text-xs text-red-500">(Overdue)</span>
    //         )}
    //       </span>
    //     );
    //   },
    // },
    // {
    //   header: "Trending",
    //   key: "is_trending",
    //   render: (value, row) => (
    //     <button
    //       onClick={() => handleTrendingToggle(row)}
    //       className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
    //         value ? "bg-yellow-500" : "bg-gray-300"
    //       }`}
    //     >
    //       <span
    //         className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
    //           value ? "translate-x-6" : "translate-x-1"
    //         }`}
    //       />
    //     </button>
    //   ),
    // },
    // {
    //   header: "Status",
    //   key: "status",
    //   render: (status, row) => {
    //     const isActive = getStatusValue(row);
    //     return (
    //       <button
    //         onClick={() => handleStatusToggle(row)}
    //         className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
    //           isActive ? "bg-[#2c0eee]" : "bg-gray-300"
    //         }`}
    //       >
    //         <span
    //           className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${
    //             isActive ? "translate-x-6" : "translate-x-1"
    //           }`}
    //         />
    //       </button>
    //     );
    //   },
    // },
    // {
    //   header: "Updated By",
    //   key: "updated_by",
    //   render: (_, row) => (
    //     <span className="text-slate-500 text-sm font-medium">
    //       {getUpdatedByName(row)}
    //     </span>
    //   ),
    // },
    // {
    //   header: "Update At",
    //   key: "updatedAt",
    //   render: (v) => (
    //     <span className="text-slate-500 text-sm">{formatDate(v)}</span>
    //   ),
    // },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() =>
              navigate(`/invoices/view/${row.id}`, { state: { item: row } })
            }
            className="p-1.5 hover:bg-blue-50 text-[#2c0eee] rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          {/* <button
            onClick={() =>
              navigate(`/invoices/edit/${row.id}`, { state: { item: row } })
            }
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button> */}
          {/* <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button> */}
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: statusCounts.all },
    { key: "active", label: "Active", count: statusCounts.active },
    { key: "inactive", label: "Inactive", count: statusCounts.inactive },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Invoices</h1>
          <p className="text-sm text-slate-500 mt-1">Manage all invoices</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdAdd}
            onClick={refreshAll}
            loading={loading || countsLoading}
          >
            Refresh
          </Button>
          {/* <Button icon={MdAdd} onClick={() => navigate("/invoices/add")}>
            Add Invoice
          </Button> */}
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search invoices..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-[#2c0eee] transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${
                  statusFilter === tab.key
                    ? "text-[#2c0eee]"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={data}
          loading={loading}
          emptyMessage="No invoices found"
        />

        {/* Footer â€” API-driven pagination */}
        <div className="px-5 py-3 border-t border-slate-100">
          <Pagination
            page={page}
            total={totalItems}
            limit={pageSize || 20}
            links={paginationLinks}
            itemsCount={data.length}
            onChange={setPage}
          />
        </div>
      </div>

      {/* Confirm Dialog */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Invoice"
        message="Delete this invoice? This action cannot be undone."
      />
    </div>
  );
};

export default Invoices;

