// import { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";
// import Input from "../../components/common/Input";
// import Button from "../../components/common/Button";
// import { showSuccess, showError } from "../../utils/toast";
// import { MdEmail } from "react-icons/md";

// const ForgotPassword = () => {
//   const navigate = useNavigate();
//   const [email, setEmail] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState(null);
//   const [success, setSuccess] = useState(false);

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     setError("");
//     setSuccess(false);

//     if (!email.trim()) {
//       showError("Please enter your email.");
//       setError("Please enter your email.");
//       return;
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

//     if (!emailRegex.test(email)) {
//       showError("Please enter a valid email.");
//       setError("Please enter a valid email.");
//       return;
//     }

//     try {
//       setLoading(true);

//       const { data, status } = await axios.post(
//         "https://apidata.hiremejobs.in/user/forgot-password",
//         {
//           email: email.trim(),
//         },
//         {
//           headers: {
//             "Content-Type": "application/json",
//           },
//         },
//       );

//       console.log("Response:", data);

//       if (status === 200 || data.success || data.status) {
//         setSuccess(true);

//         showSuccess(data.message || "Password reset link sent successfully.");

//         setTimeout(() => {
//           navigate("/login");
//         }, 3000);
//       } else {
//         showError(data.message || "Unable to send reset link.");
//         setError(data.message || "Unable to send reset link.");
//       }
//     } catch (err) {
//       console.log(err);

//       const message =
//         err.response?.data?.message ||
//         err.response?.data?.error ||
//         err.message ||
//         "Something went wrong.";

//       showError(message);
//       setError(message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#2c0eee] to-slate-900 flex items-center justify-center p-4">
//       <div className="w-full max-w-md">
//         {/* Logo */}
//         <div className="text-center mb-8">
//           <div className="inline-flex items-center justify-center w-16 h-16 bg-[#2c0eee] rounded-2xl shadow-lg mb-4">
//             <span className="text-white text-2xl font-bold">C</span>
//           </div>
//           <h1 className="text-2xl font-bold text-white">Forgot Password</h1>
//           <p className="text-gray-400 mt-1 text-sm">
//             Enter your email to receive a password reset link
//           </p>
//         </div>

//         <div className="bg-white rounded-2xl shadow-xl p-8">
//           {error && (
//             <div className="mb-4 px-4 py-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
//               {error}
//             </div>
//           )}

//           {success ? (
//             <div className="space-y-4 text-center">
//               <div className="px-4 py-3 bg-green-50 border border-green-200 rounded-lg text-green-700 text-sm">
//                 Password reset link sent! Please check your email.
//               </div>
//               <p className="text-sm text-gray-600">
//                 If you don't receive the email, check your spam folder or try
//                 again.
//               </p>
//               <Button
//                 onClick={() => navigate("/login")}
//                 className="w-full justify-center py-3"
//               >
//                 Back to Login
//               </Button>
//             </div>
//           ) : (
//             <form onSubmit={handleSubmit} className="space-y-5">
//               <div className="relative">
//                 <MdEmail
//                   className="absolute left-3 top-9 text-gray-400"
//                   size={18}
//                 />
//                 <Input
//                   label="Email address"
//                   type="email"
//                   required
//                   placeholder="Enter your registered email"
//                   className="pl-9"
//                   value={email}
//                   onChange={(e) => setEmail(e.target.value)}
//                 />
//               </div>

//               <Button
//                 type="submit"
//                 className="w-full justify-center py-3"
//                 loading={loading}
//               >
//                 Send Reset Link
//               </Button>

//               <p className="text-center text-sm text-gray-600">
//                 Remember your password?{" "}
//                 <Link
//                   to="/login"
//                   className="text-[#2c0eee] hover:text-[#2c0eee] font-medium"
//                 >
//                   Sign in
//                 </Link>
//               </p>
//             </form>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ForgotPassword;

import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Input from "../../components/common/Input";
import Button from "../../components/common/Button";
import HireMeLogo from "../../assets/HiremeLogoWhite.png";
import {
  MdEmail,
  MdLock,
  MdVisibility,
  MdVisibilityOff,
  MdArrowBack,
  MdCheckCircle,
  MdErrorOutline,
} from "react-icons/md";

const API_BASE =
  import.meta.env.VITE_API_URL || "https://apidata.hiremejobs.in";

// API endpoints — adjust if your backend uses different paths
const SEND_OTP_ENDPOINT = `${API_BASE}/user/forgot-password`;
const RESET_PWD_ENDPOINT = `${API_BASE}/user/forgot-password`;

const STEP = {
  EMAIL: 1,
  RESET: 2,
  DONE: 3,
};

const ForgotPassword = () => {
  const navigate = useNavigate();

  const [step, setStep] = useState(STEP.EMAIL);

  // ─── Step 1: email ─────────────────────────────────────────
  const [email, setEmail] = useState("");

  // ─── Step 2: OTP + new password ────────────────────────────
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // ─── Shared state ──────────────────────────────────────────
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(null);
  const [resendTimer, setResendTimer] = useState(0);

  const otpInputsRef = useRef([]);
  const abortControllerRef = useRef(null);

  // Resend cooldown ticker
  useEffect(() => {
    if (resendTimer <= 0) return undefined;
    const t = setInterval(() => setResendTimer((v) => v - 1), 1000);
    return () => clearInterval(t);
  }, [resendTimer]);

  // Clear error when step changes
  useEffect(() => {
    setError(null);
  }, [step]);

  // Auto-focus first OTP box
  useEffect(() => {
    if (step === STEP.RESET) {
      setTimeout(() => otpInputsRef.current[0]?.focus(), 100);
    }
  }, [step]);

  // Cleanup abort controller on unmount
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) abortControllerRef.current.abort();
    };
  }, []);

  // ─── Step 1: send OTP ──────────────────────────────────────
  const handleSendOtp = async (e) => {
    if (e) e.preventDefault();
    setError(null);
    setInfo(null);

    const trimmed = email.trim();
    if (!trimmed) {
      setError("Please enter your registered email.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setError("Please enter a valid email address.");
      return;
    }

    if (abortControllerRef.current) abortControllerRef.current.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setLoading(true);
    try {
      const res = await axios.post(
        SEND_OTP_ENDPOINT,
        { email: trimmed },
        {
          headers: { "Content-Type": "application/json" },
          timeout: 15000,
          signal: controller.signal,
        },
      );

      const data = res?.data ?? {};
      // Accept any 2xx as success, or an explicit success flag
      const okStatus =
        res.status === 200 ||
        res.status === 201 ||
        data.success === true ||
        data.status === "success" ||
        data.status === true;

      if (!okStatus) {
        throw new Error(data.message || "Failed to send OTP");
      }

      setInfo(
        data.message ||
          `A 6-digit verification code has been sent to ${trimmed}`,
      );
      setOtpDigits(["", "", "", "", "", ""]);
      setNewPassword("");
      setConfirmPassword("");
      setResendTimer(30);
      setStep(STEP.RESET);
    } catch (err) {
      if (axios.isCancel(err)) return;
      let message = "Failed to send OTP. Please try again.";
      if (err.code === "ECONNABORTED") {
        message = "Request timed out. Please try again.";
      } else if (err.response) {
        message =
          err.response.data?.message ||
          err.response.data?.error ||
          `Server error (${err.response.status})`;
      } else if (err.message) {
        message = err.message;
      }
      setError(message);
    } finally {
      setLoading(false);
      abortControllerRef.current = null;
    }
  };

  // ─── Step 2: verify OTP + reset password ──────────────────
  const handleResetPassword = async (e) => {
    if (e) e.preventDefault();
    setError(null);

    const code = otpDigits.join("");
    if (code.length !== 6) {
      setError("Please enter the 6-digit code from your email.");
      return;
    }
    if (!newPassword || !confirmPassword) {
      setError("Please fill in both password fields.");
      return;
    }
    if (newPassword.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    if (abortControllerRef.current) abortControllerRef.current.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setLoading(true);
    try {
      const res = await axios.patch(
        RESET_PWD_ENDPOINT,
        {
          email: email.trim(),
          otp: code,
          password: newPassword,
          confirmPassword,
        },
        {
          headers: { "Content-Type": "application/json" },
          timeout: 15000,
          signal: controller.signal,
        },
      );

      const data = res?.data ?? {};
      const okStatus =
        res.status === 200 ||
        res.status === 201 ||
        data.success === true ||
        data.status === "success" ||
        data.status === true;

      if (!okStatus) {
        throw new Error(data.message || "Failed to reset password");
      }

      setInfo(data.message || "Password reset successfully!");
      setStep(STEP.DONE);
      setTimeout(() => navigate("/login"), 2200);
    } catch (err) {
      if (axios.isCancel(err)) return;
      let message = "Failed to reset password. Please try again.";
      if (err.code === "ECONNABORTED") {
        message = "Request timed out. Please try again.";
      } else if (err.response) {
        message =
          err.response.data?.message ||
          err.response.data?.error ||
          `Server error (${err.response.status})`;
      } else if (err.message) {
        message = err.message;
      }
      setError(message);
    } finally {
      setLoading(false);
      abortControllerRef.current = null;
    }
  };

  // ─── OTP handlers ──────────────────────────────────────────
  const handleOtpChange = (index, value) => {
    const digit = value.replace(/\D/g, "").slice(-1);
    const next = [...otpDigits];
    next[index] = digit;
    setOtpDigits(next);
    setError(null);
    if (digit && index < 5) {
      otpInputsRef.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) {
      otpInputsRef.current[index - 1]?.focus();
    }
    if (e.key === "ArrowLeft" && index > 0) {
      otpInputsRef.current[index - 1]?.focus();
    }
    if (e.key === "ArrowRight" && index < 5) {
      otpInputsRef.current[index + 1]?.focus();
    }
    if (e.key === "Enter") {
      handleResetPassword(e);
    }
  };

  const handleOtpPaste = (e) => {
    const text = e.clipboardData?.getData("text")?.replace(/\D/g, "") || "";
    if (text.length === 6) {
      e.preventDefault();
      setOtpDigits(text.split("").slice(0, 6));
      setError(null);
      otpInputsRef.current[5]?.focus();
    }
  };

  const handleBackToEmail = () => {
    setStep(STEP.EMAIL);
    setOtpDigits(["", "", "", "", "", ""]);
    setNewPassword("");
    setConfirmPassword("");
    setError(null);
    setInfo(null);
    setResendTimer(0);
  };

  // ─── Password strength indicator ──────────────────────────
  const pwdStrength =
    newPassword.length === 0
      ? 0
      : newPassword.length < 6
        ? 1
        : newPassword.length < 9
          ? 2
          : 3;
  const strengthColors = ["", "bg-red-400", "bg-amber-400", "bg-emerald-500"];
  const strengthLabels = ["", "Weak", "Fair", "Strong"];
  const strengthTextColors = [
    "",
    "text-red-500",
    "text-amber-500",
    "text-emerald-600",
  ];

  const stepLabels = ["Email", "Reset Password"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#2c0eee] to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center flex flex-col items-center justify-center mb-4">
          <div className="inline-flex items-center justify-center w-24 h-16 rounded-2xl shadow-lg overflow-hidden">
            <img
              src={HireMeLogo}
              alt="Hire Me Logo"
              className="w-full h-full object-contain"
            />
          </div>
          <h2 className="text-2xl font-bold text-white mt-1">
            Forgot Password
          </h2>
          <p className="text-sm text-white/70 mt-1">
            We'll help you reset it in a few quick steps
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Step indicator (hidden on success) */}
          {step !== STEP.DONE && (
            <div className="flex items-center justify-between gap-2 mb-6">
              {stepLabels.map((label, idx) => {
                const stepNum = idx + 1;
                const isActive = step === stepNum;
                const isDone = step > stepNum;
                return (
                  <div
                    key={label}
                    className="flex-1 flex flex-col items-center gap-1.5"
                  >
                    <div className="flex items-center w-full">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all ${
                          isDone
                            ? "bg-[#2c0eee] text-white"
                            : isActive
                              ? "bg-[#2c0eee] text-white ring-4 ring-[#2c0eee]/15"
                              : "bg-gray-200 text-gray-500"
                        }`}
                      >
                        {isDone ? <MdCheckCircle size={16} /> : stepNum}
                      </div>
                      {idx < stepLabels.length - 1 && (
                        <div
                          className={`flex-1 h-[2px] rounded ml-2 transition-colors ${
                            step > stepNum ? "bg-[#2c0eee]" : "bg-gray-200"
                          }`}
                        />
                      )}
                    </div>
                    <span
                      className={`text-[10px] font-semibold uppercase tracking-wide ${
                        isActive || isDone ? "text-[#2c0eee]" : "text-gray-400"
                      }`}
                    >
                      {label}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Error banner */}
          {error && (
            <div className="mb-4 flex items-start gap-2.5 px-4 py-3 bg-red-50 border border-red-200 rounded-lg">
              <MdErrorOutline
                size={18}
                className="text-red-500 mt-0.5 flex-shrink-0"
              />
              <p className="text-sm text-red-700 font-medium leading-relaxed">
                {error}
              </p>
            </div>
          )}

          {/* Info banner */}
          {info && step === STEP.RESET && (
            <div className="mb-4 flex items-start gap-2.5 px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-lg">
              <MdCheckCircle
                size={18}
                className="text-emerald-600 mt-0.5 flex-shrink-0"
              />
              <p className="text-sm text-emerald-700 font-medium leading-relaxed">
                {info}
              </p>
            </div>
          )}

          {/* ═══════════════════════════════════════════════════ */}
          {/* STEP 1 — EMAIL                                      */}
          {/* ═══════════════════════════════════════════════════ */}
          {step === STEP.EMAIL && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div className="relative">
                <MdEmail
                  className="absolute left-3 top-9 text-gray-400"
                  size={18}
                />
                <Input
                  label="Registered Email *"
                  type="email"
                  required
                  placeholder="you@example.com"
                  className="pl-9"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError(null);
                  }}
                />
              </div>

              <p className="text-xs text-gray-500 leading-relaxed">
                Enter the email associated with your account. We'll send a
                6-digit verification code to it.
              </p>

              <Button
                type="submit"
                className="w-full justify-center py-3 bg-[#2c0eee] hover:bg-[#2c0eee]"
                loading={loading}
              >
                Send Verification Code
              </Button>
            </form>
          )}

          {/* ═══════════════════════════════════════════════════ */}
          {/* STEP 2 — OTP + NEW PASSWORD                         */}
          {/* ═══════════════════════════════════════════════════ */}
          {step === STEP.RESET && (
            <form onSubmit={handleResetPassword} className="space-y-5">
              {/* Sent-to summary */}
              <div className="flex items-center justify-between gap-3 px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="min-w-0">
                  <p className="text-[11px] text-slate-500 uppercase tracking-wide font-semibold">
                    Code sent to
                  </p>
                  <p className="text-sm font-medium text-slate-800 truncate">
                    {email}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleBackToEmail}
                  className="flex-shrink-0 inline-flex items-center gap-1 text-xs font-semibold text-[#2c0eee] hover:underline"
                >
                  <MdArrowBack size={14} />
                  Change
                </button>
              </div>

              {/* 6-digit OTP inputs */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Enter the 6-digit code
                </label>
                <div
                  className="flex items-center justify-between gap-2"
                  onPaste={handleOtpPaste}
                >
                  {otpDigits.map((digit, idx) => (
                    <input
                      key={idx}
                      ref={(el) => (otpInputsRef.current[idx] = el)}
                      type="text"
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(idx, e.target.value)}
                      onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                      onFocus={(e) => e.target.select()}
                      className={`w-full h-12 text-center text-lg font-bold rounded-lg border-2 bg-white outline-none transition-all
                        ${
                          error
                            ? "border-red-300 focus:border-red-500 focus:ring-2 focus:ring-red-500/20"
                            : "border-gray-200 focus:border-[#2c0eee] focus:ring-2 focus:ring-[#2c0eee]/20"
                        }
                        ${digit ? "text-[#2c0eee]" : "text-gray-800"}
                      `}
                    />
                  ))}
                </div>
                <p className="mt-2 text-xs text-gray-400">
                  Tip: you can paste the code directly into any box.
                </p>
              </div>

              {/* New password */}
              <div className="relative">
                <MdLock
                  className="absolute left-3 top-9 text-gray-400"
                  size={18}
                />
                <Input
                  label="New Password *"
                  type={showNew ? "text" : "password"}
                  required
                  placeholder="Min. 6 characters"
                  className="pl-9 pr-10"
                  value={newPassword}
                  onChange={(e) => {
                    setNewPassword(e.target.value);
                    setError(null);
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowNew(!showNew)}
                  className="absolute right-3 top-9 text-gray-400 hover:text-gray-600"
                >
                  {showNew ? (
                    <MdVisibilityOff size={18} />
                  ) : (
                    <MdVisibility size={18} />
                  )}
                </button>
              </div>

              {/* Strength bar */}
              {newPassword.length > 0 && (
                <div className="flex items-center gap-2 -mt-2">
                  {[1, 2, 3].map((lvl) => (
                    <div
                      key={lvl}
                      className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                        pwdStrength >= lvl
                          ? strengthColors[pwdStrength]
                          : "bg-gray-200"
                      }`}
                    />
                  ))}
                  <span
                    className={`text-[10px] font-bold whitespace-nowrap ${
                      strengthTextColors[pwdStrength]
                    }`}
                  >
                    {strengthLabels[pwdStrength]}
                  </span>
                </div>
              )}

              {/* Confirm password */}
              <div className="relative">
                <MdLock
                  className="absolute left-3 top-9 text-gray-400"
                  size={18}
                />
                <Input
                  label="Confirm New Password *"
                  type={showConfirm ? "text" : "password"}
                  required
                  placeholder="Re-enter your new password"
                  className="pl-9 pr-10"
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    setError(null);
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-9 text-gray-400 hover:text-gray-600"
                >
                  {showConfirm ? (
                    <MdVisibilityOff size={18} />
                  ) : (
                    <MdVisibility size={18} />
                  )}
                </button>
              </div>

              <Button
                type="submit"
                className="w-full justify-center py-3 bg-[#2c0eee] hover:bg-[#2c0eee]"
                loading={loading}
              >
                Reset Password
              </Button>

              {/* Resend */}
              <div className="text-center text-sm text-gray-600">
                Didn't receive the code?{" "}
                {resendTimer > 0 ? (
                  <span className="font-medium text-gray-400">
                    Resend in {resendTimer}s
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    disabled={loading}
                    className="font-semibold text-[#2c0eee] hover:underline disabled:opacity-50"
                  >
                    Resend OTP
                  </button>
                )}
              </div>
            </form>
          )}

          {/* ═══════════════════════════════════════════════════ */}
          {/* STEP 3 — SUCCESS                                    */}
          {/* ═══════════════════════════════════════════════════ */}
          {step === STEP.DONE && (
            <div className="text-center py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-4">
                <MdCheckCircle size={36} className="text-emerald-500" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-1">
                Password Reset Successfully
              </h3>
              <p className="text-sm text-gray-500 mb-6">
                You'll be redirected to the login page in a moment.
              </p>
              <Link
                to="/login"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#2c0eee] text-white text-sm font-semibold hover:bg-[#2c0eee]/90 transition-colors"
              >
                Go to Login
              </Link>
            </div>
          )}

          {/* Footer: back to login */}
          {step !== STEP.DONE && (
            <div className="mt-6 pt-4 border-t border-gray-100 text-center">
              <Link
                to="/login"
                className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-[#2c0eee] font-medium transition-colors"
              >
                <MdArrowBack size={14} />
                Back to Login
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
