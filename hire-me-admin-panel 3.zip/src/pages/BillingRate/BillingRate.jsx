﻿import React, { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  MdAdd,
  MdEdit,
  MdDelete,
  MdSearch,
  MdVisibility,
  MdRefresh,
} from "react-icons/md";
import Table from "../../components/common/Table";
import Button from "../../components/common/Button";
import Pagination from "../../components/common/Pagination";
import ConfirmDialog from "../../components/common/ConfirmDialog";
import { billingRateService } from "../../services/billingRate.service";
import { showSuccess, showError } from "../../utils/toast";
import { formatDate } from "../../utils/helpers";
import { fetchUsers } from "../../utils/getUserName";

const BillingRate = () => {
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [statusFilter, setStatusFilter] = useState("all");
  const [userNameCache, setUserNameCache] = useState({});
  const [togglingId, setTogglingId] = useState(null);

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  // Reset page on search or status filter change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, statusFilter]);

  // Get user name with caching
  const getUserNameCached = (userId) => {
    if (!userId) return "-";
    return userNameCache[userId] || `User ${userId}`;
  };

  // Format currency
  const formatCurrency = (amount) => {
    if (!amount && amount !== 0) return "-";

    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  // Normalize billing rate data
  const normalizeBillingRate = (item) => {
    let statusValue = true;

    if (item.status !== undefined && item.status !== null) {
      if (typeof item.status === "number") {
        statusValue = item.status === 1;
      } else if (typeof item.status === "boolean") {
        statusValue = item.status;
      } else if (typeof item.status === "string") {
        statusValue =
          item.status === "true" ||
          item.status === "1" ||
          item.status === "active";
      }
    } else if (item.is_status !== undefined && item.is_status !== null) {
      if (typeof item.is_status === "number") {
        statusValue = item.is_status === 1;
      } else if (typeof item.is_status === "boolean") {
        statusValue = item.is_status;
      } else if (typeof item.is_status === "string") {
        statusValue =
          item.is_status === "true" ||
          item.is_status === "1" ||
          item.is_status === "active";
      }
    }

    return {
      id: item.id || item._id,
      display_text: item.display_text || "",
      amount: item.amount || 0,
      display_order: item.display_order ?? 0,
      is_status: statusValue,
      updated_by: item.updated_by || "",
      updated_at: item.updated_at || item.updatedAt || null,
      created_at: item.created_at || item.createdAt || null,
      created_by: item.created_by || "",
    };
  };

  // Load all billing rates across pages
  const load = async () => {
    setLoading(true);
    try {
      const users = await fetchUsers();
      const userMap = {};
      Object.keys(users || {}).forEach((id) => {
        userMap[id] = users[id].name;
      });
      setUserNameCache(userMap);

      // Fetch page 1 with max limit 100 to retrieve total pagination info
      const r1 = await billingRateService.getAll({ page: 1, limit: 100 });
      const rawData1 = r1.data?.data || r1.data?.results || r1.data || [];
      const list1 = Array.isArray(rawData1) ? rawData1 : [];

      const pagination = r1.data?.pagination || r1.pagination;
      const totalPages = pagination?.totalPages || 1;

      let allRawData = [...list1];

      if (totalPages > 1) {
        const fetchPromises = [];
        for (let p = 2; p <= totalPages; p++) {
          fetchPromises.push(billingRateService.getAll({ page: p, limit: 100 }));
        }
        const results = await Promise.all(fetchPromises);
        results.forEach((res) => {
          const rawList = res.data?.data || res.data?.results || res.data || [];
          if (Array.isArray(rawList)) {
            allRawData.push(...rawList);
          }
        });
      }

      const billingRates = allRawData.map(normalizeBillingRate);

      const sortedBillingRates = billingRates.sort((a, b) => {
        return (
          new Date(b.created_at || 0) - new Date(a.created_at || 0) ||
          (b.id || 0) - (a.id || 0)
        );
      });

      setData(sortedBillingRates);
    } catch (error) {
      console.error("Load error:", error);
      showError(error.message || "Failed to load billing rates");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filteredData = useMemo(() => {
    let result = data;
    if (statusFilter !== "all") {
      const isActive = statusFilter === "active";
      result = result.filter((item) => item.is_status === isActive);
    }
    const query = debouncedSearch.toLowerCase().trim();
    if (query) {
      result = result.filter(
        (item) =>
          String(item.display_text ?? "")
            .toLowerCase()
            .includes(query) ||
          String(item.amount ?? "").includes(query) ||
          String(formatCurrency(item.amount ?? ""))
            .toLowerCase()
            .includes(query)
      );
    }
    return result;
  }, [data, debouncedSearch, statusFilter]);

  const paginatedData = useMemo(() => {
    return filteredData.slice((page - 1) * limit, page * limit);
  }, [filteredData, page, limit]);

  const activeCount = useMemo(
    () => data.filter((r) => r.is_status === true).length,
    [data]
  );
  const inactiveCount = useMemo(
    () => data.length - activeCount,
    [data, activeCount]
  );

  // Get display name for updated by
  const getUpdatedByName = (row) => {
    if (!row) return "-";
    if (row.updated_by) {
      return getUserNameCached(row.updated_by);
    }
    return "-";
  };

  // Navigation handlers
  const openAdd = () => {
    navigate("/billing-rates/add");
  };

  const openEdit = (item) => {
    navigate(`/billing-rates/edit/${item.id}`);
  };

  const openView = (item) => {
    navigate(`/billing-rates/view/${item.id}`);
  };

  // Handle delete
  const handleDelete = async () => {
    setDeleteLoading(true);
    try {
      await billingRateService.delete(deleteId);
      showSuccess("Billing rate deleted successfully");
      load();
    } catch (error) {
      console.error("Delete error:", error);
      const message = error?.response?.data?.message || error?.message || "";
      if (/foreign\s*key|constraint|used|referenced/i.test(message)) {
        showError(
          "Cannot delete this billing rate because it is being used in other records."
        );
      } else {
        showError(message || "Failed to delete billing rate");
      }
    } finally {
      setDeleteId(null);
      setDeleteLoading(false);
    }
  };

  // Toggle status optimistically
  const handleStatusToggle = async (row) => {
    if (togglingId === row.id) return;
    const currentStatus = row.is_status === true;
    const newStatus = !currentStatus;

    setTogglingId(row.id);
    setData((prev) =>
      prev.map((item) =>
        item.id === row.id ? { ...item, is_status: newStatus } : item
      )
    );

    try {
      const updateData = {
        display_text: row.display_text,
        amount: row.amount,
        status: newStatus,
      };

      await billingRateService.update(row.id, updateData);
      showSuccess(
        `Status ${newStatus ? "activated" : "deactivated"} successfully`
      );
    } catch (error) {
      console.error("Status toggle error:", error);
      setData((prev) =>
        prev.map((item) =>
          item.id === row.id ? { ...item, is_status: currentStatus } : item
        )
      );
      showError(
        error.response?.data?.message ||
          error.message ||
          "Failed to update status"
      );
    } finally {
      setTogglingId(null);
    }
  };

  const columns = [
    {
      header: "#",
      key: "id",
      render: (_, __, i) => (page - 1) * limit + i + 1,
    },
    {
      header: "Display Text",
      key: "display_text",
      render: (v) => <span className="font-medium text-slate-800">{v}</span>,
    },
    {
      header: "Amount",
      key: "amount",
      render: (v) => (
        <span className="font-semibold text-slate-900">{formatCurrency(v)}</span>
      ),
    },
    {
      header: "Status",
      key: "is_status",
      render: (value, row) => {
        const isActive = row.is_status === true;
        return (
          <button
            onClick={() => handleStatusToggle(row)}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${isActive ? "bg-[#2c0eee]" : "bg-gray-300"}`}
          >
            <span
              className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow ${isActive ? "translate-x-6" : "translate-x-1"}`}
            />
          </button>
        );
      },
    },
    {
      header: "Updated By",
      key: "updated_by",
      render: (_, row) => (
        <span className="text-slate-500 text-sm font-medium">
          {getUpdatedByName(row)}
        </span>
      ),
    },
    {
      header: "Updated At",
      key: "updated_at",
      render: (v) => (
        <span className="text-slate-500 text-sm">{formatDate(v)}</span>
      ),
    },
    {
      header: "Actions",
      key: "id",
      render: (id, row) => (
        <div className="flex gap-1">
          <button
            onClick={() => openView(row)}
            className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"
            title="View"
          >
            <MdVisibility size={16} />
          </button>
          <button
            onClick={() => openEdit(row)}
            className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors"
            title="Edit"
          >
            <MdEdit size={16} />
          </button>
          <button
            onClick={() => setDeleteId(id)}
            className="p-1.5 hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-lg transition-colors"
            title="Delete"
          >
            <MdDelete size={16} />
          </button>
        </div>
      ),
    },
  ];

  const tabs = [
    { key: "all", label: "All", count: data.length },
    { key: "active", label: "Active", count: activeCount },
    { key: "inactive", label: "Inactive", count: inactiveCount },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Billing Rates</h1>
          <p className="text-sm text-slate-500 mt-1">
            Manage billing rates for job listings
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            icon={MdRefresh}
            onClick={load}
            loading={loading}
          >
            Refresh
          </Button>
          <Button icon={MdAdd} onClick={openAdd}>
            Add Billing Rate
          </Button>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_12px_rgba(0,0,0,0.06)] overflow-hidden">
        {/* Top bar: search + tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-5 border-b border-slate-100">
          <div className="relative w-full sm:w-72">
            <MdSearch
              size={18}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search billing rates..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-full border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-colors"
            />
          </div>

          <div className="flex items-center gap-5 text-sm">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusFilter(tab.key)}
                className={`flex items-center gap-1.5 font-medium transition-colors ${statusFilter === tab.key ? "text-blue-600" : "text-slate-500 hover:text-slate-700"}`}
              >
                {tab.label}
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-md font-semibold ${
                    statusFilter === tab.key
                      ? "bg-slate-800 text-white shadow-sm"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <Table
          columns={columns}
          data={paginatedData}
          loading={loading}
          emptyMessage="No billing rates found"
        />

        <Pagination
          page={page}
          total={filteredData.length}
          limit={limit}
          onChange={setPage}
          onLimitChange={(newLimit) => {
            setLimit(newLimit);
            setPage(1);
          }}
        />
      </div>

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        loading={deleteLoading}
        title="Delete Billing Rate"
        message="Delete this billing rate? This action cannot be undone."
      />
    </div>
  );
};

export default BillingRate;


