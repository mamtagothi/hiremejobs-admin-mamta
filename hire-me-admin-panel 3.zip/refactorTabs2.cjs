const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, 'src', 'pages');

const walkSync = (dir, filelist = []) => {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const dirFile = path.join(dir, file);
    if (fs.statSync(dirFile).isDirectory()) {
      filelist = walkSync(dirFile, filelist);
    } else if (dirFile.endsWith('.jsx')) {
      filelist.push(dirFile);
    }
  }
  return filelist;
};

const allFiles = walkSync(srcDir);
let changedCount = 0;

for (const file of allFiles) {
  let content = fs.readFileSync(file, 'utf-8');

  // Updated Regex to allow optional classes like flex-wrap after text-sm
  const tabContainerRegex = /<div className="flex items-center gap-[45]\s+text-sm[^>]*?">[\s\S]*?\{tabs\.map\([\s\S]*?(?:<\/button>|<\/div>)\s*\)\)\}\s*<\/div>\s*<\/div>/g;

  if (tabContainerRegex.test(content)) {
    console.log('Modifying inline tabs in:', file);
    changedCount++;

    // Add import if missing
    if (!content.includes('StatisticFilterCard')) {
      const lastImportIndex = content.lastIndexOf('import ');
      if (lastImportIndex !== -1) {
        const endOfLine = content.indexOf('\n', lastImportIndex);
        let prefix = content.slice(0, endOfLine + 1);
        let suffix = content.slice(endOfLine + 1);
        
        let normalizedFile = file.replace(/\\/g, '/');
        const relativePath = normalizedFile.split('src/pages/')[1];
        const depth = relativePath.split('/').length - 1;
        let prefixDots = '../'.repeat(depth + 1);
        
        content = prefix + `import StatisticFilterCard from "${prefixDots}components/common/StatisticFilterCard";\n` + suffix;
      }
    }

    content = content.replace(tabContainerRegex, () => {
        return `</div> {/* Closes the search flex wrapper early */}
        
        <div className="p-5 border-b border-gray-100 bg-gray-50/50 block w-full">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
            {tabs.map((tab) => (
              <StatisticFilterCard
                key={tab.key}
                label={tab.label}
                count={tab.count}
                isActive={statusFilter === tab.key}
                onClick={() => setStatusFilter(tab.key)}
              />
            ))}
          </div>
        </div>`;
      }
    );
      
    fs.writeFileSync(file, content);
  }
}

console.log('Total fallback tabs changed:', changedCount);
