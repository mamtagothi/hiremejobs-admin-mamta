const fs = require('fs');
const path = require('path');

const srcDir = path.join('d:', 'Coding_Cloud', 'hire-me-admin-panel', 'src', 'pages');

const walkSync = (dir, filelist = []) => {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const dirFile = path.join(dir, file);
    if (fs.statSync(dirFile).isDirectory()) {
      filelist = walkSync(dirFile, filelist);
    } else if (dirFile.endsWith('.jsx')) {
      filelist.push(dirFile);
    }
  }
  return filelist;
};

const allFiles = walkSync(srcDir);

let count = 0;
for (const file of allFiles) {
  let content = fs.readFileSync(file, 'utf-8');

  // Check if this file has the exact pattern we want to replace
  // The tab block. Let's use a regex.
  const regex = /<div className="flex items-center gap-[45]\s+text-sm">\s*\{tabs\.map\(\(tab\)\s*=>\s*\(\s*<button[\s\S]*?<\/button>\s*\)\)\}\s*<\/div>/;
  
  if (regex.test(content)) {
    console.log('Replacing in', file);

    // 1. add import if not exists
    if (!content.includes('StatisticFilterCard')) {
      // find last import
      const lastImportIndex = content.lastIndexOf('import ');
      if (lastImportIndex !== -1) {
        const endOfLine = content.indexOf('\n', lastImportIndex);
        content = content.slice(0, endOfLine + 1) + 
                  'import StatisticFilterCard from "../../components/common/StatisticFilterCard";\n' + 
                  content.slice(endOfLine + 1);
      }
    }

    // Replace the block
    const replacement = `</div>
        <div className="p-5 border-b border-gray-100 bg-gray-50/50">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {tabs.map((tab) => (
              <StatisticFilterCard
                key={tab.key}
                label={tab.label}
                count={tab.count}
                isActive={statusFilter === tab.key}
                onClick={() => setStatusFilter(tab.key)}
              />
            ))}
          </div>`;
    
    // Actually, the regex replaces the div that wraps tabs.map
    // But we also need to close the top bar div before opening the new grid and remove the flex-col div's flex properties where appropriate?
    // Wait, the top bar div has:
    // <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-4 border-b border-gray-100">
    // then search box
    // then tabs
    // </div>
    // If we replace the <div className="flex items-center gap-5 text-sm">...</div> with </div> (to close the top bar div) + grid + <div? No, it's safer to use string manipulation to find the exact tree.
  }
}
